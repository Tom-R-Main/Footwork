// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Cua AI, Inc.

//! The platform-adapter contract for the browser-tool surface.
//!
//! Core owns schemas, semantics, CDP handling, the target/ref store,
//! lifecycle cleanup, and correlation. Platform crates own everything
//! that requires OS identity: process fingerprints, native window
//! metadata, browser classification, loopback-endpoint ownership, and
//! explicit endpoint setup. This trait is the entire boundary — a
//! platform crate implements it without depending on core internals,
//! and core never reaches into a platform crate.

use async_trait::async_trait;
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use std::process::{Child, Command, ExitStatus};

use super::refusal::BrowserRefusal;
use super::types::{
    BrowserClassification, BrowserProduct, NativeWindowInfo, OwnedEndpoint, ProcessFingerprint,
};

/// Root process of a driver-owned isolated browser that core launched.
///
/// Core keeps this handle for the browser's lifetime to observe launcher
/// exit, reap the process tree, and remove the driver-owned profile. The
/// default implementation is [`std::process::Child`]. A platform that runs
/// the browser under a different token than the Driver supplies its own
/// handle so that filesystem work inside the browser-writable profile uses
/// the browser's authority rather than the Driver's.
pub trait IsolatedBrowserProcess: Send {
    fn id(&self) -> u32;
    fn try_wait(&mut self) -> std::io::Result<Option<ExitStatus>>;
    fn kill(&mut self) -> std::io::Result<()>;
    fn wait(&mut self) -> std::io::Result<ExitStatus>;

    /// Run `work` with the authority of the browser's token. The browser can
    /// write its profile directory, so a more privileged Driver must not
    /// follow browser-planted links there with its own rights. When the
    /// browser runs with the Driver's token, `work` runs directly. An error
    /// means `work` did not run; callers must then skip the file operation.
    fn with_browser_file_authority(&self, work: &mut dyn FnMut()) -> std::io::Result<()> {
        work();
        Ok(())
    }
}

impl IsolatedBrowserProcess for Child {
    fn id(&self) -> u32 {
        Child::id(self)
    }

    fn try_wait(&mut self) -> std::io::Result<Option<ExitStatus>> {
        Child::try_wait(self)
    }

    fn kill(&mut self) -> std::io::Result<()> {
        Child::kill(self)
    }

    fn wait(&mut self) -> std::io::Result<ExitStatus> {
        Child::wait(self)
    }
}

/// Select the first installed, non-redirected candidate and return its
/// canonical path. Native adapters must supply only trusted installation
/// locations in public product-preference order. Rejecting redirects prevents
/// a known browser path from becoming an arbitrary executable through a
/// symlink or junction controlled outside the trusted installation.
pub fn select_isolated_browser_executable(
    candidates: impl IntoIterator<Item = PathBuf>,
) -> Result<String, BrowserRefusal> {
    for candidate in candidates {
        if !candidate.is_file() {
            continue;
        }
        let canonical = std::fs::canonicalize(&candidate).map_err(|error| {
            BrowserRefusal::new(
                super::refusal::BrowserRefusalCode::BrowserRouteUnavailable,
                format!(
                    "could not canonicalize installed browser executable {}: {error}",
                    candidate.display()
                ),
            )
        })?;
        if !same_installation_path(&candidate, &canonical) {
            continue;
        }
        return Ok(canonical.to_string_lossy().into_owned());
    }
    Err(BrowserRefusal::new(
        super::refusal::BrowserRefusalCode::BrowserRouteUnavailable,
        "no supported installed Chromium executable is available for isolated launch",
    ))
}

fn same_installation_path(candidate: &std::path::Path, canonical: &std::path::Path) -> bool {
    #[cfg(windows)]
    {
        let normalize = |path: &std::path::Path| {
            let value = path.to_string_lossy();
            value
                .strip_prefix(r"\\?\")
                .unwrap_or(&value)
                .replace('/', "\\")
                .to_ascii_lowercase()
        };
        normalize(candidate) == normalize(canonical)
    }
    #[cfg(not(windows))]
    {
        candidate == canonical
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum PrepareProfileMode {
    IsolatedNew,
    IsolatedNamed,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PrepareProfile {
    pub mode: PrepareProfileMode,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub name: Option<String>,
}

/// Acting strategy for browser preparation that is not a driver-owned profile
/// lifecycle operation. Existing profiles remain owned by the user/browser.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum PrepareStrategy {
    ExistingProfile,
}

/// Caller context for an explicit `browser_prepare` call. Prepare is never
/// implicit: `get_browser_state` must not trigger it.
#[derive(Debug, Clone)]
pub struct PrepareRequest {
    /// Existing browser process used to select and attest the launch executable.
    /// Omitted only for a driver-owned isolated launch, where the platform
    /// resolves a supported installed Chromium executable instead.
    pub pid: Option<i64>,
    /// Exact native window used as the visible approval and ownership anchor
    /// for existing-profile attachment.
    pub window_id: Option<u64>,
    pub session: String,
    /// Private transport lifecycle owner. A daemon-backed MCP proxy supplies
    /// this independently from the public capability session so either proxy
    /// disconnect or explicit `end_session` can reap a spawned browser.
    pub transport_session: Option<String>,
    /// Omitted for the legacy isolated-profile compatibility form.
    pub strategy: Option<PrepareStrategy>,
    pub profile: Option<PrepareProfile>,
    /// Allows launching a separate driver-owned isolated browser process.
    /// It never authorizes terminating or modifying the requested process.
    pub allow_launch: bool,
    /// `delivery_mode:"foreground"`: the caller accepts that existing-profile
    /// attachment may bring the browser to the front. Without it, a platform
    /// that cannot attach in the background refuses with
    /// `background_unavailable` before any visible effect.
    pub foreground: bool,
}

/// What a platform adapter actually did (or found) during prepare.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum PrepareAction {
    /// An owned endpoint already existed; nothing was changed.
    AlreadyPrepared,
    /// The adapter enabled an endpoint on the running process.
    EnabledEndpoint,
    /// The adapter (re)launched the browser with an endpoint.
    RelaunchedBrowser,
    /// The driver launched a separate isolated browser process.
    LaunchedIsolatedBrowser,
    /// Attached to a user-owned, already-running profile under a live grant.
    AttachedExistingProfile,
    /// Nothing was done — see `message` on the outcome.
    NoOp,
}

/// Result of an explicit prepare. `endpoint` is present iff an owned
/// endpoint is now available.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PrepareOutcome {
    pub action: PrepareAction,
    pub endpoint: Option<OwnedEndpoint>,
    pub message: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub prepared_pid: Option<i64>,
    #[serde(default)]
    pub side_effects: PrepareSideEffects,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub attachment: Option<PrepareAttachment>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PrepareAttachment {
    pub kind: PrepareAttachmentKind,
    pub browser: String,
    pub capabilities_invalidated: bool,
    pub next_action: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum PrepareAttachmentKind {
    ExistingProfile,
}

#[derive(Debug, Clone, Default)]
pub struct BrowserConsentAction(std::sync::Arc<std::sync::atomic::AtomicBool>);

impl BrowserConsentAction {
    pub fn perform<T>(&self, action: impl FnOnce() -> T) -> T {
        self.0.store(true, std::sync::atomic::Ordering::Release);
        action()
    }

    pub(crate) fn started(&self) -> bool {
        self.0.load(std::sync::atomic::Ordering::Acquire)
    }
}

#[derive(Debug, Clone)]
pub struct BrowserConsentRequest {
    pub action: BrowserConsentAction,
    pub pid: i64,
    pub window_id: u64,
    pub attempt: u8,
}

/// Exact, already-approved browser/window scope for enabling an existing
/// Chromium profile's own DevTools endpoint. Core consumes the approval and
/// validates this native window before invoking the platform adapter.
#[derive(Debug, Clone)]
pub struct ExistingProfileSetupRequest {
    pub pid: i64,
    pub window_id: u64,
    /// Product identity attested immediately before approval-bound setup.
    pub browser: BrowserProduct,
}

/// Declared user-visible effects of one bounded existing-profile setup.
#[derive(Debug, Clone, Default, Serialize)]
pub struct ExistingProfileSetupOutcome {
    pub opened_setup_page: bool,
    pub closed_setup_page: bool,
    pub enabled_remote_debugging: bool,
    pub used_bounded_pixel_fallback: bool,
    pub focused_setup_address_field: bool,
    pub foregrounded_window: bool,
    pub injected_global_input: bool,
    /// Endpoint proven as part of an exact setup transition. This is needed
    /// for Chrome's in-browser toggle, whose listener does not expose the
    /// classic `/json/version` discovery surface.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub endpoint: Option<OwnedEndpoint>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BrowserConsentOutcome {
    /// One exact browser-owned consent action was semantically pressed.
    Accepted,
    /// The adapter proved no consent prompt was present in the approved scope.
    NotPresent,
}

/// Visual-only feedback for an already-authorized browser mutation.
///
/// This is deliberately separate from input delivery: platform adapters may
/// animate an agent cursor, but must never synthesize input, activate a
/// browser, or change whether the browser action succeeds.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BrowserVisualActionKind {
    Click,
    Type,
    Hover,
    RightClick,
    DoubleClick,
    Scroll,
    Drag,
}

#[derive(Debug, Clone)]
pub struct BrowserVisualAction {
    pub session: String,
    pub window_id: u64,
    /// Real CDP page target that owns this cursor. Platform adapters may use
    /// it to keep several session cursors associated with separate tabs.
    pub cdp_target_id: String,
    /// Live, non-activating page-visibility proof collected immediately
    /// before the action. False also covers an unavailable proof so visual
    /// feedback fails closed instead of appearing over the wrong tab.
    pub tab_is_active: bool,
    /// Screen coordinates in the platform-normalized device-independent
    /// space used by [`NativeWindowInfo::bounds`]. Child-frame or
    /// untrustworthy geometry intentionally produces no visual point while
    /// still allowing the platform to update active-tab visibility.
    pub screen_x: Option<f64>,
    pub screen_y: Option<f64>,
    pub kind: BrowserVisualActionKind,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct PrepareSideEffects {
    pub launched_browser: bool,
    pub restarted_browser: bool,
    pub created_profile: bool,
    pub reused_driver_profile: bool,
    pub copied_profile_data: bool,
    pub changed_preferences: bool,
    pub displayed_consent_prompt: bool,
    pub opened_setup_page: bool,
    pub closed_setup_page: bool,
    pub enabled_remote_debugging: bool,
    pub used_bounded_pixel_fallback: bool,
    pub focused_setup_address_field: bool,
    pub foregrounded_window: bool,
    pub injected_global_input: bool,
    /// A foreground attachment left the browser in front, and the app that
    /// was in front before the call was brought back.
    pub restored_frontmost_app: bool,
}

/// OS-identity services a platform crate provides to the browser-tool
/// core. All methods are point-in-time queries; core re-invokes them
/// for revalidation before every mutation rather than caching.
///
/// Error convention: methods return `Err(BrowserRefusal)` for
/// conditions the calling agent should see as a structured refusal
/// (including infrastructure failures, which map naturally onto
/// `browser_route_unavailable`).
#[async_trait]
pub trait BrowserPlatform: Send + Sync {
    /// Resolve a canonical installed Chromium-family executable for a
    /// driver-owned isolated launch that did not name an existing process.
    /// Native adapters use deterministic product priority and fail closed when
    /// no supported executable can be proven.
    fn isolated_browser_executable(&self) -> Result<String, BrowserRefusal> {
        Err(BrowserRefusal::new(
            super::refusal::BrowserRefusalCode::BrowserRouteUnavailable,
            "no supported installed Chromium executable is available for isolated launch",
        ))
    }

    /// Spawn the driver-owned isolated browser that core fully configured in
    /// `command` for the private profile at `profile`. The default launches
    /// it with the Driver's own token. A platform may instead launch it with
    /// a less privileged token; it must then keep every trust check made by
    /// [`Self::isolated_browser_executable`] valid for that token and refuse
    /// rather than fall back to the Driver's token.
    fn spawn_isolated_browser(
        &self,
        mut command: Command,
        _profile: &Path,
    ) -> Result<Box<dyn IsolatedBrowserProcess>, BrowserRefusal> {
        command
            .spawn()
            .map(|child| Box::new(child) as Box<dyn IsolatedBrowserProcess>)
            .map_err(|error| {
                BrowserRefusal::new(
                    super::refusal::BrowserRefusalCode::BrowserRouteUnavailable,
                    format!("could not launch an isolated browser process: {error}"),
                )
            })
    }

    /// Explain why a trusted CDP Input route cannot preserve background
    /// posture for a standalone browser on this platform. Embedded Chromium
    /// routes are independently proven and do not consult this capability.
    fn standalone_trusted_input_background_limitation(&self) -> Option<&'static str> {
        None
    }

    /// Explain why attaching to an existing browser profile cannot keep the
    /// browser in the background on this platform, for example because the
    /// browser brings itself to the front to show its own remote-debugging
    /// consent prompt. `None` (the default) means attachment needs no
    /// background check. When this returns `Some` and the browser is not the
    /// frontmost app, a background `browser_prepare` refuses with
    /// `background_unavailable` before discovery, setup or connection.
    fn existing_profile_attach_background_limitation(&self) -> Option<&'static str> {
        None
    }

    /// Guard a background existing-profile attachment that
    /// [`Self::existing_profile_attach_background_limitation`] would refuse,
    /// when the platform can keep it out of the user's way: while the returned
    /// value is alive, every self-activation of `browser_pid` is reverted
    /// within milliseconds. `None` (the default) keeps the refusal. macOS
    /// returns a guard only when `window_id` is on another Space than the
    /// user's active one, where the browser's consent window stays out of
    /// sight.
    fn guard_background_attach(
        &self,
        _browser_pid: i64,
        _window_id: u64,
    ) -> Option<Box<dyn std::any::Any + Send>> {
        None
    }

    /// Pid of the app the user has in front, when the platform can tell.
    fn frontmost_app_pid(&self) -> Option<i64> {
        None
    }

    /// After a foreground attachment, bring `previous_pid` back to the front
    /// if `browser_pid` is still in front. Returns true when it did so.
    /// Implementations must not act when another app took the front since.
    fn restore_frontmost_app(&self, _previous_pid: i64, _browser_pid: i64) -> bool {
        false
    }

    /// Best-effort, visual-only feedback for an authorized browser action.
    /// The default is a no-op so platforms without an agent-cursor overlay do
    /// not change behavior. Implementations must not deliver input or alter
    /// focus/z-order; failures are intentionally not part of browser results.
    async fn visualize_browser_action(&self, _action: BrowserVisualAction) {}

    /// Classify `pid`: is it a browser, which engine family, can it do
    /// CDP at all. Must not have side effects.
    async fn classify_browser(&self, pid: i64) -> Result<BrowserClassification, BrowserRefusal>;

    /// Resolve native metadata (title, normalized bounds, ownership
    /// proof) for one window of `pid`. Must fail — not guess — when the
    /// window does not exist or is not attributable to `pid`.
    async fn native_window(
        &self,
        pid: i64,
        window_id: u64,
    ) -> Result<NativeWindowInfo, BrowserRefusal>;

    /// Prove whether `window_id` is the only native top-level window owned by
    /// `pid`. `Some(true)` is an exact platform-attested cardinality proof;
    /// `Some(false)` means another window exists; `None` means this window
    /// system cannot prove cardinality. Used for embedded Chromium endpoints
    /// that omit Browser.getWindowForTarget and standalone browsers whose
    /// bounds were overridden by a tiling compositor.
    async fn is_only_exact_native_window(
        &self,
        pid: i64,
        window_id: u64,
    ) -> Result<Option<bool>, BrowserRefusal>;

    /// Discover a loopback DevTools endpoint owned by `pid`, with an
    /// explicit ownership proof. `Ok(None)` means "no endpoint right
    /// now" (core maps that to `browser_requires_setup`); it must NOT
    /// silently start one — setup belongs to [`Self::prepare_endpoint`].
    async fn discover_owned_endpoint(
        &self,
        pid: i64,
    ) -> Result<Option<OwnedEndpoint>, BrowserRefusal>;

    /// Attest the exact private-profile endpoint emitted by a browser process
    /// that core just spawned. The default keeps ordinary exact-pid ownership.
    /// Platforms with launcher-stub handoffs may override this narrowly; they
    /// must match `expected_ws_url` and retain the exact listener pid so core
    /// can promote the live runtime identity.
    async fn discover_spawned_endpoint(
        &self,
        pid: i64,
        expected_ws_url: &str,
    ) -> Result<Option<OwnedEndpoint>, BrowserRefusal> {
        Ok(self
            .discover_owned_endpoint(pid)
            .await?
            .filter(|endpoint| endpoint.ws_url == expected_ws_url))
    }

    /// Discover an endpoint while handling an explicitly approved
    /// existing-profile request. The default is the ordinary side-effect-free
    /// discovery path. Platforms may additionally return a uniquely proven
    /// browser-level route that does not expose HTTP discovery, but must not
    /// open its WebSocket or interact with consent UI here.
    async fn discover_existing_profile_endpoint(
        &self,
        pid: i64,
    ) -> Result<Option<OwnedEndpoint>, BrowserRefusal> {
        self.discover_owned_endpoint(pid).await
    }

    /// Re-prove an endpoint that was already claimed under an existing-profile
    /// grant. Unlike discovery, this receives the exact WebSocket URL captured
    /// during the approved setup and may therefore prove that specific route
    /// without treating an arbitrary PID-owned listener as DevTools.
    async fn reprove_existing_profile_endpoint(
        &self,
        pid: i64,
        _expected_ws_url: &str,
    ) -> Result<Option<OwnedEndpoint>, BrowserRefusal> {
        self.discover_existing_profile_endpoint(pid).await
    }

    /// Enable an existing Chromium profile's browser-owned DevTools endpoint
    /// after core has consumed exact interactive approval. Implementations may
    /// act only within `pid` and `window_id`, must fail on ambiguous UI, and
    /// must not restart the browser or modify profile files.
    async fn setup_existing_profile_endpoint(
        &self,
        _request: ExistingProfileSetupRequest,
    ) -> Result<ExistingProfileSetupOutcome, BrowserRefusal> {
        Err(BrowserRefusal::new(
            super::refusal::BrowserRefusalCode::BrowserRequiresSetup,
            "automatic existing-profile endpoint setup is not proven on this platform",
        ))
    }

    /// Commit a setup transition after core has protocol-proven and claimed
    /// the correlated browser endpoint. Implementations use this boundary to
    /// close only the exact temporary setup tab they opened.
    async fn commit_existing_profile_setup(
        &self,
        _request: ExistingProfileSetupRequest,
    ) -> Result<bool, BrowserRefusal> {
        Ok(false)
    }

    /// Restore a browser-owned remote-debugging setting that Cua enabled for
    /// an existing-profile grant. Core calls this only when the last grant for
    /// the process ends and only when setup recorded that Cua changed it.
    fn cleanup_existing_profile_setup(
        &self,
        _request: ExistingProfileSetupRequest,
    ) -> Result<bool, BrowserRefusal> {
        Ok(false)
    }

    /// Roll back a setup transition that core could not safely claim. The
    /// adapter must preserve `error`, adding exact cleanup evidence where
    /// useful, and must never act on an unproven current tab or control.
    async fn abort_existing_profile_setup(
        &self,
        _request: ExistingProfileSetupRequest,
        error: BrowserRefusal,
    ) -> BrowserRefusal {
        error
    }

    /// Handle one pending browser-owned connection prompt. Implementations
    /// must use exact native semantics and may perform at most one declared
    /// consent action for this request. Generic dialog automation is forbidden.
    async fn handle_existing_profile_consent(
        &self,
        _request: BrowserConsentRequest,
    ) -> Result<BrowserConsentOutcome, BrowserRefusal> {
        Err(BrowserRefusal::new(
            super::refusal::BrowserRefusalCode::BrowserRouteUnavailable,
            "prompt-assisted existing-profile attachment is not proven on this platform",
        ))
    }

    /// Current identity fingerprint for `pid`. Used to detect pid reuse
    /// between binding and mutation.
    async fn process_fingerprint(&self, pid: i64) -> Result<ProcessFingerprint, BrowserRefusal>;

    /// Explicitly prepare an owned endpoint for `pid`. Only ever called
    /// from the `browser_prepare` tool. Adapters gate disruptive or
    /// consent-requiring paths on the request's explicit fields and
    /// refuse with `browser_consent_required` otherwise.
    async fn prepare_endpoint(
        &self,
        request: PrepareRequest,
    ) -> Result<PrepareOutcome, BrowserRefusal>;
}

#[cfg(test)]
mod tests {
    #[test]
    fn consent_action_boundary_precedes_success_and_failure_and_never_resets() {
        for succeeds in [true, false] {
            let action = super::BrowserConsentAction::default();
            let observer = action.clone();
            assert!(!observer.started());
            let result = action.perform(|| {
                assert!(observer.started());
                if succeeds {
                    Ok(())
                } else {
                    Err("native action failed")
                }
            });
            assert_eq!(result.is_ok(), succeeds);
            assert!(observer.started());
            assert!(!super::BrowserConsentAction::default().started());
        }
    }

    use super::select_isolated_browser_executable;

    #[test]
    fn isolated_browser_selection_uses_first_installed_canonical_candidate() {
        let root = tempfile::tempdir().expect("temporary browser candidates");
        let canonical_root = std::fs::canonicalize(root.path()).expect("canonical temp root");
        let first = canonical_root.join("chrome");
        let second = canonical_root.join("chromium");
        std::fs::write(&first, b"first").expect("first candidate");
        std::fs::write(&second, b"second").expect("second candidate");

        let selected = select_isolated_browser_executable([
            canonical_root.join("missing"),
            first.clone(),
            second,
        ])
        .expect("select installed browser");

        assert_eq!(
            std::path::PathBuf::from(selected),
            std::fs::canonicalize(first).expect("canonical first candidate")
        );
    }

    #[cfg(unix)]
    #[test]
    fn isolated_browser_selection_rejects_symlinked_candidate() {
        use std::os::unix::fs::symlink;

        let root = tempfile::tempdir().expect("temporary browser candidates");
        let canonical_root = std::fs::canonicalize(root.path()).expect("canonical temp root");
        let arbitrary = canonical_root.join("arbitrary");
        let redirected = canonical_root.join("chrome");
        std::fs::write(&arbitrary, b"not a browser").expect("arbitrary executable fixture");
        symlink(&arbitrary, &redirected).expect("redirected browser fixture");

        let error = select_isolated_browser_executable([redirected])
            .expect_err("redirected browser path must fail closed");
        assert_eq!(
            error.code,
            super::super::refusal::BrowserRefusalCode::BrowserRouteUnavailable
        );
    }
}
