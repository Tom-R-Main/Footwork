//! Pure `tools/list` schema-shape assertions.
//!
//! These never invoke a tool — they only inspect the advertised schemas: that
//! every tool keeps its top-level schema provider-compatible, that every
//! advertised `enum` is string-only, that `type_text_chars` is hidden, the
//! `list_windows.on_screen_only` knob, the `set_agent_cursor_motion` Bezier
//! knobs, delivery and scope enums, and the `set_config.capture_mode` enum and
//! the per-session capture-scope contract. Every advertised top-level parameter
//! must carry a non-empty description: the generated Cua Driver MCP reference
//! renders it verbatim.

#![cfg(any(target_os = "linux", target_os = "macos", target_os = "windows"))]

use cua_driver_testkit::{Driver, McpDriver, RawDriver};
use std::collections::BTreeSet;

/// Gemini function calling accepts `enum` only on string schemas and rejects
/// the whole request otherwise, so one boolean or numeric enum in any
/// advertised schema breaks every call from that client (#4220).
fn assert_string_enums(value: &serde_json::Value, path: &str) {
    match value {
        serde_json::Value::Object(map) => {
            if let Some(values) = map.get("enum") {
                let values = values
                    .as_array()
                    .unwrap_or_else(|| panic!("{path}.enum must be an array: {values}"));
                for (index, item) in values.iter().enumerate() {
                    assert!(
                        item.is_string(),
                        "{path}.enum[{index}] must be a string for Gemini-compatible clients: {item}"
                    );
                }
            }
            for (key, child) in map {
                assert_string_enums(child, &format!("{path}.{key}"));
            }
        }
        serde_json::Value::Array(items) => {
            for (index, item) in items.iter().enumerate() {
                assert_string_enums(item, &format!("{path}[{index}]"));
            }
        }
        _ => {}
    }
}

#[test]
fn tools_list_schema_shape() {
    //! `type_text_chars` is an accepted-but-deprecated invoke alias that stays
    //! HIDDEN from tools/list on every platform (the live Windows roster carries
    //! no `type_text_chars` either — the old Windows mirror asserted it was
    //! exposed, but that had never been run). The advertised schemas must still
    //! carry their expected knobs.
    assert_tools_list_schema_shape(
        RawDriver::spawn().expect("spawn source-built driver for schema test"),
    );
}

#[cfg(target_os = "linux")]
#[test]
fn explicit_direct_tools_list_schema_shape() {
    // Supported direct stdio transport. This does not replace the daemon gate.
    assert_tools_list_schema_shape(
        RawDriver::spawn_explicit_direct().expect("spawn source-built direct MCP driver"),
    );
}

fn assert_tools_list_schema_shape(mut d: RawDriver) {
    d.send(&serde_json::json!({"jsonrpc":"2.0","id":1,"method":"initialize","params":{}}));
    d.recv();

    d.send(&serde_json::json!({"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}));
    let list_resp = d.recv();
    let tools = list_resp["result"]["tools"]
        .as_array()
        .expect("tools array");
    assert!(!tools.is_empty(), "tools/list must not be empty");
    assert!(
        list_resp["result"]["nextCursor"].is_null(),
        "unread tool page"
    );
    let names: BTreeSet<&str> = tools
        .iter()
        .map(|tool| tool["name"].as_str().unwrap())
        .collect();
    assert_eq!(names.len(), tools.len(), "duplicate tool name");
    assert!(
        names.contains("run_steps"),
        "runtime-only batch tool missing"
    );
    let platform = if cfg!(target_os = "macos") {
        cua_driver_contract::Platform::Macos
    } else if cfg!(target_os = "windows") {
        cua_driver_contract::Platform::Windows
    } else {
        cua_driver_contract::Platform::Linux
    };
    for tool in cua_driver_contract::manifest().tools {
        if tool.platforms.contains(&platform) {
            assert!(
                names.contains(tool.name.as_str()),
                "missing portable tool {}",
                tool.name
            );
        }
    }
    eprintln!("linted {} live tool input schemas", tools.len());

    let properties = |name: &str| {
        &tools
            .iter()
            .find(|tool| tool["name"] == name)
            .unwrap_or_else(|| panic!("{name} not found in tools/list"))["inputSchema"]
            ["properties"]
    };
    let mut undocumented = Vec::new();
    for tool in tools {
        let name = tool["name"].as_str().expect("tool name");
        let schema = &tool["inputSchema"];
        assert_eq!(
            schema["type"], "object",
            "{name} must advertise a plain object input schema"
        );
        if let Some(params) = schema["properties"].as_object() {
            for (param, param_schema) in params {
                let described = param_schema["description"]
                    .as_str()
                    .is_some_and(|text| !text.trim().is_empty());
                if !described {
                    undocumented.push(format!("{name}.{param}"));
                }
            }
        }
        for unsupported in ["anyOf", "oneOf", "allOf"] {
            assert!(
                schema.get(unsupported).is_none(),
                "{name} top-level {unsupported} is rejected by Bedrock: {schema}"
            );
        }
        assert_string_enums(&tool["outputSchema"], &format!("{name}.outputSchema"));
        let violations = cua_driver_testkit::vertex::input_schema_violations(schema);
        assert!(
            violations.is_empty(),
            "{name} inputSchema is outside the Vertex AI Schema object (#4798):\n{}",
            violations.join("\n")
        );
    }
    assert!(
        undocumented.is_empty(),
        "advertised parameters without a description (add one at the tool's schema source): {}",
        undocumented.join(", ")
    );
    let enum_contains = |schema: &serde_json::Value, expected: &str| {
        schema["enum"]
            .as_array()
            .map(|values| values.iter().any(|value| value.as_str() == Some(expected)))
            .unwrap_or(false)
    };

    // Deprecated alias is hidden from tools/list (accepted at invoke time only).
    assert!(
        tools.iter().all(|t| t["name"] != "type_text_chars"),
        "type_text_chars should be hidden from tools/list"
    );

    // Browser v1 is a cross-platform source-owned surface. Keep its full
    // roster, capability inputs, and read-only boundary pinned at the spawned
    // driver layer so platform registration drift cannot pass core-only tests.
    for name in [
        "get_browser_state",
        "browser_prepare",
        "browser_navigate",
        "browser_click",
        "browser_type",
    ] {
        assert!(
            tools.iter().any(|tool| tool["name"] == name),
            "browser tool {name} missing from tools/list"
        );
    }
    let browser_state = tools
        .iter()
        .find(|tool| tool["name"] == "get_browser_state")
        .expect("get_browser_state not found in tools/list");
    assert_eq!(
        browser_state["annotations"]["readOnlyHint"], true,
        "get_browser_state must remain side-effect free"
    );
    for field in ["pid", "window_id", "target_id", "tab_id", "session"] {
        assert!(
            browser_state["inputSchema"]["properties"][field].is_object(),
            "get_browser_state schema missing {field}"
        );
    }
    assert_eq!(
        browser_state["inputSchema"]["properties"]["include_screenshot"]["default"], false,
        "get_browser_state should advertise opt-in exact-tab capture"
    );
    for (name, required) in [
        ("browser_prepare", &[][..]),
        ("browser_navigate", &["target_id", "tab_id", "url"][..]),
        ("browser_click", &["target_id", "tab_id"][..]),
        ("browser_type", &["target_id", "tab_id", "ref", "text"][..]),
    ] {
        let tool = tools
            .iter()
            .find(|tool| tool["name"] == name)
            .unwrap_or_else(|| panic!("{name} not found in tools/list"));
        assert_eq!(
            tool["annotations"]["readOnlyHint"], false,
            "{name} must remain a mutation"
        );
        assert!(
            tool["inputSchema"]["properties"]["session"].is_object(),
            "{name} schema must expose the public session field"
        );
        let advertised = tool["inputSchema"]["required"]
            .as_array()
            .unwrap_or_else(|| panic!("{name} required fields missing"));
        for field in required {
            assert!(
                advertised.iter().any(|value| value.as_str() == Some(field)),
                "{name} schema missing required field {field}: {advertised:?}"
            );
        }
    }
    const DELIVERY_MODE_TOOLS: &[&str] = &[
        "click",
        "double_click",
        "right_click",
        "drag",
        "type_text",
        "press_key",
        "hotkey",
        "scroll",
        "browser_dialog",
        // Trusted browser input may activate the browser window (Linux
        // Chromium); foreground accepts that.
        "browser_click",
        "browser_pointer",
        // Existing-profile attachment that would bring the browser forward
        // (macOS Chrome); foreground accepts that.
        "browser_prepare",
        // The batch's default for its steps' own delivery_mode.
        "run_steps",
        // macOS desktop move_cursor refuses over a background app unless
        // foreground is requested.
        #[cfg(target_os = "macos")]
        "move_cursor",
        // macOS set_value has no delivery ladder.
        #[cfg(any(target_os = "linux", target_os = "windows"))]
        "set_value",
    ];
    for tool in DELIVERY_MODE_TOOLS {
        let delivery = &properties(tool)["delivery_mode"];
        assert!(
            enum_contains(delivery, "background") && enum_contains(delivery, "foreground"),
            "{tool}.delivery_mode should advertise background and foreground: {delivery:?}"
        );
    }
    for tool in ["browser_click", "browser_pointer"] {
        let tool = tools
            .iter()
            .find(|candidate| candidate["name"] == tool)
            .unwrap_or_else(|| panic!("{tool} not found in tools/list"));
        let description = tool["inputSchema"]["properties"]["delivery_mode"]["description"]
            .as_str()
            .unwrap_or_else(|| panic!("{tool}.delivery_mode description missing"));
        assert!(
            description.contains("including Linux Chromium and macOS Chromium configurations"),
            "{tool}.delivery_mode should name macOS and Linux: {description}"
        );
    }
    let browser_click = tools
        .iter()
        .find(|tool| tool["name"] == "browser_click")
        .expect("browser_click not found in tools/list");
    assert!(
        browser_click["description"].as_str().is_some_and(
            |description| description.contains("including Linux Chromium configurations")
        ),
        "browser_click description should name Linux: {}",
        browser_click["description"]
    );
    let schema_tools: BTreeSet<&str> = tools
        .iter()
        .filter(|tool| tool["inputSchema"]["properties"]["delivery_mode"].is_object())
        .filter_map(|tool| tool["name"].as_str())
        .collect();
    let expected_tools: BTreeSet<&str> = DELIVERY_MODE_TOOLS.iter().copied().collect();
    // The matching `input.delivery_mode` capability claim is owned by
    // `schema_consistency_test::registered_tool_contracts_match_on_active_backend`.
    assert_eq!(
        schema_tools, expected_tools,
        "unexpected delivery_mode schema set"
    );
    // Session capture scope remains advertised only for compatibility. New
    // clients choose one typed window or desktop target on each action.
    let capture_scope = &properties("start_session")["capture_scope"];
    for expected in ["auto", "window", "desktop"] {
        assert!(
            enum_contains(capture_scope, expected),
            "start_session.capture_scope should advertise {expected}: {capture_scope:?}"
        );
    }
    assert!(
        tools.iter().any(|tool| tool["name"] == "escalate_session"),
        "escalate_session missing from tools/list"
    );
    assert!(
        tools.iter().any(|tool| tool["name"] == "get_session_state"),
        "get_session_state missing from tools/list"
    );
    assert!(
        properties("set_config")["capture_scope"].is_null(),
        "persistent set_config.capture_scope must remain retired"
    );
    for action in [
        "click",
        "type_text",
        "press_key",
        "hotkey",
        "scroll",
        "drag",
        "move_cursor",
    ] {
        let scope = &properties(action)["scope"];
        assert!(
            enum_contains(scope, "window") && enum_contains(scope, "desktop"),
            "{action}.scope should advertise window and desktop: {scope:?}"
        );
    }

    // list_windows schema has on_screen_only.
    let lw = tools
        .iter()
        .find(|t| t["name"] == "list_windows")
        .expect("list_windows not found in tools/list");
    assert!(
        lw["inputSchema"]["properties"]["on_screen_only"].is_object(),
        "list_windows schema missing on_screen_only: {:?}",
        lw["inputSchema"]["properties"]
    );

    // set_agent_cursor_motion has the Bezier motion knobs.
    let sacm = tools
        .iter()
        .find(|t| t["name"] == "set_agent_cursor_motion")
        .expect("set_agent_cursor_motion not found in tools/list");
    let sacm_props = &sacm["inputSchema"]["properties"];
    for knob in &[
        "arc_size",
        "spring",
        "glide_duration_ms",
        "dwell_after_click_ms",
        "idle_hide_ms",
    ] {
        assert!(
            sacm_props[knob].is_object(),
            "set_agent_cursor_motion schema missing {knob}: {sacm_props:?}"
        );
    }

    // capture_mode enum restriction. On macOS, capture_mode is a per-call param
    // on get_window_state (removed from set_config — behavior knobs are per-call
    // now, not settings). On Windows it is still also a set_config field.
    #[cfg(target_os = "macos")]
    {
        let gws = tools
            .iter()
            .find(|t| t["name"] == "get_window_state")
            .expect("get_window_state not found in tools/list");
        assert!(
            gws["inputSchema"]["properties"]["capture_mode"]["enum"].is_array(),
            "get_window_state capture_mode should have enum: {:?}",
            gws["inputSchema"]["properties"]
        );
    }
    #[cfg(target_os = "windows")]
    {
        let sc = tools
            .iter()
            .find(|t| t["name"] == "set_config")
            .expect("set_config not found in tools/list");
        assert!(
            sc["inputSchema"]["properties"]["capture_mode"]["enum"].is_array(),
            "set_config capture_mode should have enum: {:?}",
            sc["inputSchema"]["properties"]
        );
    }
}

#[test]
fn legacy_page_mutation_requires_unrestricted_launch_and_operator_opt_in() {
    let args = serde_json::json!({
        "action": "enable_javascript_apple_events",
        "user_has_confirmed_enabling": false
    });

    {
        let mut driver = McpDriver::spawn().expect("spawn default source-built driver");
        let response = driver.call("page", args.clone());
        assert!(response.is_error(), "mutation must refuse by default");
        assert!(
            response.text().contains("requires unrestricted mode"),
            "default refusal must name the trusted launch gate: {}",
            response.text()
        );
    }

    let mut driver = McpDriver::spawn_with_env(&[
        ("CUA_DRIVER_PERMISSION_MODE", "unrestricted"),
        ("CUA_DRIVER_DANGEROUSLY_BYPASS_APPROVALS", "1"),
        ("CUA_DRIVER_ENABLE_LEGACY_PAGE_MUTATIONS", "1"),
    ])
    .expect("spawn source-built driver with unrestricted legacy compatibility enabled");
    let response = driver.call("page", args);
    assert!(
        response.is_error(),
        "unconfirmed mutation must still refuse"
    );
    assert!(
        response
            .text()
            .contains("Set user_has_confirmed_enabling=true"),
        "enabled daemon should reach the explicit confirmation gate: {}",
        response.text()
    );
    assert!(
        !response.text().contains("disabled by default"),
        "the daemon did not observe its startup environment: {}",
        response.text()
    );
}

#[test]
#[cfg(any(target_os = "linux", target_os = "macos"))]
#[cfg_attr(
    target_os = "macos",
    ignore = "host desktop: macOS serves the knobs only with the overlay window on the real display; Linux runs it unignored"
)]
fn cursor_motion_knobs_are_applied() {
    // macOS serves cursor-overlay controls only when the daemon hosts the
    // overlay; Linux applies the knobs without one.
    #[cfg(target_os = "macos")]
    let driver = RawDriver::spawn_with_overlay();
    #[cfg(not(target_os = "macos"))]
    let driver = RawDriver::spawn();
    let mut driver = driver.expect("spawn source-built driver");
    driver.send(&serde_json::json!({
        "jsonrpc": "2.0",
        "id": 1,
        "method": "initialize",
        "params": {}
    }));
    driver.recv();

    driver.send(&serde_json::json!({
        "jsonrpc": "2.0",
        "id": 2,
        "method": "tools/call",
        "params": {
            "name": "set_agent_cursor_motion",
            "arguments": {
                "session": "schema-motion",
                "arc_size": 0.4,
                "spring": 0.85,
                "glide_duration_ms": 500,
                "dwell_after_click_ms": 200,
                "idle_hide_ms": 5000
            }
        }
    }));
    let response = driver.recv();
    assert!(
        !response["result"]["isError"].as_bool().unwrap_or(false),
        "cursor motion update failed: {response:?}"
    );
    let structured = &response["result"]["structuredContent"];
    assert_eq!(structured["session"].as_str(), Some("schema-motion"));
    assert_eq!(structured["motion"]["arc_size"].as_f64(), Some(0.4));
    assert_eq!(
        structured["motion"]["glide_duration_ms"].as_f64(),
        Some(500.0)
    );
    assert_eq!(structured["motion"]["idle_hide_ms"].as_f64(), Some(5000.0));
}
