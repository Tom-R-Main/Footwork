// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Cua AI, Inc.

//! Trusted KWin window identity adapter.
//!
//! The optional in-process KWin effect exposes stable window tokens, process
//! identity, geometry, active/minimized state, and stacking metadata through a
//! deliberately read-only D-Bus surface. It does not expose activation or input
//! mutation methods. KWin's portal/libei input path is still focus-bound: libei
//! delivers to whichever surface is focused when KWin processes the event.
//!
//! A focus check followed by global input therefore has an unavoidable TOCTOU
//! race. Until Cua has a KWin input API that binds each mutation to the target
//! token/window, [`available`] reports no target-bound input and the shared
//! delivery policy refuses raw target-addressed input. Window discovery
//! remains available; input authorization does not.

use std::collections::HashSet;
use std::os::unix::fs::{MetadataExt, PermissionsExt};
use std::process::Command;
use std::time::Duration;

use crate::x11::WindowInfo;

const DEST: &str = "org.cua.KWinTarget";
const KWIN_DEST: &str = "org.kde.KWin";
const PATH: &str = "/org/cua/KWinTarget";
const IFACE: &str = "org.cua.KWinTarget";
const DBUS_DEST: &str = "org.freedesktop.DBus";
const DBUS_PATH: &str = "/org/freedesktop/DBus";
const DBUS_IFACE: &str = "org.freedesktop.DBus";
pub const PROTOCOL_VERSION: u32 = 1;
const CALL_TIMEOUT: Duration = Duration::from_secs(3);

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct KwinWindow {
    pub token: u64,
    pub pid: u32,
    pub title: String,
    pub app_name: String,
    pub x: i32,
    pub y: i32,
    pub width: u32,
    pub height: u32,
    pub active: bool,
    pub minimized: bool,
    pub stacking: usize,
}

/// Whether KWin currently offers a target-bound raw-input capability that can
/// safely authorize portal/libei foreground mutations.
///
/// This is intentionally distinct from helper presence: the read-only helper
/// may be installed and usable for discovery while target-bound raw input is
/// unavailable. Keep this false until the input operation itself is bound to
/// the KWin target token/window.
pub fn available() -> bool {
    false
}

/// The index of the keyboard layout KWin has active, or `None` when this isn't
/// KWin or it doesn't answer. KWin before 6.8 doesn't tell libei clients.
pub fn active_layout() -> Option<u32> {
    let reply = gdbus_call_to(
        "org.kde.keyboard",
        "/Layouts",
        "org.kde.KeyboardLayouts.getLayout",
        &[],
    )?;
    parse_first_u32(&reply)
}

pub fn list_windows() -> Option<Vec<KwinWindow>> {
    snapshot_for_owner(&helper_owner()?)
}

pub fn list_window_infos() -> Option<Vec<WindowInfo>> {
    Some(
        list_windows()?
            .into_iter()
            .map(|window| WindowInfo {
                xid: window.token,
                pid: Some(window.pid),
                app_name: window.app_name,
                title: window.title,
                is_on_screen: !window.minimized && window.width > 0 && window.height > 0,
                z_index: Some(window.stacking),
                x: window.x,
                y: window.y,
                width: window.width,
                height: window.height,
            })
            .collect(),
    )
}

pub fn trusted_window_for_id(pid: u32, token: u64) -> Option<KwinWindow> {
    snapshot_for_owner(&helper_owner()?)?
        .into_iter()
        .find(|window| window.pid == pid && window.token == token)
}

fn helper_owner() -> Option<String> {
    let owner_raw = dbus_call("GetNameOwner", &[DEST.to_owned()]);
    let owner = parse_quoted_string(&owner_raw?)?;
    if !owner.starts_with(':') {
        return None;
    }

    let pid_raw = gdbus_call_to(
        DBUS_DEST,
        DBUS_PATH,
        &format!("{DBUS_IFACE}.GetConnectionUnixProcessID"),
        std::slice::from_ref(&owner),
    );
    let uid_raw = gdbus_call_to(
        DBUS_DEST,
        DBUS_PATH,
        &format!("{DBUS_IFACE}.GetConnectionUnixUser"),
        std::slice::from_ref(&owner),
    );
    let pid = parse_first_u32(&pid_raw?)?;
    let uid = parse_first_u32(&uid_raw?)?;
    if uid != current_uid() || !is_trusted_kwin(pid, &owner) {
        return None;
    }

    let version_raw = call_to(&owner, "GetVersion", &[]);
    let version = parse_first_u32(&version_raw?)?;
    (version == PROTOCOL_VERSION).then_some(owner)
}

fn snapshot_for_owner(owner: &str) -> Option<Vec<KwinWindow>> {
    // Keep this synchronous API safe to call from either sync or async driver
    // code by running the zbus/Tokio client on its own OS thread. In
    // particular, do not use zbus's blocking wrapper directly from a Tokio
    // task: that would create an async-sandwich nested-runtime hazard.
    let owner = owner.to_owned();
    std::thread::spawn(move || {
        let runtime = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .ok()?;

        runtime.block_on(async move {
            let connection = tokio::time::timeout(CALL_TIMEOUT, zbus::Connection::session())
                .await
                .ok()?
                .ok()?;
            let proxy = tokio::time::timeout(
                CALL_TIMEOUT,
                zbus::Proxy::new(&connection, owner.as_str(), PATH, IFACE),
            )
            .await
            .ok()?
            .ok()?;

            for attempt in 0..3 {
                let raw = tokio::time::timeout(
                    CALL_TIMEOUT,
                    proxy.call::<_, _, String>("GetWindows", &()),
                )
                .await
                .ok()
                .and_then(Result::ok);
                if let Some(snapshot) = raw.as_deref().and_then(parse_snapshot) {
                    return Some(snapshot);
                }
                if attempt < 2 {
                    tokio::time::sleep(Duration::from_millis(50)).await;
                }
            }
            None
        })
    })
    .join()
    .ok()
    .flatten()
}

pub fn parse_snapshot(raw: &str) -> Option<Vec<KwinWindow>> {
    // `raw` is the actual QString payload decoded by zbus, not gdbus's
    // human-readable GVariant rendering. Parsing the display representation is
    // unsafe because GLib may change its quoting/escaping for valid titles.
    let values: Vec<serde_json::Value> = serde_json::from_str(raw).ok()?;

    let mut tokens = HashSet::new();
    let mut active_count = 0usize;
    values
        .into_iter()
        .map(|value| {
            let token = value
                .get("token")
                .and_then(serde_json::Value::as_u64)
                .filter(|token| *token > 0)?;
            if !tokens.insert(token) {
                return None;
            }

            let active = value.get("active")?.as_bool()?;
            if active {
                active_count += 1;
                if active_count > 1 {
                    return None;
                }
            }

            Some(KwinWindow {
                token,
                pid: u32::try_from(value.get("pid")?.as_u64()?).ok()?,
                title: value
                    .get("title")
                    .and_then(serde_json::Value::as_str)
                    .unwrap_or_default()
                    .to_owned(),
                app_name: value
                    .get("app_id")
                    .and_then(serde_json::Value::as_str)
                    .unwrap_or_default()
                    .to_owned(),
                x: json_i32(&value, "x")?,
                y: json_i32(&value, "y")?,
                width: json_u32(&value, "w")?,
                height: json_u32(&value, "h")?,
                active,
                minimized: value.get("minimized")?.as_bool()?,
                stacking: usize::try_from(value.get("stacking")?.as_u64()?).ok()?,
            })
        })
        .collect()
}

fn json_i32(value: &serde_json::Value, key: &str) -> Option<i32> {
    let number = value.get(key)?.as_f64()?;
    (number.is_finite() && number >= i32::MIN as f64 && number <= i32::MAX as f64)
        .then(|| number.round() as i32)
}

fn json_u32(value: &serde_json::Value, key: &str) -> Option<u32> {
    let number = value.get(key)?.as_f64()?;
    (number.is_finite() && number >= 0.0 && number <= u32::MAX as f64)
        .then(|| number.round() as u32)
}

/// KWin's own support report, which names its version. No permission needed.
pub(crate) fn support_information() -> Option<String> {
    gdbus_call_to(KWIN_DEST, "/KWin", "org.kde.KWin.supportInformation", &[])
}

fn dbus_call(method: &str, args: &[String]) -> Option<String> {
    gdbus_call_to(
        DBUS_DEST,
        DBUS_PATH,
        &format!("{DBUS_IFACE}.{method}"),
        args,
    )
}

fn call_to(owner: &str, method: &str, args: &[String]) -> Option<String> {
    gdbus_call_to(owner, PATH, &format!("{IFACE}.{method}"), args)
}

fn gdbus_call_to(
    destination: &str,
    object_path: &str,
    method: &str,
    args: &[String],
) -> Option<String> {
    let mut command = Command::new("gdbus");
    command
        .arg("call")
        .arg("--session")
        .arg("--dest")
        .arg(destination)
        .arg("--object-path")
        .arg(object_path)
        .arg("--method")
        .arg(method)
        .args(args)
        .stdin(std::process::Stdio::null())
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::null());
    let child = command.spawn().ok()?;
    wait_timeout(child, CALL_TIMEOUT)
}

fn wait_timeout(mut child: std::process::Child, timeout: Duration) -> Option<String> {
    use std::io::Read;

    let mut stdout = child.stdout.take()?;
    let reader = std::thread::spawn(move || {
        let mut bytes = Vec::new();
        stdout.read_to_end(&mut bytes).ok()?;
        String::from_utf8(bytes).ok()
    });
    let deadline = crate::interaction::operation_deadline(timeout);
    loop {
        match child.try_wait() {
            Ok(Some(status)) if status.success() => return reader.join().ok().flatten(),
            Ok(Some(_)) | Err(_) => return None,
            Ok(None) if std::time::Instant::now() >= deadline => {
                let _ = child.kill();
                let _ = child.wait();
                let _ = reader.join();
                return None;
            }
            Ok(None) => crate::interaction::pause(Duration::from_millis(10)),
        }
    }
}

fn parse_quoted_string(raw: &str) -> Option<String> {
    let start = raw.find('\'')? + 1;
    let end = raw[start..].find('\'')? + start;
    (end > start).then(|| raw[start..end].to_owned())
}

fn parse_first_u32(raw: &str) -> Option<u32> {
    let payload = raw.split_once("uint32").map_or(raw, |(_, payload)| payload);
    payload
        .split(|character: char| !character.is_ascii_digit())
        .find(|part| !part.is_empty())?
        .parse()
        .ok()
}

pub(super) fn current_uid() -> u32 {
    std::fs::metadata(format!("/proc/{}", std::process::id()))
        .map(|meta| meta.uid())
        .unwrap_or(u32::MAX)
}

fn is_trusted_kwin(pid: u32, helper_owner: &str) -> bool {
    let Some(owner_raw) = dbus_call("GetNameOwner", &[KWIN_DEST.to_owned()]) else {
        return false;
    };
    parse_quoted_string(&owner_raw).as_deref() == Some(helper_owner) && is_trusted_kwin_process(pid)
}

pub(super) fn is_trusted_kwin_process(pid: u32) -> bool {
    let comm = std::fs::read_to_string(format!("/proc/{pid}/comm")).ok();
    if !matches!(
        comm.as_deref().map(str::trim),
        Some("kwin_wayland" | ".kwin_wayland-w")
    ) {
        return false;
    }

    let executable = std::fs::read_link(format!("/proc/{pid}/exe")).ok();
    match executable {
        Some(path) => {
            let metadata = std::fs::metadata(&path).ok();
            matches!(
                path.file_name().and_then(|name| name.to_str()),
                Some("kwin_wayland" | ".kwin_wayland-wrapped")
            ) && metadata
                .is_some_and(|meta| meta.uid() == 0 && meta.permissions().mode() & 0o022 == 0)
        }
        None => true,
    }
}
