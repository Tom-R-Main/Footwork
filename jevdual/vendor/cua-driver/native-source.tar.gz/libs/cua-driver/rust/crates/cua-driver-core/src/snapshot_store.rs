// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Cua AI, Inc.

use crate::element_token::{
    current_snapshots_json, current_snapshots_phrase, format_snapshot_id, parse_token, refusal,
    token_for, CurrentSnapshot, ResolvedElement, TokenOwner, LRU_CAP_PER_PID, STALE_TOKEN_ERROR,
};
use crate::protocol::ToolResult;
use std::any::Any;
use std::collections::{HashMap, VecDeque};
use std::sync::{Arc, Mutex, OnceLock, Weak};

/// Reserved dispatch argument marking window-relative pixels as native
/// window pixels. Dispatch strips every caller-supplied underscore argument,
/// so only [`crate::tool::ToolRegistry::invoke_with_native_window_pixels`]
/// (an in-process Rust API) can set it.
pub const NATIVE_WINDOW_PIXELS_ARG: &str = "_native_window_pixels";

pub trait SnapshotPayload: Send + Sync + 'static {
    type Element;
    fn len(&self) -> usize;
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
    fn retain(&self, index: usize) -> Option<Self::Element>;
}

struct Snapshot<S> {
    id: u32,
    window_id: u64,
    screenshot_owner: Option<String>,
    screenshot_scale: Option<f64>,
    /// Window size in points when the screenshot was taken. A tree-only read
    /// keeps the screenshot frame only while the window still has this size.
    screenshot_window_size: Option<(f64, f64)>,
    zoom: Option<ZoomContext>,
    semantic: bool,
    payload: S,
}

impl<S> Snapshot<S> {
    fn screenshot(&self, session: Option<&str>) -> Option<ScreenshotContext> {
        let scale = self
            .screenshot_scale
            .filter(|_| self.screenshot_owner.as_deref() == session)?;
        Some(ScreenshotContext {
            snapshot_id: self.id,
            window_id: self.window_id,
            scale,
        })
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ScreenshotContext {
    pub snapshot_id: u32,
    pub window_id: u64,
    pub scale: f64,
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ZoomContext {
    pub screenshot: ScreenshotContext,
    pub origin_x: f64,
    pub origin_y: f64,
    pub scale_inv: f64,
}

impl ZoomContext {
    pub fn zoom_to_window(&self, x: f64, y: f64) -> (f64, f64) {
        (
            self.origin_x + x * self.scale_inv,
            self.origin_y + y * self.scale_inv,
        )
    }
}

/// Why a pixel action found no screenshot frame for its window.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum MissingFrame {
    /// This pid has no snapshot of the window at all in this runtime.
    WindowNeverRead,
    /// The window's current snapshot carries no screenshot frame: the last
    /// read skipped the screenshot after the window changed size, or no
    /// screenshot was ever taken of it.
    NoScreenshot,
    /// The current screenshot frame belongs to another session.
    OtherSession,
    /// No window was named and the process's snapshots disagree.
    Ambiguous,
}

impl MissingFrame {
    fn as_str(self) -> &'static str {
        match self {
            Self::WindowNeverRead => "window_never_read",
            Self::NoScreenshot => "no_screenshot",
            Self::OtherSession => "other_session",
            Self::Ambiguous => "ambiguous_window",
        }
    }
}

fn screenshot_context_refusal(
    pid: Option<i32>,
    window_id: Option<u64>,
    why: MissingFrame,
) -> ToolResult {
    let read = match (pid, window_id) {
        (Some(pid), Some(window_id)) => {
            format!("get_window_state(pid:{pid}, window_id:{window_id})")
        }
        (None, Some(window_id)) => format!("get_window_state(pid, window_id:{window_id})"),
        _ => "get_window_state(pid, window_id)".to_owned(),
    };
    let window = window_id.map_or_else(|| "this window".to_owned(), |id| format!("window {id}"));
    let message = match why {
        MissingFrame::WindowNeverRead => format!(
            "No screenshot of {window} in this session: it has not been read yet. Call {read} \
             and take x,y from that window's own screenshot; pixels read off another window's \
             screenshot do not apply to it."
        ),
        MissingFrame::NoScreenshot => format!(
            "No screenshot frame for {window}: its latest read had no screenshot and the window \
             changed size since the last one (or it was never captured). Call {read} with the \
             default screenshot and take x,y from that image."
        ),
        MissingFrame::OtherSession => format!(
            "The current screenshot of {window} belongs to another session. Call {read} on \
             this connection before using pixels."
        ),
        MissingFrame::Ambiguous => format!(
            "Pass window_id: this process has several windows without one shared screenshot \
             frame. Then call {read} if that window has no screenshot yet."
        ),
    };
    ToolResult::error(message).with_structured(serde_json::json!({
        "code": "screenshot_context_missing",
        "reason": why.as_str(),
        "pid": pid,
        "window_id": window_id,
    }))
}

fn stale_token_refusal(pid: i32, current: &[CurrentSnapshot]) -> ToolResult {
    let message = if current.is_empty() {
        format!("{STALE_TOKEN_ERROR}; pid {pid} has no current snapshot")
    } else {
        format!(
            "{STALE_TOKEN_ERROR}; {}",
            current_snapshots_phrase(pid, current)
        )
    };
    ToolResult::error(message.clone()).with_structured(serde_json::json!({
        "status": "refused",
        "refusal": { "code": "stale_element_token", "message": message },
        "current_snapshots": current_snapshots_json(current),
    }))
}

fn zoom_context_refusal(pid: i32, window_id: Option<u64>) -> ToolResult {
    let message = "The zoom coordinate context is missing or was replaced by a newer snapshot. Call get_window_state and zoom again on the same connection before using from_zoom coordinates.";
    ToolResult::error(message).with_structured(serde_json::json!({
        // Explicit shared refusal envelope: the context is resolved before any
        // input is dispatched, so nothing was delivered. Top-level fields stay
        // for existing consumers.
        "status": "refused",
        "refusal": { "code": "zoom_context_missing", "message": message },
        "code": "zoom_context_missing",
        "pid": pid,
        "window_id": window_id,
    }))
}

/// Why a bare row number did not resolve to exactly one read.
enum RowMiss<'a, S> {
    /// No snapshot of the window (and no single snapshot of the process).
    NoSnapshot,
    /// This caller has read the window again since, so the row no longer names
    /// the read it was printed in.
    Reread(&'a Snapshot<S>),
    /// This caller has not read the window in this session, so no read of
    /// theirs is behind the row.
    NotRead(&'a Snapshot<S>),
    /// This caller read the window once, but a later read (theirs or another
    /// caller's) replaced the snapshot that printed the row.
    Replaced(&'a Snapshot<S>),
    /// Several windows, none named.
    Ambiguous,
}

/// Why a bare row number could not be attributed to a read of this caller's.
impl<S> RowMiss<'_, S> {
    fn as_str(&self) -> &'static str {
        match self {
            Self::NoSnapshot => "no_current_snapshot",
            Self::Reread(_) => "stale_bare_row",
            Self::NotRead(_) => "unattributed_bare_row",
            Self::Replaced(_) => "stale_bare_row",
            Self::Ambiguous => "ambiguous_window",
        }
    }

    fn snapshot(&self) -> Option<&Snapshot<S>> {
        match self {
            Self::Reread(snapshot) | Self::NotRead(snapshot) | Self::Replaced(snapshot) => {
                Some(snapshot)
            }
            Self::NoSnapshot | Self::Ambiguous => None,
        }
    }
}

/// The snapshot a bare row number refers to: the snapshot this caller's single
/// read of the window printed, which must still be the window's current one.
///
/// A bare row number carries no snapshot id, so the only read it can honestly
/// name is one the caller made and that nothing has since replaced. Every other
/// case is refused, because the alternative is acting on whatever element now
/// occupies that row — a different element, reported as a success. The caller
/// recovers by passing the full `s<id>:<row>` token it needs to be exact.
fn row_snapshot<'a, S: SnapshotPayload>(
    pid: i32,
    lane: &'a [Snapshot<S>],
    reads: &HashMap<(String, i32, u64), ReadRecord>,
    session: &str,
    window_id: Option<u64>,
) -> Result<&'a Snapshot<S>, RowMiss<'a, S>> {
    let attribution = |snapshot: &'a Snapshot<S>| {
        match reads.get(&(session.to_owned(), pid, snapshot.window_id)) {
            // One read, and it printed the snapshot that is current now: the
            // row can only be a row of that read.
            Some(read) if read.reads == 1 && read.snapshot_id == snapshot.id => Ok(snapshot),
            // Read more than once: rows from the earlier read are gone.
            Some(read) if read.reads > 1 => Err(RowMiss::Reread(snapshot)),
            // One read, but a later one replaced its snapshot.
            Some(_) => Err(RowMiss::Replaced(snapshot)),
            None => Err(RowMiss::NotRead(snapshot)),
        }
    };
    match window_id {
        Some(window_id) => lane
            .iter()
            .find(|snapshot| snapshot.window_id == window_id)
            .map_or(Err(RowMiss::NoSnapshot), attribution),
        None => match lane {
            [only] => attribution(only),
            [] => Err(RowMiss::NoSnapshot),
            _ => Err(RowMiss::Ambiguous),
        },
    }
}

/// The refusal for a bare row number that cannot name exactly one read.
fn row_refusal<S: SnapshotPayload>(
    pid: i32,
    row: usize,
    lane: &[Snapshot<S>],
    miss: RowMiss<'_, S>,
) -> ToolResult {
    let reason = miss.as_str();
    let window = miss.snapshot().map(|snapshot| snapshot.window_id);
    let message = match (&miss, window) {
        (RowMiss::Reread(snapshot) | RowMiss::Replaced(snapshot), Some(window)) => {
            let token = token_for(snapshot.id, row);
            format!(
                "element_token \"{row}\" is a bare row number, and it no longer names the \
                     read it was printed in: window {window} has been read again since, and \
                     rows belong to the read that printed them. Acting on it would mean acting \
                     on whatever element now sits at row [{row}], which may not be the element \
                     you selected. Pass the full token from the read you mean (\"{token}\" is \
                     row [{row}] of the current snapshot), or re-read and use a row the new \
                     tree prints."
            )
        }
        (RowMiss::NotRead(snapshot), Some(window)) => format!(
            "element_token \"{row}\" is a bare row number, and this session has not read \
                 window {window}: a row number names a row of a read you made, and there is none \
                 behind it. Pass the full token from the read you mean (\"{}\" is row [{row}] of \
                 the current snapshot), or call get_window_state and use a row it prints.",
            token_for(snapshot.id, row)
        ),
        (RowMiss::Ambiguous, _) => format!(
            "element_token \"{row}\" is a row number, not a token. Pass the full token, \
                 <snapshot_id>:{row}: {}; or add window_id.",
            lane.iter()
                .map(|snapshot| format!(
                    "\"{}\" (window {})",
                    token_for(snapshot.id, row),
                    snapshot.window_id
                ))
                .collect::<Vec<_>>()
                .join(", ")
        ),
        _ => format!(
            "element_token \"{row}\" is a row number, and pid {pid} has no current \
             snapshot. Call get_window_state, then pass \"<snapshot_id>:{row}\"."
        ),
    };
    let mut error = ToolResult::error(message.clone()).with_structured(serde_json::json!({
        "status": "refused",
        "refusal": { "code": "invalid_element_token", "message": message },
        "code": "invalid_element_token",
        "reason": reason,
        "pid": pid,
        "window_id": window,
    }));
    if let (Some(snapshot), Some(structured)) = (miss.snapshot(), error.structured_content.as_mut())
    {
        structured["current_snapshot"] = format_snapshot_id(snapshot.id).into();
    }
    error
}

fn invalid_token_refusal<S>(token: &str, lane: &[Snapshot<S>]) -> ToolResult {
    let example = lane.last().map_or_else(
        || "s0000002a:11".to_owned(),
        |snapshot| token_for(snapshot.id, 11),
    );
    refusal(
        "invalid_element_token",
        format!(
            "element_token \"{token}\" has invalid format: use <snapshot_id>:<row>, e.g. \
             \"{example}\" for row [11] of the read whose snapshot_id is {}.",
            example.split(':').next().unwrap_or_default()
        ),
    )
}

fn out_of_range_refusal<S: SnapshotPayload>(snapshot: &Snapshot<S>, row: usize) -> ToolResult {
    let snapshot_id = format_snapshot_id(snapshot.id);
    let rows = match snapshot.payload.len() {
        0 => "no rows".to_owned(),
        n => format!("rows [0] to [{}] only", n - 1),
    };
    refusal(
        "invalid_element_token",
        format!(
            "element_token {snapshot_id}:{row} is out of range: snapshot {snapshot_id} has \
             {rows} ({} element(s)). Row numbers belong to one read: a read with a smaller \
             max_elements, max_depth or another query can stop before row [{row}]. Use a row \
             printed in {snapshot_id}, or re-read with a larger max_elements (or a query that \
             matches the target) and use that read's rows.",
            snapshot.payload.len()
        ),
    )
}

/// How many retired snapshot ids a runtime remembers, so a refusal for a token
/// whose snapshot is gone can still name the process (and so the current
/// snapshots) it belonged to.
const RETIRED_MEMORY: usize = 256;

/// What one caller's reads of one window looked like.
#[derive(Clone, Copy, Debug)]
struct ReadRecord {
    /// The snapshot the caller's most recent read of the window printed.
    snapshot_id: u32,
    /// How many reads of the window printed rows for this caller.
    reads: u32,
}

/// Everything one runtime remembers about published snapshots.
struct SnapshotState<S> {
    lanes: HashMap<i32, Vec<Snapshot<S>>>,
    /// Element reads a caller has made of a window: `(session, pid, window)`
    /// -> how many reads printed rows. A bare row number names a read only
    /// while its caller has read that window exactly once, because a second
    /// read can put a different element at the same row. The count outlives
    /// eviction, so the caller's *second* read is what stops a row from the
    /// first being re-pointed.
    reads: HashMap<(String, i32, u64), ReadRecord>,
    /// Recently retired snapshot ids with the pid that minted them, oldest
    /// first. This is what lets a token-only call learn whose snapshots
    /// replaced the one it named.
    retired: VecDeque<(u32, i32)>,
}

impl<S> SnapshotState<S> {
    fn new() -> Self {
        Self {
            lanes: HashMap::new(),
            reads: HashMap::new(),
            retired: VecDeque::new(),
        }
    }

    fn lane(&self, pid: i32) -> &[Snapshot<S>] {
        self.lanes.get(&pid).map(Vec::as_slice).unwrap_or_default()
    }

    fn remember_retired(&mut self, pid: i32, ids: impl IntoIterator<Item = u32>) {
        for id in ids {
            if self.retired.len() == RETIRED_MEMORY {
                self.retired.pop_front();
            }
            self.retired.push_back((id, pid));
        }
    }

    /// The current snapshots of `pid`, in the shape every stale refusal reports.
    fn current_snapshots(&self, pid: i32) -> Vec<CurrentSnapshot> {
        self.lane(pid)
            .iter()
            .map(|snapshot| CurrentSnapshot {
                snapshot_id: format_snapshot_id(snapshot.id),
                window_id: snapshot.window_id,
            })
            .collect()
    }

    /// The pid a snapshot id was minted for, while that snapshot is current.
    fn pid_of_current(&self, snapshot_id: u32) -> Option<i32> {
        self.lanes
            .iter()
            .find(|(_, lane)| lane.iter().any(|snapshot| snapshot.id == snapshot_id))
            .map(|(pid, _)| *pid)
    }

    /// The pid a snapshot id was minted for, including ids retired earlier.
    fn pid_of(&self, snapshot_id: u32) -> Option<i32> {
        self.pid_of_current(snapshot_id).or_else(|| {
            self.retired
                .iter()
                .rev()
                .find(|(id, _)| *id == snapshot_id)
                .map(|(_, pid)| *pid)
        })
    }
}

pub struct SnapshotStore<S: SnapshotPayload> {
    runtime_scope: String,
    inner: Mutex<SnapshotState<S>>,
}

impl<S: SnapshotPayload> SnapshotStore<S> {
    pub fn new() -> Self {
        Self {
            runtime_scope: current_runtime_scope(),
            inner: Mutex::new(SnapshotState::new()),
        }
    }

    pub fn publish(&self, pid: i32, window_id: u64, payload: S) -> u32 {
        self.publish_for_session(pid, window_id, payload, None, None)
            .expect("anonymous snapshot publication cannot be retired")
            .0
    }

    /// Publish the latest runtime-owned snapshot and its screenshot coordinate frame,
    /// returning its id and the ids of the snapshots it replaced or evicted.
    ///
    /// `screenshot_scale` is the native-image-width / delivered-image-width ratio.
    /// A `None` scale deliberately records that the latest observation did not
    /// deliver an actionable screenshot. Publications completing after their
    /// owning session ended are discarded instead of resurrecting retired state.
    pub fn publish_for_session(
        &self,
        pid: i32,
        window_id: u64,
        payload: S,
        session: Option<&str>,
        screenshot_scale: Option<f64>,
    ) -> Option<(u32, Vec<u32>)> {
        self.publish_snapshot(
            pid,
            window_id,
            payload,
            session,
            (screenshot_scale, None),
            true,
        )
    }

    /// [`Self::publish_for_session`] that also records the window's size in
    /// points (`window_size`), so later reads can tell whether the screenshot
    /// frame still applies.
    ///
    /// * With a `screenshot_scale`, the size is stored with the new frame.
    /// * Without one (a tree-only read), the new snapshot keeps the replaced
    ///   snapshot's screenshot frame when that frame belongs to the same
    ///   session and was taken at the same window size. Window-relative pixels
    ///   off that screenshot still land where they did, so a pixel action
    ///   after a tree-only re-read is not refused. A resized window, an
    ///   unknown size or another session's frame retires the frame as before.
    pub fn publish_sized_for_session(
        &self,
        pid: i32,
        window_id: u64,
        payload: S,
        session: Option<&str>,
        screenshot_scale: Option<f64>,
        window_size: Option<(f64, f64)>,
    ) -> Option<(u32, Vec<u32>)> {
        self.publish_snapshot(
            pid,
            window_id,
            payload,
            session,
            (screenshot_scale, window_size),
            true,
        )
    }

    /// Refresh the screenshot frame of the window's current snapshot in place,
    /// keeping its id, its elements and their tokens. Used by a
    /// screenshot-only read (no tree walk): it adds a new image but no new
    /// element indices, so the tokens the caller holds stay valid. Returns the
    /// kept snapshot id, or `None` when the window has no snapshot with
    /// elements (the caller then publishes a new one).
    pub fn refresh_screenshot_for_session(
        &self,
        pid: i32,
        window_id: u64,
        session: Option<&str>,
        screenshot_scale: f64,
        window_size: Option<(f64, f64)>,
    ) -> Option<u32> {
        let mut inner = self.inner.lock().unwrap();
        if session.is_some_and(crate::session::is_session_ended) {
            return None;
        }
        let snapshot = inner
            .lanes
            .get_mut(&pid)?
            .iter_mut()
            .find(|snapshot| snapshot.window_id == window_id)
            .filter(|snapshot| snapshot.semantic && !snapshot.payload.is_empty())?;
        snapshot.screenshot_owner = session.map(str::to_owned);
        snapshot.screenshot_scale = Some(screenshot_scale);
        snapshot.screenshot_window_size = window_size;
        snapshot.zoom = None;
        Some(snapshot.id)
    }

    /// Publish screenshot/capture state without claiming that an accessibility
    /// walk has completed for this window.
    pub fn publish_capture_for_session(
        &self,
        pid: i32,
        window_id: u64,
        payload: S,
        session: Option<&str>,
        screenshot_scale: Option<f64>,
    ) -> Option<(u32, Vec<u32>)> {
        self.publish_snapshot(
            pid,
            window_id,
            payload,
            session,
            (screenshot_scale, None),
            false,
        )
    }

    fn publish_snapshot(
        &self,
        pid: i32,
        window_id: u64,
        payload: S,
        session: Option<&str>,
        // The new screenshot's scale, if any, and the window size in points
        // at this read.
        (screenshot_scale, window_size): (Option<f64>, Option<(f64, f64)>),
        semantic: bool,
    ) -> Option<(u32, Vec<u32>)> {
        let (id, retired) = {
            let mut inner = self.inner.lock().unwrap();
            if session.is_some_and(crate::session::is_session_ended) {
                return None;
            }
            // The new snapshot replaces the window's current one, so the lane
            // borrow has to end before the bookkeeping below.
            let (id, retired_here) = {
                let lane = inner.lanes.entry(pid).or_default();
                let mut retired = Vec::new();
                if let Some(position) = lane.iter().position(|entry| entry.window_id == window_id) {
                    retired.push(lane.remove(position));
                }
                // A new screenshot brings its own frame. A tree-only read keeps
                // the replaced snapshot's frame while the window keeps its size.
                let (scale, frame_size) = match (screenshot_scale, window_size) {
                    (Some(scale), size) => (Some(scale), size),
                    (None, Some(now)) => retired
                        .first()
                        .filter(|previous| previous.screenshot_owner.as_deref() == session)
                        .and_then(|previous| {
                            let then = previous.screenshot_window_size?;
                            let same = (then.0 - now.0).abs() < 0.5 && (then.1 - now.1).abs() < 0.5;
                            same.then_some((previous.screenshot_scale?, then))
                        })
                        .map_or((None, None), |(scale, size)| (Some(scale), Some(size))),
                    (None, None) => (None, None),
                };
                if lane.len() == LRU_CAP_PER_PID {
                    retired.push(lane.remove(0));
                }
                let id = crate::element_token::mint_snapshot_id();
                lane.push(Snapshot {
                    id,
                    window_id,
                    screenshot_owner: session.map(str::to_owned),
                    screenshot_scale: scale,
                    screenshot_window_size: frame_size,
                    zoom: None,
                    semantic,
                    payload,
                });
                (id, retired)
            };
            let invalidated: Vec<u32> = retired_here.iter().map(|snapshot| snapshot.id).collect();
            inner.remember_retired(pid, invalidated.iter().copied());
            // Only a read that printed rows can leave a bare row number
            // behind, so only those count. A screenshot-only capture mints no
            // rows, and a screenshot-only refresh keeps the snapshot (and so
            // its rows) in place without publishing at all.
            if semantic {
                let read = inner
                    .reads
                    .entry((session.unwrap_or_default().to_owned(), pid, window_id))
                    .or_insert(ReadRecord {
                        snapshot_id: id,
                        reads: 0,
                    });
                read.snapshot_id = id;
                read.reads = read.reads.saturating_add(1);
            }
            (id, retired_here)
        };
        let invalidated = retired.iter().map(|snapshot| snapshot.id).collect();
        drop(retired);
        Some((id, invalidated))
    }

    /// Resolve the screenshot transform from the same authoritative latest
    /// snapshot used for element tokens. Without a window, every snapshot of
    /// the process must agree on one transform owned by this session.
    pub fn screenshot_context(
        &self,
        pid: i32,
        window_id: Option<u64>,
        session: Option<&str>,
    ) -> Result<ScreenshotContext, ToolResult> {
        let inner = self.inner.lock().unwrap();
        let lane = inner.lane(pid);
        match window_id {
            Some(window_id) => {
                let snapshot = lane
                    .iter()
                    .find(|snapshot| snapshot.window_id == window_id)
                    .ok_or_else(|| {
                        screenshot_context_refusal(
                            Some(pid),
                            Some(window_id),
                            MissingFrame::WindowNeverRead,
                        )
                    })?;
                snapshot.screenshot(session).ok_or_else(|| {
                    let why = if snapshot.screenshot_scale.is_some() {
                        MissingFrame::OtherSession
                    } else {
                        MissingFrame::NoScreenshot
                    };
                    screenshot_context_refusal(Some(pid), Some(window_id), why)
                })
            }
            None => {
                let mut contexts = lane.iter().map(|snapshot| snapshot.screenshot(session));
                let why = match lane {
                    [] => MissingFrame::WindowNeverRead,
                    [_] => MissingFrame::NoScreenshot,
                    _ => MissingFrame::Ambiguous,
                };
                contexts
                    .next()
                    .flatten()
                    .filter(|first| {
                        contexts.all(|context| {
                            context
                                .is_some_and(|context| (context.scale - first.scale).abs() < 1e-9)
                        })
                    })
                    .ok_or_else(|| screenshot_context_refusal(Some(pid), None, why))
            }
        }
    }

    /// The native-image / delivered-image scale for a window-relative pixel
    /// action: 1.0 for a trusted in-process call whose pixels are already
    /// native ([`NATIVE_WINDOW_PIXELS_ARG`]), otherwise the scale of the
    /// session's current screenshot of the window (refused without one).
    pub fn screenshot_scale(
        &self,
        pid: i32,
        window_id: Option<u64>,
        args: &serde_json::Value,
    ) -> Result<f64, ToolResult> {
        if args.get(NATIVE_WINDOW_PIXELS_ARG) == Some(&serde_json::Value::Bool(true)) {
            return Ok(1.0);
        }
        self.screenshot_context(
            pid,
            window_id,
            args.get("_session_id").and_then(serde_json::Value::as_str),
        )
        .map(|context| context.scale)
    }

    pub fn screenshot_context_for_zoom(
        &self,
        pid: Option<i32>,
        window_id: u64,
        session: Option<&str>,
    ) -> Result<(i32, ScreenshotContext), ToolResult> {
        if let Some(pid) = pid {
            return self
                .screenshot_context(pid, Some(window_id), session)
                .map(|context| (pid, context));
        }
        let inner = self.inner.lock().unwrap();
        let mut matches = inner.lanes.iter().filter_map(|(pid, lane)| {
            let snapshot = lane
                .iter()
                .find(|snapshot| snapshot.window_id == window_id)?;
            Some((*pid, snapshot.screenshot(session)?))
        });
        match (matches.next(), matches.next()) {
            (Some(found), None) => Ok(found),
            _ => Err(screenshot_context_refusal(
                None,
                Some(window_id),
                MissingFrame::WindowNeverRead,
            )),
        }
    }

    pub fn set_zoom(
        &self,
        pid: i32,
        session: Option<&str>,
        zoom: ZoomContext,
    ) -> Result<(), ToolResult> {
        let mut inner = self.inner.lock().unwrap();
        let snapshot = inner
            .lanes
            .get_mut(&pid)
            .and_then(|lane| {
                lane.iter_mut()
                    .find(|snapshot| snapshot.window_id == zoom.screenshot.window_id)
            })
            .filter(|snapshot| snapshot.screenshot(session) == Some(zoom.screenshot))
            .ok_or_else(|| zoom_context_refusal(pid, Some(zoom.screenshot.window_id)))?;
        snapshot.zoom = Some(zoom);
        Ok(())
    }

    pub fn zoom(
        &self,
        pid: i32,
        window_id: Option<u64>,
        session: Option<&str>,
    ) -> Result<ZoomContext, ToolResult> {
        let inner = self.inner.lock().unwrap();
        let mut zooms = inner
            .lanes
            .get(&pid)
            .into_iter()
            .flatten()
            .filter(|snapshot| {
                window_id.is_none_or(|window_id| snapshot.window_id == window_id)
                    && snapshot.screenshot_owner.as_deref() == session
            })
            .filter_map(|snapshot| snapshot.zoom);
        match (zooms.next(), zooms.next()) {
            (Some(zoom), None) => Ok(zoom),
            _ => Err(zoom_context_refusal(pid, window_id)),
        }
    }

    pub fn retire_session_screenshots(&self, session: &str) -> usize {
        let retired = {
            let mut inner = self.inner.lock().unwrap();
            let mut retired = Vec::new();
            let mut retired_ids: Vec<(i32, u32)> = Vec::new();
            for (pid, lane) in inner.lanes.iter_mut() {
                let (owned, kept) = std::mem::take(lane)
                    .into_iter()
                    .partition(|snapshot| snapshot.screenshot_owner.as_deref() == Some(session));
                *lane = kept;
                retired_ids.extend(owned.iter().map(|snapshot| (*pid, snapshot.id)));
                retired.extend::<Vec<_>>(owned);
            }
            inner.lanes.retain(|_, lane| !lane.is_empty());
            for (pid, id) in retired_ids {
                inner.remember_retired(pid, [id]);
            }
            retired
        };
        let count = retired.len();
        drop(retired);
        count
    }

    pub fn window_for_snapshot(&self, pid: i32, snapshot_id: u32) -> Option<u64> {
        self.inner
            .lock()
            .unwrap()
            .lanes
            .get(&pid)?
            .iter()
            .find(|entry| entry.id == snapshot_id)
            .map(|entry| entry.window_id)
    }

    /// Whether this runtime has already published any snapshot for the window.
    pub fn contains_window(&self, pid: i32, window_id: u64) -> bool {
        self.inner
            .lock()
            .unwrap()
            .lanes
            .get(&pid)
            .is_some_and(|lane| lane.iter().any(|entry| entry.window_id == window_id))
    }

    /// Whether an accessibility/semantic snapshot has been published for the
    /// window. Screenshot-only previews deliberately do not satisfy this.
    pub fn contains_semantic_window(&self, pid: i32, window_id: u64) -> bool {
        self.inner
            .lock()
            .unwrap()
            .lanes
            .get(&pid)
            .is_some_and(|lane| {
                lane.iter()
                    .any(|entry| entry.window_id == window_id && entry.semantic)
            })
    }

    /// The pid an `element_token` was minted for, found without the caller
    /// naming it. Snapshot ids are unique per runtime, so a token alone names
    /// its snapshot, window and process. `None` when the token is absent,
    /// malformed, or no longer current; callers then fall back to the
    /// ordinary missing-`pid` error.
    pub fn pid_for_token(&self, args: &serde_json::Value) -> Option<i32> {
        let token = args.get("element_token")?.as_str()?;
        let (snapshot_id, _) = parse_token(token)?;
        self.inner.lock().unwrap().pid_of_current(snapshot_id)
    }

    /// Who a call's `element_token` belonged to, and that process's current
    /// snapshots, for the refusal [`crate::element_token::fill_pid_from_token`]
    /// reports when the token is gone.
    ///
    /// The pid is looked up for retired snapshots too, so a token one read
    /// behind still names the process and the refusal can say what replaced it.
    /// A token this runtime never minted — or one whose retirement has aged out
    /// of [`RETIRED_MEMORY`] — is reported as unattributed rather than guessed.
    pub fn token_owner(&self, args: &serde_json::Value) -> TokenOwner {
        let Some((snapshot_id, _)) = args
            .get("element_token")
            .and_then(serde_json::Value::as_str)
            .and_then(parse_token)
        else {
            return TokenOwner::default();
        };
        let inner = self.inner.lock().unwrap();
        let Some(pid) = inner.pid_of(snapshot_id) else {
            return TokenOwner::default();
        };
        TokenOwner {
            pid: Some(pid),
            current: inner.current_snapshots(pid),
            live: inner.pid_of_current(snapshot_id).is_some(),
        }
    }

    pub fn resolve(
        &self,
        pid: i32,
        args: &serde_json::Value,
    ) -> Result<ResolvedElement<S::Element>, ToolResult> {
        let Some(token) = args
            .get("element_token")
            .and_then(serde_json::Value::as_str)
        else {
            return Ok(ResolvedElement::None);
        };
        let window_arg = args["window_id"].as_u64();
        let inner = self.inner.lock().unwrap();
        let lane = inner.lane(pid);
        let (snapshot, element_index) = match parse_token(token) {
            Some((snapshot_id, element_index)) => {
                let Some(snapshot) = lane.iter().find(|snapshot| snapshot.id == snapshot_id) else {
                    return Err(stale_token_refusal(pid, &inner.current_snapshots(pid)));
                };
                (snapshot, element_index)
            }
            // A bare row number ("11") is the `[11]` of a markdown read. It
            // carries no snapshot id, so it names a read only while that read
            // is still the window's only one; a re-read retires the tree the
            // number came from and the number is refused rather than re-pointed
            // at whatever row [11] now holds.
            None => match token.trim().parse::<usize>() {
                Ok(row) => match row_snapshot(
                    pid,
                    lane,
                    &inner.reads,
                    args.get("_session_id")
                        .and_then(serde_json::Value::as_str)
                        .unwrap_or_default(),
                    window_arg,
                ) {
                    Ok(snapshot) => (snapshot, row),
                    Err(miss) => return Err(row_refusal(pid, row, lane, miss)),
                },
                Err(_) => return Err(invalid_token_refusal(token, lane)),
            },
        };
        if window_arg.is_some_and(|window_id| window_id != snapshot.window_id) {
            return Err(refusal(
                "conflicting_element_target",
                "element_token conflicts with window_id".into(),
            ));
        }
        let element = snapshot
            .payload
            .retain(element_index)
            .ok_or_else(|| out_of_range_refusal(snapshot, element_index))?;
        Ok(ResolvedElement::Element {
            window_id: snapshot.window_id,
            element_index,
            element,
        })
    }

    pub fn remove(&self, pid: i32, window_id: u64) -> Option<u32> {
        let retired = {
            let mut inner = self.inner.lock().unwrap();
            let removed = inner.lanes.get_mut(&pid).and_then(|lane| {
                let position = lane.iter().position(|entry| entry.window_id == window_id)?;
                Some(lane.remove(position))
            });
            let id = removed.as_ref().map(|snapshot| snapshot.id);
            if let Some(id) = id {
                inner.remember_retired(pid, [id]);
            }
            removed
        };
        retired.map(|snapshot| snapshot.id)
    }

    pub fn clear(&self) -> usize {
        let retired = {
            let mut inner = self.inner.lock().unwrap();
            let lanes = std::mem::take(&mut inner.lanes);
            inner.reads.clear();
            inner.retired.clear();
            lanes
        };
        let count = retired.len();
        drop(retired);
        count
    }
}

impl<S: SnapshotPayload> Drop for SnapshotStore<S> {
    fn drop(&mut self) {
        let mut caches = runtime_stores().lock().unwrap();
        if caches
            .get(&self.runtime_scope)
            .is_some_and(|cache| std::ptr::addr_eq(cache.as_ptr(), self as *const Self))
        {
            caches.remove(&self.runtime_scope);
        }
        if caches.is_empty() {
            caches.shrink_to_fit();
        }
    }
}

impl<S: SnapshotPayload> Default for SnapshotStore<S> {
    fn default() -> Self {
        Self::new()
    }
}

trait RuntimeStore: Any + Send + Sync {
    fn clear(&self) -> usize;
}

impl<S: SnapshotPayload> RuntimeStore for SnapshotStore<S> {
    fn clear(&self) -> usize {
        self.clear()
    }
}

fn runtime_stores() -> &'static Mutex<HashMap<String, Weak<dyn RuntimeStore>>> {
    static STORES: OnceLock<Mutex<HashMap<String, Weak<dyn RuntimeStore>>>> = OnceLock::new();
    STORES.get_or_init(|| Mutex::new(HashMap::new()))
}

fn current_runtime_scope() -> String {
    crate::tool::current_dispatch_runtime_scope().unwrap_or_else(|| "legacy".into())
}

pub fn register_runtime_store<S: SnapshotPayload>(cache: &Arc<SnapshotStore<S>>) {
    let erased: Arc<dyn RuntimeStore> = cache.clone();
    let mut caches = runtime_stores().lock().unwrap();
    caches.retain(|_, cache| cache.strong_count() > 0);
    caches.insert(cache.runtime_scope.clone(), Arc::downgrade(&erased));
}

pub fn current_runtime_store<S: SnapshotPayload>() -> Option<Arc<SnapshotStore<S>>> {
    let cache = runtime_stores()
        .lock()
        .unwrap()
        .get(&current_runtime_scope())?
        .upgrade()?;
    let erased: Arc<dyn Any + Send + Sync> = cache;
    erased.downcast().ok()
}

pub fn retire_runtime_scope(runtime_scope: &str) -> usize {
    let cache = runtime_stores()
        .lock()
        .unwrap()
        .remove(runtime_scope)
        .and_then(|cache| cache.upgrade());
    cache.map_or(0, |cache| cache.clear())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::element_token::token_for;
    use crate::snapshot_test_support::Payload;
    use std::sync::atomic::{AtomicUsize, Ordering};

    #[test]
    fn pid_for_token_finds_the_owning_process() {
        let cache = SnapshotStore::new();
        let id = cache.publish(42, 7, Payload(vec![10, 20]));
        cache.publish(43, 8, Payload(vec![1]));
        let args = serde_json::json!({ "element_token": token_for(id, 1) });
        assert_eq!(cache.pid_for_token(&args), Some(42));
        assert_eq!(cache.pid_for_token(&serde_json::json!({})), None);
        let unknown = serde_json::json!({ "element_token": token_for(id + 1000, 0) });
        assert_eq!(cache.pid_for_token(&unknown), None);
    }

    #[test]
    fn publish_then_resolve_returns_projection() {
        let cache = SnapshotStore::new();
        let id = cache.publish(42, 7, Payload(vec![10, 20, 30]));
        let result = cache
            .resolve(
                42,
                &serde_json::json!({ "element_token": token_for(id, 2) }),
            )
            .unwrap();
        assert!(matches!(
            result,
            ResolvedElement::Element { element: 30, .. }
        ));
    }

    #[test]
    fn miss_returns_refusal() {
        let cache = SnapshotStore::<Payload>::new();
        assert!(cache
            .resolve(1, &serde_json::json!({ "element_token": token_for(0, 0) }))
            .is_err());
    }

    #[test]
    fn token_resolution_rejects_conflicting_windows() {
        let cache = SnapshotStore::new();
        let token = token_for(cache.publish(7, 42, Payload(vec![1])), 0);
        let mut args = serde_json::json!({ "element_token": token });
        for window_id in [None, Some(42)] {
            if let Some(window_id) = window_id {
                args["window_id"] = serde_json::json!(window_id);
            }
            assert!(matches!(
                cache.resolve(7, &args).unwrap(),
                ResolvedElement::Element { window_id: 42, .. }
            ));
        }
        args["window_id"] = serde_json::json!(99);
        let error = cache.resolve(7, &args).unwrap_err();
        assert_eq!(
            error.structured_content.unwrap()["refusal"]["code"],
            "conflicting_element_target"
        );
    }

    #[test]
    fn membership_matches_payload_length() {
        let cache = SnapshotStore::new();
        let id = cache.publish(9, 99, Payload(vec![1, 2, 3, 4, 5]));
        for index in 0..5 {
            assert!(cache
                .resolve(
                    9,
                    &serde_json::json!({ "element_token": token_for(id, index) })
                )
                .is_ok());
        }
        assert!(cache
            .resolve(9, &serde_json::json!({ "element_token": token_for(id, 5) }))
            .is_err());
    }

    #[test]
    fn semantic_membership_ignores_capture_only_publication() {
        let cache = SnapshotStore::new();
        assert!(!cache.contains_window(9, 99));
        assert!(!cache.contains_semantic_window(9, 99));

        cache
            .publish_capture_for_session(9, 99, Payload(vec![]), None, Some(1.0))
            .unwrap();
        assert!(cache.contains_window(9, 99));
        assert!(!cache.contains_semantic_window(9, 99));

        cache.publish(9, 99, Payload(vec![]));
        assert!(cache.contains_semantic_window(9, 99));
        assert!(!cache.contains_semantic_window(9, 100));
        assert!(!cache.contains_semantic_window(10, 99));

        cache.remove(9, 99);
        assert!(!cache.contains_window(9, 99));
        assert!(!cache.contains_semantic_window(9, 99));
    }

    fn token_refusal(cache: &SnapshotStore<Payload>, pid: i32, token: &str) -> serde_json::Value {
        cache
            .resolve(pid, &serde_json::json!({ "element_token": token }))
            .unwrap_err()
            .structured_content
            .unwrap()
    }

    #[test]
    fn malformed_token_is_invalid_not_stale() {
        let cache = SnapshotStore::new();
        cache.publish(10, 1, Payload(vec![0]));
        assert_eq!(
            token_refusal(&cache, 10, "garbage")["refusal"]["code"],
            "invalid_element_token"
        );
    }

    #[test]
    fn tokens_in_different_pids_dont_collide() {
        let cache = SnapshotStore::new();
        let first = cache.publish(100, 11, Payload(vec![0]));
        cache.publish(200, 22, Payload(vec![0]));
        assert_eq!(
            token_refusal(&cache, 200, &token_for(first, 0))["refusal"]["code"],
            "stale_element_token"
        );
    }

    /// R4. A refusal is supposed to tell the caller what *is* current so it can
    /// recover without a blind re-read. The token-only path (a call carrying
    /// `element_token` and no `pid`, which `fill_pid_from_token` resolves before
    /// dispatch) used to answer only "stale or unknown", naming nothing.
    ///
    /// This is the TLA+ finding replayed against the real store: read, read,
    /// act with the token from the first read and no pid.
    #[test]
    fn the_token_only_refusal_names_the_current_snapshots() {
        let cache = SnapshotStore::new();
        let first = cache.publish(10, 100, Payload(vec![1, 2, 3]));
        let current = cache.publish(10, 100, Payload(vec![4, 5, 6])).to_owned();
        assert_ne!(first, current);

        let mut token_only = serde_json::json!({ "element_token": token_for(first, 0) });
        let refusal = crate::element_token::fill_pid_from_token(&mut token_only, |args| {
            cache.token_owner(args)
        })
        .expect_err("a token whose snapshot is gone must be refused");

        let structured = refusal.structured_content.clone().unwrap();
        assert_eq!(structured["refusal"]["code"], "stale_element_token");
        // The pid the token belonged to, and what is current for it.
        assert_eq!(structured["pid"], 10);
        assert_eq!(
            structured["current_snapshots"],
            serde_json::json!([{
                "snapshot_id": format_snapshot_id(current),
                "window_id": 100,
            }])
        );

        let text = crate::snapshot_test_support::text(&refusal);
        assert!(
            text.contains(&format_snapshot_id(current)),
            "the message must name the current snapshot: {text}"
        );
        assert!(text.contains("current snapshots for pid 10"), "{text}");

        // Both refusal shapes now report the same field.
        let with_pid = token_refusal(&cache, 10, &token_for(first, 0));
        assert_eq!(
            structured["current_snapshots"], with_pid["current_snapshots"],
            "the token-only refusal reports what the pid-carrying refusal reports"
        );
    }

    /// A token this runtime never minted cannot be attributed, and the refusal
    /// says that rather than inventing a snapshot.
    #[test]
    fn an_unattributable_token_is_refused_without_inventing_a_snapshot() {
        let cache = SnapshotStore::new();
        cache.publish(10, 100, Payload(vec![1, 2, 3]));

        let mut unknown = serde_json::json!({ "element_token": token_for(0xdead_beef, 0) });
        let refusal =
            crate::element_token::fill_pid_from_token(&mut unknown, |args| cache.token_owner(args))
                .expect_err("an unknown token is refused");
        let structured = refusal.structured_content.clone().unwrap();
        assert_eq!(structured["refusal"]["code"], "stale_element_token");
        assert!(
            structured.get("current_snapshots").is_none(),
            "no attribution, no snapshot claim: {structured}"
        );
        let text = crate::snapshot_test_support::text(&refusal);
        assert!(text.contains("cannot be attributed to a pid"), "{text}");
        assert!(
            !text.contains(&format_snapshot_id(1)) && !text.contains("window 100"),
            "an unattributed refusal must not name another process's snapshot: {text}"
        );
    }

    /// Attribution survives retirement, so a token one read behind still says
    /// whose snapshots replaced it — but a token retired by `clear` is gone.
    #[test]
    fn a_retired_snapshot_still_attributes_its_token() {
        let cache = SnapshotStore::new();
        let first = cache.publish(7, 42, Payload(vec![1]));
        cache.remove(7, 42);
        let owner = cache.token_owner(&serde_json::json!({ "element_token": token_for(first, 0) }));
        assert_eq!(owner.pid, Some(7));
        assert!(owner.current.is_empty(), "the lane was removed");
        assert!(!owner.live, "a removed snapshot is not live");

        let mut args = serde_json::json!({ "element_token": token_for(first, 0) });
        let refusal =
            crate::element_token::fill_pid_from_token(&mut args, |args| cache.token_owner(args))
                .expect_err("the snapshot is gone");
        let text = crate::snapshot_test_support::text(&refusal);
        assert!(
            text.contains("pid 7 has no current snapshot"),
            "a known pid with nothing current says so: {text}"
        );
        assert_eq!(
            refusal.structured_content.unwrap()["current_snapshots"],
            serde_json::json!([])
        );
    }

    #[test]
    fn stale_token_names_the_current_snapshots() {
        let cache = SnapshotStore::new();
        let current = cache.publish(1, 555, Payload(vec![0]));
        let structured = token_refusal(&cache, 1, &token_for(0xdead, 0));
        assert_eq!(structured["refusal"]["code"], "stale_element_token");
        assert_eq!(
            structured["current_snapshots"],
            serde_json::json!([{ "snapshot_id": format_snapshot_id(current), "window_id": 555 }])
        );
    }

    #[test]
    fn stale_zoom_is_an_explicit_refusal_with_no_delivery() {
        let cache = SnapshotStore::<Payload>::new();
        let structured = cache
            .zoom(7, Some(9), None)
            .unwrap_err()
            .structured_content
            .unwrap();
        // Legacy top-level fields remain for existing consumers.
        assert_eq!(structured["code"], "zoom_context_missing");
        assert_eq!(structured["pid"], 7);
        assert_eq!(structured["window_id"], 9);
        assert_eq!(structured["status"], "refused");
        assert_eq!(structured["refusal"]["code"], "zoom_context_missing");

        let args = serde_json::json!({
            "pid": 7, "window_id": 9, "x": 1, "y": 2, "from_zoom": true,
            "delivery_mode": "foreground",
        });
        let record =
            crate::action_record::ActionExecutionRecord::from_legacy("click", &args, &structured)
                .unwrap();
        assert_eq!(record.effect, crate::action_record::ActionEffect::Refused);
        assert_eq!(record.actual_delivery, None);
        assert_eq!(record.delivered_count, None);
        assert_eq!(record.refusal.unwrap().code, "zoom_context_missing");
    }

    #[test]
    fn clear_then_publish_starts_clean() {
        let cache = SnapshotStore::new();
        let first = cache.publish(1, 1, Payload(vec![0]));
        assert_eq!(cache.clear(), 1);
        assert_eq!(cache.clear(), 0);
        assert_eq!(
            token_refusal(&cache, 1, &token_for(first, 0))["refusal"]["code"],
            "stale_element_token"
        );
        let second = cache.publish(1, 1, Payload(vec![0]));
        assert!(cache
            .resolve(
                1,
                &serde_json::json!({ "element_token": token_for(second, 0) })
            )
            .is_ok());
    }

    #[test]
    fn missing_token_resolves_to_none() {
        assert!(matches!(
            SnapshotStore::<Payload>::new()
                .resolve(1, &serde_json::json!({}))
                .unwrap(),
            ResolvedElement::None
        ));
    }

    #[test]
    fn runtime_store_discovery_is_weak_and_shared_across_calls() {
        crate::tool::with_runtime_scope("token-discovery-test".into(), || {
            let cache = Arc::new(SnapshotStore::<Payload>::new());
            register_runtime_store(&cache);
            assert!(Arc::ptr_eq(
                &cache,
                &current_runtime_store::<Payload>().unwrap()
            ));
            drop(cache);
            assert!(current_runtime_store::<Payload>().is_none());
        });
    }

    fn refusal_code(result: ToolResult) -> String {
        result.structured_content.unwrap()["code"]
            .as_str()
            .unwrap()
            .to_owned()
    }

    fn scale(cache: &SnapshotStore<Payload>, window_id: u64, session: &str) -> Option<f64> {
        cache
            .screenshot_context(10, Some(window_id), Some(session))
            .ok()
            .map(|context| context.scale)
    }

    fn zoom_on(snapshot: u32, scale: f64) -> ZoomContext {
        ZoomContext {
            screenshot: ScreenshotContext {
                snapshot_id: snapshot,
                window_id: 20,
                scale,
            },
            origin_x: 100.0,
            origin_y: 50.0,
            scale_inv: 2.0,
        }
    }

    #[test]
    fn screenshot_coordinates_never_borrow_another_sessions_latest_transform() {
        let cache = SnapshotStore::new();
        cache.publish_for_session(10, 20, Payload(vec![]), Some("client-a"), Some(7.35));
        assert_eq!(scale(&cache, 20, "client-a"), Some(7.35));

        cache.publish_for_session(10, 20, Payload(vec![]), Some("client-b"), Some(1.0));
        assert_eq!(scale(&cache, 20, "client-b"), Some(1.0));
        let refusal = cache
            .screenshot_context(10, Some(20), Some("client-a"))
            .expect_err("stale image coordinates must be refused");
        assert_eq!(refusal_code(refusal), "screenshot_context_missing");
    }

    #[test]
    fn window_pixels_need_a_session_screenshot_unless_marked_native() {
        let cache = SnapshotStore::new();
        let session = |extra: serde_json::Value| {
            let mut args = serde_json::json!({ "_session_id": "client-a" });
            args.as_object_mut()
                .unwrap()
                .extend(extra.as_object().unwrap().clone());
            args
        };
        let refusal = cache
            .screenshot_scale(10, Some(20), &session(serde_json::json!({})))
            .expect_err("pixels without a read are refused");
        assert_eq!(refusal_code(refusal), "screenshot_context_missing");
        let native = session(serde_json::json!({ NATIVE_WINDOW_PIXELS_ARG: true }));
        assert_eq!(cache.screenshot_scale(10, Some(20), &native).unwrap(), 1.0);

        // Native pixels ignore the session's screenshot scale; other calls use it.
        cache.publish_for_session(10, 20, Payload(vec![]), Some("client-a"), Some(2.5));
        assert_eq!(cache.screenshot_scale(10, Some(20), &native).unwrap(), 1.0);
        assert_eq!(
            cache
                .screenshot_scale(10, Some(20), &session(serde_json::json!({})))
                .unwrap(),
            2.5
        );
        // Only the boolean true marks native pixels.
        let refusal = cache
            .screenshot_scale(
                10,
                Some(21),
                &session(serde_json::json!({ NATIVE_WINDOW_PIXELS_ARG: "true" })),
            )
            .expect_err("a non-boolean marker is not native pixels");
        assert_eq!(refusal_code(refusal), "screenshot_context_missing");
    }

    #[test]
    fn screenshot_transforms_are_independent_across_windows() {
        let cache = SnapshotStore::new();
        cache.publish_for_session(10, 20, Payload(vec![]), Some("client-a"), Some(7.35));
        cache.publish_for_session(10, 21, Payload(vec![]), Some("client-b"), Some(2.0));
        assert_eq!(scale(&cache, 20, "client-a"), Some(7.35));
        assert_eq!(scale(&cache, 21, "client-b"), Some(2.0));
    }

    #[test]
    fn same_session_latest_snapshot_replaces_or_refuses_older_image_context() {
        let cache = SnapshotStore::new();
        cache.publish_for_session(10, 20, Payload(vec![]), Some("client-a"), Some(7.35));
        cache.publish_for_session(10, 20, Payload(vec![]), Some("client-a"), Some(1.0));
        assert_eq!(
            scale(&cache, 20, "client-a"),
            Some(1.0),
            "a newer native capture replaces the older resized frame"
        );

        cache.publish_for_session(10, 20, Payload(vec![]), Some("client-a"), None);
        assert_eq!(
            scale(&cache, 20, "client-a"),
            None,
            "a newer tree-only observation retires the older image frame"
        );
    }

    #[test]
    fn tree_only_read_keeps_the_screenshot_frame_while_the_window_keeps_its_size() {
        let cache = SnapshotStore::new();
        let size = Some((900.0, 680.0));
        cache.publish_sized_for_session(10, 20, Payload(vec![1]), Some("a"), Some(2.0), size);
        cache.publish_sized_for_session(10, 20, Payload(vec![1, 2]), Some("a"), None, size);
        assert_eq!(scale(&cache, 20, "a"), Some(2.0), "same size: frame kept");
        cache.publish_sized_for_session(10, 20, Payload(vec![1]), Some("a"), None, size);
        assert_eq!(
            scale(&cache, 20, "a"),
            Some(2.0),
            "kept across repeated tree reads"
        );

        cache.publish_sized_for_session(
            10,
            20,
            Payload(vec![1]),
            Some("a"),
            None,
            Some((901.0, 680.0)),
        );
        assert_eq!(scale(&cache, 20, "a"), None, "resized: frame retired");

        cache.publish_sized_for_session(10, 20, Payload(vec![1]), Some("a"), Some(1.0), size);
        cache.publish_sized_for_session(10, 20, Payload(vec![1]), Some("b"), None, size);
        assert_eq!(scale(&cache, 20, "a"), None, "another session's tree read");
        assert_eq!(
            scale(&cache, 20, "b"),
            None,
            "never inherits a foreign frame"
        );

        cache.publish_sized_for_session(10, 20, Payload(vec![1]), Some("a"), Some(1.0), size);
        cache.publish_sized_for_session(10, 20, Payload(vec![1]), Some("a"), None, None);
        assert_eq!(scale(&cache, 20, "a"), None, "unknown size: frame retired");
    }

    #[test]
    fn screenshot_only_read_refreshes_the_frame_and_keeps_tokens() {
        let cache = SnapshotStore::new();
        assert_eq!(
            cache.refresh_screenshot_for_session(10, 20, Some("a"), 1.0, None),
            None,
            "nothing to refresh"
        );
        let (id, _) = cache
            .publish_sized_for_session(10, 20, Payload(vec![5, 6, 7]), Some("a"), None, None)
            .unwrap();
        assert_eq!(scale(&cache, 20, "a"), None);
        assert_eq!(
            cache.refresh_screenshot_for_session(10, 20, Some("a"), 2.0, Some((10.0, 10.0))),
            Some(id)
        );
        assert_eq!(scale(&cache, 20, "a"), Some(2.0));
        let token = serde_json::json!({ "element_token": token_for(id, 2) });
        assert!(matches!(
            cache.resolve(10, &token).unwrap(),
            ResolvedElement::Element { element: 7, .. }
        ));

        // A capture-only snapshot has no rows to keep: publish a new one.
        cache.publish_sized_for_session(10, 21, Payload(vec![]), Some("a"), Some(1.0), None);
        assert_eq!(
            cache.refresh_screenshot_for_session(10, 21, Some("a"), 1.0, None),
            None
        );
    }

    #[test]
    fn missing_frame_refusals_say_why() {
        let cache = SnapshotStore::new();
        let reason = |cache: &SnapshotStore<Payload>, window: u64| {
            let refused = cache
                .screenshot_context(10, Some(window), Some("a"))
                .unwrap_err();
            let structured = refused.structured_content.clone().unwrap();
            assert_eq!(structured["code"], "screenshot_context_missing");
            (
                structured["reason"].as_str().unwrap().to_owned(),
                crate::snapshot_test_support::text(&refused),
            )
        };
        let (why, text) = reason(&cache, 20);
        assert_eq!(why, "window_never_read");
        assert!(
            text.contains("get_window_state(pid:10, window_id:20)"),
            "{text}"
        );
        assert!(text.contains("another window's"), "{text}");

        cache.publish_for_session(10, 20, Payload(vec![1]), Some("a"), None);
        assert_eq!(reason(&cache, 20).0, "no_screenshot");

        cache.publish_for_session(10, 20, Payload(vec![1]), Some("b"), Some(1.0));
        assert_eq!(reason(&cache, 20).0, "other_session");
    }

    #[test]
    fn bare_row_number_resolves_against_the_named_windows_current_snapshot() {
        let cache = SnapshotStore::new();
        let first = cache.publish(10, 20, Payload(vec![100, 101, 102]));
        cache.publish(10, 21, Payload(vec![200, 201]));

        let row = serde_json::json!({ "element_token": "2", "window_id": 20 });
        assert!(matches!(
            cache.resolve(10, &row).unwrap(),
            ResolvedElement::Element {
                window_id: 20,
                element_index: 2,
                element: 102
            }
        ));

        // Two windows and no window_id: refused, naming the full tokens.
        let refused = cache
            .resolve(10, &serde_json::json!({ "element_token": "1" }))
            .unwrap_err();
        let text = crate::snapshot_test_support::text(&refused);
        assert!(text.contains("is a row number, not a token"), "{text}");
        assert!(
            text.contains(&format!("\"{}\" (window 20)", token_for(first, 1))),
            "{text}"
        );

        // One snapshot for the pid: the row is unambiguous.
        let only = SnapshotStore::new();
        only.publish(11, 30, Payload(vec![7, 8]));
        assert!(matches!(
            only.resolve(11, &serde_json::json!({ "element_token": "1" }))
                .unwrap(),
            ResolvedElement::Element { element: 8, .. }
        ));

        // Garbage still fails, with the expected shape spelled out.
        let refused = cache
            .resolve(10, &serde_json::json!({ "element_token": "row11" }))
            .unwrap_err();
        let text = crate::snapshot_test_support::text(&refused);
        assert!(text.contains("use <snapshot_id>:<row>"), "{text}");
    }

    /// R3. A bare row number carries no snapshot id, so it names a read only
    /// while it is still the only read of that window the caller made. Acting
    /// with a row remembered from an earlier read must not silently act on
    /// whatever element now sits at that row.
    ///
    /// This is the TLA+ finding replayed against the real store: read (row [1]
    /// = 20), read again (row [1] = 88), act "1". Before the fix that acted on
    /// 88 and reported success.
    #[test]
    fn a_bare_row_number_does_not_re_point_at_a_newer_snapshot() {
        let cache = SnapshotStore::new();
        let first = cache.publish(10, 100, Payload(vec![10, 20, 30]));
        // The row the model read, and the element it saw there.
        let seen = match cache
            .resolve(
                10,
                &serde_json::json!({ "element_token": token_for(first, 1) }),
            )
            .unwrap()
        {
            ResolvedElement::Element { element, .. } => element,
            ResolvedElement::None => panic!("row [1] exists"),
        };
        assert_eq!(seen, 20);

        let second = cache.publish(10, 100, Payload(vec![99, 88, 77]));
        assert_ne!(first, second);
        let bare = serde_json::json!({ "pid": 10, "window_id": 100, "element_token": "1" });
        let refused = cache
            .resolve(10, &bare)
            .expect_err("a bare row from a retired read must be refused, not re-pointed");
        let text = crate::snapshot_test_support::text(&refused);
        assert!(
            text.contains("no longer names the read it was printed in"),
            "the refusal must say the row is stale: {text}"
        );
        assert!(
            text.contains(&token_for(second, 1)),
            "the refusal must name the current token for that row: {text}"
        );
        assert!(
            !text.contains("row [1] = ") && !text.contains("clicked"),
            "the refusal must not describe an action: {text}"
        );
        let structured = refused.structured_content.unwrap();
        assert_eq!(structured["refusal"]["code"], "invalid_element_token");
        assert_eq!(structured["reason"], "stale_bare_row");
        assert_eq!(structured["current_snapshot"], format_snapshot_id(second));
        assert_eq!(structured["window_id"], 100);

        // The full token from the read the caller meant still resolves — the
        // fix refuses the ambiguous form, it does not break element addressing.
        assert!(matches!(
            cache
                .resolve(
                    10,
                    &serde_json::json!({ "element_token": token_for(second, 1) })
                )
                .unwrap(),
            ResolvedElement::Element { element: 88, .. }
        ));
    }

    /// The same protection for a *different* caller re-reading the window: the
    /// row is not theirs to re-point either.
    #[test]
    fn another_sessions_read_retires_a_bare_row_number() {
        let cache = SnapshotStore::new();
        let first = cache
            .publish_for_session(10, 100, Payload(vec![1, 2]), Some("mine"), None)
            .unwrap()
            .0;
        cache
            .publish_for_session(10, 100, Payload(vec![7, 8]), Some("theirs"), None)
            .unwrap();

        let refused = cache
            .resolve(
                10,
                &serde_json::json!({
                    "window_id": 100,
                    "element_token": "0",
                    "_session_id": "mine",
                }),
            )
            .expect_err("a row printed by a replaced snapshot must be refused");
        let structured = refused.structured_content.unwrap();
        assert_eq!(structured["reason"], "stale_bare_row");
        assert_ne!(structured["current_snapshot"], format_snapshot_id(first));

        // A caller's own second read spends the convenience too: the number
        // still cannot say which of its two reads printed it.
        cache
            .publish_for_session(10, 100, Payload(vec![5, 6]), Some("mine"), None)
            .unwrap();
        let refused = cache
            .resolve(
                10,
                &serde_json::json!({
                    "window_id": 100,
                    "element_token": "1",
                    "_session_id": "mine",
                }),
            )
            .expect_err("two reads, one ambiguous number");
        assert_eq!(
            refused.structured_content.unwrap()["reason"],
            "stale_bare_row"
        );

        // A window this caller has read once is unambiguous.
        cache
            .publish_for_session(10, 101, Payload(vec![3, 4]), Some("mine"), None)
            .unwrap();
        assert!(matches!(
            cache
                .resolve(
                    10,
                    &serde_json::json!({
                        "window_id": 101,
                        "element_token": "1",
                        "_session_id": "mine",
                    }),
                )
                .unwrap(),
            ResolvedElement::Element { element: 4, .. }
        ));
    }

    /// A bare row number from a caller that has read nothing this session has
    /// no read behind it, and the refusal says so instead of guessing.
    #[test]
    fn a_bare_row_number_without_a_read_of_your_own_is_refused() {
        let cache = SnapshotStore::new();
        let current = cache
            .publish_for_session(10, 100, Payload(vec![1, 2]), Some("theirs"), None)
            .unwrap()
            .0;
        let refused = cache
            .resolve(
                10,
                &serde_json::json!({
                    "window_id": 100,
                    "element_token": "1",
                    "_session_id": "someone-else",
                }),
            )
            .expect_err("no read of mine, no row of mine");
        let text = crate::snapshot_test_support::text(&refused);
        assert!(text.contains("has not read"), "{text}");
        assert!(text.contains(&token_for(current, 1)), "{text}");
        assert_eq!(
            refused.structured_content.unwrap()["reason"],
            "unattributed_bare_row"
        );
    }

    /// The convenience still works where it is unambiguous: one read, still
    /// current, for the caller that made it.
    #[test]
    fn a_bare_row_number_resolves_after_the_callers_only_read() {
        let cache = SnapshotStore::new();
        cache.publish(10, 100, Payload(vec![10, 20, 30]));
        assert!(matches!(
            cache
                .resolve(
                    10,
                    &serde_json::json!({ "window_id": 100, "element_token": "1" }),
                )
                .unwrap(),
            ResolvedElement::Element { element: 20, .. }
        ));
    }

    #[test]
    fn out_of_range_row_explains_that_rows_belong_to_one_read() {
        let cache = SnapshotStore::new();
        let id = cache.publish(10, 20, Payload(vec![0; 44]));
        let refused = cache
            .resolve(
                10,
                &serde_json::json!({ "element_token": token_for(id, 48) }),
            )
            .unwrap_err();
        let text = crate::snapshot_test_support::text(&refused);
        assert!(
            text.contains("rows [0] to [43] only (44 element(s))"),
            "{text}"
        );
        assert!(text.contains("smaller max_elements"), "{text}");
        assert_eq!(
            refused.structured_content.unwrap()["refusal"]["code"],
            "invalid_element_token"
        );
    }

    #[test]
    fn window_relative_pixels_require_a_current_snapshot() {
        let cache = SnapshotStore::<Payload>::new();
        assert_eq!(scale(&cache, 20, "client-a"), None);
        cache.publish_for_session(10, 20, Payload(vec![]), Some("client-a"), Some(2.0));
        cache.remove(10, 20);
        assert_eq!(scale(&cache, 20, "client-a"), None);
    }

    #[test]
    fn window_less_screenshot_context_requires_one_agreed_transform() {
        let cache = SnapshotStore::new();
        assert!(cache
            .screenshot_context(10, None, Some("client-a"))
            .is_err());
        cache.publish_for_session(10, 20, Payload(vec![]), Some("client-a"), Some(2.0));
        cache.publish_for_session(10, 21, Payload(vec![]), Some("client-a"), Some(2.0));
        assert_eq!(
            cache
                .screenshot_context(10, None, Some("client-a"))
                .unwrap()
                .scale,
            2.0
        );
        cache.publish_for_session(10, 22, Payload(vec![]), Some("client-a"), Some(3.0));
        assert!(cache
            .screenshot_context(10, None, Some("client-a"))
            .is_err());
    }

    #[test]
    fn publication_reports_replaced_and_evicted_snapshots() {
        let cache = SnapshotStore::new();
        let (first, invalidated) = cache
            .publish_for_session(10, 0, Payload(vec![]), None, None)
            .unwrap();
        assert!(invalidated.is_empty());
        let (second, invalidated) = cache
            .publish_for_session(10, 0, Payload(vec![]), None, None)
            .unwrap();
        assert_eq!(invalidated, vec![first]);
        for window_id in 1..LRU_CAP_PER_PID as u64 {
            cache.publish(10, window_id, Payload(vec![]));
        }
        let (_, invalidated) = cache
            .publish_for_session(10, LRU_CAP_PER_PID as u64, Payload(vec![]), None, None)
            .unwrap();
        assert_eq!(invalidated, vec![second]);
    }

    #[test]
    fn session_retirement_removes_only_snapshots_owned_by_that_session() {
        let cache = SnapshotStore::new();
        cache.publish_for_session(10, 20, Payload(vec![]), Some("ending"), Some(7.35));
        cache.publish_for_session(10, 21, Payload(vec![]), Some("survivor"), Some(2.0));
        assert_eq!(cache.retire_session_screenshots("ending"), 1);
        assert_eq!(scale(&cache, 20, "ending"), None);
        assert_eq!(scale(&cache, 21, "survivor"), Some(2.0));
    }

    #[test]
    fn recreating_an_idle_reclaimed_implicit_session_keeps_its_old_tokens_stale() {
        use crate::session::{
            begin_session_dispatch, evict_idle_with_prefix, register_scoped_session_end_hook,
            SessionClientKind, SessionTransport,
        };
        let session = format!("snapshot-idle-implicit-{}", std::process::id());
        let cache = Arc::new(SnapshotStore::<Payload>::new());
        let retiring = cache.clone();
        let _hook = register_scoped_session_end_hook(move |ended| {
            retiring.retire_session_screenshots(ended);
        });
        let begin = || {
            begin_session_dispatch(
                &session,
                None,
                &session,
                true,
                SessionTransport::McpStdio,
                SessionClientKind::Mcp,
            )
        };
        let resolve =
            |token: &str| cache.resolve(10, &serde_json::json!({ "element_token": token }));

        let guard = begin().expect("first unnamed call starts the session");
        let (snapshot, _) = cache
            .publish_for_session(10, 20, Payload(vec![0, 1]), Some(&session), Some(1.0))
            .expect("live session publishes");
        let token = token_for(snapshot, 1);
        drop(guard);
        assert_eq!(
            evict_idle_with_prefix(std::time::Duration::ZERO, &session),
            std::slice::from_ref(&session)
        );

        let guard = begin().expect("next unnamed call recreates the session");
        assert!(resolve(&token).is_err());
        let (fresh, _) = cache
            .publish_for_session(10, 20, Payload(vec![0, 1]), Some(&session), Some(1.0))
            .expect("recreated session publishes again");
        assert!(matches!(
            resolve(&token_for(fresh, 1)).unwrap(),
            ResolvedElement::Element {
                window_id: 20,
                element: 1,
                ..
            }
        ));
        drop(guard);
        crate::session::end_session(&session);
        crate::session::revive_session(&session);
    }

    #[test]
    fn capture_completing_after_session_end_is_not_published() {
        let cache = SnapshotStore::new();
        let session = format!("snapshot-late-capture-{}", uuid::Uuid::new_v4());
        assert!(crate::session::fire_session_end(&session));
        assert_eq!(
            cache.publish_for_session(10, 20, Payload(vec![]), Some(&session), Some(7.35)),
            None
        );
        assert_eq!(scale(&cache, 20, &session), None);
    }

    #[test]
    fn zoom_context_is_bound_to_snapshot_session_and_window() {
        let cache = SnapshotStore::new();
        let snapshot = cache
            .publish_for_session(10, 20, Payload(vec![]), Some("client-a"), Some(7.35))
            .unwrap()
            .0;
        let context = zoom_on(snapshot, 7.35);
        cache.set_zoom(10, Some("client-a"), context).unwrap();

        assert_eq!(cache.zoom(10, Some(20), Some("client-a")).unwrap(), context);
        assert_eq!(cache.zoom(10, None, Some("client-a")).unwrap(), context);
        assert_eq!(context.zoom_to_window(3.0, 4.0), (106.0, 58.0));
        for (window_id, session) in [(20, "client-b"), (21, "client-a")] {
            assert_eq!(
                refusal_code(cache.zoom(10, Some(window_id), Some(session)).unwrap_err()),
                "zoom_context_missing"
            );
        }
    }

    #[test]
    fn window_only_screenshot_lookup_requires_one_current_owned_snapshot() {
        let cache = SnapshotStore::new();
        let first = cache
            .publish_for_session(10, 20, Payload(vec![]), Some("client-a"), Some(2.0))
            .unwrap()
            .0;
        assert_eq!(
            cache
                .screenshot_context_for_zoom(None, 20, Some("client-a"))
                .unwrap(),
            (
                10,
                ScreenshotContext {
                    snapshot_id: first,
                    window_id: 20,
                    scale: 2.0,
                }
            )
        );
        assert_eq!(
            cache
                .screenshot_context_for_zoom(Some(10), 20, Some("client-a"))
                .unwrap()
                .0,
            10
        );
        assert!(cache
            .screenshot_context_for_zoom(None, 20, Some("client-b"))
            .is_err());

        cache.publish_for_session(11, 20, Payload(vec![]), Some("client-a"), Some(1.0));
        assert!(cache
            .screenshot_context_for_zoom(None, 20, Some("client-a"))
            .is_err());
    }

    #[test]
    fn late_zoom_completion_cannot_replace_newer_valid_context() {
        let cache = SnapshotStore::new();
        let snapshot_a = cache
            .publish_for_session(10, 20, Payload(vec![]), Some("client-a"), Some(2.0))
            .unwrap()
            .0;
        let snapshot_b = cache
            .publish_for_session(10, 20, Payload(vec![]), Some("client-a"), Some(1.0))
            .unwrap()
            .0;
        let valid_b = zoom_on(snapshot_b, 1.0);
        cache.set_zoom(10, Some("client-a"), valid_b).unwrap();
        assert!(cache
            .set_zoom(10, Some("client-a"), zoom_on(snapshot_a, 2.0))
            .is_err());
        assert_eq!(cache.zoom(10, Some(20), Some("client-a")).unwrap(), valid_b);
    }

    #[test]
    fn newer_snapshot_or_session_end_retires_zoom() {
        let cache = SnapshotStore::new();
        let snapshot = cache
            .publish_for_session(10, 20, Payload(vec![]), Some("client-a"), Some(7.35))
            .unwrap()
            .0;
        cache
            .set_zoom(10, Some("client-a"), zoom_on(snapshot, 7.35))
            .unwrap();
        cache.publish_for_session(10, 20, Payload(vec![]), Some("client-b"), Some(1.0));
        assert_eq!(
            refusal_code(cache.zoom(10, Some(20), Some("client-a")).unwrap_err()),
            "zoom_context_missing"
        );

        let latest = cache
            .publish_for_session(10, 20, Payload(vec![]), Some("client-a"), Some(1.0))
            .unwrap()
            .0;
        cache
            .set_zoom(10, Some("client-a"), zoom_on(latest, 1.0))
            .unwrap();
        assert_eq!(cache.retire_session_screenshots("client-a"), 1);
        assert!(cache.zoom(10, Some(20), Some("client-a")).is_err());
    }

    struct DropCounter {
        owner: Weak<SnapshotStore<DropCounter>>,
        drops: Arc<AtomicUsize>,
    }
    impl SnapshotPayload for DropCounter {
        type Element = ();
        fn len(&self) -> usize {
            1
        }
        fn retain(&self, index: usize) -> Option<()> {
            (index == 0).then_some(())
        }
    }
    impl Drop for DropCounter {
        fn drop(&mut self) {
            if let Some(owner) = self.owner.upgrade() {
                assert!(
                    owner.inner.try_lock().is_ok(),
                    "native cleanup ran under the storage lock"
                );
            }
            self.drops.fetch_add(1, Ordering::SeqCst);
        }
    }

    #[test]
    fn session_retirement_drops_payload_outside_lock() {
        let cache = Arc::new(SnapshotStore::new());
        let drops = Arc::new(AtomicUsize::new(0));
        cache.publish_for_session(
            10,
            20,
            DropCounter {
                owner: Arc::downgrade(&cache),
                drops: drops.clone(),
            },
            Some("ending"),
            Some(2.0),
        );
        assert_eq!(cache.retire_session_screenshots("ending"), 1);
        assert_eq!(drops.load(Ordering::SeqCst), 1);
        assert!(cache.inner.lock().unwrap().lanes.is_empty());
    }

    #[test]
    fn replacement_remove_and_clear_run_drop_outside_lock() {
        let cache = Arc::new(SnapshotStore::new());
        let drops = Arc::new(AtomicUsize::new(0));
        let payload = || DropCounter {
            owner: Arc::downgrade(&cache),
            drops: drops.clone(),
        };
        cache.publish(1, 1, payload());
        assert_eq!(drops.load(Ordering::SeqCst), 0);
        cache.publish(1, 1, payload());
        assert_eq!(drops.load(Ordering::SeqCst), 1);
        cache.remove(1, 1);
        assert_eq!(drops.load(Ordering::SeqCst), 2);
        cache.publish(1, 1, payload());
        cache.clear();
        assert_eq!(drops.load(Ordering::SeqCst), 3);
    }

    #[test]
    fn window_identity_preserves_high_bits_through_resolution_and_retirement() {
        let cache = SnapshotStore::new();
        let low = 7;
        let high = (1_u64 << 32) | low;
        let first = cache.publish(42, low, Payload(vec![10]));
        let second = cache.publish(42, high, Payload(vec![20]));
        let token = serde_json::json!({ "element_token": token_for(second, 0) });
        assert!(matches!(
            cache.resolve(42, &token).unwrap(),
            ResolvedElement::Element { window_id, element: 20, .. } if window_id == high
        ));
        cache.remove(42, high);
        assert!(cache.resolve(42, &token).is_err());
        assert!(matches!(
            cache
                .resolve(
                    42,
                    &serde_json::json!({ "element_token": token_for(first, 0) })
                )
                .unwrap(),
            ResolvedElement::Element { window_id: 7, .. }
        ));
    }

    #[test]
    fn bindings_sharing_a_scope_keep_independent_payload_ownership() {
        crate::tool::with_runtime_scope("snapshot-binding-ownership".into(), || {
            let first = Arc::new(SnapshotStore::new());
            let second = Arc::new(SnapshotStore::new());
            register_runtime_store(&first);
            register_runtime_store(&second);
            let first_id = first.publish(42, 7, Payload(vec![10]));
            let second_id = second.publish(42, 7, Payload(vec![20]));
            assert!(second
                .resolve(
                    42,
                    &serde_json::json!({ "element_token": token_for(first_id, 0) })
                )
                .is_err());
            drop(first);
            let resolved = second
                .resolve(
                    42,
                    &serde_json::json!({ "element_token": token_for(second_id, 0) }),
                )
                .unwrap();
            assert!(matches!(
                resolved,
                ResolvedElement::Element { element: 20, .. }
            ));
            assert!(Arc::ptr_eq(
                &current_runtime_store::<Payload>().unwrap(),
                &second
            ));
            retire_runtime_scope("snapshot-binding-ownership");
        });
    }

    #[test]
    fn recording_discovery_does_not_extend_payload_lifetime() {
        crate::tool::with_runtime_scope("snapshot-weak-discovery".into(), || {
            let cache = Arc::new(SnapshotStore::new());
            let drops = Arc::new(AtomicUsize::new(0));
            cache.publish(
                42,
                7,
                DropCounter {
                    owner: Arc::downgrade(&cache),
                    drops: drops.clone(),
                },
            );
            register_runtime_store(&cache);
            assert_eq!(Arc::strong_count(&cache), 1);
            drop(cache);
            assert_eq!(drops.load(Ordering::SeqCst), 1);
            assert!(current_runtime_store::<DropCounter>().is_none());
            {
                let caches = runtime_stores().lock().unwrap();
                assert!(!caches.contains_key("snapshot-weak-discovery"));
                if caches.is_empty() {
                    assert_eq!(caches.capacity(), 0);
                }
            }
            assert_eq!(retire_runtime_scope("snapshot-weak-discovery"), 0);
        });
    }

    #[test]
    fn default_impl_matches_new() {
        let _cache: SnapshotStore<Payload> = SnapshotStore::default();
    }
}
