//! Offline AX-provider adapter: production schema and recipient validator, no OS input.
use cua_driver_contract::row::{discover_row, discover_row_traced, dispatch_row, RowBinding, RowGraph};
use cua_driver_contract::{ActionTarget, ClickInput, ToolInput};
use cua_driver_contract::row_window::{prove_window_member, WindowMembership, WindowReference};
// Synthetic provider only: no claim that this graph was captured from Chrome.
struct Membership<'a> { graph: &'a RowGraph, faults: &'a serde_json::Value, budget: usize, window_id: u64 }
impl Membership<'_> {
 fn node(&self,id:u64)->Result<&cua_driver_contract::row::RowNode,String>{self.graph.nodes.iter().find(|n|n.id==id).ok_or("missing held peer".into())}
}
impl WindowMembership for Membership<'_> {
 fn checkpoint(&mut self)->Result<(),String>{if self.budget==0{return Err("row census equality budget".into())}self.budget-=1;Ok(())}
 fn pid(&mut self,id:u64)->Result<u32,String>{Ok(self.node(id)?.pid)}
 fn window(&mut self,id:u64)->Result<WindowReference,String>{
  match self.faults[id.to_string()].as_str() {
   Some("no_value")=>Ok(WindowReference::NoValue),
   Some("unsupported")=>Err("AXWindow unreadable (-25205)".into()),
   Some("timeout")=>Err("AXWindow unreadable (-25204)".into()),
   Some("foreign")=>Ok(WindowReference::Direct(u64::MAX)),
   _=>if self.node(id)?.window_id==self.window_id {Ok(WindowReference::Direct(self.graph.root))}else{Err("row peer window mismatch".into())}
  }
 }
 fn parent(&mut self,id:u64)->Result<u64,String>{self.node(id)?.parent.ok_or("AXParent missing".into())}
 fn children(&mut self,id:u64)->Result<Vec<u64>,String>{Ok(self.node(id)?.children.clone())}
}
fn capture_membership(input:&serde_json::Value,graph:RowGraph,pid:u32,window_id:u64)->Result<RowGraph,String>{
 let mut p=Membership{graph:&graph,faults:&input["window_faults"],budget:input["membership_budget"].as_u64().unwrap_or(500000) as usize,window_id};
 for node in &graph.nodes {if node.id!=graph.root {prove_window_member(&mut p,node.id,graph.root,pid)?;}}
 Ok(graph)
}
use std::io::{self, Read};
fn main() {
    let mut text = String::new();
    io::stdin().read_to_string(&mut text).unwrap();
    let input: serde_json::Value = serde_json::from_str(&text).unwrap();
    if input["mode"] == "trace" {
        let graph: RowGraph = serde_json::from_value(input["graph"].clone()).unwrap();
        let pid = input["pid"].as_u64().unwrap() as u32;
        let window = input["window_id"].as_u64().unwrap();
        let recipient = input["recipient"].as_u64().unwrap();
        let off = discover_row(&graph, pid, window, recipient);
        let mut events = Vec::new();
        let on = discover_row_traced(&graph, pid, window, recipient, Some(&mut events));
        println!("{}", serde_json::json!({"off": off, "on": on, "keys": events}));
        return;
    }
    if input["mode"] == "discover" {
        let graph: RowGraph = serde_json::from_value(input["graph"].clone()).unwrap();
        let result = capture_membership(&input, graph, input["pid"].as_u64().unwrap() as u32, input["window_id"].as_u64().unwrap()).and_then(|graph| discover_row(
            &graph,
            input["pid"].as_u64().unwrap() as u32,
            input["window_id"].as_u64().unwrap(),
            input["recipient"].as_u64().unwrap(),
        ));
        println!(
            "{}",
            match result {
                Ok(binding) => serde_json::json!({"binding":binding}),
                Err(error) => serde_json::json!({"binding":null,"error":error}),
            }
        );
        return;
    }
    let parsed = serde_json::from_value::<ClickInput>(input["click"].clone())
        .map_err(|e| e.to_string())
        .and_then(|i| {
            i.validate()?;
            Ok(i)
        });
    let click = match parsed {
        Ok(click) => click,
        Err(error) => {
            println!(
                "{}",
                serde_json::json!({"schema_valid":false,"error":error,"presses":[]})
            );
            return;
        }
    };
    if input["mode"] != "dispatch" {
        println!("{}", serde_json::json!({"schema_valid":true}));
        return;
    }
    let binding: RowBinding = serde_json::from_value(input["binding"].clone()).unwrap();
    let graph =
        serde_json::from_value::<RowGraph>(input["graph"].clone()).map_err(|e| e.to_string());
    let ActionTarget::Window { pid, window_id } = click.target else {
        panic!("fixture requires window")
    };
    let graph = graph.and_then(|graph| capture_membership(&input, graph, pid, window_id));
    let recipient = input["recipient"].as_u64().unwrap();
    let mut presses = Vec::new();
    let receipt = dispatch_row(
        graph,
        &binding,
        click.expected_row.as_ref(),
        pid,
        window_id,
        recipient,
        || {
            if input["admission_error"] == true {
                Err("fixture focus lost before press".into())
            } else {
                Ok(())
            }
        },
        || {
            presses.push(recipient);
            if input["press_error"] == true {
                Err("fixture AXPress response lost".into())
            } else {
                Ok(())
            }
        },
    );
    println!(
        "{}",
        serde_json::json!({"schema_valid":true,"receipt":receipt,"presses":presses})
    );
}
