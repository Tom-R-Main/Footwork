// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Cua AI, Inc.

//! Browser state, preparation, navigation, input, and page-owned dialog tools.
//!
//! Schemas, annotations, and exact-or-refused semantics live here; OS
//! identity comes from the [`BrowserPlatform`] adapter; CDP mechanics
//! from [`super::engine`]. All structured outputs share the shape
//! `{"status": "ok" | "refused", ...}`.

use std::sync::Arc;
use std::time::{Duration, Instant};

use async_trait::async_trait;
use serde_json::{json, Value};

use crate::action_record::{
    effect_from_value_readback, ActionEffect, ActionEscalation, ActionEvidence,
    ActionExecutionRecord, ActionTransport, ActualDelivery, EscalationKind, EvidenceKind,
    RequestedDelivery,
};
use crate::protocol::{Content, ToolResult};
use crate::tool::{ProtectedResourceOwnership, Tool, ToolDef, ToolRegistry};
use crate::tool_args::ArgsExt;

use super::cdp_ws::CdpConnection;
use super::download::BrowserDownloadTool;
use super::engine::{BrowserEngine, BrowserTabScreenshot, DIALOG_SUBSCRIPTION_TIMEOUT};
use super::platform::{
    BrowserVisualActionKind, PrepareAction, PrepareProfile, PrepareProfileMode, PrepareRequest,
    PrepareStrategy,
};
use super::pointer::BrowserPointerTool;
use super::refusal::{BrowserRefusal, BrowserRefusalCode};
use super::session_schema as schema_session;
use super::store::{BrowserActionKind, FrameKind};
use super::types::BindingQuality;

/// Register the complete browser surface against one shared engine. Platform
/// crates call this from their `register_all` after constructing the
/// engine with their adapter.
pub fn register_browser_tools(engine: &Arc<BrowserEngine>, registry: &mut ToolRegistry) {
    registry.register(Box::new(GetBrowserStateTool::new(engine.clone())));
    registry.register(Box::new(BrowserPrepareTool::new(engine.clone())));
    registry.register(Box::new(BrowserNavigateTool::new(engine.clone())));
    registry.register(Box::new(BrowserClickTool::new(engine.clone())));
    registry.register(Box::new(BrowserTypeTool::new(engine.clone())));
    registry.register(Box::new(BrowserSelectTool::new(engine.clone())));
    registry.register(Box::new(BrowserDialogTool::new(engine.clone())));
    registry.register(Box::new(BrowserSetInputFilesTool::new(engine.clone())));
    registry.register(Box::new(BrowserDownloadTool::new(engine.clone())));
    registry.register(Box::new(BrowserPointerTool::new(engine.clone())));
}

// ── Shared helpers ───────────────────────────────────────────────────────────

const DOM_CLICK_READBACK: &str = r#"function() {
  const bounded = value => typeof value === 'string' ? value.slice(0, 512) : null;
  const attr = name => bounded(this.getAttribute(name));
  return {
    ariaPressed: attr('aria-pressed'),
    ariaSelected: attr('aria-selected'),
    ariaChecked: attr('aria-checked'),
    ariaExpanded: attr('aria-expanded'),
    ariaCurrent: attr('aria-current'),
    ariaDisabled: attr('aria-disabled'),
    disabled: 'disabled' in this ? Boolean(this.disabled) : null,
    checked: 'checked' in this ? Boolean(this.checked) : null,
    value: 'value' in this ? bounded(String(this.value)) : null,
    innerText: bounded(this.innerText),
    href: this.ownerDocument && this.ownerDocument.location
      ? bounded(this.ownerDocument.location.href)
      : null
  };
}"#;

const DOM_CLICK_READBACK_DEADLINE: Duration = Duration::from_millis(400);
/// The pre-click baseline gets a larger budget than the post-click polls: a
/// loaded Windows Edge can take longer than 400 ms to answer the first
/// `Runtime.callFunctionOn`, and a missed baseline turns a verifiable click
/// into "readback unavailable" for the whole action.
const DOM_CLICK_BASELINE_DEADLINE: Duration = Duration::from_millis(1_000);
const DOM_CLICK_READBACK_INTERVAL: Duration = Duration::from_millis(25);

struct DomClickObservation {
    effect: ActionEffect,
    readback_available: bool,
}

async fn read_dom_click_state(
    conn: &CdpConnection,
    cdp: &str,
    object_id: &str,
    budget: Duration,
) -> Option<Value> {
    tokio::time::timeout(
        budget,
        conn.call(
            Some(cdp),
            "Runtime.callFunctionOn",
            json!({
                "objectId": object_id,
                "functionDeclaration": DOM_CLICK_READBACK,
                "returnByValue": true,
            }),
        ),
    )
    .await
    .ok()
    .and_then(Result::ok)
    .and_then(|reply| reply.pointer("/result/value").cloned())
    .filter(Value::is_object)
}

fn dom_click_state_changed(before: &Value, after: &Value) -> bool {
    before
        .as_object()
        .zip(after.as_object())
        .is_some_and(|(before, after)| before != after)
}

async fn observe_dom_click(
    conn: &CdpConnection,
    cdp: &str,
    object_id: &str,
    before: Option<Value>,
) -> DomClickObservation {
    let Some(before) = before else {
        return DomClickObservation {
            effect: effect_from_value_readback(false, false, false),
            readback_available: false,
        };
    };
    let started = Instant::now();
    loop {
        if started.elapsed() >= DOM_CLICK_READBACK_DEADLINE {
            return DomClickObservation {
                effect: ActionEffect::Unverifiable,
                readback_available: true,
            };
        }
        // The window only decides whether to start another read; each read
        // keeps a full budget. Clipping an in-flight read to the window's
        // remainder reported a slow-but-answering page as "readback
        // unavailable" instead of "state unchanged".
        if let Some(after) =
            read_dom_click_state(conn, cdp, object_id, DOM_CLICK_READBACK_DEADLINE).await
        {
            if dom_click_state_changed(&before, &after) {
                return DomClickObservation {
                    effect: effect_from_value_readback(true, true, true),
                    readback_available: true,
                };
            }
        } else {
            return DomClickObservation {
                effect: effect_from_value_readback(false, false, false),
                readback_available: false,
            };
        }
        tokio::time::sleep(DOM_CLICK_READBACK_INTERVAL).await;
    }
}

fn dom_click_action_record(observation: &DomClickObservation) -> ActionExecutionRecord {
    let mut builder = ActionExecutionRecord::builder(
        observation.effect,
        ActionTransport::BrowserCdpRuntimeFunction,
        RequestedDelivery::NotApplicable,
    )
    .actual_delivery(ActualDelivery::Background);
    if observation.readback_available {
        builder = builder.evidence(ActionEvidence {
            kind: EvidenceKind::BrowserReadback,
            detail: if observation.effect == ActionEffect::Confirmed {
                "bounded semantic target state changed".to_owned()
            } else {
                "bounded semantic target state remained unchanged".to_owned()
            },
        });
    }
    if observation.effect != ActionEffect::Confirmed {
        builder = builder.escalation(ActionEscalation {
            kind: EscalationKind::RetryWithPageAction,
            detail: Some(if observation.readback_available {
                "bounded semantic target state remained unchanged; application effect is unverifiable"
                    .to_owned()
            } else {
                "semantic target readback was unavailable".to_owned()
            }),
        });
    }
    builder
        .build()
        .expect("DOM click action record must satisfy the stable contract")
}

/// What a DOM click sequence's reply says about its delivery. Only a
/// well-formed receipt counts: an exception, a missing value or any other
/// shape is an interrupted click, never a completed or an undelivered one.
#[derive(Debug, PartialEq)]
enum DomClickReceipt {
    Completed,
    Detached {
        count: u64,
        last: String,
    },
    /// A filmed click found its point off the node and sent nothing.
    Misplaced,
    /// A filmed click's node left its point during the hover events, before
    /// the press: `count` hover and move events were sent and nothing else.
    Left {
        count: u64,
        last: String,
    },
    Interrupted(&'static str),
}

fn dom_click_receipt(reply: &Value) -> DomClickReceipt {
    if reply.get("exceptionDetails").is_some() {
        return DomClickReceipt::Interrupted("the sequence threw");
    }
    let Some(value) = reply.pointer("/result/value") else {
        return DomClickReceipt::Interrupted("no completion receipt");
    };
    let count = value.get("count").and_then(Value::as_u64);
    match (
        value.get("complete").and_then(Value::as_bool),
        value.get("stopped"),
        count,
    ) {
        (Some(true), Some(Value::Null), Some(_)) => DomClickReceipt::Completed,
        (Some(false), Some(Value::String(stopped)), Some(0)) if stopped == "not_under_pointer" => {
            DomClickReceipt::Misplaced
        }
        (Some(false), Some(Value::String(stopped)), Some(count))
            if stopped == "left_pointer" && count > 0 =>
        {
            match value.get("last").and_then(Value::as_str) {
                Some(last) if !last.is_empty() => DomClickReceipt::Left {
                    count,
                    last: last.to_owned(),
                },
                _ => DomClickReceipt::Interrupted("a malformed receipt"),
            }
        }
        (Some(false), Some(Value::String(stopped)), Some(count)) if stopped == "detached" => {
            match value.get("last").and_then(Value::as_str) {
                Some(last) if count == 0 || !last.is_empty() => DomClickReceipt::Detached {
                    count,
                    last: last.to_owned(),
                },
                _ => DomClickReceipt::Interrupted("a malformed receipt"),
            }
        }
        _ => DomClickReceipt::Interrupted("a malformed receipt"),
    }
}

/// What a DOM click does after its sequence call returns.
#[derive(Debug, PartialEq)]
enum DomClickNext {
    /// The sequence completed: read the target back.
    Readback,
    /// A page dialog interrupted the sequence or is blocking the page.
    Dialog(super::cdp_ws::CdpDialogState),
    /// The ref's node left its document before the first event.
    Refuse,
    /// A filmed click's point was not on the ref's node; no event was sent.
    Misplaced,
    /// A filmed click's node left its point before the press; only hover and
    /// move events were sent.
    Left {
        count: u64,
        last: String,
    },
    Partial {
        count: u64,
        last: String,
    },
    Interrupted(&'static str),
    Failed(String),
}

/// Decide from the call's outcome and one dialog snapshot. A dialog the call
/// helper saw interrupt the sequence stays the outcome even if it has closed
/// since, and readback is reachable only from a completed receipt, so a
/// sequence that never reported completing cannot be read back as confirmed.
fn dom_click_next(
    outcome: Result<anyhow::Result<Value>, super::cdp_ws::CdpDialogState>,
    dialog_now: impl FnOnce() -> Option<super::cdp_ws::CdpDialogState>,
) -> DomClickNext {
    let reply = match outcome {
        Err(open) => return DomClickNext::Dialog(open),
        Ok(Err(error)) => return DomClickNext::Failed(error.to_string()),
        Ok(Ok(reply)) => reply,
    };
    if let Some(open) = dialog_now() {
        return DomClickNext::Dialog(open);
    }
    match dom_click_receipt(&reply) {
        DomClickReceipt::Completed => DomClickNext::Readback,
        DomClickReceipt::Detached { count: 0, .. } => DomClickNext::Refuse,
        DomClickReceipt::Misplaced => DomClickNext::Misplaced,
        DomClickReceipt::Left { count, last } => DomClickNext::Left { count, last },
        DomClickReceipt::Detached { count, last } => DomClickNext::Partial { count, last },
        DomClickReceipt::Interrupted(reason) => DomClickNext::Interrupted(reason),
    }
}

fn dom_click_stopped_action_record(count: u64, last: &str) -> ActionExecutionRecord {
    ActionExecutionRecord::builder(
        ActionEffect::Unverifiable,
        ActionTransport::BrowserCdpRuntimeFunction,
        RequestedDelivery::NotApplicable,
    )
    .actual_delivery(ActualDelivery::Background)
    .evidence(ActionEvidence {
        kind: EvidenceKind::EventReceipt,
        detail: format!(
            "the click sequence stopped after {last} because the ref's node left its document; \
             {count} events sent"
        ),
    })
    .escalation(ActionEscalation {
        kind: EscalationKind::RefreshPageState,
        detail: Some("the ref's node left its document during the click".to_owned()),
    })
    .build()
    .expect("DOM click action record must satisfy the stable contract")
}

fn dom_click_interrupted_action_record(reason: &str) -> ActionExecutionRecord {
    ActionExecutionRecord::builder(
        ActionEffect::Unverifiable,
        ActionTransport::BrowserCdpRuntimeFunction,
        RequestedDelivery::NotApplicable,
    )
    .actual_delivery(ActualDelivery::Background)
    .escalation(ActionEscalation {
        kind: EscalationKind::RefreshPageState,
        detail: Some(format!(
            "the click sequence did not report completing: {reason}"
        )),
    })
    .build()
    .expect("DOM click action record must satisfy the stable contract")
}

/// The public caller session id, falling back to the daemon's internal mirror.
fn session_of(args: &Value) -> String {
    args.opt_str("session")
        .or_else(|| args.opt_str("_session_id"))
        .unwrap_or_else(|| "default".into())
}

/// Target/ref minting requires an explicit (non-default) session so the
/// capability namespace has a real owner whose end event cleans it up.
fn require_explicit_session(args: &Value) -> Result<String, ToolResult> {
    let sid = session_of(args);
    if sid.is_empty() || sid == "default" {
        return Err(ToolResult::error(
            "Browser targets and page refs are session-scoped capabilities — declare an \
             explicit session (start_session) and pass its id on this call.",
        ));
    }
    Ok(sid)
}

/// `delivery_mode` of a trusted page mutation: `background` (default)
/// refuses trusted input that would activate the browser window on platforms
/// where the trusted route cannot stay in the background; `foreground`
/// accepts that activation. Returns true for `foreground`.
pub(crate) fn parse_delivery_mode(args: &Value) -> Result<bool, String> {
    match args.get("delivery_mode").and_then(Value::as_str) {
        None => Ok(false),
        Some(mode) if mode.eq_ignore_ascii_case("background") => Ok(false),
        Some(mode) if mode.eq_ignore_ascii_case("foreground") => Ok(true),
        Some(other) => Err(format!(
            "delivery_mode must be \"background\" or \"foreground\", got {other:?}"
        )),
    }
}

fn schema_delivery_mode() -> Value {
    json!({
        "type": "string",
        "enum": ["background", "foreground"],
        "default": "background",
        "description": "background (default) refuses trusted input where it would activate the browser window, including Linux Chromium and macOS Chromium configurations whose trusted route cannot stay in the background. foreground accepts that activation, for a browser whose window nobody else is using (for example inside a sandbox)."
    })
}

fn schema_target_id() -> Value {
    json!({
        "type": "string",
        "description": "Opaque browser target id minted by get_browser_state \
            (session-scoped; never a CDP id)."
    })
}

fn schema_tab_id() -> Value {
    json!({
        "type": "string",
        "description": "Opaque tab id from get_browser_state (session-scoped)."
    })
}

fn schema_ref() -> Value {
    json!({
        "type": "string",
        "description": "Page element ref in the p<snapshot>:<index> namespace from \
            get_browser_state. Refs are invalidated by navigation and by newer \
            snapshots of the same tab."
    })
}

pub(crate) async fn browser_resource_ownership(
    engine: &BrowserEngine,
    args: &Value,
) -> ProtectedResourceOwnership {
    let Some(session) = args
        .get("session")
        .and_then(Value::as_str)
        .filter(|session| !session.is_empty())
    else {
        return ProtectedResourceOwnership::UserOwned;
    };
    let runtime_session = crate::tool::current_dispatch_authorization_context()
        .map(|context| context.runtime_session_key(session))
        .unwrap_or_else(|| session.to_owned());
    let pid = args.get("pid").and_then(Value::as_i64).or_else(|| {
        args.get("target_id")
            .and_then(Value::as_str)
            .and_then(|target_id| engine.store.get_target(&runtime_session, target_id).ok())
            .map(|target| target.pid)
    });
    let Some(pid) = pid else {
        return ProtectedResourceOwnership::UserOwned;
    };
    if engine
        .is_driver_owned_pid_for_session(&runtime_session, pid)
        .await
        || engine.is_driver_owned_pid_for_session(session, pid).await
    {
        ProtectedResourceOwnership::DriverOwned
    } else {
        ProtectedResourceOwnership::UserOwned
    }
}

pub(crate) async fn browser_protected_resource_scope(
    engine: &BrowserEngine,
    args: &Value,
    tool_name: &str,
) -> Result<Option<Value>, crate::tool::ProtectedResourceScopeError> {
    let session = args
        .get("session")
        .and_then(Value::as_str)
        .filter(|session| !session.is_empty())
        .ok_or_else(|| "the browser operation requires an explicit session".to_owned())?;
    let target_id = args
        .get("target_id")
        .and_then(Value::as_str)
        .filter(|target| !target.is_empty())
        .ok_or_else(|| "the browser operation requires an exact target_id".to_owned())?;
    let tab_id = args
        .get("tab_id")
        .and_then(Value::as_str)
        .filter(|tab| !tab.is_empty())
        .ok_or_else(|| "the browser operation requires an exact tab_id".to_owned())?;
    let runtime_session = crate::tool::current_dispatch_authorization_context()
        .map(|context| context.runtime_session_key(session))
        .unwrap_or_else(|| session.to_owned());
    let (validated, live_origin) = engine
        .attest_protected_tab(&runtime_session, target_id, tab_id)
        .await?;
    let target = validated.record;
    let tab = validated.tab;
    let requested_origin = if tool_name == "browser_navigate" {
        let requested = args
            .get("url")
            .and_then(Value::as_str)
            .ok_or_else(|| "browser_navigate requires a destination URL".to_owned())?;
        if requested.to_ascii_lowercase().starts_with("about:") {
            Some("about:".to_owned())
        } else {
            let parsed = url::Url::parse(requested)
                .map_err(|_| "the destination URL is invalid".to_owned())?;
            Some(parsed.origin().ascii_serialization())
        }
    } else {
        None
    };
    let action_class = match tool_name {
        "get_browser_state" => "page_observation",
        "browser_navigate" => "navigation",
        "browser_dialog" => "page_dialog_resolution",
        _ => "page_input",
    };
    let mut resource = json!({
        "kind": "authenticated_browser_tab",
        "target_id": target_id,
        "tab_id": tab_id,
        "pid": target.pid,
        "process_fingerprint": target.fingerprint,
        "binding_generation": target.generation,
        "cdp_target_id": tab.cdp_target_id,
        "tab_generation": tab.generation,
        "live_origin": live_origin,
        "requested_origin": requested_origin,
        "action_class": action_class,
    });
    if tool_name == "browser_dialog" {
        resource["dialog_id"] = args.get("dialog_id").cloned().unwrap_or(Value::Null);
        resource["dialog_action"] = args.get("action").cloned().unwrap_or(Value::Null);
        resource["delivery_mode"] = Value::String(
            args.get("delivery_mode")
                .and_then(Value::as_str)
                .unwrap_or("background")
                .to_owned(),
        );
        resource["prompt_text_present"] =
            Value::Bool(args.get("prompt_text").and_then(Value::as_str).is_some());
    }
    Ok(Some(resource))
}

fn semantic_ref_value(listed: &super::engine::SemanticListedRef) -> Value {
    json!({
        "ref": listed.external,
        "role": listed.node.role,
        "name": listed.node.name,
        "value": listed.node.value,
        "states": listed.node.states,
        "actions": listed.node.actions.iter().map(|action| action.as_str()).collect::<Vec<_>>(),
        "frame": listed.node.frame.kind.as_str(),
        "visibility": listed.node.visibility.as_str(),
    })
}

fn with_tab_screenshot(mut result: ToolResult, screenshot: BrowserTabScreenshot) -> ToolResult {
    if let Some(structured) = result.structured_content.as_mut() {
        structured["screenshot"] = json!({
            "source": "cdp_tab",
            "scope": "viewport",
            "mime_type": "image/png",
            "width": screenshot.width,
            "height": screenshot.height,
            "coordinate_space": "viewport_css_px",
            "viewport_css_width": screenshot.viewport_css_width,
            "viewport_css_height": screenshot.viewport_css_height,
            "pixel_to_css_scale_x": screenshot.pixel_to_css_scale_x,
            "pixel_to_css_scale_y": screenshot.pixel_to_css_scale_y,
            "tab_activation": "not_requested",
            "window_foregrounding": "not_requested",
        });
        structured["screenshot_width"] = json!(screenshot.width);
        structured["screenshot_height"] = json!(screenshot.height);
        structured["screenshot_mime_type"] = json!("image/png");
    }
    result
        .content
        .insert(0, Content::image_png(screenshot.data_base64));
    result
}

// ── get_browser_state ────────────────────────────────────────────────────────

pub struct GetBrowserStateTool {
    def: ToolDef,
    engine: Arc<BrowserEngine>,
}

impl GetBrowserStateTool {
    pub fn new(engine: Arc<BrowserEngine>) -> Self {
        let def = ToolDef {
            name: "get_browser_state".into(),
            description: "Read-only browser inspection. Mode 1 (bind): pass pid + \
                window_id of a native browser window to classify it, correlate it to \
                a CDP target (exact-or-refuse), and mint a session-scoped target id \
                plus tab ids. Mode 2 (snapshot): pass target_id + tab_id. The \
                dom_refs_v1 compatibility format returns composed DOM refs. \
                semantic_v2 joins accessibility, DOM, layout, and viewport state; \
                ranks visible content before retained/offscreen state; and returns a \
                semantic outline, typed action refs, content refs, scoped reads, and \
                opaque continuation. Mode 3 (locate): pass target_id + tab_id + \
                locate_ref to read where one current ref's element is in the viewport, \
                what is at its centre, whether a clipping ancestor hides part of it \
                and whether its document is showing; with locate_point, also what is \
                at that point. It scrolls nothing and mints no snapshot. \
                Never performs setup: a browser that is not \
                attached yet refuses with browser_consent_required or \
                browser_requires_setup, and detail.next_call names the browser_prepare call \
                that attaches it. Use this route for any web page in Chrome, Edge or Brave; \
                desktop pointer tools move the user's pointer."
                .into(),
            input_schema: json!({
                "type": "object",
                "properties": {
                    "pid": { "type": "integer", "description": "Native browser process id (bind mode)." },
                    "window_id": { "type": "integer", "description": "Native window id owned by pid (bind mode)." },
                    "target_id": schema_target_id(),
                    "tab_id": schema_tab_id(),
                    "session": schema_session(),
                    "snapshot_format": {
                        "type": "string",
                        "enum": ["dom_refs_v1", "semantic_v2"],
                        "description": "Versioned snapshot contract. dom_refs_v1 remains the compatibility default."
                    },
                    "scope_ref": {
                        "type": "string",
                        "description": "Current semantic/content ref whose subtree should be observed."
                    },
                    "query": {
                        "type": "string",
                        "description": "Read-only semantic match over role, accessible name, and visible text."
                    },
                    "continuation": {
                        "type": "string",
                        "description": "Opaque continuation minted by an earlier semantic_v2 response."
                    },
                    "locate_ref": {
                        "type": "string",
                        "description": "A current ref. Returns only `locate`: the element's \
                            rectangle and centre in viewport CSS px, whether the element at \
                            that centre is the target or inside it, the border-box centre \
                            from DOM.getBoxModel, the viewport's size, zoom and pinch \
                            scale, `clipped` (an ancestor that clips or scrolls its overflow \
                            hides part of the rectangle), `visibility_state` (the \
                            document's), `focused` (the element is its root's active \
                            element) and `page_focused` (its document has focus). The page \
                            is read in an isolated world (`world`), out of reach of the \
                            page's own script. Read-only: nothing is scrolled, focused or \
                            dispatched, and no snapshot is taken. Unavailable for a ref in a \
                            child frame, or when no isolated world can be made."
                    },
                    "locate_point": {
                        "type": "object",
                        "properties": { "x": { "type": "number" }, "y": { "type": "number" } },
                        "required": ["x", "y"],
                        "description": "With locate_ref: a point in viewport CSS px. `locate.point` \
                            then says whether the element at that point is the ref's element, \
                            inside it, another element or none."
                    },
                    "include_screenshot": {
                        "type": "boolean",
                        "default": false,
                        "description": "Capture the exact tab viewport as PNG through CDP without selecting the tab or foregrounding its native window. The request refuses if capture cannot be completed."
                    },
                },
                "additionalProperties": true
            }),
            read_only: true,
            destructive: false,
            idempotent: true,
            open_world: false,
        };
        Self { def, engine }
    }
}

#[async_trait]
impl Tool for GetBrowserStateTool {
    fn def(&self) -> &ToolDef {
        &self.def
    }

    async fn protected_resource_ownership(
        &self,
        adapter_id: &str,
        args: &Value,
    ) -> ProtectedResourceOwnership {
        if adapter_id == "private_observation" {
            browser_resource_ownership(&self.engine, args).await
        } else {
            ProtectedResourceOwnership::UserOwned
        }
    }

    async fn protected_resource_scope(
        &self,
        adapter_id: &str,
        args: &Value,
    ) -> Result<Option<Value>, crate::tool::ProtectedResourceScopeError> {
        if adapter_id == "private_observation"
            && args.get("target_id").and_then(Value::as_str).is_some()
        {
            browser_protected_resource_scope(&self.engine, args, "get_browser_state").await
        } else {
            Ok(None)
        }
    }

    async fn invoke(&self, args: Value) -> ToolResult {
        // Snapshot mode: target_id (+ tab_id) — uses existing capabilities.
        if let Some(target_id) = args.opt_str("target_id") {
            let session = match require_explicit_session(&args) {
                Ok(s) => s,
                Err(e) => return e,
            };
            let tab_id = match args.opt_str("tab_id") {
                Some(t) => t,
                None => {
                    return BrowserRefusal::new(
                        BrowserRefusalCode::BrowserTabRequired,
                        "snapshot mode requires a tab_id from a prior bind",
                    )
                    .to_tool_result()
                }
            };
            if let Some(locate_ref) = args.opt_str("locate_ref") {
                let locate_point = match point_arg(&args, "locate_point") {
                    Ok(point) => point,
                    Err(error) => return error,
                };
                return match locate_browser_ref(
                    &self.engine,
                    &session,
                    &target_id,
                    &tab_id,
                    &locate_ref,
                    locate_point,
                )
                .await
                {
                    Ok(locate) => ToolResult::text(format!(
                        "located {locate_ref} in {tab_id}; nothing was scrolled or dispatched"
                    ))
                    .with_structured(json!({
                        "status": "ok",
                        "mode": "locate",
                        "target_id": target_id,
                        "tab_id": tab_id,
                        "ref": locate_ref,
                        "locate": locate,
                    })),
                    Err(refusal) => refusal.to_tool_result(),
                };
            }
            let snapshot_format = args
                .opt_str("snapshot_format")
                .unwrap_or_else(|| "dom_refs_v1".into());
            let include_screenshot = match args.get("include_screenshot") {
                None => false,
                Some(Value::Bool(include)) => *include,
                Some(_) => {
                    return ToolResult::error(
                        "Field include_screenshot has wrong type: expected boolean",
                    )
                }
            };
            if snapshot_format != "dom_refs_v1" && snapshot_format != "semantic_v2" {
                return ToolResult::error(format!(
                    "snapshot_format must be \"dom_refs_v1\" or \"semantic_v2\", got {snapshot_format:?}"
                ));
            }
            if snapshot_format == "dom_refs_v1"
                && (args.opt_str("scope_ref").is_some()
                    || args.opt_str("query").is_some()
                    || args.opt_str("continuation").is_some())
            {
                return ToolResult::error(
                    "scope_ref, query, and continuation require snapshot_format=\"semantic_v2\"",
                );
            }
            if snapshot_format == "semantic_v2" {
                let snapshot = match self
                    .engine
                    .snapshot_tab_semantic(
                        &session,
                        &target_id,
                        &tab_id,
                        args.opt_str("scope_ref").as_deref(),
                        args.opt_str("query").as_deref(),
                        args.opt_str("continuation").as_deref(),
                    )
                    .await
                {
                    Ok(outcome) => {
                        let refs = outcome
                            .refs
                            .iter()
                            .map(semantic_ref_value)
                            .collect::<Vec<_>>();
                        let content_refs = outcome
                            .content_refs
                            .iter()
                            .map(semantic_ref_value)
                            .collect::<Vec<_>>();
                        ToolResult::text(format!(
                            "semantic snapshot p{} of {}: {} action ref(s), {} content ref(s)",
                            outcome.snapshot_id,
                            outcome.url,
                            refs.len(),
                            content_refs.len()
                        ))
                        .with_structured(json!({
                            "status": "ok",
                            "mode": "snapshot",
                            "target_id": target_id,
                            "tab_id": tab_id,
                            "snapshot": {
                                "id": format!("p{}", outcome.snapshot_id),
                                "format": "semantic_v2",
                                "complete": outcome.complete,
                                "scope": outcome.scope,
                                "selected_nodes": outcome.selected_nodes,
                                "total_nodes": outcome.total_nodes,
                                "node_budget": super::semantic::DEFAULT_SEMANTIC_NODE_BUDGET,
                                "omitted": {
                                    "css_hidden": outcome.omissions.css_hidden,
                                    "offscreen": outcome.omissions.offscreen,
                                    "page_occluded": outcome.omissions.page_occluded,
                                    "no_layout": outcome.omissions.no_layout,
                                    "unknown": outcome.omissions.unknown,
                                    "budget": outcome.omissions.budget,
                                    "unprovable_frame": outcome.omissions.unprovable_frame,
                                    "not_rendered": outcome.omissions.not_rendered,
                                },
                                "continuation": outcome.continuation,
                                "hint": (outcome.omissions.not_rendered > 0).then_some("Chrome has not rendered this background tab, so this tree is partial. Bring the tab to the front in the browser, then re-run get_browser_state; observation never activates tabs."),
                            },
                            "page": {
                                "url": outcome.url,
                                "title": outcome.title,
                            },
                            "outline": outcome.outline,
                            "refs": refs,
                            "content_refs": content_refs,
                            "oopif": {
                                "status": outcome.oopif.as_str(),
                                "frames": outcome.oopif.frames(),
                            },
                        }))
                    }
                    Err(refusal) => return refusal.to_tool_result(),
                };
                if include_screenshot {
                    return match self
                        .engine
                        .capture_tab_screenshot(&session, &target_id, &tab_id)
                        .await
                    {
                        Ok(screenshot) => with_tab_screenshot(snapshot, screenshot),
                        Err(refusal) => refusal.to_tool_result(),
                    };
                }
                return snapshot;
            }
            let snapshot = match self
                .engine
                .snapshot_tab(&session, &target_id, &tab_id)
                .await
            {
                Ok(outcome) => {
                    let ref_list: Vec<Value> = outcome
                        .refs
                        .iter()
                        .map(|(ext, entry)| {
                            json!({
                                "ref": ext,
                                "node": entry.node_name,
                                "label": entry.label,
                                "frame": entry.frame.kind.as_str(),
                            })
                        })
                        .collect();
                    ToolResult::text(format!(
                        "snapshot p{} of {}: {} interactive element(s)",
                        outcome.snapshot_id,
                        outcome.url,
                        ref_list.len()
                    ))
                    .with_structured(json!({
                        "status": "ok",
                        "mode": "snapshot",
                        "target_id": target_id,
                        "tab_id": tab_id,
                        "snapshot_id": format!("p{}", outcome.snapshot_id),
                        "url": outcome.url,
                        "refs": ref_list,
                        "truncated": outcome.truncated,
                        "oopif": {
                            "status": outcome.oopif.as_str(),
                            "frames": outcome.oopif.frames(),
                        },
                    }))
                }
                Err(refusal) => return refusal.to_tool_result(),
            };
            if include_screenshot {
                return match self
                    .engine
                    .capture_tab_screenshot(&session, &target_id, &tab_id)
                    .await
                {
                    Ok(screenshot) => with_tab_screenshot(snapshot, screenshot),
                    Err(refusal) => refusal.to_tool_result(),
                };
            }
            return snapshot;
        }

        // Bind mode: pid + window_id.
        let pid = match args.require_i64("pid") {
            Ok(v) => v,
            Err(e) => return e,
        };
        let window_id = match args.require_u64("window_id") {
            Ok(v) => v,
            Err(e) => return e,
        };
        let session = match require_explicit_session(&args) {
            Ok(s) => s,
            Err(e) => return e,
        };

        let transport_session = args.opt_str("_transport_session_id");
        match self
            .engine
            .bind_native(&session, transport_session.as_deref(), pid, window_id)
            .await
        {
            Ok((target_id, record)) => {
                let tabs: Vec<Value> = record
                    .tabs
                    .values()
                    .map(|t| {
                        json!({
                            "tab_id": t.tab_id,
                            "title": t.title,
                            "url": t.url,
                            "active": t.active,
                        })
                    })
                    .collect();
                let quality = match record.quality {
                    BindingQuality::Exact => "exact",
                    BindingQuality::Heuristic => "heuristic",
                };
                let binding_route = if record.cdp_window_id.is_some() {
                    "native_cdp_window"
                } else {
                    "embedded_single_page"
                };
                ToolResult::text(format!(
                    "bound target {target_id} ({quality}) with {} tab(s)",
                    tabs.len()
                ))
                .with_structured(json!({
                    "status": "ok",
                    "mode": "bind",
                    "target_id": target_id,
                    "binding_quality": quality,
                    "binding_route": binding_route,
                    "endpoint_transport": record.endpoint_transport,
                    "endpoint_access_class": record.endpoint_access_class,
                    "mutation_allowed": record.quality == BindingQuality::Exact,
                    "native_title": record.native_title,
                    "tabs": tabs,
                }))
            }
            Err(refusal) => refusal.to_tool_result(),
        }
    }
}

// ── browser_prepare ──────────────────────────────────────────────────────────

pub struct BrowserPrepareTool {
    def: ToolDef,
    engine: Arc<BrowserEngine>,
}

impl BrowserPrepareTool {
    pub fn new(engine: Arc<BrowserEngine>) -> Self {
        let def = ToolDef {
            name: "browser_prepare".into(),
            description: "Attach the browser tools to a browser. For a page in the user's \
                running Chrome, Edge or Brave, call it once with pid, window_id, session and \
                strategy {\"kind\":\"existing_profile\"} when get_browser_state refuses with \
                browser_consent_required or browser_requires_setup; then call \
                get_browser_state again and act with browser_click, browser_type or \
                browser_pointer. It attaches, or refuses with nothing changed and says why. \
                Explicitly prepare an owned DevTools endpoint for a browser. \
                pid is required for an existing process or existing-profile attachment, \
                and optional only for allow_launch=true with an isolated profile. Existing \
                endpoints are detected without side effects. Acting setup \
                for an isolated profile follows the runtime permission mode and optional \
                capability manifest. It requires allow_launch=true, launches a separate browser, and never \
                copies, modifies, or terminates the requested user profile. Without pid, only a \
                platform-attested system Chrome/Edge installation (or a root-owned package \
                payload on Linux) is eligible; redirects and user-controlled locations fail closed. Existing-profile \
                attachment is explicit and follows the runtime's immutable permission mode: \
                standard requires an explicit --grant existing-profile launch grant or an \
                embedding authorization host, bounded requires a launch-approved exact resource \
                manifest, and unrestricted requires explicit trusted startup risk acceptance. \
                Ordinary MCP transport approval never proves profile authorization. On proven platforms, an \
                authorized request also permits one bounded exact-window setup: \
                open the recognized browser product's fixed remote-debugging page, toggle \
                its uniquely matched per-instance checkbox, prove the PID-owned loopback \
                endpoint, and close the temporary tab. Every visible effect is reported; \
                ambiguity is refused. Where attaching would bring the browser in front of \
                the user's app (macOS Chrome shows its own remote-debugging prompt in front \
                whenever the driver opens a new browser connection; sessions for the same \
                browser share one approved connection, kept for up to 30 minutes idle and \
                8 hours in total, so later sessions do not prompt again), existing-profile \
                attachment refuses with \
                background_unavailable unless delivery_mode is \"foreground\" (the app that \
                was in front is brought back afterwards) or the browser window is on another \
                Space than the user's, where it attaches in the background while the driver \
                reverts the browser's own brief activations. A driver-owned isolated launch \
                result carries an advisory lifecycle object: the browser process ends with the \
                calling session after idle_expires_in_seconds without session activity, an \
                isolated_named profile persists after the session and an isolated_new profile \
                does not, and explicit end, disconnect, revocation or shutdown end it earlier."
                .into(),
            input_schema: json!({
                "type": "object",
                "properties": {
                    "pid": { "type": "integer", "description": "Browser process id to prepare. Required except for a driver-owned isolated_new/isolated_named launch with allow_launch=true." },
                    "window_id": { "type": "integer", "description": "Exact native window approval anchor; required for strategy.kind=existing_profile." },
                    "allow_launch": {
                        "type": "boolean",
                        "description": "Allow a separate driver-owned isolated Chromium process to be launched (default false)."
                    },
                    "profile": {
                        "type": "object",
                        "description": "Driver-owned isolated Chromium profile to launch with allow_launch=true. mode=isolated_new creates a fresh throwaway profile; mode=isolated_named reuses the named driver-owned profile. Never an existing user profile.",
                        "properties": {
                            "mode": { "type": "string", "enum": ["isolated_new", "isolated_named"] },
                            "name": { "type": "string", "description": "Required only for isolated_named; 1-64 path-safe ASCII characters." }
                        },
                        "required": ["mode"],
                        "additionalProperties": false
                    },
                    "strategy": {
                        "type": "object",
                        "description": "Attach to an already-running browser instead of launching one. Pass an object, {\"kind\":\"existing_profile\"}, not a string. kind=existing_profile attaches to the user's running profile at pid/window_id under the runtime's profile authorization.",
                        "properties": {
                            "kind": { "type": "string", "enum": ["existing_profile"] }
                        },
                        "required": ["kind"],
                        "additionalProperties": false
                    },
                    "delivery_mode": {
                        "type": "string",
                        "enum": ["background", "foreground"],
                        "default": "background",
                        "description": "Existing-profile attachment only. background (default) attaches in the background when the browser window is on another Space than the user's, and otherwise refuses with background_unavailable, before any visible effect, where attaching would bring the browser in front of the user's app. foreground accepts that, for a screen nobody else is using or when the user agreed; the app that was in front is brought back afterwards."
                    },
                    "session": schema_session(),
                },
                // Keep the top-level input schema a plain object. Bedrock rejects
                // anyOf/oneOf/allOf at this level, so the conditional pid/profile
                // contract is described above and enforced by invoke instead.
                "required": [],
                "additionalProperties": true
            }),
            read_only: false,
            destructive: true,
            idempotent: false,
            open_world: true,
        };
        Self { def, engine }
    }
}

#[async_trait]
impl Tool for BrowserPrepareTool {
    fn def(&self) -> &ToolDef {
        &self.def
    }

    async fn invoke(&self, args: Value) -> ToolResult {
        let session = match require_explicit_session(&args) {
            Ok(session) => session,
            Err(error) => return error,
        };
        let profile = match args.get("profile") {
            None | Some(Value::Null) => None,
            Some(value) => match serde_json::from_value::<PrepareProfile>(value.clone()) {
                Ok(profile) => Some(profile),
                Err(error) => {
                    return ToolResult::error(format!("invalid browser profile request: {error}"))
                }
            },
        };
        let strategy = match args.get("strategy") {
            None | Some(Value::Null) => None,
            Some(value) => match serde_json::from_value::<PrepareStrategy>(value.clone()) {
                Ok(strategy) => Some(strategy),
                Err(error) => {
                    return ToolResult::error(format!(
                        "invalid browser preparation strategy ({error}). Pass an object: \
                         \"strategy\": {{\"kind\": \"existing_profile\"}}, with pid and \
                         window_id from list_windows."
                    ))
                }
            },
        };
        let allow_launch = args.opt_bool("allow_launch").unwrap_or(false);
        let foreground = match parse_delivery_mode(&args) {
            Ok(foreground) => foreground,
            Err(error) => return ToolResult::error(error),
        };
        let pid = match args.get("pid") {
            None => None,
            Some(_) => match args.require_i64("pid") {
                Ok(pid) => Some(pid),
                Err(error) => return error,
            },
        };
        let pid_optional = strategy.is_none() && profile.is_some() && allow_launch;
        if pid.is_none() && !pid_optional {
            return match args.require_i64("pid") {
                Ok(_) => unreachable!("pid was already parsed"),
                Err(error) => error,
            };
        }
        let profile_mode = profile.as_ref().map(|profile| profile.mode);
        let transport_session = args.opt_str("_transport_session_id");
        let owner_transport = transport_session
            .clone()
            .filter(|owner| !owner.is_empty())
            .unwrap_or_else(|| session.clone());
        let request = PrepareRequest {
            pid,
            window_id: args.opt_u64("window_id"),
            session: session.clone(),
            transport_session,
            strategy,
            profile,
            allow_launch,
            foreground,
        };
        match self.engine.prepare_browser(request).await {
            Ok(outcome) => {
                let prepared = outcome.endpoint.is_some();
                let lifecycle = profile_mode
                    .filter(|_| outcome.action == PrepareAction::LaunchedIsolatedBrowser)
                    .and_then(|mode| isolated_session_lifecycle(&session, &owner_transport, mode));
                let text = format!(
                    "browser_prepare: {} — {}",
                    if prepared {
                        "endpoint available"
                    } else {
                        "no endpoint"
                    },
                    outcome.message
                );
                let mut structured = json!({
                    "status": "ok",
                    "prepared": prepared,
                    "action": outcome.action,
                    "message": outcome.message,
                    // The ws_url itself stays internal; expose only proof metadata.
                    "endpoint_ownership": outcome.endpoint.map(|e| e.ownership),
                    "prepared_pid": outcome.prepared_pid,
                    "side_effects": outcome.side_effects,
                    "attachment": outcome.attachment,
                });
                if let Some(lifecycle) = lifecycle {
                    structured["lifecycle"] = lifecycle;
                }
                ToolResult::text(text).with_structured(structured)
            }
            Err(refusal) if refusal.code == BrowserRefusalCode::BackgroundUnavailable => {
                let reason = refusal
                    .detail
                    .as_ref()
                    .and_then(|detail| detail.get("limitation"))
                    .and_then(Value::as_str)
                    .unwrap_or("attaching would bring the browser to the front")
                    .to_owned();
                crate::delivery::background_unavailable_result_with_suggestion(
                    format!("browser_prepare refused: {}", refusal.message),
                    refusal.code.as_str(),
                    reason,
                    json!({
                        "status": "refused",
                        "refusal": refusal,
                    }),
                    BROWSER_PREPARE_BACKGROUND_SUGGESTION,
                )
            }
            Err(refusal) => refusal.to_tool_result(),
        }
    }
}

/// `browser_prepare` is optional: the page's accessibility tree is a working
/// background route, so the refusal leads with it.
const BROWSER_PREPARE_BACKGROUND_SUGGESTION: &str = "Not blocked: use get_window_state on this window and act through the accessibility tree (set_value, click by element token). If the first read shows only browser chrome and no AXWebArea, read the window again after a moment. Use delivery_mode:\"foreground\" only if that fails and nobody is using the screen.";

fn isolated_session_lifecycle(
    session: &str,
    owner_transport: &str,
    mode: PrepareProfileMode,
) -> Option<Value> {
    let snapshot = crate::session::session_snapshot(
        session,
        owner_transport,
        crate::session::DEFAULT_SESSION_IDLE_TTL,
    )
    .filter(|snapshot| !snapshot.ending)?;
    Some(json!({
        "owner": "session",
        "idle_expires_in_seconds": snapshot.idle_ttl.as_secs(),
        "process_ends_with_session": true,
        "profile_persists_after_session": mode == PrepareProfileMode::IsolatedNamed,
    }))
}

// ── browser_navigate ─────────────────────────────────────────────────────────

pub struct BrowserNavigateTool {
    def: ToolDef,
    engine: Arc<BrowserEngine>,
}

impl BrowserNavigateTool {
    pub fn new(engine: Arc<BrowserEngine>) -> Self {
        let def = ToolDef {
            name: "browser_navigate".into(),
            description: "Navigate one tab of an exactly-bound browser target to a \
                new URL (http/https/about only). Refused for heuristic bindings. \
                Navigation invalidates all p<snapshot>:<index> refs for the tab."
                .into(),
            input_schema: json!({
                "type": "object",
                "properties": {
                    "target_id": schema_target_id(),
                    "tab_id": schema_tab_id(),
                    "url": { "type": "string", "description": "Destination URL (http:, https:, or about:)." },
                    "session": schema_session(),
                },
                "required": ["target_id", "tab_id", "url"],
                "additionalProperties": true
            }),
            read_only: false,
            destructive: false,
            idempotent: false,
            open_world: true,
        };
        Self { def, engine }
    }
}

#[async_trait]
impl Tool for BrowserNavigateTool {
    fn def(&self) -> &ToolDef {
        &self.def
    }

    async fn protected_resource_ownership(
        &self,
        adapter_id: &str,
        args: &Value,
    ) -> ProtectedResourceOwnership {
        if adapter_id == "browser_bound_input" {
            browser_resource_ownership(&self.engine, args).await
        } else {
            ProtectedResourceOwnership::UserOwned
        }
    }

    async fn protected_resource_scope(
        &self,
        adapter_id: &str,
        args: &Value,
    ) -> Result<Option<Value>, crate::tool::ProtectedResourceScopeError> {
        if adapter_id == "browser_bound_input" {
            browser_protected_resource_scope(&self.engine, args, "browser_navigate").await
        } else {
            Ok(None)
        }
    }

    async fn invoke(&self, args: Value) -> ToolResult {
        let (target_id, tab_id, url) = match (
            args.require_str("target_id"),
            args.require_str("tab_id"),
            args.require_str("url"),
        ) {
            (Ok(t), Ok(tab), Ok(u)) => (t, tab, u),
            (Err(e), _, _) | (_, Err(e), _) | (_, _, Err(e)) => return e,
        };
        let session = match require_explicit_session(&args) {
            Ok(s) => s,
            Err(e) => return e,
        };
        let lower = url.to_ascii_lowercase();
        if !(lower.starts_with("http://")
            || lower.starts_with("https://")
            || lower.starts_with("about:"))
        {
            return ToolResult::error(format!(
                "browser_navigate only accepts http/https/about URLs, got: {url}"
            ));
        }

        let _mutation = match self
            .engine
            .lock_mutation(&session, &target_id, &tab_id)
            .await
        {
            Ok(guard) => guard,
            Err(refusal) => return refusal.to_tool_result(),
        };
        let validated = match self
            .engine
            .revalidate_for_mutation(&session, &target_id, Some(&tab_id))
            .await
        {
            Ok(v) => v,
            Err(refusal) => return refusal.to_tool_result(),
        };

        match validated
            .conn
            .call(
                Some(&validated.cdp_session),
                "Page.navigate",
                json!({ "url": url }),
            )
            .await
        {
            Ok(result) => {
                if let Some(err_text) = result.get("errorText").and_then(Value::as_str) {
                    return ToolResult::error(format!("navigation failed: {err_text}"));
                }
                // Refs die with the old document.
                self.engine
                    .store
                    .invalidate_tab_snapshots(&session, &target_id, &tab_id);
                ToolResult::text(format!("navigated {tab_id} to {url}")).with_structured(json!({
                    "status": "ok",
                    "target_id": target_id,
                    "tab_id": tab_id,
                    "url": url,
                    "refs_invalidated": true,
                }))
            }
            Err(e) => ToolResult::error(format!("Page.navigate failed: {e}")),
        }
    }
}

// ── browser_click ────────────────────────────────────────────────────────────

pub struct BrowserClickTool {
    def: ToolDef,
    engine: Arc<BrowserEngine>,
}

impl BrowserClickTool {
    pub fn new(engine: Arc<BrowserEngine>) -> Self {
        let def = ToolDef {
            name: "browser_click".into(),
            description: "Click a page element (by ref) or viewport coordinates in an \
                exactly-bound tab. Default route is trusted hardware-like input \
                (Input.dispatchMouseEvent), and refuses where that route cannot \
                preserve standalone-browser background posture unless \
                delivery_mode=\"foreground\" accepts that the browser window may \
                activate (including Linux Chromium configurations whose trusted route cannot stay in the background; \
                for example a browser inside a sandbox). \
                input_route=\"dom_event\" (synthetic pointer and mouse \
                down/up/click sequence at the element's center, ref required) is used only when explicitly requested; \
                it proves dispatch, not control activation, because trust-gated \
                controls may ignore synthetic events. If a click's handler opens a \
                page-owned JavaScript dialog, on either route, the call returns at once with a \
                dialog block (present, kind, dialog_id) to pass to browser_dialog. \
                Refused while a page-owned dialog is open on the tab, and for \
                heuristic bindings."
                .into(),
            input_schema: json!({
                "type": "object",
                "properties": {
                    "target_id": schema_target_id(),
                    "tab_id": schema_tab_id(),
                    "session": schema_session(),
                    "ref": schema_ref(),
                    "x": { "type": "number", "description": "Viewport x (CSS px) — alternative to ref." },
                    "y": { "type": "number", "description": "Viewport y (CSS px) — alternative to ref." },
                    "delivery_mode": schema_delivery_mode(),
                    "input_route": {
                        "type": "string",
                        "enum": ["trusted", "dom_event"],
                        "description": "\"trusted\" (default): Input.dispatchMouseEvent. \
                            It refuses rather than foregrounding a standalone browser. \
                            \"dom_event\": synthetic full-background DOM click, only \
                            when explicitly requested. Dispatch does not prove the \
                            control activated; refresh page state and verify the \
                            expected postcondition."
                    },
                    "filmed_point": {
                        "type": "object",
                        "description": "Where a filmed pointer is, in viewport CSS px. With \
                            input_route=dom_event and a ref in the tab's own frame: the \
                            click is checked and sent in one turn of script in an \
                            isolated world. It is sent only if this point is inside the \
                            ref's rectangle and hit-tests as the ref or something inside \
                            it; its events carry this point; nothing is scrolled first \
                            and no cursor is drawn.",
                        "properties": {
                            "x": { "type": "number" },
                            "y": { "type": "number" }
                        },
                        "required": ["x", "y"]
                    },
                },
                "required": ["target_id", "tab_id"],
                "additionalProperties": true
            }),
            read_only: false,
            destructive: false,
            idempotent: false,
            open_world: true,
        };
        Self { def, engine }
    }
}

#[async_trait]
impl Tool for BrowserClickTool {
    fn def(&self) -> &ToolDef {
        &self.def
    }

    async fn protected_resource_ownership(
        &self,
        adapter_id: &str,
        args: &Value,
    ) -> ProtectedResourceOwnership {
        if adapter_id == "browser_bound_input" {
            browser_resource_ownership(&self.engine, args).await
        } else {
            ProtectedResourceOwnership::UserOwned
        }
    }

    async fn protected_resource_scope(
        &self,
        adapter_id: &str,
        args: &Value,
    ) -> Result<Option<Value>, crate::tool::ProtectedResourceScopeError> {
        if adapter_id == "browser_bound_input" {
            browser_protected_resource_scope(&self.engine, args, "browser_click").await
        } else {
            Ok(None)
        }
    }

    async fn invoke(&self, args: Value) -> ToolResult {
        let (target_id, tab_id) = match (args.require_str("target_id"), args.require_str("tab_id"))
        {
            (Ok(t), Ok(tab)) => (t, tab),
            (Err(e), _) | (_, Err(e)) => return e,
        };
        let session = match require_explicit_session(&args) {
            Ok(s) => s,
            Err(e) => return e,
        };
        let route = args
            .opt_str("input_route")
            .unwrap_or_else(|| "trusted".into());
        if route != "trusted" && route != "dom_event" {
            return ToolResult::error(format!(
                "input_route must be \"trusted\" or \"dom_event\", got {route:?}"
            ));
        }
        let ext_ref = args.opt_str("ref");
        let coords = match (args.opt_f64("x"), args.opt_f64("y")) {
            (Some(x), Some(y)) => Some((x, y)),
            (None, None) => None,
            _ => return ToolResult::error("pass both x and y, or neither"),
        };
        if ext_ref.is_none() && coords.is_none() {
            return ToolResult::error("browser_click needs a ref or x/y coordinates");
        }
        if route == "dom_event" && ext_ref.is_none() {
            return ToolResult::error("input_route=dom_event requires a ref");
        }
        let filmed_point = match point_arg(&args, "filmed_point") {
            Ok(point) => point,
            Err(error) => return error,
        };
        if filmed_point.is_some() && route != "dom_event" {
            return ToolResult::error("filmed_point requires input_route=dom_event and a ref");
        }
        let foreground = match parse_delivery_mode(&args) {
            Ok(f) => f,
            Err(e) => return ToolResult::error(e),
        };

        // Resolve the ref BEFORE revalidation? No — revalidate first so a
        // stale binding refuses before we touch the page at all.
        let _mutation = match self
            .engine
            .lock_mutation(&session, &target_id, &tab_id)
            .await
        {
            Ok(guard) => guard,
            Err(refusal) => return refusal.to_tool_result(),
        };
        let validated = match self
            .engine
            .revalidate_for_mutation(&session, &target_id, Some(&tab_id))
            .await
        {
            Ok(v) => v,
            Err(refusal) => return refusal.to_tool_result(),
        };
        if route == "trusted" && !foreground && validated.record.cdp_window_id.is_some() {
            if let Some(limitation) = self
                .engine
                .platform
                .standalone_trusted_input_background_limitation()
            {
                return BrowserRefusal::new(
                    BrowserRefusalCode::BrowserInputTrustUnavailable,
                    format!(
                        "{limitation}; use input_route=\"dom_event\" with a ref for a synthetic full-background click, or delivery_mode=\"foreground\" to accept that the browser window may activate"
                    ),
                )
                .with_detail(json!({
                    "requested_route": "trusted",
                    "limitation": limitation,
                    "alternative_route": "dom_event",
                    "alternative_requires_ref": true,
                    "alternative_delivery_mode": "foreground",
                    "trusted_delivery_attempted": false,
                }))
                .to_tool_result();
            }
        }

        // A page-owned dialog blocks the renderer, so any frame revalidation
        // below would wait out its timeout. Refuse before touching the page.
        if let Some(open) = validated
            .conn
            .dialog_state(validated.tab.cdp_target_id.as_str())
        {
            let remedy = if open.detached {
                "its CDP session was detached, so browser_dialog cannot resolve it; close it in the browser"
            } else {
                "resolve it with browser_dialog before clicking"
            };
            return BrowserRefusal::new(
                BrowserRefusalCode::BrowserActionUnavailable,
                format!(
                    "a {} dialog is already open on the exact tab; {remedy}",
                    open.kind
                ),
            )
            .with_detail(json!({ "dialog": dialog_block(&open) }))
            .to_tool_result();
        }

        // Ref path: re-prove the ref's frame/document identity and get
        // the session (tab or contained OOPIF child) its node lives in.
        let (backend_node_id, frame_kind, cdp_session) = match &ext_ref {
            Some(r) => {
                let entry = match self
                    .engine
                    .store
                    .resolve_ref(&session, &target_id, &tab_id, r)
                {
                    Ok(entry) => entry,
                    Err(refusal) => return refusal.to_tool_result(),
                };
                if entry.semantic && !entry.actions.contains(&BrowserActionKind::Click) {
                    return BrowserRefusal::new(
                        BrowserRefusalCode::BrowserActionUnavailable,
                        format!("semantic ref {r} does not declare the click action"),
                    )
                    .to_tool_result();
                }
                let frame_session = match self
                    .engine
                    .frame_session_for_mutation(
                        &session,
                        &target_id,
                        &tab_id,
                        &validated,
                        &entry.frame,
                    )
                    .await
                {
                    Ok(s) => s,
                    Err(refusal) => return refusal.to_tool_result(),
                };
                (
                    Some(entry.backend_node_id),
                    Some(entry.frame.kind.as_str()),
                    frame_session,
                )
            }
            None => (None, None, validated.cdp_session.clone()),
        };

        let conn = &validated.conn;
        let cdp = cdp_session.as_str();
        let cdp_target_id = validated.tab.cdp_target_id.as_str();

        // dom_event route: explicit opt-in only.
        if route == "dom_event" {
            let backend = backend_node_id.expect("checked above");
            // A filmed click runs wholly in the isolated world: the page's own
            // script world can replace what the sequence calls, and such a
            // replacement could move the node after the pointer was verified
            // on it. Nothing is read in the page's world instead.
            let mut resolve = json!({ "backendNodeId": backend });
            if filmed_point.is_some() {
                if frame_kind != Some(FrameKind::Main.as_str()) {
                    return BrowserRefusal::new(
                        BrowserRefusalCode::BrowserActionUnavailable,
                        "filmed_point is for a ref in the tab's own frame; no event was sent",
                    )
                    .to_tool_result();
                }
                let Some(world) = isolated_world(conn, cdp).await else {
                    return BrowserRefusal::new(
                        BrowserRefusalCode::BrowserActionUnavailable,
                        "no isolated world could be made for the filmed click; no event was sent",
                    )
                    .to_tool_result();
                };
                resolve["executionContextId"] = json!(world);
            }
            let resolved = match conn.call(Some(cdp), "DOM.resolveNode", resolve).await {
                Ok(v) => v,
                Err(_) => {
                    return BrowserRefusal::new(
                        BrowserRefusalCode::BrowserRefStale,
                        "the ref's node no longer resolves in the live page",
                    )
                    .to_tool_result()
                }
            };
            let object_id = match resolved
                .get("object")
                .and_then(|o| o.get("objectId"))
                .and_then(Value::as_str)
            {
                Some(o) => o.to_owned(),
                None => {
                    return BrowserRefusal::new(
                        BrowserRefusalCode::BrowserRefStale,
                        "the ref's node has no live object in the page",
                    )
                    .to_tool_result()
                }
            };
            // A backend node the page has removed still resolves to an object,
            // and the click sequence would run its handlers. Only a node still
            // in its document is clicked; an unreadable check sends nothing.
            let connected = tokio::time::timeout(
                DOM_CLICK_BASELINE_DEADLINE,
                conn.call(
                    Some(cdp),
                    "Runtime.callFunctionOn",
                    json!({
                        "objectId": object_id,
                        "functionDeclaration": DOM_NODE_CONNECTED_CHECK,
                        "returnByValue": true,
                    }),
                ),
            )
            .await
            .ok()
            .and_then(Result::ok)
            .and_then(|reply| reply.pointer("/result/value").and_then(Value::as_bool));
            if connected != Some(true) {
                return BrowserRefusal::new(
                    BrowserRefusalCode::BrowserRefStale,
                    if connected == Some(false) {
                        "the ref's node is no longer in its document"
                    } else {
                        "the ref's node could not be confirmed in its document"
                    },
                )
                .to_tool_result();
            }
            // Cursor feedback is best-effort and visual-only. A missing box
            // must not turn a valid DOM-event action into a refusal. A filmed
            // click has neither: a scroll would move the node from under the
            // pointer, and the pointer on screen is the cursor.
            if filmed_point.is_none() {
                let _ = conn
                    .call(
                        Some(cdp),
                        "DOM.scrollIntoViewIfNeeded",
                        json!({ "backendNodeId": backend }),
                    )
                    .await;
                if let Ok(box_model) = conn
                    .call(
                        Some(cdp),
                        "DOM.getBoxModel",
                        json!({ "backendNodeId": backend }),
                    )
                    .await
                {
                    if let Some((x, y)) = quad_center(&box_model) {
                        self.engine
                            .visualize_browser_action(
                                &session,
                                &validated,
                                cdp,
                                x,
                                y,
                                BrowserVisualActionKind::Click,
                            )
                            .await;
                    }
                }
            }
            let before =
                read_dom_click_state(conn, cdp, &object_id, DOM_CLICK_BASELINE_DEADLINE).await;
            // Without a filmed point the request is the one this route has always sent:
            // the sequence takes no arguments and acts at the node's centre.
            let mut sequence = json!({
                "objectId": object_id,
                "functionDeclaration": DOM_EVENT_CLICK_SEQUENCE,
                "returnByValue": true,
            });
            if let Some((x, y)) = filmed_point {
                sequence["arguments"] = json!([{ "value": x }, { "value": y }]);
            }
            let click = conn.call(Some(cdp), "Runtime.callFunctionOn", sequence);
            let ext = ext_ref.as_deref().unwrap_or("?");
            let outcome = call_until_dialog(conn, cdp_target_id, click).await;
            return match dom_click_next(outcome, || conn.dialog_state(cdp_target_id)) {
                DomClickNext::Readback => {
                    let observation = observe_dom_click(conn, cdp, &object_id, before).await;
                    let text = match observation.effect {
                        ActionEffect::Confirmed => format!(
                            "dispatched synthetic DOM click on {ext} in {tab_id}; bounded semantic \
                             readback confirmed a target-state change"
                        ),
                        _ if observation.readback_available => format!(
                            "dispatched synthetic DOM click on {ext} in {tab_id}; bounded semantic \
                             target state remained unchanged; application effect is unverifiable. \
                             Refresh page state and verify the expected postcondition"
                        ),
                        _ => format!(
                            "dispatched synthetic DOM click on {ext} in {tab_id}; application effect \
                             not verified because semantic target readback was unavailable. Refresh \
                             page state and verify the expected postcondition"
                        ),
                    };
                    let action_record = dom_click_action_record(&observation);
                    ToolResult::text(text).with_action_record(action_record)
                }
                DomClickNext::Dialog(open) => {
                    let text = format!(
                        "dispatched synthetic DOM click on {ext} in {tab_id}; its handler opened \
                         a {} dialog that is blocking the page. Inspect and resolve it with \
                         browser_dialog (dialog_id {}) before any other action on this tab",
                        open.kind,
                        dialog_capability_id(open.generation)
                    );
                    ToolResult::text(text).with_structured(json!({
                        "status": "ok",
                        "effect": "unverifiable",
                        "route": "dom_event",
                        "target_id": target_id,
                        "tab_id": tab_id,
                        "ref": ext_ref,
                        "frame": frame_kind,
                        "dialog": dialog_block(&open),
                        "escalation": {
                            "recommended": "page",
                            "reason": "the click opened a page-owned JavaScript dialog; resolve it with browser_dialog, then refresh page state",
                        },
                    }))
                }
                DomClickNext::Refuse => BrowserRefusal::new(
                    BrowserRefusalCode::BrowserRefStale,
                    "the ref's node left its document before the click's first event",
                )
                .to_tool_result(),
                DomClickNext::Misplaced => BrowserRefusal::new(
                    BrowserRefusalCode::BrowserActionUnavailable,
                    "the ref's node is not under the filmed point; no event was sent",
                )
                .to_tool_result(),
                DomClickNext::Left { count, last } => BrowserRefusal::new(
                    BrowserRefusalCode::BrowserActionUnavailable,
                    format!(
                        "the ref's node left the filmed point after {last}, before the press: \
                         {count} hover and move events were sent and no press or click was sent"
                    ),
                )
                .with_detail(json!({ "events_sent": count, "last_event": last, "pressed": false }))
                .to_tool_result(),
                DomClickNext::Partial { count, last } => {
                    let text = format!(
                        "sent part of a synthetic DOM click on {ext} in {tab_id}: the ref's node \
                         left its document after {last}, so the rest of the sequence was not \
                         sent; application effect is unverifiable. Refresh page state and \
                         verify the expected postcondition"
                    );
                    ToolResult::text(text)
                        .with_action_record(dom_click_stopped_action_record(count, &last))
                }
                DomClickNext::Interrupted(reason) => {
                    let text = format!(
                        "ran a synthetic DOM click on {ext} in {tab_id}, but its sequence did not \
                         report completing ({reason}); some of its events may have been sent and \
                         application effect is unverifiable. Refresh page state and verify the \
                         expected postcondition"
                    );
                    ToolResult::text(text)
                        .with_action_record(dom_click_interrupted_action_record(reason))
                }
                DomClickNext::Failed(error) => {
                    ToolResult::error(format!("DOM click failed: {error}"))
                }
            };
        }

        // Trusted route: resolve a click point, then Input.dispatchMouseEvent.
        let (x, y) = match (backend_node_id, coords) {
            (Some(backend), _) => {
                // Best effort scroll-into-view; ignore failure (older Chromium).
                let _ = conn
                    .call(
                        Some(cdp),
                        "DOM.scrollIntoViewIfNeeded",
                        json!({ "backendNodeId": backend }),
                    )
                    .await;
                let box_model = match conn
                    .call(
                        Some(cdp),
                        "DOM.getBoxModel",
                        json!({ "backendNodeId": backend }),
                    )
                    .await
                {
                    Ok(v) => v,
                    Err(_) => {
                        return BrowserRefusal::new(
                            BrowserRefusalCode::BrowserRefStale,
                            "the ref's node has no layout box — it left the DOM or is hidden",
                        )
                        .to_tool_result()
                    }
                };
                match quad_center(&box_model) {
                    Some(pt) => pt,
                    None => {
                        return BrowserRefusal::new(
                            BrowserRefusalCode::BrowserRefStale,
                            "the ref's node returned an unusable layout box",
                        )
                        .to_tool_result()
                    }
                }
            }
            (None, Some(pt)) => pt,
            (None, None) => unreachable!("validated above"),
        };

        self.engine
            .visualize_browser_action(
                &session,
                &validated,
                cdp,
                x,
                y,
                BrowserVisualActionKind::Click,
            )
            .await;

        if let Err(error) = conn
            .call(
                Some(cdp),
                "Emulation.setFocusEmulationEnabled",
                json!({ "enabled": true }),
            )
            .await
        {
            return BrowserRefusal::new(
                BrowserRefusalCode::BrowserInputTrustUnavailable,
                format!(
                    "the target tab could not enter CDP focus emulation for trusted input: {error}"
                ),
            )
            .to_tool_result();
        }
        tokio::time::sleep(std::time::Duration::from_millis(25)).await;

        let mut delivery_error = None;
        let mut opened = None;
        for (event_type, click_count) in [("mousePressed", 1), ("mouseReleased", 1)] {
            let press = conn.call(
                Some(cdp),
                "Input.dispatchMouseEvent",
                json!({
                    "type": event_type,
                    "x": x,
                    "y": y,
                    "button": "left",
                    "clickCount": click_count,
                }),
            );
            match call_until_dialog(conn, cdp_target_id, press).await {
                Ok(Ok(_)) => {}
                Ok(Err(error)) => {
                    delivery_error = Some(error);
                    break;
                }
                // Still send the release after a mousedown dialog, so the
                // page is not left with the button held.
                Err(open) => opened = Some(open),
            }
        }
        let opened = opened.or_else(|| conn.dialog_state(cdp_target_id));
        let unfocus = json!({ "enabled": false });
        let cleanup_error = if opened.is_some() {
            // The blocked renderer applies this once the dialog closes, and
            // only then replies, so send it without waiting for the reply.
            let _ = conn
                .call_with_timeout(
                    Some(cdp),
                    "Emulation.setFocusEmulationEnabled",
                    unfocus,
                    std::time::Duration::from_millis(50),
                )
                .await;
            None
        } else {
            conn.call(Some(cdp), "Emulation.setFocusEmulationEnabled", unfocus)
                .await
                .err()
        };
        if let Some(error) = delivery_error {
            // Trusted input is the contract; we never silently fall back to
            // synthetic events. Focus emulation has already been unwound.
            return BrowserRefusal::new(
                BrowserRefusalCode::BrowserInputTrustUnavailable,
                format!(
                    "trusted Input route failed ({error}) — re-run with \
                     input_route=\"dom_event\" to explicitly request a synthetic click"
                ),
            )
            .to_tool_result();
        }
        if let Some(error) = cleanup_error {
            return BrowserRefusal::new(
                BrowserRefusalCode::BrowserInputTrustUnavailable,
                format!(
                    "trusted click was acknowledged but CDP focus emulation could not be restored ({error}); delivery is unknown and must not be retried automatically"
                ),
            )
            .with_detail(json!({ "delivery": "unknown", "retryable": false }))
            .to_tool_result();
        }
        let mut structured = json!({
            "status": "ok",
            "route": "trusted",
            "delivery_mode": if foreground { "foreground" } else { "background" },
            "target_id": target_id,
            "tab_id": tab_id,
            "ref": ext_ref,
            "frame": frame_kind,
            "x": x,
            "y": y,
        });
        let Some(open) = opened else {
            return ToolResult::text(format!("clicked ({x:.0}, {y:.0}) in {tab_id}"))
                .with_structured(structured);
        };
        structured["dialog"] = dialog_block(&open);
        structured["escalation"] = json!({
            "recommended": "page",
            "reason": "the click opened a page-owned JavaScript dialog; resolve it with browser_dialog, then refresh page state",
        });
        ToolResult::text(format!(
            "clicked ({x:.0}, {y:.0}) in {tab_id}; its handler opened a {} dialog that is \
             blocking the page. Inspect and resolve it with browser_dialog (dialog_id {}) \
             before any other action on this tab",
            open.kind,
            dialog_capability_id(open.generation)
        ))
        .with_structured(structured)
    }
}

/// Await `call` unless a page-owned dialog opens on the tab first. The dialog
/// blocks the renderer, so the call's reply would not come until it closes.
async fn call_until_dialog(
    conn: &super::cdp_ws::CdpConnection,
    cdp_target_id: &str,
    call: impl std::future::Future<Output = anyhow::Result<Value>>,
) -> Result<anyhow::Result<Value>, super::cdp_ws::CdpDialogState> {
    tokio::pin!(call);
    loop {
        tokio::select! {
            replied = &mut call => return Ok(replied),
            _ = tokio::time::sleep(std::time::Duration::from_millis(25)) => {
                if let Some(open) = conn.dialog_state(cdp_target_id) {
                    return Err(open);
                }
            }
        }
    }
}

/// The public id for one dialog generation, shared by `browser_click` and
/// `browser_dialog` so a caller can hand the click's id straight back.
fn dialog_capability_id(generation: u64) -> String {
    format!("dialog-{generation}")
}

fn dialog_block(dialog: &super::cdp_ws::CdpDialogState) -> Value {
    json!({
        "present": true,
        "kind": dialog.kind,
        "dialog_id": dialog_capability_id(dialog.generation),
        "resolvable": !dialog.detached,
    })
}

/// A `{x, y}` argument of finite numbers, `None` when absent.
fn point_arg(args: &Value, field: &str) -> Result<Option<(f64, f64)>, ToolResult> {
    match args.get(field) {
        None | Some(Value::Null) => Ok(None),
        Some(point) => {
            let read = |axis: &str| {
                point
                    .get(axis)
                    .and_then(Value::as_f64)
                    .filter(|n| n.is_finite())
            };
            match (read("x"), read("y")) {
                (Some(x), Some(y)) => Ok(Some((x, y))),
                _ => Err(ToolResult::error(format!(
                    "Field {field} has wrong type: expected an object with finite numbers x and y"
                ))),
            }
        }
    }
}

/// The execution context of the isolated world ([`LOCATE_WORLD`]) in the
/// session's main frame, or `None` when the frame or the world could not be
/// had. The world shares the page's DOM and none of its script objects.
async fn isolated_world(conn: &CdpConnection, cdp: &str) -> Option<i64> {
    let frame_tree = conn
        .call(Some(cdp), "Page.getFrameTree", json!({}))
        .await
        .ok()?;
    let frame = frame_tree.pointer("/frameTree/frame/id")?.as_str()?;
    conn.call(
        Some(cdp),
        "Page.createIsolatedWorld",
        json!({ "frameId": frame, "worldName": LOCATE_WORLD }),
    )
    .await
    .ok()?
    .get("executionContextId")?
    .as_i64()
}

/// Where one current ref's element is, for `get_browser_state`'s locate
/// mode. It proves the binding and the ref's document as a click does and
/// refuses a stale or removed node the same way, then only reads: the
/// node's rectangle and the hit test at its centre (script on the node,
/// the click sequence's own geometry), whether a clipping ancestor hides
/// part of it, its document's visibility state, whether it has focus, the
/// hit test at `point` when one is given, the border-box centre from
/// `DOM.getBoxModel`, and the viewport's zoom and scale. Nothing is
/// scrolled, focused or dispatched.
///
/// The script runs in an isolated world of the tab's main frame
/// ([`LOCATE_WORLD`]), with the node resolved into that world. The world
/// shares the page's DOM and none of its script objects, so what the read
/// calls (`elementFromPoint`, `getBoundingClientRect`, `getComputedStyle`,
/// `contains`, `isConnected`, `visibilityState`, `hasFocus`) is the
/// browser's own whatever the page's script replaced. Without such a world
/// there is no position to report.
async fn locate_browser_ref(
    engine: &Arc<BrowserEngine>,
    session: &str,
    target_id: &str,
    tab_id: &str,
    ext_ref: &str,
    point: Option<(f64, f64)>,
) -> Result<Value, BrowserRefusal> {
    let validated = engine
        .revalidate_for_mutation(session, target_id, Some(tab_id))
        .await?;
    // A page-owned dialog blocks the renderer; every read below would wait
    // out its timeout.
    if let Some(open) = validated
        .conn
        .dialog_state(validated.tab.cdp_target_id.as_str())
    {
        return Err(BrowserRefusal::new(
            BrowserRefusalCode::BrowserActionUnavailable,
            format!(
                "a {} dialog is open on the exact tab; the page cannot be read until it is resolved",
                open.kind
            ),
        )
        .with_detail(json!({ "dialog": dialog_block(&open) })));
    }
    let entry = engine
        .store
        .resolve_ref(session, target_id, tab_id, ext_ref)?;
    if entry.frame.kind != FrameKind::Main {
        // The node's rectangle is relative to its own frame's viewport, not
        // the tab's.
        return Ok(json!({ "available": false, "reason": "child_frame" }));
    }
    let cdp_session = engine
        .frame_session_for_mutation(session, target_id, tab_id, &validated, &entry.frame)
        .await?;
    let conn = &validated.conn;
    let cdp = cdp_session.as_str();
    let backend = entry.backend_node_id;
    let stale = |message: &str| BrowserRefusal::new(BrowserRefusalCode::BrowserRefStale, message);
    let Some(world) = isolated_world(conn, cdp).await else {
        // Read in the page's own world, a position would be the page's word.
        return Ok(json!({ "available": false, "reason": "world_unavailable" }));
    };
    let resolved = conn
        .call(
            Some(cdp),
            "DOM.resolveNode",
            json!({ "backendNodeId": backend, "executionContextId": world }),
        )
        .await
        .map_err(|_| stale("the ref's node no longer resolves in the live page"))?;
    let object_id = resolved
        .get("object")
        .and_then(|o| o.get("objectId"))
        .and_then(Value::as_str)
        .ok_or_else(|| stale("the ref's node has no live object in the page"))?
        .to_owned();
    let on_node = |declaration: &'static str, arguments: Value| {
        let call = conn.call(
            Some(cdp),
            "Runtime.callFunctionOn",
            json!({
                "objectId": object_id,
                "functionDeclaration": declaration,
                "arguments": arguments,
                "returnByValue": true,
            }),
        );
        async move {
            tokio::time::timeout(DOM_CLICK_BASELINE_DEADLINE, call)
                .await
                .ok()
                .and_then(Result::ok)
        }
    };
    let connected = on_node(DOM_NODE_CONNECTED_CHECK, json!([]))
        .await
        .and_then(|reply| reply.pointer("/result/value").and_then(Value::as_bool));
    if connected != Some(true) {
        return Err(stale(if connected == Some(false) {
            "the ref's node is no longer in its document"
        } else {
            "the ref's node could not be confirmed in its document"
        }));
    }
    let asked = match point {
        Some((x, y)) => json!([{ "value": x }, { "value": y }]),
        None => json!([]),
    };
    let located = on_node(DOM_NODE_LOCATE, asked).await;
    let box_center = conn
        .call(
            Some(cdp),
            "DOM.getBoxModel",
            json!({ "backendNodeId": backend }),
        )
        .await
        .ok()
        .as_ref()
        .and_then(border_center);
    let metrics = conn
        .call(Some(cdp), "Page.getLayoutMetrics", json!({}))
        .await
        .ok();
    Ok(dom_locate_value(
        located.as_ref(),
        box_center,
        metrics.as_ref(),
    ))
}

/// Center of the content quad from a `DOM.getBoxModel` result.
fn quad_center(box_model: &Value) -> Option<(f64, f64)> {
    quad_center_of(box_model, "content")
}

/// Center of the border quad (the box `getBoundingClientRect` describes), or
/// of the content quad when the model has no border quad.
fn border_center(box_model: &Value) -> Option<(f64, f64)> {
    quad_center_of(box_model, "border").or_else(|| quad_center_of(box_model, "content"))
}

/// Name of the isolated world [`locate_browser_ref`] reads in and a filmed
/// click or insert runs in. Chromium keeps one world per frame and name, so
/// repeated calls on a document share it.
const LOCATE_WORLD: &str = "cua-driver-locate";

/// Where the ref's node is, evaluated ON the node with the click sequence's
/// own geometry: its bounding rectangle in viewport CSS px and what
/// `elementFromPoint` finds at its centre, and at (`px`, `py`) when both are
/// numbers.
///
/// `focus` is whether the node is the active element of its root (its
/// document or shadow root) and whether its document has focus: when both
/// hold, focusing the node again changes nothing in the page.
///
/// `clipped` is whether an ancestor that clips or scrolls its overflow
/// leaves part of the rectangle outside its padding box: such a node is
/// what `DOM.scrollIntoViewIfNeeded` and `focus()` scroll. The walk follows
/// the flat tree (an assigned slot, then the parent, then a shadow host). A
/// slot in a closed shadow tree is not visible to script in any world, so a
/// clipping ancestor inside a closed tree, between a slotted node and the
/// tree's host, is not seen: a known limit. The root element is skipped: its overflow applies to the viewport, which the
/// rectangle and `inner` already describe. `body` is skipped only when its
/// overflow propagates to the viewport too, that is when the root's overflow
/// is `visible` and neither element has containment; otherwise it is a
/// scroller like any other. Every other ancestor is tested whether or not
/// it is the node's containing block, so a fixed or absolutely positioned
/// node outside a clipping ancestor's box reads as clipped: the error is on
/// the side of saying so. An ancestor's padding box is scaled by the ratio of
/// its bounding rectangle to its layout size, which is exact only for
/// translation and scaling by positive factors: `transformed` is true when
/// the node or any ancestor is rotated (a half turn included), skewed,
/// reflected (a negative axis in `transform` or `scale`), transformed in 3D
/// or placed on a motion path, and the caller then reports no position at
/// all.
const DOM_NODE_LOCATE: &str = "function(px, py) { \
    const node = this; \
    const doc = node.ownerDocument, view = doc.defaultView; \
    const r = node.getBoundingClientRect(); \
    const x = r.left + r.width / 2, y = r.top + r.height / 2; \
    const root = node.getRootNode(); \
    const probe = (qx, qy) => { \
        const at = ('elementFromPoint' in root) ? root.elementFromPoint(qx, qy) : null; \
        return !at ? 'none' : (at === node ? 'target' : (node.contains(at) ? 'descendant' : 'other')); \
    }; \
    const up = (el) => el.assignedSlot || el.parentElement || (el.getRootNode().host || null); \
    const shows = (style) => style.overflowX === 'visible' && style.overflowY === 'visible'; \
    const free = (style) => (style.contain || 'none') === 'none' \
        && (style.containerType || 'normal') === 'normal' \
        && (style.contentVisibility || 'visible') === 'visible'; \
    const turned = (style) => { \
        if ((style.rotate || 'none') !== 'none') return true; \
        if ((style.offsetPath || 'none') !== 'none') return true; \
        const scale = style.scale || 'none'; \
        if (scale !== 'none' && scale.split(' ').some((part) => !(Number(part) > 0))) return true; \
        const t = style.transform || 'none'; \
        if (t === 'none') return false; \
        if (!t.startsWith('matrix(')) return true; \
        const m = t.slice(7, -1).split(',').map(Number); \
        return !(m[0] > 0 && m[3] > 0 && Math.abs(m[1]) < 1e-6 && Math.abs(m[2]) < 1e-6); \
    }; \
    const rootStyle = view.getComputedStyle(doc.documentElement); \
    const bodyIsViewport = !!doc.body && shows(rootStyle) && free(rootStyle) \
        && free(view.getComputedStyle(doc.body)); \
    let clipped = false, transformed = turned(view.getComputedStyle(node)); \
    for (let el = up(node); el; el = up(el)) { \
        const style = view.getComputedStyle(el); \
        if (turned(style)) transformed = true; \
        if (clipped || el === doc.documentElement) continue; \
        if (el === doc.body && bodyIsViewport) continue; \
        if (shows(style)) continue; \
        const b = el.getBoundingClientRect(); \
        let left = b.left, top = b.top, width = b.width, height = b.height; \
        if (typeof el.offsetWidth === 'number' && el.offsetWidth > 0 && el.offsetHeight > 0) { \
            const sx = b.width / el.offsetWidth, sy = b.height / el.offsetHeight; \
            left += el.clientLeft * sx; top += el.clientTop * sy; \
            width = el.clientWidth * sx; height = el.clientHeight * sy; \
        } \
        clipped = r.left < left - 0.5 || r.top < top - 0.5 \
            || r.right > left + width + 0.5 || r.bottom > top + height + 0.5; \
    } \
    const point = (typeof px === 'number' && typeof py === 'number') ? [px, py, probe(px, py)] : null; \
    const active = ('activeElement' in root) ? root.activeElement === node : false; \
    return { rect: [r.left, r.top, r.width, r.height], hit: probe(x, y), \
        inner: [view.innerWidth, view.innerHeight], clipped, transformed, \
        visibility: doc.visibilityState, focus: [active, doc.hasFocus() === true], point }; \
}";

/// The `locate` block of `get_browser_state`'s locate mode from the locate
/// script's reply, the box model's centre and the layout metrics. Anything
/// but a well-formed reply with a positive-area rectangle is unavailable,
/// and so is a node the script found under a rotation, skew or 3D transform;
/// the box-model centre, the viewport's zoom and scale, `clipped`,
/// `visibility_state`, `focused`, `page_focused` and `point` are `null` when
/// they could not be read or were not asked for, for the caller to refuse
/// on. `world` says the reply was read in an isolated world: this is called
/// with no other.
fn dom_locate_value(
    located: Option<&Value>,
    box_center: Option<(f64, f64)>,
    metrics: Option<&Value>,
) -> Value {
    let unavailable = |reason: &str| json!({ "available": false, "reason": reason });
    let Some(reply) = located else {
        return unavailable("unreadable");
    };
    if reply.get("exceptionDetails").is_some() {
        return unavailable("unreadable");
    }
    let Some(value) = reply.pointer("/result/value") else {
        return unavailable("unreadable");
    };
    let numbers = |field: &str, len: usize| -> Option<Vec<f64>> {
        let items = value.get(field)?.as_array()?;
        let numbers: Vec<f64> = items
            .iter()
            .filter_map(Value::as_f64)
            .filter(|n| n.is_finite())
            .collect();
        (items.len() == len && numbers.len() == len).then_some(numbers)
    };
    let Some(rect) = numbers("rect", 4) else {
        return unavailable("unreadable");
    };
    let hit = match value.get("hit").and_then(Value::as_str) {
        Some(hit @ ("target" | "descendant" | "other" | "none")) => hit,
        _ => return unavailable("unreadable"),
    };
    if rect[2] <= 0.0 || rect[3] <= 0.0 {
        return unavailable("no_box");
    }
    if value.get("transformed").and_then(Value::as_bool) == Some(true) {
        // the clip test's geometry holds only for translation and scaling
        return unavailable("transformed");
    }
    let inner = numbers("inner", 2);
    let point = value
        .get("point")
        .and_then(Value::as_array)
        .filter(|point| point.len() == 3)
        .and_then(|point| {
            let x = point[0].as_f64().filter(|n| n.is_finite())?;
            let y = point[1].as_f64().filter(|n| n.is_finite())?;
            match point[2].as_str()? {
                hit @ ("target" | "descendant" | "other" | "none") => {
                    Some(json!({ "x": x, "y": y, "hit": hit }))
                }
                _ => None,
            }
        });
    let focus = value
        .get("focus")
        .and_then(Value::as_array)
        .filter(|focus| focus.len() == 2);
    let viewport = metrics.and_then(|m| m.get("cssVisualViewport"));
    let factor = |field: &str| {
        viewport
            .and_then(|v| v.get(field))
            .and_then(Value::as_f64)
            .filter(|n| n.is_finite())
    };
    json!({
        "available": true,
        "rect": { "x": rect[0], "y": rect[1], "width": rect[2], "height": rect[3] },
        "center": { "x": rect[0] + rect[2] / 2.0, "y": rect[1] + rect[3] / 2.0 },
        "hit": hit,
        "box_center": box_center.map(|(x, y)| json!({ "x": x, "y": y })),
        "viewport": {
            "width": inner.as_ref().map(|i| i[0]),
            "height": inner.as_ref().map(|i| i[1]),
            "zoom": factor("zoom"),
            "scale": factor("scale"),
        },
        "clipped": value.get("clipped").and_then(Value::as_bool),
        "visibility_state": value.get("visibility").and_then(Value::as_str),
        "focused": focus.and_then(|focus| focus[0].as_bool()),
        "page_focused": focus.and_then(|focus| focus[1].as_bool()),
        "world": "isolated",
        // This driver checks a filmed pointer's position inside a click's or an
        // insert's own delivery (`filmed_point`). A caller that relies on that
        // reads it here: an older driver accepts the argument and ignores it.
        "filmed_delivery": true,
        "point": point,
    })
}

fn quad_center_of(box_model: &Value, quad: &str) -> Option<(f64, f64)> {
    let quad = box_model.get("model")?.get(quad)?.as_array()?;
    if quad.len() < 8 {
        return None;
    }
    let nums: Vec<f64> = quad.iter().filter_map(Value::as_f64).collect();
    if nums.len() < 8 {
        return None;
    }
    let xs = [nums[0], nums[2], nums[4], nums[6]];
    let ys = [nums[1], nums[3], nums[5], nums[7]];
    Some((xs.iter().sum::<f64>() / 4.0, ys.iter().sum::<f64>() / 4.0))
}

/// Whether the ref's node is still in its document, evaluated ON the node.
const DOM_NODE_CONNECTED_CHECK: &str = "function() { return this.isConnected === true; }";

/// Synthetic click for `input_route:"dom_event"`, evaluated ON the ref's node.
///
/// `HTMLElement.click()` fires only a bare `click` with no coordinates, so
/// apps that open rows or menus from `pointerdown`/`mousedown`/`pointerup`
/// (common in React tables and grids) ignore it. This dispatches the sequence
/// a real primary-button mouse click produces, at the element's center and on
/// the hit-tested descendant there: hover, move, down, focus, up, click. Like
/// a real click, `preventDefault()` on `pointerdown` suppresses the
/// compatibility mouse events, and on `mousedown` suppresses the focus move.
/// The events stay untrusted (`isTrusted === false`).
///
/// Before every event and before the focus move it checks that the ref's node
/// is still in its document, and stops at the first check that fails: a page
/// or one of its own handlers can remove the node after the pre-dispatch
/// guard, and real input sends no click to a node that left the document
/// between press and release. When only the hit-tested descendant left (an
/// icon re-rendered inside a button), the remaining events go to the ref's
/// node, as a browser sends them to the surviving ancestor. JavaScript runs
/// to completion, so the page cannot act between a check and its event. The
/// target is also rechecked to still be inside the ref's node, so a descendant
/// a handler moves elsewhere gets no further events, and the focus candidate is
/// chosen after that check. It returns `{ complete, stopped, count, last,
/// retargeted }`, counted in local primitives rather than page-replaceable
/// built-ins: whether it completed, `"detached"` when it stopped early, how
/// many events it dispatched and the last one's type, and whether it moved to
/// the ref's node. An exception that interrupts it leaves no such receipt.
///
/// With a filmed point (`px`, `py`, both numbers) the caller runs it on the
/// node resolved into the isolated world, where every method it calls is the
/// browser's own. It then acts at that point instead of the centre, and
/// first requires the point to lie inside the node's rectangle and to
/// hit-test as the node or something inside it; otherwise it returns
/// `stopped: "not_under_pointer"` with nothing sent. That check and the
/// first event are in one turn of script, so nothing the page does can come
/// between them. The six hover and move events that precede the press run
/// the page's listeners, which can move the node, so the same requirement is
/// made again immediately before `pointerdown`, in the same turn as it: when
/// it fails the sequence returns `stopped: "left_pointer"` having sent hover
/// and move events only. From the press on, the sequence goes to the node
/// wherever it is, as the press of a real pointer already has.
const DOM_EVENT_CLICK_SEQUENCE: &str = "function(px, py) { \
    const el = this; \
    let count = 0, last = '', retargeted = false; \
    if (!el.isConnected) return { complete: false, stopped: 'detached', count, last, retargeted }; \
    const doc = el.ownerDocument; \
    const view = doc.defaultView; \
    const r = el.getBoundingClientRect(); \
    const filmed = typeof px === 'number' && typeof py === 'number'; \
    const x = filmed ? px : r.left + r.width / 2, y = filmed ? py : r.top + r.height / 2; \
    const root = el.getRootNode(); \
    const hit = ('elementFromPoint' in root) ? root.elementFromPoint(x, y) : null; \
    if (filmed && !(x >= r.left && x <= r.right && y >= r.top && y <= r.bottom && hit && el.contains(hit))) \
        return { complete: false, stopped: 'not_under_pointer', count, last, retargeted }; \
    const under = () => { \
        const q = el.getBoundingClientRect(); \
        const h = ('elementFromPoint' in root) ? root.elementFromPoint(x, y) : null; \
        return x >= q.left && x <= q.right && y >= q.top && y <= q.bottom && !!h && el.contains(h); \
    }; \
    let target = (hit && el.contains(hit)) ? hit : el; \
    const sx = x + (view.screenX || 0), sy = y + (view.screenY || 0); \
    const base = { bubbles: true, cancelable: true, composed: true, view, \
        clientX: x, clientY: y, screenX: sx, screenY: sy, button: 0 }; \
    const DETACHED = {}; \
    const live = () => { \
        if (!el.isConnected) throw DETACHED; \
        if (target !== el && !(target.isConnected && el.contains(target))) { target = el; retargeted = true; } \
    }; \
    const send = (type, event) => { live(); const kept = target.dispatchEvent(event); count += 1; last = type; return kept; }; \
    const P = (type, buttons, extra) => send(type, new view.PointerEvent(type, \
        { ...base, buttons, pointerId: 1, pointerType: 'mouse', isPrimary: true, \
          width: 1, height: 1, pressure: buttons ? 0.5 : 0, ...extra })); \
    const M = (type, buttons, extra) => send(type, new view.MouseEvent(type, \
        { ...base, buttons, detail: 0, ...extra })); \
    try { \
        P('pointerover', 0); P('pointerenter', 0, { bubbles: false, cancelable: false }); \
        M('mouseover', 0); M('mouseenter', 0, { bubbles: false, cancelable: false }); \
        P('pointermove', 0); M('mousemove', 0); \
        if (filmed) { \
            live(); \
            if (!under()) return { complete: false, stopped: 'left_pointer', count, last, retargeted }; \
        } \
        const compat = P('pointerdown', 1); \
        if (compat && M('mousedown', 1, { detail: 1 })) { \
            live(); \
            const focusable = target.closest('a[href],button,input,select,textarea,summary,[tabindex],[contenteditable=\"\"],[contenteditable=\"true\"]'); \
            if (focusable && focusable.isConnected && typeof focusable.focus === 'function') focusable.focus({ preventScroll: true }); \
        } \
        P('pointerup', 0); \
        if (compat) M('mouseup', 0, { detail: 1 }); \
        M('click', 0, { detail: 1 }); \
    } catch (error) { \
        if (error === DETACHED) return { complete: false, stopped: 'detached', count, last, retargeted }; \
        throw error; \
    } \
    return { complete: true, stopped: null, count, last, retargeted }; \
}";

// ── browser_type ─────────────────────────────────────────────────────────────

/// Editability check evaluated ON the ref's node (`this`), so focus is
/// verified against the node's own root — Document or ShadowRoot — and
/// behaves the same in the main frame, composed shadow DOM,
/// same-process iframes, and OOPIF child documents.
const EDITABLE_AND_FOCUSED_CHECK: &str = "function() { \
    const root = this.getRootNode(); \
    const active = ('activeElement' in root) ? root.activeElement : null; \
    if (active !== this) return false; \
    if (this.isContentEditable) return true; \
    if (this.tagName === 'TEXTAREA') return !this.disabled && !this.readOnly; \
    if (this.tagName !== 'INPUT') return false; \
    return !this.disabled && !this.readOnly && \
        !['button','checkbox','color','file','hidden','image','radio','range','reset','submit']\
        .includes((this.type || 'text').toLowerCase()); \
}";

/// The filmed insert, evaluated ON the ref's node resolved into the isolated
/// world, where every method it calls is the browser's own. In one turn of
/// script it requires the node to be in its document, the active element of
/// its root, editable by the same rule as [`EDITABLE_AND_FOCUSED_CHECK`], and
/// under (`px`, `py`): the point inside its rectangle and hit-testing as the
/// node or something inside it. It then inserts `text` at the caret with the
/// document's `insertText` command. Nothing the page does can come between
/// the checks and the insertion. Chrome fires a trusted `input` event for the
/// command and no `beforeinput` (Footwork notebook FP27, Chrome 157), so a
/// page that takes its text from `beforeinput` does not see this insertion as
/// it sees typing. It returns `{ inserted, why }`: `why` names the first
/// check that failed, with nothing inserted, or `command_refused` when the
/// command reported no insertion.
const DOM_FILMED_INSERT: &str = "function(px, py, text) { \
    const el = this; \
    if (el.isConnected !== true) return { inserted: false, why: 'detached' }; \
    const doc = el.ownerDocument, root = el.getRootNode(); \
    if (!(('activeElement' in root) && root.activeElement === el)) return { inserted: false, why: 'not_focused' }; \
    const kind = (el.type || 'text').toLowerCase(); \
    const editable = el.isContentEditable === true \
        || (el.tagName === 'TEXTAREA' && !el.disabled && !el.readOnly) \
        || (el.tagName === 'INPUT' && !el.disabled && !el.readOnly \
            && !['button','checkbox','color','file','hidden','image','radio','range','reset','submit'].includes(kind)); \
    if (!editable) return { inserted: false, why: 'not_editable' }; \
    const r = el.getBoundingClientRect(); \
    const hit = ('elementFromPoint' in root) ? root.elementFromPoint(px, py) : null; \
    if (!(px >= r.left && px <= r.right && py >= r.top && py <= r.bottom && hit && el.contains(hit))) \
        return { inserted: false, why: 'not_under_pointer' }; \
    const done = doc.execCommand('insertText', false, text) === true; \
    return { inserted: done, why: done ? null : 'command_refused' }; \
}";

const FOCUS_EMULATION_READY_CHECK: &str = "function() { \
    const root = this.getRootNode(); \
    const active = ('activeElement' in root) ? root.activeElement : null; \
    return document.hasFocus() && active === this; \
}";

// Select the element's whole content so the next insertion replaces it instead
// of appending. Returns the number of characters selected, or -1 when the node
// is not a shape we know how to select. Selection is the only clearing path
// that keeps input semantics intact: assigning `value` directly would skip the
// beforeinput/input events that frameworks bind their state to.
const SELECT_ALL_IN_ELEMENT: &str = "function() { \
    if (this.tagName === 'INPUT' || this.tagName === 'TEXTAREA') { \
        const value = this.value || ''; \
        try { this.setSelectionRange(0, value.length); } catch (e) { \
            try { this.select(); } catch (_) { return -1; } \
        } \
        if (this.selectionStart !== 0 || this.selectionEnd !== value.length) return -1; \
        return Array.from(value).length; \
    } \
    if (this.isContentEditable) { \
        const root = this.getRootNode(); \
        const owner = ('getSelection' in root) ? root : this.ownerDocument; \
        const selection = owner.getSelection(); \
        if (!selection) return -1; \
        const range = this.ownerDocument.createRange(); \
        range.selectNodeContents(this); \
        selection.removeAllRanges(); \
        selection.addRange(range); \
        return Array.from(this.textContent || '').length; \
    } \
    return -1; \
}";

/// Put the element's entire content into the selection.
///
/// `browser_type` delivers through `Input.insertText` and the trusted key path,
/// and both insert at the caret. Without an explicit selection there is no way
/// to *set* a field that already holds text — a caller who tries ends up with
/// the old and the new value concatenated. Both delivery paths replace the
/// current selection, so selecting everything first turns "insert" into "set".
async fn select_all_in_element(
    conn: &CdpConnection,
    cdp: &str,
    object_id: &str,
) -> Result<usize, String> {
    let selected = conn
        .call(
            Some(cdp),
            "Runtime.callFunctionOn",
            json!({
                "objectId": object_id,
                "functionDeclaration": SELECT_ALL_IN_ELEMENT,
                "returnByValue": true,
            }),
        )
        .await
        .map_err(|error| error.to_string())?;
    match selected["result"]["value"].as_i64() {
        Some(n) if n >= 0 => Ok(n as usize),
        _ => Err("the ref is not a text input, textarea, or contenteditable \
                  element, so its content cannot be selected for replacement"
            .into()),
    }
}

/// Establish Chromium's trusted-input focus state for an inactive tab.
///
/// Selection alone is not durable in a fully occluded window: without focus
/// emulation Chromium can accept `Input.insertText` while discarding the
/// selection, silently turning replacement back into append.
async fn enter_focus_emulation(
    conn: &CdpConnection,
    cdp: &str,
    backend_node_id: i64,
    object_id: &str,
) -> Result<(), String> {
    conn.call(
        Some(cdp),
        "Emulation.setFocusEmulationEnabled",
        json!({ "enabled": true }),
    )
    .await
    .map_err(|error| error.to_string())?;

    let mut focus_error = None;
    for _ in 0..20 {
        if let Err(error) = conn
            .call(
                Some(cdp),
                "DOM.focus",
                json!({ "backendNodeId": backend_node_id }),
            )
            .await
        {
            focus_error = Some(error.to_string());
            break;
        }
        let ready = conn
            .call(
                Some(cdp),
                "Runtime.callFunctionOn",
                json!({
                    "objectId": object_id,
                    "functionDeclaration": FOCUS_EMULATION_READY_CHECK,
                    "returnByValue": true,
                }),
            )
            .await;
        if matches!(
            ready,
            Ok(ref value) if value["result"]["value"].as_bool() == Some(true)
        ) {
            tokio::time::sleep(std::time::Duration::from_millis(100)).await;
            if let Err(error) = conn
                .call(
                    Some(cdp),
                    "DOM.focus",
                    json!({ "backendNodeId": backend_node_id }),
                )
                .await
            {
                focus_error = Some(error.to_string());
                break;
            }
            return Ok(());
        }
        tokio::time::sleep(std::time::Duration::from_millis(25)).await;
    }

    let _ = conn
        .call(
            Some(cdp),
            "Emulation.setFocusEmulationEnabled",
            json!({ "enabled": false }),
        )
        .await;
    Err(format!(
        "the exact editable ref did not become focus-ready under CDP emulation{}",
        focus_error
            .map(|error| format!(": {error}"))
            .unwrap_or_default()
    ))
}

pub struct BrowserTypeTool {
    def: ToolDef,
    engine: Arc<BrowserEngine>,
}

impl BrowserTypeTool {
    pub fn new(engine: Arc<BrowserEngine>) -> Self {
        let def = ToolDef {
            name: "browser_type".into(),
            description: "Type text into an exactly-bound tab via the Input domain. \
                mode=\"insert_text\" (default) uses Input.insertText; \
                mode=\"keystrokes\" dispatches per-character key events. Both insert \
                at the caret, so typing into a field that already holds text appends \
                to it; pass replace=true to set the field instead, or to clear it by \
                typing an empty string. Pass a ref to an editable element from the \
                latest snapshot. A ref is required; heuristic bindings are refused."
                .into(),
            input_schema: json!({
                "type": "object",
                "properties": {
                    "target_id": schema_target_id(),
                    "tab_id": schema_tab_id(),
                    "session": schema_session(),
                    "text": { "type": "string", "description": "Text to type." },
                    "ref": schema_ref(),
                    "mode": {
                        "type": "string",
                        "enum": ["insert_text", "keystrokes"],
                        "description": "insert_text (default): bulk Input.insertText. \
                            keystrokes: per-character Input.dispatchKeyEvent."
                    },
                    "replace": {
                        "type": "boolean",
                        "description": "false (default): insert at the caret, appending \
                            to whatever the field already holds. true: select the \
                            element's whole content first so the text replaces it — \
                            with an empty text this clears the field. Replacement goes \
                            through the selection, so beforeinput/input still fire and \
                            framework state stays consistent."
                    },
                    "filmed_point": {
                        "type": "object",
                        "description": "Where a filmed pointer is, in viewport CSS px. With \
                            mode=insert_text and replace=false, for a ref in the tab's \
                            own frame: one turn of script in an isolated world checks \
                            that the ref is the focused editable element under this \
                            point and inserts the text. Nothing is focused, scrolled or \
                            selected first and no cursor is drawn.",
                        "properties": {
                            "x": { "type": "number" },
                            "y": { "type": "number" }
                        },
                        "required": ["x", "y"]
                    },
                },
                "required": ["target_id", "tab_id", "ref", "text"],
                "additionalProperties": true
            }),
            read_only: false,
            destructive: false,
            idempotent: false,
            open_world: true,
        };
        Self { def, engine }
    }
}

#[async_trait]
impl Tool for BrowserTypeTool {
    fn def(&self) -> &ToolDef {
        &self.def
    }

    async fn protected_resource_ownership(
        &self,
        adapter_id: &str,
        args: &Value,
    ) -> ProtectedResourceOwnership {
        if adapter_id == "browser_bound_input" {
            browser_resource_ownership(&self.engine, args).await
        } else {
            ProtectedResourceOwnership::UserOwned
        }
    }

    async fn protected_resource_scope(
        &self,
        adapter_id: &str,
        args: &Value,
    ) -> Result<Option<Value>, crate::tool::ProtectedResourceScopeError> {
        if adapter_id == "browser_bound_input" {
            browser_protected_resource_scope(&self.engine, args, "browser_type").await
        } else {
            Ok(None)
        }
    }

    async fn invoke(&self, args: Value) -> ToolResult {
        let (target_id, tab_id, text) = match (
            args.require_str("target_id"),
            args.require_str("tab_id"),
            args.require_str("text"),
        ) {
            (Ok(t), Ok(tab), Ok(x)) => (t, tab, x),
            (Err(e), _, _) | (_, Err(e), _) | (_, _, Err(e)) => return e,
        };
        let session = match require_explicit_session(&args) {
            Ok(s) => s,
            Err(e) => return e,
        };
        let mode = args.opt_str("mode").unwrap_or_else(|| "insert_text".into());
        if mode != "insert_text" && mode != "keystrokes" {
            return ToolResult::error(format!(
                "mode must be \"insert_text\" or \"keystrokes\", got {mode:?}"
            ));
        }
        let replace = args.opt_bool("replace").unwrap_or(false);
        let filmed_point = match point_arg(&args, "filmed_point") {
            Ok(point) => point,
            Err(error) => return error,
        };
        if filmed_point.is_some() && (mode != "insert_text" || replace) {
            return ToolResult::error("filmed_point requires mode=insert_text and replace=false");
        }

        let _mutation = match self
            .engine
            .lock_mutation(&session, &target_id, &tab_id)
            .await
        {
            Ok(guard) => guard,
            Err(refusal) => return refusal.to_tool_result(),
        };
        let validated = match self
            .engine
            .revalidate_for_mutation(&session, &target_id, Some(&tab_id))
            .await
        {
            Ok(v) => v,
            Err(refusal) => return refusal.to_tool_result(),
        };

        let ext_ref = match args.require_str("ref") {
            Ok(value) => value,
            Err(error) => return error,
        };
        let entry = match self
            .engine
            .store
            .resolve_ref(&session, &target_id, &tab_id, &ext_ref)
        {
            Ok(e) => e,
            Err(refusal) => return refusal.to_tool_result(),
        };
        if entry.semantic && !entry.actions.contains(&BrowserActionKind::Type) {
            return BrowserRefusal::new(
                BrowserRefusalCode::BrowserActionUnavailable,
                format!("semantic ref {ext_ref} does not declare the type action"),
            )
            .to_tool_result();
        }
        // Re-prove the ref's frame identity; typing routes to the frame's
        // own session (tab, or the contained OOPIF child session).
        let cdp_session = match self
            .engine
            .frame_session_for_mutation(&session, &target_id, &tab_id, &validated, &entry.frame)
            .await
        {
            Ok(s) => s,
            Err(refusal) => return refusal.to_tool_result(),
        };
        let conn = &validated.conn;
        let cdp = cdp_session.as_str();

        if let Some((x, y)) = filmed_point {
            // One turn of script in the isolated world checks the node and
            // inserts. Nothing is focused, scrolled, selected or drawn first,
            // and no page-world method runs before the insertion.
            let not_sent = |code: BrowserRefusalCode, message: &str| {
                BrowserRefusal::new(code, format!("{message}; nothing was inserted"))
                    .to_tool_result()
            };
            if entry.frame.kind != FrameKind::Main {
                return not_sent(
                    BrowserRefusalCode::BrowserActionUnavailable,
                    "filmed_point is for a ref in the tab's own frame",
                );
            }
            let Some(world) = isolated_world(conn, cdp).await else {
                return not_sent(
                    BrowserRefusalCode::BrowserActionUnavailable,
                    "no isolated world could be made for the filmed insert",
                );
            };
            let object_id = match conn
                .call(
                    Some(cdp),
                    "DOM.resolveNode",
                    json!({ "backendNodeId": entry.backend_node_id, "executionContextId": world }),
                )
                .await
                .ok()
                .and_then(|resolved| {
                    resolved
                        .pointer("/object/objectId")
                        .and_then(Value::as_str)
                        .map(str::to_owned)
                }) {
                Some(object) => object,
                None => {
                    return not_sent(
                        BrowserRefusalCode::BrowserRefStale,
                        "the ref's node no longer resolves in the live page",
                    )
                }
            };
            let requested_chars = text.chars().count();
            let insert = conn.call(
                Some(cdp),
                "Runtime.callFunctionOn",
                json!({
                    "objectId": object_id,
                    "functionDeclaration": DOM_FILMED_INSERT,
                    "arguments": [{ "value": x }, { "value": y }, { "value": text }],
                    "returnByValue": true,
                }),
            );
            let cdp_target_id = validated.tab.cdp_target_id.as_str();
            let unknown = |why: String| {
                BrowserRefusal::new(
                    BrowserRefusalCode::BrowserInputIncomplete,
                    format!("the filmed insert did not report completing ({why}); what reached the page is unknown"),
                )
                .with_detail(json!({
                    "requested_chars": requested_chars,
                    "delivery": "unknown",
                    "retryable": false,
                }))
                .to_tool_result()
            };
            let reply = match call_until_dialog(conn, cdp_target_id, insert).await {
                Err(open) => {
                    return unknown(format!(
                    "a {} dialog opened during it; resolve it with browser_dialog (dialog_id {})",
                    open.kind,
                    dialog_capability_id(open.generation)
                ))
                }
                Ok(Err(error)) => return unknown(error.to_string()),
                Ok(Ok(reply)) => reply,
            };
            if reply.get("exceptionDetails").is_some() {
                return unknown("it threw".to_owned());
            }
            let receipt = reply.pointer("/result/value");
            let why = receipt.and_then(|r| r.get("why")).and_then(Value::as_str);
            return match (
                receipt
                    .and_then(|r| r.get("inserted"))
                    .and_then(Value::as_bool),
                why,
            ) {
                (Some(true), _) => {
                    ToolResult::text(format!("typed {requested_chars} char(s) into {tab_id}"))
                        .with_structured(json!({
                            "status": "ok",
                            "target_id": target_id,
                            "tab_id": tab_id,
                            "ref": ext_ref,
                            "frame": entry.frame.kind.as_str(),
                            "mode": mode,
                            "chars": requested_chars,
                            "requested_chars": requested_chars,
                            "delivered_chars": requested_chars,
                            "replace": false,
                            "replaced_chars": 0,
                            "filmed": true,
                        }))
                }
                (Some(false), Some("detached")) => not_sent(
                    BrowserRefusalCode::BrowserRefStale,
                    "the ref's node is no longer in its document",
                ),
                (Some(false), Some("not_focused" | "not_editable")) => not_sent(
                    BrowserRefusalCode::BrowserInputTrustUnavailable,
                    "the requested ref is not a focused editable element",
                ),
                (Some(false), Some("not_under_pointer")) => not_sent(
                    BrowserRefusalCode::BrowserActionUnavailable,
                    "the ref's node is not under the filmed point",
                ),
                (Some(false), Some("command_refused")) => {
                    unknown("the page's document did not accept the insertion".to_owned())
                }
                _ => unknown("a malformed receipt".to_owned()),
            };
        }

        if let Err(_e) = conn
            .call(
                Some(cdp),
                "DOM.focus",
                json!({ "backendNodeId": entry.backend_node_id }),
            )
            .await
        {
            return BrowserRefusal::new(
                BrowserRefusalCode::BrowserRefStale,
                "the ref's node can no longer be focused — re-snapshot the tab",
            )
            .to_tool_result();
        }
        // Frame- and shadow-aware editability check: evaluated on the
        // ref's own node so it works identically for the main document,
        // shadow roots (getRootNode().activeElement), same-process
        // iframes, and OOPIF child documents.
        let object_id = match conn
            .call(
                Some(cdp),
                "DOM.resolveNode",
                json!({ "backendNodeId": entry.backend_node_id }),
            )
            .await
            .ok()
            .and_then(|resolved| {
                resolved
                    .get("object")
                    .and_then(|o| o.get("objectId"))
                    .and_then(Value::as_str)
                    .map(str::to_owned)
            }) {
            Some(o) => o,
            None => {
                return BrowserRefusal::new(
                    BrowserRefusalCode::BrowserRefStale,
                    "the ref's node no longer resolves in the live page",
                )
                .to_tool_result()
            }
        };
        let editable = conn
            .call(
                Some(cdp),
                "Runtime.callFunctionOn",
                json!({
                    "objectId": object_id,
                    "functionDeclaration": EDITABLE_AND_FOCUSED_CHECK,
                    "returnByValue": true,
                }),
            )
            .await;
        if !matches!(
            editable,
            Ok(ref value) if value["result"]["value"].as_bool() == Some(true)
        ) {
            return BrowserRefusal::new(
                BrowserRefusalCode::BrowserInputTrustUnavailable,
                "the requested ref is not a focused editable element",
            )
            .to_tool_result();
        }

        // Give the recording a visual target before text delivery. Keep this
        // best-effort: editability/input semantics never depend on the overlay.
        let _ = conn
            .call(
                Some(cdp),
                "DOM.scrollIntoViewIfNeeded",
                json!({ "backendNodeId": entry.backend_node_id }),
            )
            .await;
        if let Ok(box_model) = conn
            .call(
                Some(cdp),
                "DOM.getBoxModel",
                json!({ "backendNodeId": entry.backend_node_id }),
            )
            .await
        {
            if let Some((x, y)) = quad_center(&box_model) {
                self.engine
                    .visualize_browser_action(
                        &session,
                        &validated,
                        cdp,
                        x,
                        y,
                        BrowserVisualActionKind::Type,
                    )
                    .await;
            }
        }

        let requested_chars = text.chars().count();
        let mut replaced_chars = 0usize;
        let (typed, delivered_chars) = if mode == "insert_text" {
            if replace {
                if let Err(detail) =
                    enter_focus_emulation(conn, cdp, entry.backend_node_id, &object_id).await
                {
                    return BrowserRefusal::new(
                        BrowserRefusalCode::BrowserInputTrustUnavailable,
                        format!(
                            "the inactive tab could not prepare trusted replacement input: {detail}"
                        ),
                    )
                    .to_tool_result();
                }
                match select_all_in_element(conn, cdp, &object_id).await {
                    Ok(n) => replaced_chars = n,
                    Err(detail) => {
                        let _ = conn
                            .call(
                                Some(cdp),
                                "Emulation.setFocusEmulationEnabled",
                                json!({ "enabled": false }),
                            )
                            .await;
                        return BrowserRefusal::new(
                            BrowserRefusalCode::BrowserActionUnavailable,
                            format!("replace=true could not select the ref's content: {detail}"),
                        )
                        .to_tool_result();
                    }
                }
            }
            // An empty insertText is a no-op, so "clear the field" needs an
            // explicit deletion of the selection we just made. Delete keeps the
            // same event path as typing; it is not a value assignment.
            let mut call = if replace && text.is_empty() {
                if replaced_chars == 0 {
                    Ok(json!({}))
                } else {
                    match conn
                        .call(
                            Some(cdp),
                            "Input.dispatchKeyEvent",
                            json!({
                                "type": "keyDown",
                                "key": "Delete",
                                "code": "Delete",
                                "windowsVirtualKeyCode": 46,
                                "nativeVirtualKeyCode": 46,
                            }),
                        )
                        .await
                    {
                        Ok(_) => {
                            conn.call(
                                Some(cdp),
                                "Input.dispatchKeyEvent",
                                json!({
                                    "type": "keyUp",
                                    "key": "Delete",
                                    "code": "Delete",
                                    "windowsVirtualKeyCode": 46,
                                    "nativeVirtualKeyCode": 46,
                                }),
                            )
                            .await
                        }
                        Err(error) => Err(error),
                    }
                }
            } else {
                conn.call(Some(cdp), "Input.insertText", json!({ "text": text }))
                    .await
            };
            if replace {
                if let Err(error) = conn
                    .call(
                        Some(cdp),
                        "Emulation.setFocusEmulationEnabled",
                        json!({ "enabled": false }),
                    )
                    .await
                {
                    call = Err(error);
                }
            }
            match call {
                Ok(_) => (Ok(()), requested_chars),
                Err(error) => (Err(error), 0),
            }
        } else {
            if let Err(error) = conn
                .call(
                    Some(cdp),
                    "Emulation.setFocusEmulationEnabled",
                    json!({ "enabled": true }),
                )
                .await
            {
                return BrowserRefusal::new(
                    BrowserRefusalCode::BrowserInputTrustUnavailable,
                    format!(
                        "the inactive tab could not enter CDP focus emulation for trusted keystrokes: {error}"
                    ),
                )
                .to_tool_result();
            }
            let mut focus_ready = false;
            let mut focus_error = None;
            for _ in 0..20 {
                if let Err(error) = conn
                    .call(
                        Some(cdp),
                        "DOM.focus",
                        json!({ "backendNodeId": entry.backend_node_id }),
                    )
                    .await
                {
                    focus_error = Some(error);
                    break;
                }
                let ready = conn
                    .call(
                        Some(cdp),
                        "Runtime.callFunctionOn",
                        json!({
                            "objectId": object_id,
                            "functionDeclaration": FOCUS_EMULATION_READY_CHECK,
                            "returnByValue": true,
                        }),
                    )
                    .await;
                if matches!(
                    ready,
                    Ok(ref value) if value["result"]["value"].as_bool() == Some(true)
                ) {
                    focus_ready = true;
                    break;
                }
                tokio::time::sleep(std::time::Duration::from_millis(25)).await;
            }
            if !focus_ready {
                let _ = conn
                    .call(
                        Some(cdp),
                        "Emulation.setFocusEmulationEnabled",
                        json!({ "enabled": false }),
                    )
                    .await;
                return BrowserRefusal::new(
                    BrowserRefusalCode::BrowserInputTrustUnavailable,
                    format!(
                        "the exact editable ref did not become focus-ready under CDP emulation{}",
                        focus_error
                            .as_ref()
                            .map(|error| format!(": {error}"))
                            .unwrap_or_default()
                    ),
                )
                .to_tool_result();
            }
            // Chromium acknowledges focus emulation before every renderer's
            // trusted-input path is ready. Edge on Linux can otherwise drop
            // the first one or two characters while still returning success.
            tokio::time::sleep(std::time::Duration::from_millis(100)).await;
            if let Err(error) = conn
                .call(
                    Some(cdp),
                    "DOM.focus",
                    json!({ "backendNodeId": entry.backend_node_id }),
                )
                .await
            {
                let _ = conn
                    .call(
                        Some(cdp),
                        "Emulation.setFocusEmulationEnabled",
                        json!({ "enabled": false }),
                    )
                    .await;
                return BrowserRefusal::new(
                    BrowserRefusalCode::BrowserRefStale,
                    format!("the exact editable ref became stale before trusted typing: {error}"),
                )
                .to_tool_result();
            }
            // Select AFTER the last DOM.focus above: re-focusing a node drops
            // the selection again, so selecting any earlier would silently
            // degrade replace=true back to append.
            if replace {
                match select_all_in_element(conn, cdp, &object_id).await {
                    Ok(n) => replaced_chars = n,
                    Err(detail) => {
                        // Leave focus emulation the way we found it, exactly as
                        // the other early returns in this branch do.
                        let _ = conn
                            .call(
                                Some(cdp),
                                "Emulation.setFocusEmulationEnabled",
                                json!({ "enabled": false }),
                            )
                            .await;
                        return BrowserRefusal::new(
                            BrowserRefusalCode::BrowserActionUnavailable,
                            format!("replace=true could not select the ref's content: {detail}"),
                        )
                        .to_tool_result();
                    }
                }
            }
            let mut result = Ok(());
            let mut delivered = 0;
            // No characters to type means the selection has to go away by
            // itself; the loop below would leave the old content selected but
            // present, and "cleared" would be a false report.
            if replace && text.is_empty() && replaced_chars > 0 {
                for phase in ["keyDown", "keyUp"] {
                    if let Err(error) = conn
                        .call(
                            Some(cdp),
                            "Input.dispatchKeyEvent",
                            json!({
                                "type": phase,
                                "key": "Delete",
                                "code": "Delete",
                                "windowsVirtualKeyCode": 46,
                                "nativeVirtualKeyCode": 46,
                            }),
                        )
                        .await
                    {
                        result = Err(error);
                        break;
                    }
                }
            }
            for ch in text.chars() {
                let (key, key_text) = if ch == '\n' {
                    ("Enter".to_string(), "\r".to_string())
                } else {
                    (ch.to_string(), ch.to_string())
                };
                let down = conn
                    .call(
                        Some(cdp),
                        "Input.dispatchKeyEvent",
                        json!({ "type": "keyDown", "key": key }),
                    )
                    .await;
                let character = if down.is_ok() {
                    conn.call(
                        Some(cdp),
                        "Input.dispatchKeyEvent",
                        json!({
                            "type": "char",
                            "key": key,
                            "text": key_text,
                            "unmodifiedText": key_text,
                        }),
                    )
                    .await
                } else {
                    Ok(json!({}))
                };
                let up = conn
                    .call(
                        Some(cdp),
                        "Input.dispatchKeyEvent",
                        json!({ "type": "keyUp", "key": key }),
                    )
                    .await;
                if let Err(e) = down.and(character).and(up) {
                    result = Err(e);
                    break;
                }
                delivered += 1;
                tokio::time::sleep(std::time::Duration::from_millis(15)).await;
            }
            if let Err(error) = conn
                .call(
                    Some(cdp),
                    "Emulation.setFocusEmulationEnabled",
                    json!({ "enabled": false }),
                )
                .await
            {
                result = Err(error);
            }
            (result, delivered)
        };

        match typed {
            Ok(()) => ToolResult::text(if replace {
                format!(
                    "typed {requested_chars} char(s) into {tab_id}, replacing \
                     {replaced_chars} char(s)"
                )
            } else {
                format!("typed {requested_chars} char(s) into {tab_id}")
            })
            .with_structured(json!({
                "status": "ok",
                "target_id": target_id,
                "tab_id": tab_id,
                "ref": ext_ref,
                "frame": entry.frame.kind.as_str(),
                "mode": mode,
                "chars": requested_chars,
                "requested_chars": requested_chars,
                "delivered_chars": delivered_chars,
                // Report what was displaced, not just what was sent: a caller
                // that asked to replace needs to distinguish "set an empty
                // field" from "overwrote something" without re-reading the page.
                "replace": replace,
                "replaced_chars": replaced_chars,
            })),
            Err(e) => BrowserRefusal::new(
                BrowserRefusalCode::BrowserInputIncomplete,
                format!(
                    "trusted Input typing stopped after {delivered_chars} of {requested_chars} character(s): {e}"
                ),
            )
            .with_detail(json!({
                "requested_chars": requested_chars,
                "delivered_chars": delivered_chars,
                "retryable": false,
            }))
            .to_tool_result(),
        }
    }
}

const SELECT_NATIVE_OPTION: &str = "function(field, wanted) { \
    const view = this.ownerDocument && this.ownerDocument.defaultView; \
    if (!view || !(this instanceof view.HTMLSelectElement)) \
        return { refused: 'the ref is not a native HTML select element' }; \
    if (this.multiple) return { refused: 'multiple-selection select elements are not supported' }; \
    if (this.matches(':disabled')) return { refused: 'the select element is disabled' }; \
    const matches = Array.from(this.options).filter((option) => option[field] === wanted); \
    if (matches.length !== 1) \
        return { refused: `${matches.length} options match the requested ${field}; exactly one must` }; \
    const option = matches[0]; \
    if (option.matches(':disabled')) return { refused: 'the matching option is disabled' }; \
    const changed = !option.selected; \
    if (changed) { \
        option.selected = true; \
        this.dispatchEvent(new view.Event('input', { bubbles: true, composed: true })); \
        this.dispatchEvent(new view.Event('change', { bubbles: true })); \
    } \
    const current = this.options[this.selectedIndex]; \
    return { changed, value: this.value, label: current ? current.label : null }; \
}";

pub struct BrowserSelectTool {
    def: ToolDef,
    engine: Arc<BrowserEngine>,
}

impl BrowserSelectTool {
    pub fn new(engine: Arc<BrowserEngine>) -> Self {
        let def = ToolDef {
            name: "browser_select".into(),
            description: "Select one option of a native HTML <select> ref on an exactly-bound \
                tab without opening its popup. Pass exactly one of label or value; exactly one \
                option must equal it. Refuses non-native, multiple-selection, and disabled \
                selects, disabled options, and zero or ambiguous matches before changing \
                anything. A change dispatches bubbling input and change events; they are \
                synthetic, so verify the page accepted the selection. Selecting the option \
                that is already selected dispatches no events."
                .into(),
            input_schema: json!({
                "type": "object",
                "properties": {
                    "target_id": schema_target_id(),
                    "tab_id": schema_tab_id(),
                    "session": schema_session(),
                    "ref": schema_ref(),
                    "label": {
                        "type": "string",
                        "description": "Exact visible label of the option to select."
                    },
                    "value": {
                        "type": "string",
                        "description": "Exact value attribute of the option to select."
                    },
                },
                "required": ["target_id", "tab_id", "ref"],
                "additionalProperties": false
            }),
            read_only: false,
            destructive: false,
            idempotent: false,
            open_world: true,
        };
        Self { def, engine }
    }
}

#[async_trait]
impl Tool for BrowserSelectTool {
    fn def(&self) -> &ToolDef {
        &self.def
    }

    async fn protected_resource_ownership(
        &self,
        adapter_id: &str,
        args: &Value,
    ) -> ProtectedResourceOwnership {
        if adapter_id == "browser_bound_input" {
            browser_resource_ownership(&self.engine, args).await
        } else {
            ProtectedResourceOwnership::UserOwned
        }
    }

    async fn protected_resource_scope(
        &self,
        adapter_id: &str,
        args: &Value,
    ) -> Result<Option<Value>, crate::tool::ProtectedResourceScopeError> {
        if adapter_id == "browser_bound_input" {
            browser_protected_resource_scope(&self.engine, args, "browser_select").await
        } else {
            Ok(None)
        }
    }

    async fn invoke(&self, args: Value) -> ToolResult {
        let (target_id, tab_id, ext_ref) = match (
            args.require_str("target_id"),
            args.require_str("tab_id"),
            args.require_str("ref"),
        ) {
            (Ok(target), Ok(tab), Ok(ext_ref)) => (target, tab, ext_ref),
            (Err(error), _, _) | (_, Err(error), _) | (_, _, Err(error)) => return error,
        };
        let (field, wanted) = match (args.opt_str("label"), args.opt_str("value")) {
            (Some(label), None) => ("label", label),
            (None, Some(value)) => ("value", value),
            _ => return ToolResult::error("pass exactly one of label or value"),
        };
        let session = match require_explicit_session(&args) {
            Ok(session) => session,
            Err(error) => return error,
        };
        let _mutation = match self
            .engine
            .lock_mutation(&session, &target_id, &tab_id)
            .await
        {
            Ok(guard) => guard,
            Err(refusal) => return refusal.to_tool_result(),
        };
        let validated = match self
            .engine
            .revalidate_for_mutation(&session, &target_id, Some(&tab_id))
            .await
        {
            Ok(validated) => validated,
            Err(refusal) => return refusal.to_tool_result(),
        };
        let entry = match self
            .engine
            .store
            .resolve_ref(&session, &target_id, &tab_id, &ext_ref)
        {
            Ok(entry) => entry,
            Err(refusal) => return refusal.to_tool_result(),
        };
        let cdp_session = match self
            .engine
            .frame_session_for_mutation(&session, &target_id, &tab_id, &validated, &entry.frame)
            .await
        {
            Ok(session) => session,
            Err(refusal) => return refusal.to_tool_result(),
        };
        let conn = &validated.conn;
        let object_id = match conn
            .call(
                Some(&cdp_session),
                "DOM.resolveNode",
                json!({ "backendNodeId": entry.backend_node_id }),
            )
            .await
            .ok()
            .and_then(|resolved| resolved["object"]["objectId"].as_str().map(str::to_owned))
        {
            Some(object_id) => object_id,
            None => {
                return BrowserRefusal::new(
                    BrowserRefusalCode::BrowserRefStale,
                    "the ref's node no longer resolves in the live page",
                )
                .to_tool_result()
            }
        };
        let outcome = match conn
            .call(
                Some(&cdp_session),
                "Runtime.callFunctionOn",
                json!({
                    "objectId": object_id,
                    "functionDeclaration": SELECT_NATIVE_OPTION,
                    "arguments": [{ "value": field }, { "value": wanted }],
                    "returnByValue": true,
                }),
            )
            .await
        {
            Ok(reply) => reply["result"]["value"].clone(),
            Err(error) => {
                return BrowserRefusal::new(
                    BrowserRefusalCode::BrowserActionUnavailable,
                    format!("the select script could not run on the ref: {error}"),
                )
                .to_tool_result()
            }
        };
        if let Some(reason) = outcome["refused"].as_str() {
            return BrowserRefusal::new(BrowserRefusalCode::BrowserActionUnavailable, reason)
                .to_tool_result();
        }
        let Some(changed) = outcome["changed"].as_bool() else {
            return BrowserRefusal::new(
                BrowserRefusalCode::BrowserActionUnavailable,
                "the select script failed before reporting a selection",
            )
            .to_tool_result();
        };
        ToolResult::text(if changed {
            format!(
                "selected {} in {tab_id} and dispatched synthetic input and change events",
                outcome["label"]
            )
        } else {
            format!("{} was already selected in {tab_id}", outcome["label"])
        })
        .with_structured(json!({
            "status": "ok",
            "target_id": target_id,
            "tab_id": tab_id,
            "ref": ext_ref,
            "frame": entry.frame.kind.as_str(),
            "changed": changed,
            "value": outcome["value"],
            "label": outcome["label"],
        }))
    }
}

// ── browser_dialog ──────────────────────────────────────────────────────────

pub struct BrowserDialogTool {
    def: ToolDef,
    engine: Arc<BrowserEngine>,
}

impl BrowserDialogTool {
    pub fn new(engine: Arc<BrowserEngine>) -> Self {
        Self {
            def: ToolDef {
                name: "browser_dialog".into(),
                description: "Inspect or resolve a page-owned JavaScript alert, confirm, prompt, or beforeunload dialog on one exactly-bound tab. This never handles browser permission UI, extension UI, native dialogs, or file pickers. Inspect returns an opaque dialog_id; accept/dismiss require that exact current id. Resolution defaults to background delivery; Linux callers must explicitly request foreground delivery because Chromium's native modal cannot be resolved there without changing foreground posture.".into(),
                input_schema: json!({
                    "type": "object",
                    "properties": {
                        "target_id": schema_target_id(),
                        "tab_id": schema_tab_id(),
                        "session": schema_session(),
                        "action": { "type": "string", "enum": ["inspect", "accept", "dismiss"], "description": "inspect returns the current dialog and its dialog_id; accept or dismiss resolves that exact dialog." },
                        "dialog_id": { "type": "string", "description": "Opaque current dialog generation returned by action=inspect." },
                        "prompt_text": { "type": "string", "description": "Sensitive response text, valid only when accepting a prompt dialog." },
                        "delivery_mode": {
                            "type": "string",
                            "enum": ["background", "foreground"],
                            "default": "background",
                            "description": "Requested foreground posture for accept/dismiss. Linux Chromium requires foreground; inspect is read-only."
                        }
                    },
                    "required": ["target_id", "tab_id", "action"],
                    "additionalProperties": true
                }),
                read_only: false,
                destructive: false,
                idempotent: false,
                open_world: true,
            },
            engine,
        }
    }
}

#[async_trait]
impl Tool for BrowserDialogTool {
    fn def(&self) -> &ToolDef {
        &self.def
    }

    async fn protected_resource_ownership(
        &self,
        adapter_id: &str,
        args: &Value,
    ) -> ProtectedResourceOwnership {
        if matches!(
            adapter_id,
            "private_observation" | "browser_consequential_action"
        ) {
            browser_resource_ownership(&self.engine, args).await
        } else {
            ProtectedResourceOwnership::UserOwned
        }
    }

    async fn protected_resource_scope(
        &self,
        adapter_id: &str,
        args: &Value,
    ) -> Result<Option<Value>, crate::tool::ProtectedResourceScopeError> {
        if matches!(
            adapter_id,
            "private_observation" | "browser_consequential_action"
        ) {
            browser_protected_resource_scope(&self.engine, args, "browser_dialog").await
        } else {
            Ok(None)
        }
    }

    async fn invoke(&self, args: Value) -> ToolResult {
        let (target_id, tab_id, action) = match (
            args.require_str("target_id"),
            args.require_str("tab_id"),
            args.require_str("action"),
        ) {
            (Ok(target), Ok(tab), Ok(action)) => (target, tab, action),
            (Err(error), _, _) | (_, Err(error), _) | (_, _, Err(error)) => return error,
        };
        if !matches!(action.as_str(), "inspect" | "accept" | "dismiss") {
            return ToolResult::error("action must be inspect, accept, or dismiss");
        }
        let delivery_mode = args
            .opt_str("delivery_mode")
            .unwrap_or_else(|| "background".into());
        if !matches!(delivery_mode.as_str(), "background" | "foreground") {
            return ToolResult::error("delivery_mode must be background or foreground");
        }
        let session = match require_explicit_session(&args) {
            Ok(session) => session,
            Err(error) => return error,
        };
        let _mutation = match self
            .engine
            .lock_mutation(&session, &target_id, &tab_id)
            .await
        {
            Ok(guard) => guard,
            Err(refusal) => return refusal.to_tool_result(),
        };
        let validated = match self
            .engine
            .revalidate_for_mutation(&session, &target_id, Some(&tab_id))
            .await
        {
            Ok(validated) => validated,
            Err(refusal) => return refusal.to_tool_result(),
        };
        if cfg!(target_os = "linux") && action != "inspect" && delivery_mode == "background" {
            return BrowserRefusal::new(
                BrowserRefusalCode::BrowserInputTrustUnavailable,
                "Chromium's native JavaScript modal cannot be resolved on Linux without changing foreground posture; retry with delivery_mode=\"foreground\"",
            )
            .with_detail(json!({ "supported_delivery_mode": "foreground" }))
            .to_tool_result();
        }
        let conn = &validated.conn;
        let cdp_session = validated.cdp_session.as_str();
        let cdp_target_id = validated.tab.cdp_target_id.as_str();
        if conn.dialog_state(cdp_target_id).is_none() && !conn.has_dialog_session(cdp_target_id) {
            // Register before Page.enable so an opening event delivered before
            // the command reply is still attributed to the exact target. A
            // renderer blocked by an unseen dialog never answers, so use the
            // short subscription deadline rather than the full call timeout.
            conn.register_dialog_session(cdp_session, cdp_target_id);
            if let Err(error) = conn
                .call_with_timeout(
                    Some(cdp_session),
                    "Page.enable",
                    json!({}),
                    DIALOG_SUBSCRIPTION_TIMEOUT,
                )
                .await
            {
                if conn.dialog_state(cdp_target_id).is_none() {
                    conn.unregister_dialog_session(cdp_session, cdp_target_id);
                    return BrowserRefusal::new(
                        BrowserRefusalCode::BrowserActionUnavailable,
                        format!("the exact tab does not expose JavaScript dialog events: {error}"),
                    )
                    .to_tool_result();
                }
            }
            tokio::task::yield_now().await;
        }

        let Some(dialog) = conn.dialog_state(cdp_target_id) else {
            return if action == "inspect" {
                ToolResult::text(format!(
                    "no page-owned JavaScript dialog is open in {tab_id}"
                ))
                .with_structured(json!({
                    "status": "ok", "target_id": target_id, "tab_id": tab_id,
                    "present": false
                }))
            } else {
                BrowserRefusal::new(
                    BrowserRefusalCode::BrowserActionUnavailable,
                    "no current page-owned JavaScript dialog exists on the exact tab",
                )
                .to_tool_result()
            };
        };
        let dialog_id = dialog_capability_id(dialog.generation);
        if action == "inspect" {
            return ToolResult::text(format!("{} dialog is open in {tab_id}", dialog.kind))
                .with_structured(json!({
                    "status": "ok", "target_id": target_id, "tab_id": tab_id,
                    "present": true, "dialog_id": dialog_id, "kind": dialog.kind,
                    "resolvable": !dialog.detached
                }));
        }
        if dialog.detached {
            // Chromium lets only the session that saw the dialog open resolve
            // it; every other session is told none is showing.
            return BrowserRefusal::new(
                BrowserRefusalCode::BrowserActionUnavailable,
                "the dialog's CDP session was detached, so the driver cannot resolve it; close it in the browser",
            )
            .with_detail(json!({ "dialog": dialog_block(&dialog) }))
            .to_tool_result();
        }

        let supplied_id = match args.require_str("dialog_id") {
            Ok(id) => id,
            Err(error) => return error,
        };
        if supplied_id != dialog_id {
            return BrowserRefusal::new(
                BrowserRefusalCode::BrowserActionUnavailable,
                "the dialog capability is stale or belongs to another dialog",
            )
            .to_tool_result();
        }
        let prompt_text = args.opt_str("prompt_text");
        if prompt_text.is_some() && (action != "accept" || dialog.kind != "prompt") {
            return ToolResult::error("prompt_text is valid only when accepting a prompt dialog");
        }
        let mut params = json!({ "accept": action == "accept" });
        if let Some(text) = prompt_text {
            params["promptText"] = Value::String(text);
        }
        match conn
            .call(
                Some(&dialog.session_id),
                "Page.handleJavaScriptDialog",
                params,
            )
            .await
        {
            Ok(_) => {
                conn.clear_dialog_state(cdp_target_id, dialog.generation);
                ToolResult::text(format!("{action}ed {} dialog in {tab_id}", dialog.kind))
                    .with_structured(json!({
                        "status": "ok", "target_id": target_id, "tab_id": tab_id,
                        "dialog_id": dialog_id, "kind": dialog.kind, "action": action
                    }))
            }
            // The journal only mirrors Chromium. If the close event was lost,
            // the dialog's own session saying none is showing wins.
            Err(error)
                if error.to_string().contains("(-32602)")
                    && error.to_string().contains("No dialog is showing") =>
            {
                conn.clear_dialog_state(cdp_target_id, dialog.generation);
                BrowserRefusal::new(
                    BrowserRefusalCode::BrowserActionUnavailable,
                    "the dialog is no longer showing on the exact tab; refresh page state",
                )
                .with_detail(json!({ "dialog": { "present": false } }))
                .to_tool_result()
            }
            Err(error) => BrowserRefusal::new(
                BrowserRefusalCode::BrowserActionUnavailable,
                format!("the exact JavaScript dialog could not be resolved: {error}"),
            )
            .to_tool_result(),
        }
    }
}

// ── browser_set_input_files ─────────────────────────────────────────────────

pub struct BrowserSetInputFilesTool {
    def: ToolDef,
    engine: Arc<BrowserEngine>,
}

impl BrowserSetInputFilesTool {
    pub fn new(engine: Arc<BrowserEngine>) -> Self {
        Self {
            def: ToolDef {
                name: "browser_set_input_files".into(),
                description: "Assign one or more explicit absolute local files to an exact live <input type=file> ref through CDP. This bypasses native file pickers, rejects symlinks and non-regular files, and never returns local paths.".into(),
                input_schema: json!({
                    "type": "object",
                    "properties": {
                        "target_id": schema_target_id(),
                        "tab_id": schema_tab_id(),
                        "session": schema_session(),
                        "ref": schema_ref(),
                        "files": {
                            "type": "array", "minItems": 1, "maxItems": 32,
                            "description": "Absolute paths of 1 to 32 local regular files to assign to the input.",
                            "items": { "type": "string", "description": "Absolute path to one local regular file." }
                        }
                    },
                    "required": ["target_id", "tab_id", "ref", "files"],
                    "additionalProperties": true
                }),
                read_only: false,
                destructive: false,
                idempotent: false,
                open_world: true,
            },
            engine,
        }
    }
}

fn validated_upload_paths(args: &Value) -> Result<Vec<String>, ToolResult> {
    let Some(files) = args.get("files").and_then(Value::as_array) else {
        return Err(ToolResult::error(
            "files must be a non-empty array of absolute paths",
        ));
    };
    if files.is_empty() || files.len() > 32 {
        return Err(ToolResult::error(
            "files must contain between 1 and 32 paths",
        ));
    }
    files
        .iter()
        .map(|value| {
            let raw = value
                .as_str()
                .ok_or_else(|| ToolResult::error("every files entry must be a string"))?;
            let path = std::path::Path::new(raw);
            if !path.is_absolute() {
                return Err(ToolResult::error("every upload path must be absolute"));
            }
            let metadata = std::fs::symlink_metadata(path)
                .map_err(|_| ToolResult::error("an approved upload path does not exist"))?;
            if metadata.file_type().is_symlink() || !metadata.is_file() {
                return Err(ToolResult::error(
                    "upload paths must name regular files directly, not links or directories",
                ));
            }
            std::fs::canonicalize(path)
                .map(|path| path.to_string_lossy().into_owned())
                .map_err(|_| ToolResult::error("an upload path could not be canonicalized"))
        })
        .collect()
}

#[async_trait]
impl Tool for BrowserSetInputFilesTool {
    fn def(&self) -> &ToolDef {
        &self.def
    }

    async fn invoke(&self, args: Value) -> ToolResult {
        let (target_id, tab_id, ext_ref) = match (
            args.require_str("target_id"),
            args.require_str("tab_id"),
            args.require_str("ref"),
        ) {
            (Ok(target), Ok(tab), Ok(ext_ref)) => (target, tab, ext_ref),
            (Err(error), _, _) | (_, Err(error), _) | (_, _, Err(error)) => return error,
        };
        let files = match validated_upload_paths(&args) {
            Ok(files) => files,
            Err(error) => return error,
        };
        let session = match require_explicit_session(&args) {
            Ok(session) => session,
            Err(error) => return error,
        };
        let _mutation = match self
            .engine
            .lock_mutation(&session, &target_id, &tab_id)
            .await
        {
            Ok(guard) => guard,
            Err(refusal) => return refusal.to_tool_result(),
        };
        let validated = match self
            .engine
            .revalidate_for_mutation(&session, &target_id, Some(&tab_id))
            .await
        {
            Ok(validated) => validated,
            Err(refusal) => return refusal.to_tool_result(),
        };
        let entry = match self
            .engine
            .store
            .resolve_ref(&session, &target_id, &tab_id, &ext_ref)
        {
            Ok(entry) => entry,
            Err(refusal) => return refusal.to_tool_result(),
        };
        if entry.semantic && !entry.actions.contains(&BrowserActionKind::Upload) {
            return BrowserRefusal::new(
                BrowserRefusalCode::BrowserActionUnavailable,
                "the semantic ref is not a file-upload control",
            )
            .to_tool_result();
        }
        let cdp_session = match self
            .engine
            .frame_session_for_mutation(&session, &target_id, &tab_id, &validated, &entry.frame)
            .await
        {
            Ok(session) => session,
            Err(refusal) => return refusal.to_tool_result(),
        };
        let described = match validated
            .conn
            .call(
                Some(&cdp_session),
                "DOM.describeNode",
                json!({ "backendNodeId": entry.backend_node_id }),
            )
            .await
        {
            Ok(node) => node,
            Err(_) => {
                return BrowserRefusal::new(
                    BrowserRefusalCode::BrowserRefStale,
                    "the upload ref no longer resolves in the live page",
                )
                .to_tool_result()
            }
        };
        let node = &described["node"];
        let attributes = node["attributes"].as_array().cloned().unwrap_or_default();
        let is_file_input = node["nodeName"]
            .as_str()
            .is_some_and(|name| name.eq_ignore_ascii_case("input"))
            && attributes.chunks_exact(2).any(|pair| {
                pair[0]
                    .as_str()
                    .is_some_and(|name| name.eq_ignore_ascii_case("type"))
                    && pair[1]
                        .as_str()
                        .is_some_and(|value| value.eq_ignore_ascii_case("file"))
            });
        if !is_file_input {
            return BrowserRefusal::new(
                BrowserRefusalCode::BrowserActionUnavailable,
                "the live ref is not an input[type=file] element",
            )
            .to_tool_result();
        }
        match validated
            .conn
            .call(
                Some(&cdp_session),
                "DOM.setFileInputFiles",
                json!({ "backendNodeId": entry.backend_node_id, "files": files }),
            )
            .await
        {
            Ok(_) => ToolResult::text(format!("assigned {} file(s) in {tab_id}", files.len()))
                .with_structured(json!({
                    "status": "ok", "target_id": target_id, "tab_id": tab_id,
                    "ref": ext_ref, "frame": entry.frame.kind.as_str(), "file_count": files.len()
                })),
            Err(error) => BrowserRefusal::new(
                BrowserRefusalCode::BrowserActionUnavailable,
                format!("the browser refused the exact file input assignment: {error}"),
            )
            .to_tool_result(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn located(value: Value) -> Value {
        json!({ "result": { "value": value } })
    }

    #[test]
    fn locate_value_reports_the_rectangle_its_centre_and_the_viewport() {
        let reply = located(
            json!({ "rect": [10.0, 20.0, 100.0, 40.0], "hit": "descendant", "inner": [800.0, 600.0] }),
        );
        let metrics = json!({ "cssVisualViewport": { "zoom": 1.25, "scale": 2.0 } });
        let value = dom_locate_value(Some(&reply), Some((60.0, 40.0)), Some(&metrics));
        assert_eq!(value["available"], true);
        assert_eq!(value["center"], json!({ "x": 60.0, "y": 40.0 }));
        assert_eq!(value["hit"], "descendant");
        assert_eq!(value["box_center"], json!({ "x": 60.0, "y": 40.0 }));
        assert_eq!(
            value["viewport"],
            json!({ "width": 800.0, "height": 600.0, "zoom": 1.25, "scale": 2.0 })
        );
    }

    #[test]
    fn locate_value_leaves_unread_checks_null_for_the_caller_to_refuse_on() {
        let reply = located(
            json!({ "rect": [0.0, 0.0, 1.0, 1.0], "hit": "target", "inner": [800.0, 600.0] }),
        );
        let value = dom_locate_value(Some(&reply), None, None);
        assert_eq!(value["available"], true);
        assert!(value["box_center"].is_null());
        assert!(value["viewport"]["zoom"].is_null() && value["viewport"]["scale"].is_null());
        assert!(value["clipped"].is_null() && value["visibility_state"].is_null());
        assert!(value["point"].is_null());
    }

    #[test]
    fn locate_value_reports_clipping_visibility_and_the_asked_point() {
        let reply = located(json!({
            "rect": [10.0, 20.0, 100.0, 40.0], "hit": "target", "inner": [800.0, 600.0],
            "clipped": true, "visibility": "hidden", "point": [60.5, 40.0, "other"],
        }));
        let value = dom_locate_value(Some(&reply), None, None);
        assert_eq!(value["available"], true);
        assert_eq!(value["clipped"], true);
        assert_eq!(value["visibility_state"], "hidden");
        assert_eq!(
            value["point"],
            json!({ "x": 60.5, "y": 40.0, "hit": "other" })
        );
    }

    #[test]
    fn locate_value_is_unavailable_under_a_rotation_or_skew() {
        let turned = located(json!({
            "rect": [10.0, 20.0, 100.0, 40.0], "hit": "target", "inner": [800.0, 600.0],
            "clipped": false, "transformed": true, "visibility": "visible", "point": null,
        }));
        assert_eq!(
            dom_locate_value(Some(&turned), Some((60.0, 40.0)), None),
            json!({ "available": false, "reason": "transformed" })
        );
        let level = located(json!({
            "rect": [10.0, 20.0, 100.0, 40.0], "hit": "target", "inner": [800.0, 600.0],
            "clipped": false, "transformed": false, "visibility": "visible", "point": null,
        }));
        assert_eq!(
            dom_locate_value(Some(&level), None, None)["available"],
            true
        );
    }

    #[test]
    fn locate_value_reports_no_point_for_a_malformed_one() {
        for point in [
            json!([60.0, 40.0]),
            json!([60.0, 40.0, "nearby"]),
            json!(["a", 40.0, "target"]),
            json!([60.0, 40.0, "target", 1]),
            json!({ "x": 60.0, "y": 40.0, "hit": "target" }),
        ] {
            let reply = located(json!({
                "rect": [10.0, 20.0, 100.0, 40.0], "hit": "target", "inner": [800.0, 600.0],
                "clipped": "no", "visibility": 1, "point": point,
            }));
            let value = dom_locate_value(Some(&reply), None, None);
            assert_eq!(value["available"], true, "{reply}");
            assert!(value["point"].is_null(), "{reply}");
            assert!(value["clipped"].is_null() && value["visibility_state"].is_null());
        }
    }

    #[test]
    fn locate_value_is_unavailable_for_anything_but_a_well_formed_reply() {
        let unreadable = json!({ "available": false, "reason": "unreadable" });
        assert_eq!(dom_locate_value(None, None, None), unreadable);
        for reply in [
            json!({ "exceptionDetails": { "text": "boom" }, "result": { "value": { "rect": [0, 0, 1, 1], "hit": "target" } } }),
            json!({ "result": {} }),
            located(json!({ "rect": [0.0, 0.0, 1.0], "hit": "target" })),
            located(json!({ "rect": [0.0, "a", 1.0, 1.0], "hit": "target" })),
            located(json!({ "rect": [0.0, 0.0, 1.0, 1.0], "hit": "nearby" })),
            located(json!({ "rect": [0.0, 0.0, 1.0, 1.0] })),
        ] {
            assert_eq!(
                dom_locate_value(Some(&reply), None, None),
                unreadable,
                "{reply}"
            );
        }
        let empty = located(json!({ "rect": [5.0, 5.0, 0.0, 10.0], "hit": "none" }));
        assert_eq!(
            dom_locate_value(Some(&empty), None, None),
            json!({ "available": false, "reason": "no_box" })
        );
    }

    #[test]
    fn border_center_prefers_the_border_quad() {
        let model = json!({ "model": {
            "content": [10.0, 10.0, 20.0, 10.0, 20.0, 20.0, 10.0, 20.0],
            "border": [0.0, 0.0, 40.0, 0.0, 40.0, 20.0, 0.0, 20.0],
        } });
        assert_eq!(border_center(&model), Some((20.0, 10.0)));
        assert_eq!(quad_center(&model), Some((15.0, 15.0)));
        let content_only =
            json!({ "model": { "content": [10.0, 10.0, 20.0, 10.0, 20.0, 20.0, 10.0, 20.0] } });
        assert_eq!(border_center(&content_only), Some((15.0, 15.0)));
    }

    fn dialog(generation: u64) -> super::super::cdp_ws::CdpDialogState {
        super::super::cdp_ws::CdpDialogState {
            generation,
            kind: "alert".to_owned(),
            session_id: "page".to_owned(),
            detached: false,
        }
    }

    #[test]
    fn dom_click_keeps_a_dialog_that_closed_after_interrupting_its_sequence() {
        // The helper saw the dialog interrupt the sequence; by the time the
        // click decides, the dialog has closed. It must not reach readback.
        let next = dom_click_next(Err(dialog(3)), || None);
        assert_eq!(next, DomClickNext::Dialog(dialog(3)));
    }

    #[test]
    fn dom_click_reads_back_only_a_completed_receipt() {
        let completed = json!({ "result": { "value": {
            "complete": true, "stopped": null, "count": 11, "last": "click", "retargeted": false,
        } } });
        assert_eq!(
            dom_click_next(Ok(Ok(completed.clone())), || None),
            DomClickNext::Readback
        );
        assert_eq!(
            dom_click_next(Ok(Ok(completed)), || Some(dialog(4))),
            DomClickNext::Dialog(dialog(4))
        );
        for reply in [
            json!({}),
            json!({ "result": { "value": true } }),
            json!({ "result": {}, "exceptionDetails": { "text": "Uncaught" } }),
        ] {
            assert!(
                matches!(
                    dom_click_next(Ok(Ok(reply.clone())), || None),
                    DomClickNext::Interrupted(_)
                ),
                "{reply}"
            );
        }
        assert!(matches!(
            dom_click_next(Ok(Err(anyhow::anyhow!("socket closed"))), || None),
            DomClickNext::Failed(_)
        ));
    }
    use crate::browser::platform::{
        BrowserPlatform, PrepareAction, PrepareOutcome, PrepareRequest,
    };
    use crate::browser::types::{
        BrowserClassification, BrowserEngineFamily, BrowserProduct, NativeWindowInfo,
        OwnedEndpoint, ProcessFingerprint,
    };

    /// Minimal adapter: pid 1 is a CDP-capable browser with no endpoint
    /// (setup required); pid 2 is not a browser; pid 3 is Safari-like
    /// (browser, no CDP). Prepare requires consent.
    #[derive(Default)]
    struct MockPlatform {
        devtools: Option<std::net::TcpListener>,
        launch_delay: std::time::Duration,
        /// Start time reported for every pid; a change stands for pid reuse.
        start_time: std::sync::atomic::AtomicU64,
    }

    impl MockPlatform {
        fn devtools_endpoint(&self, pid: i64) -> Option<OwnedEndpoint> {
            use crate::browser::types::{
                EndpointOwnershipMethod, EndpointOwnershipProof, EndpointTransport,
            };
            let port = self.devtools.as_ref()?.local_addr().unwrap().port();
            Some(OwnedEndpoint {
                ws_url: format!("ws://127.0.0.1:{port}/devtools/browser/mock"),
                http_port: Some(port),
                transport: EndpointTransport::DevToolsActivePort,
                ownership: EndpointOwnershipProof {
                    method: EndpointOwnershipMethod::DevtoolsActivePortsFile,
                    owner_pid: pid,
                    listener_pid: None,
                    detail: None,
                },
            })
        }
    }

    #[async_trait]
    impl BrowserPlatform for MockPlatform {
        async fn classify_browser(
            &self,
            pid: i64,
        ) -> Result<BrowserClassification, BrowserRefusal> {
            Ok(match pid {
                1 => BrowserClassification {
                    is_browser: true,
                    engine: BrowserEngineFamily::Chromium,
                    product_kind: BrowserProduct::GoogleChrome,
                    product: Some("MockChrome".into()),
                    channel: Some("stable".into()),
                    process_role: crate::browser::types::BrowserProcessRole::StandaloneConsumer,
                    supports_cdp: true,
                },
                3 => BrowserClassification {
                    is_browser: true,
                    engine: BrowserEngineFamily::Webkit,
                    product_kind: BrowserProduct::Safari,
                    product: Some("MockSafari".into()),
                    channel: None,
                    process_role: crate::browser::types::BrowserProcessRole::StandaloneConsumer,
                    supports_cdp: false,
                },
                4 => BrowserClassification {
                    is_browser: true,
                    engine: BrowserEngineFamily::Gecko,
                    product_kind: BrowserProduct::Firefox,
                    product: Some("MockFirefox".into()),
                    channel: None,
                    process_role: crate::browser::types::BrowserProcessRole::StandaloneConsumer,
                    supports_cdp: false,
                },
                _ => BrowserClassification {
                    is_browser: false,
                    engine: BrowserEngineFamily::Unknown,
                    product_kind: BrowserProduct::Other,
                    product: None,
                    channel: None,
                    process_role: crate::browser::types::BrowserProcessRole::Unknown,
                    supports_cdp: false,
                },
            })
        }

        async fn native_window(
            &self,
            pid: i64,
            window_id: u64,
        ) -> Result<NativeWindowInfo, BrowserRefusal> {
            assert!(
                !matches!(pid, 3 | 4),
                "unsupported browser engines must refuse before native-window probing"
            );
            use crate::browser::types::{NativeOwnershipMethod, NativeOwnershipProof, Rect};
            Ok(NativeWindowInfo {
                pid,
                window_id,
                title: "Mock - Chrome".into(),
                bounds: Rect::new(0.0, 0.0, 800.0, 600.0),
                geometry_exact: true,
                ownership: NativeOwnershipProof {
                    method: NativeOwnershipMethod::WindowServerOwner,
                    owner_pid: pid,
                    detail: None,
                },
            })
        }

        async fn is_only_exact_native_window(
            &self,
            _pid: i64,
            _window_id: u64,
        ) -> Result<Option<bool>, BrowserRefusal> {
            Ok(Some(true))
        }

        async fn discover_owned_endpoint(
            &self,
            pid: i64,
        ) -> Result<Option<OwnedEndpoint>, BrowserRefusal> {
            Ok(self.devtools_endpoint(pid))
        }

        async fn process_fingerprint(
            &self,
            pid: i64,
        ) -> Result<ProcessFingerprint, BrowserRefusal> {
            Ok(ProcessFingerprint {
                pid,
                start_time: Some(1 + self.start_time.load(std::sync::atomic::Ordering::SeqCst)),
                executable: None,
            })
        }

        async fn prepare_endpoint(
            &self,
            request: PrepareRequest,
        ) -> Result<PrepareOutcome, BrowserRefusal> {
            let pid = request.pid.expect("prepare_endpoint receives a pid");
            let endpoint = self.devtools_endpoint(pid).ok_or_else(|| {
                BrowserRefusal::new(
                    BrowserRefusalCode::BrowserRequiresSetup,
                    "mock endpoint needs acting setup",
                )
            })?;
            Ok(PrepareOutcome {
                action: PrepareAction::AlreadyPrepared,
                endpoint: Some(endpoint),
                message: "mock endpoint already exists".into(),
                prepared_pid: Some(pid),
                side_effects: Default::default(),
                attachment: None,
            })
        }

        fn isolated_browser_executable(&self) -> Result<String, BrowserRefusal> {
            match self.devtools {
                Some(_) => Ok("sleep".into()),
                None => Err(BrowserRefusal::new(
                    BrowserRefusalCode::BrowserRouteUnavailable,
                    "mock has no isolated browser executable",
                )),
            }
        }

        fn spawn_isolated_browser(
            &self,
            _command: std::process::Command,
            profile: &std::path::Path,
        ) -> Result<Box<dyn crate::browser::platform::IsolatedBrowserProcess>, BrowserRefusal>
        {
            std::thread::sleep(self.launch_delay);
            let port = self.devtools.as_ref().unwrap().local_addr().unwrap().port();
            std::fs::write(
                profile.join("DevToolsActivePort"),
                format!("{port}\n/devtools/browser/mock\n"),
            )
            .unwrap();
            let mut stand_in = std::process::Command::new("sleep");
            stand_in.arg("30");
            #[cfg(unix)]
            std::os::unix::process::CommandExt::process_group(&mut stand_in, 0);
            Ok(Box::new(stand_in.spawn().unwrap()))
        }
    }

    fn engine() -> Arc<BrowserEngine> {
        BrowserEngine::new(Arc::new(MockPlatform::default()))
    }

    #[cfg(unix)]
    fn launching_engine() -> Arc<BrowserEngine> {
        slow_launching_engine(std::time::Duration::ZERO)
    }

    #[cfg(unix)]
    fn slow_launching_engine(launch_delay: std::time::Duration) -> Arc<BrowserEngine> {
        static PROFILE_ROOT: std::sync::Once = std::sync::Once::new();
        PROFILE_ROOT.call_once(|| {
            std::env::set_var(
                "CUA_DRIVER_BROWSER_PROFILE_ROOT",
                std::env::temp_dir().join("cua-browser-tools-profiles"),
            )
        });
        BrowserEngine::new(Arc::new(MockPlatform {
            devtools: Some(std::net::TcpListener::bind("127.0.0.1:0").unwrap()),
            launch_delay,
            ..MockPlatform::default()
        }))
    }

    #[cfg(unix)]
    fn start_lifecycle_session(idle_ttl: Option<std::time::Duration>) -> (String, String) {
        use crate::session::{SessionClientKind, SessionTransport};
        let session = format!("browser-lifecycle-{}", uuid::Uuid::new_v4());
        let owner = format!("browser-lifecycle-owner-{}", uuid::Uuid::new_v4());
        match idle_ttl {
            Some(ttl) => crate::session::activate_session_with_ttl(
                &session,
                None,
                &owner,
                false,
                SessionTransport::McpStdio,
                SessionClientKind::Mcp,
                ttl,
            ),
            None => crate::session::activate_session(
                &session,
                None,
                &owner,
                false,
                SessionTransport::McpStdio,
                SessionClientKind::Mcp,
            ),
        }
        .unwrap();
        (session, owner)
    }

    #[cfg(unix)]
    async fn prepare_isolated(
        engine: &Arc<BrowserEngine>,
        session: &str,
        owner: &str,
        profile: Value,
    ) -> Value {
        let result = BrowserPrepareTool::new(engine.clone())
            .invoke(json!({
                "allow_launch": true,
                "profile": profile,
                "session": session,
                "_transport_session_id": owner
            }))
            .await;
        let structured = structured(&result).clone();
        assert_eq!(
            structured["action"], "launched_isolated_browser",
            "{structured}"
        );
        structured
    }

    fn structured(result: &ToolResult) -> &Value {
        result
            .structured_content
            .as_ref()
            .expect("structured content")
    }

    #[test]
    fn tool_annotations_and_schemas() {
        let e = engine();
        let state = GetBrowserStateTool::new(e.clone());
        assert!(
            state.def().read_only,
            "get_browser_state must be strictly read-only"
        );
        assert!(state.def().idempotent);
        assert_eq!(
            state.def().input_schema["properties"]["include_screenshot"]["default"],
            false
        );

        let prepare = BrowserPrepareTool::new(e.clone());
        assert!(prepare.def().destructive);
        assert!(!prepare.def().idempotent);
        let prepare_properties = prepare.def().input_schema["properties"]
            .as_object()
            .expect("browser_prepare properties");
        assert!(!prepare_properties.contains_key("consent"));
        assert!(!prepare_properties.contains_key("allow_restart"));
        assert!(!prepare_properties.contains_key("approval_token"));

        let dialog = BrowserDialogTool::new(e.clone());
        assert_eq!(
            dialog.def().input_schema["properties"]["delivery_mode"]["default"],
            "background"
        );

        for (def, name) in [
            (
                BrowserPrepareTool::new(e.clone()).def().clone(),
                "browser_prepare",
            ),
            (
                BrowserNavigateTool::new(e.clone()).def().clone(),
                "browser_navigate",
            ),
            (
                BrowserClickTool::new(e.clone()).def().clone(),
                "browser_click",
            ),
            (
                BrowserTypeTool::new(e.clone()).def().clone(),
                "browser_type",
            ),
            (
                BrowserSelectTool::new(e.clone()).def().clone(),
                "browser_select",
            ),
            (
                BrowserDialogTool::new(e.clone()).def().clone(),
                "browser_dialog",
            ),
            (
                BrowserSetInputFilesTool::new(e.clone()).def().clone(),
                "browser_set_input_files",
            ),
            (
                BrowserDownloadTool::new(e.clone()).def().clone(),
                "browser_download",
            ),
            (
                BrowserPointerTool::new(e.clone()).def().clone(),
                "browser_pointer",
            ),
        ] {
            assert_eq!(def.name, name);
            assert!(!def.read_only, "{name} is a mutation");
            assert!(def.input_schema["properties"].is_object(), "{name} schema");
        }
        // Every browser mutation can affect web or browser state outside the
        // client, even when the immediate delivery route is local CDP.
        for def in [
            BrowserPrepareTool::new(e.clone()).def().clone(),
            BrowserNavigateTool::new(e.clone()).def().clone(),
            BrowserClickTool::new(e.clone()).def().clone(),
            BrowserTypeTool::new(e.clone()).def().clone(),
            BrowserSelectTool::new(e.clone()).def().clone(),
            BrowserDialogTool::new(e.clone()).def().clone(),
            BrowserSetInputFilesTool::new(e.clone()).def().clone(),
            BrowserDownloadTool::new(e.clone()).def().clone(),
            BrowserPointerTool::new(e.clone()).def().clone(),
        ] {
            assert!(def.open_world, "{} can affect open-world state", def.name);
        }
        assert!(BrowserDownloadTool::new(e.clone()).def().destructive);
    }

    #[test]
    fn registration_registers_all_browser_tools() {
        let e = engine();
        let mut registry = ToolRegistry::new();
        register_browser_tools(&e, &mut registry);
        let names: Vec<&str> = registry.tool_names().collect();
        assert_eq!(
            names,
            vec![
                "get_browser_state",
                "browser_prepare",
                "browser_navigate",
                "browser_click",
                "browser_type",
                "browser_select",
                "browser_dialog",
                "browser_set_input_files",
                "browser_download",
                "browser_pointer"
            ]
        );
    }

    #[test]
    fn upload_paths_are_absolute_regular_files_and_outputs_need_no_path() {
        let path = std::env::temp_dir().join(format!("cua-upload-{}.txt", uuid::Uuid::new_v4()));
        std::fs::write(&path, b"fixture").unwrap();
        let args = json!({ "files": [path.to_string_lossy()] });
        let validated = validated_upload_paths(&args).unwrap();
        assert_eq!(validated.len(), 1);
        assert!(std::path::Path::new(&validated[0]).is_absolute());
        assert!(validated_upload_paths(&json!({ "files": ["relative.txt"] })).is_err());
        std::fs::remove_file(path).unwrap();
    }

    #[tokio::test]
    async fn bind_requires_an_explicit_session() {
        let e = engine();
        let tool = GetBrowserStateTool::new(e);
        for args in [
            json!({ "pid": 1, "window_id": 7 }),
            json!({ "pid": 1, "window_id": 7, "_session_id": "default" }),
        ] {
            let result = tool.invoke(args).await;
            assert_eq!(result.is_error, Some(true));
        }
    }

    #[tokio::test]
    async fn snapshot_rejects_non_boolean_include_screenshot() {
        let result = GetBrowserStateTool::new(engine())
            .invoke(json!({
                "target_id": "bt-fixture",
                "tab_id": "tab-fixture",
                "session": "browser-run",
                "include_screenshot": "yes"
            }))
            .await;
        assert_eq!(result.is_error, Some(true));
        assert!(matches!(
            &result.content[0],
            Content::Text { text, .. } if text.contains("expected boolean")
        ));
    }

    #[tokio::test]
    async fn public_session_field_is_the_primary_capability_namespace() {
        let tool = GetBrowserStateTool::new(engine());
        let result = tool
            .invoke(json!({ "pid": 2, "window_id": 7, "session": "public-run" }))
            .await;
        assert_eq!(
            structured(&result)["refusal"]["code"],
            "browser_route_unavailable"
        );
        assert_ne!(
            result.is_error,
            Some(true),
            "public session must pass capability-namespace validation"
        );
    }

    #[tokio::test]
    async fn non_browser_pid_refuses_route_unavailable() {
        let tool = GetBrowserStateTool::new(engine());
        let result = tool
            .invoke(json!({ "pid": 2, "window_id": 7, "_session_id": "run-1" }))
            .await;
        assert_eq!(
            structured(&result)["refusal"]["code"],
            "browser_route_unavailable"
        );
    }

    #[tokio::test]
    async fn cdp_less_browser_refuses_route_unavailable() {
        let tool = GetBrowserStateTool::new(engine());
        let result = tool
            .invoke(json!({ "pid": 3, "window_id": 7, "_session_id": "run-1" }))
            .await;
        assert_eq!(
            structured(&result)["refusal"]["code"],
            "browser_route_unavailable"
        );
        assert_eq!(
            structured(&result)["refusal"]["detail"]["engine_family"],
            "webkit"
        );
        assert_eq!(
            structured(&result)["refusal"]["detail"]["product"],
            "safari"
        );
        assert_eq!(
            structured(&result)["refusal"]["detail"]["limitation"],
            "no_attachable_runtime_endpoint"
        );
    }

    #[tokio::test]
    async fn firefox_refusal_names_the_required_protocol_without_probing_the_window() {
        let tool = GetBrowserStateTool::new(engine());
        let result = tool
            .invoke(json!({ "pid": 4, "window_id": 7, "_session_id": "run-1" }))
            .await;
        let refusal = &structured(&result)["refusal"];
        assert_eq!(refusal["code"], "browser_route_unavailable");
        assert_eq!(refusal["detail"]["engine_family"], "gecko");
        assert_eq!(refusal["detail"]["product"], "firefox");
        assert_eq!(refusal["detail"]["required_protocol"], "webdriver_bidi");
        assert_eq!(
            refusal["detail"]["limitation"],
            "remote_agent_requires_launch_time_enablement"
        );
    }

    #[tokio::test]
    async fn standalone_consumer_refuses_existing_profile_approval_without_preparing() {
        let tool = GetBrowserStateTool::new(engine());
        let result = tool
            .invoke(json!({ "pid": 1, "window_id": 7, "_session_id": "run-1" }))
            .await;
        let s = structured(&result);
        assert_eq!(s["status"], "refused");
        assert_eq!(s["refusal"]["code"], "browser_consent_required");
        assert_eq!(
            s["refusal"]["detail"]["reason"],
            "consumer_profile_endpoint_requires_grant"
        );
        assert_eq!(s["refusal"]["detail"]["next_action"], "browser_prepare");
    }

    #[tokio::test]
    async fn isolated_prepare_uses_runtime_authorization_without_a_token() {
        let tool = BrowserPrepareTool::new(engine());
        let result = tool
            .invoke(json!({
                "pid": 1,
                "allow_launch": true,
                "profile": { "mode": "isolated_new" },
                "session": "run-1"
            }))
            .await;
        assert_eq!(
            structured(&result)["refusal"]["code"],
            "browser_route_unavailable"
        );
    }

    #[tokio::test]
    async fn isolated_launch_accepts_omitted_pid() {
        let tool = BrowserPrepareTool::new(engine());
        let result = tool
            .invoke(json!({
                "allow_launch": true,
                "profile": { "mode": "isolated_new" },
                "session": "pid-free-isolated-run"
            }))
            .await;
        assert_eq!(
            structured(&result)["refusal"]["code"],
            "browser_route_unavailable"
        );
    }

    #[tokio::test]
    async fn pid_remains_required_without_a_complete_isolated_launch_request() {
        let tool = BrowserPrepareTool::new(engine());
        for request in [
            json!({
                "allow_launch": true,
                "session": "pid-free-without-profile"
            }),
            json!({
                "profile": { "mode": "isolated_new" },
                "session": "pid-free-without-allow-launch"
            }),
            json!({
                "window_id": 7,
                "strategy": { "kind": "existing_profile" },
                "session": "existing-profile-without-pid"
            }),
            json!({
                "allow_launch": true,
                "profile": { "mode": "isolated_new" },
                "strategy": { "kind": "existing_profile" },
                "session": "conflicting-strategy-without-pid"
            }),
        ] {
            let result = tool.invoke(request).await;
            assert_eq!(result.is_error, Some(true));
            let body = serde_json::to_string(&result.content).expect("serialize tool error");
            assert!(
                body.contains("Missing required integer field: pid"),
                "{body}"
            );
        }
    }

    #[tokio::test]
    async fn existing_profile_requires_runtime_authorization() {
        let tool = BrowserPrepareTool::new(engine());
        let result = tool
            .invoke(json!({
                "pid": 1,
                "window_id": 7,
                "strategy": { "kind": "existing_profile" },
                "session": "existing-profile-run"
            }))
            .await;
        let structured = structured(&result);
        assert_eq!(structured["refusal"]["code"], "browser_consent_required");
        assert_eq!(
            structured["refusal"]["detail"]["authorization_required"],
            true
        );
    }

    #[tokio::test]
    async fn existing_strategy_conflicts_fail_before_platform_setup() {
        let tool = BrowserPrepareTool::new(engine());
        let result = tool
            .invoke(json!({
                "pid": 1,
                "window_id": 7,
                "strategy": { "kind": "existing_profile" },
                "profile": { "mode": "isolated_new" },
                "session": "existing-conflict"
            }))
            .await;
        assert_eq!(
            structured(&result)["refusal"]["code"],
            "browser_consent_required"
        );
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn isolated_new_publishes_the_session_effective_idle_ttl() {
        let engine = launching_engine();
        for (idle_ttl, expected) in [
            (None, crate::session::DEFAULT_SESSION_IDLE_TTL.as_secs()),
            (Some(std::time::Duration::from_secs(1234)), 1234),
        ] {
            let (session, owner) = start_lifecycle_session(idle_ttl);
            let prepared =
                prepare_isolated(&engine, &session, &owner, json!({ "mode": "isolated_new" }))
                    .await;
            assert_eq!(
                prepared["lifecycle"],
                json!({
                    "owner": "session",
                    "idle_expires_in_seconds": expected,
                    "process_ends_with_session": true,
                    "profile_persists_after_session": false
                })
            );
            crate::session::end_session(&session);
        }
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn preparation_longer_than_the_idle_ttl_still_publishes_the_ttl() {
        let engine = slow_launching_engine(std::time::Duration::from_millis(2100));
        let (session, owner) = start_lifecycle_session(Some(std::time::Duration::from_secs(1)));
        let prepared =
            prepare_isolated(&engine, &session, &owner, json!({ "mode": "isolated_new" })).await;
        assert_eq!(prepared["lifecycle"]["idle_expires_in_seconds"], 1);
        crate::session::end_session(&session);
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn ending_session_gets_no_lifecycle() {
        use crate::session::{SessionClientKind, SessionTransport};
        let engine = launching_engine();
        let (session, owner) = start_lifecycle_session(None);
        let live =
            prepare_isolated(&engine, &session, &owner, json!({ "mode": "isolated_new" })).await;
        assert_eq!(live["lifecycle"]["owner"], "session", "{live}");
        let guard = crate::session::begin_session_dispatch(
            &session,
            None,
            &owner,
            false,
            SessionTransport::McpStdio,
            SessionClientKind::Mcp,
        )
        .unwrap();
        assert!(crate::session::end_session_for_owner(&session, &owner));
        let prepared =
            prepare_isolated(&engine, &session, &owner, json!({ "mode": "isolated_new" })).await;
        assert!(prepared.get("lifecycle").is_none(), "{prepared}");
        drop(guard);
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn isolated_named_profile_persists_after_session() {
        let engine = launching_engine();
        let (session, owner) = start_lifecycle_session(None);
        let name = format!("lifecycle-{}", uuid::Uuid::new_v4().simple());
        let prepared = prepare_isolated(
            &engine,
            &session,
            &owner,
            json!({ "mode": "isolated_named", "name": name }),
        )
        .await;
        assert_eq!(
            prepared["lifecycle"]["profile_persists_after_session"],
            true
        );
        assert_eq!(prepared["lifecycle"]["process_ends_with_session"], true);
        crate::session::end_session(&session);
        let root = std::env::var_os("CUA_DRIVER_BROWSER_PROFILE_ROOT").unwrap();
        std::fs::remove_dir_all(std::path::Path::new(&root).join(name)).unwrap();
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn lifecycle_requires_a_driver_launch_owned_by_a_visible_session() {
        let engine = launching_engine();
        let (session, owner) = start_lifecycle_session(None);
        let discovered = BrowserPrepareTool::new(engine.clone())
            .invoke(json!({
                "pid": 1,
                "allow_launch": true,
                "profile": { "mode": "isolated_new" },
                "session": session,
                "_transport_session_id": owner
            }))
            .await;
        let discovered = structured(&discovered);
        assert_eq!(discovered["action"], "already_prepared");
        assert!(discovered.get("lifecycle").is_none(), "{discovered}");

        let foreign_owner = format!("browser-lifecycle-foreign-{}", uuid::Uuid::new_v4());
        let foreign = prepare_isolated(
            &engine,
            &session,
            &foreign_owner,
            json!({ "mode": "isolated_new" }),
        )
        .await;
        assert!(foreign.get("lifecycle").is_none(), "{foreign}");

        let owned =
            prepare_isolated(&engine, &session, &owner, json!({ "mode": "isolated_new" })).await;
        assert_eq!(owned["lifecycle"]["owner"], "session");
        crate::session::end_session(&session);
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn an_idle_end_reaps_the_browser_and_forgets_its_pid() {
        // The killed browser's pid can be reused by a user's browser, so no
        // launch record for it may outlive the idle sweep.
        let engine = launching_engine();
        let (session, owner) = start_lifecycle_session(None);
        let prepared =
            prepare_isolated(&engine, &session, &owner, json!({ "mode": "isolated_new" })).await;
        let pid = prepared["prepared_pid"].as_i64().expect("prepared pid");
        let launched_app = pid + 1;
        let ownership = engine.protected_resource_ownership.clone();
        ownership.mark_driver_owned_pid(&session, launched_app);
        let args = json!({ "session": session, "pid": pid });
        assert_eq!(
            browser_resource_ownership(&engine, &args).await,
            ProtectedResourceOwnership::DriverOwned
        );

        assert_eq!(
            crate::session::evict_idle_with_prefix(Duration::ZERO, &session),
            vec![session.clone()]
        );

        assert!(!ownership.is_driver_owned_pid(&session, pid));
        assert!(!ownership.is_driver_owned_pid(&owner, pid));
        assert_eq!(
            browser_resource_ownership(&engine, &args).await,
            ProtectedResourceOwnership::UserOwned
        );
        // Records the browser engine did not create stay for the registry.
        assert!(ownership.is_driver_owned_pid(&session, launched_app));
        crate::session::end_session(&session);
    }

    #[cfg(unix)]
    #[tokio::test]
    async fn a_reused_browser_pid_is_not_driver_owned() {
        let platform = Arc::new(MockPlatform {
            devtools: Some(std::net::TcpListener::bind("127.0.0.1:0").unwrap()),
            ..MockPlatform::default()
        });
        launching_engine();
        let engine = BrowserEngine::new(platform.clone());
        let (session, owner) = start_lifecycle_session(None);
        let prepared =
            prepare_isolated(&engine, &session, &owner, json!({ "mode": "isolated_new" })).await;
        let pid = prepared["prepared_pid"].as_i64().expect("prepared pid");
        let args = json!({ "session": session, "pid": pid });
        assert_eq!(
            browser_resource_ownership(&engine, &args).await,
            ProtectedResourceOwnership::DriverOwned
        );

        // The browser exits and the session's next launch_app gets its pid.
        platform
            .start_time
            .store(1, std::sync::atomic::Ordering::SeqCst);
        let reused = ProcessFingerprint {
            pid,
            start_time: Some(2),
            executable: None,
        };
        let ownership = engine.protected_resource_ownership.clone();
        ownership.mark_driver_owned_process(&session, reused.clone());
        assert_eq!(
            browser_resource_ownership(&engine, &args).await,
            ProtectedResourceOwnership::UserOwned
        );

        // Reaping the browser forgets only its own launch, not the app's.
        assert_eq!(
            crate::session::evict_idle_with_prefix(Duration::ZERO, &session),
            vec![session.clone()]
        );
        assert!(ownership.reprove_driver_owned_process(&session, &reused));
        crate::session::end_session(&session);
    }

    #[tokio::test]
    async fn mutations_on_unknown_targets_refuse_binding_stale() {
        let e = engine();
        for result in [
            BrowserNavigateTool::new(e.clone())
                .invoke(json!({
                    "target_id": "bt999", "tab_id": "tab1",
                    "url": "https://example.test", "_session_id": "run-1"
                }))
                .await,
            BrowserClickTool::new(e.clone())
                .invoke(json!({
                    "target_id": "bt999", "tab_id": "tab1", "ref": "p1:0",
                    "_session_id": "run-1"
                }))
                .await,
            BrowserTypeTool::new(e)
                .invoke(json!({
                    "target_id": "bt999", "tab_id": "tab1", "text": "hi",
                    "_session_id": "run-1"
                }))
                .await,
        ] {
            assert_eq!(
                structured(&result)["refusal"]["code"],
                "browser_binding_stale",
                "unknown capability must refuse, not error"
            );
        }
    }

    #[tokio::test]
    async fn mutations_reject_bad_url_and_bad_route_before_binding() {
        let e = engine();
        let nav = BrowserNavigateTool::new(e.clone())
            .invoke(json!({
                "target_id": "bt1", "tab_id": "tab1", "url": "file:///etc/passwd",
                "_session_id": "run-1"
            }))
            .await;
        assert_eq!(nav.is_error, Some(true));

        let click = BrowserClickTool::new(e)
            .invoke(json!({
                "target_id": "bt1", "tab_id": "tab1", "ref": "p1:0",
                "input_route": "sneaky", "_session_id": "run-1"
            }))
            .await;
        assert_eq!(click.is_error, Some(true));
    }

    #[tokio::test]
    async fn heuristic_bindings_refuse_mutation() {
        use crate::browser::types::{BindingQuality, Rect};
        use indexmap::IndexMap;
        use std::collections::HashMap;

        let e = engine();
        // Seed a heuristic binding directly into the store.
        let mut tabs = IndexMap::new();
        let tab_id = e.store.mint_tab_id();
        tabs.insert(
            tab_id.clone(),
            crate::browser::store::TabRecord {
                tab_id: tab_id.clone(),
                cdp_target_id: "CDPX".into(),
                title: "Mock".into(),
                url: "https://example.test".into(),
                active: Some(true),
                generation: 0,
                snapshots: HashMap::new(),
            },
        );
        let target_id = e.store.mint_target(
            "run-1",
            crate::browser::store::TargetRecord {
                target_id: String::new(),
                pid: 1,
                window_id: 7,
                ws_url: "ws://127.0.0.1:9222/devtools/browser/x".into(),
                endpoint_owner_pid: 1,
                endpoint_transport: crate::browser::types::EndpointTransport::LegacyJsonVersion,
                endpoint_access_class:
                    crate::browser::types::EndpointAccessClass::EmbeddedApplication,
                generation: 0,
                transport_session: None,
                fingerprint: ProcessFingerprint {
                    pid: 1,
                    start_time: Some(1),
                    executable: None,
                },
                native_title: "Mock - Chrome".into(),
                native_bounds: Rect::new(0.0, 0.0, 800.0, 600.0),
                cdp_target_id: "CDPX".into(),
                cdp_window_id: Some(5),
                quality: BindingQuality::Heuristic,
                tabs,
            },
        );

        let result = BrowserTypeTool::new(e)
            .invoke(json!({
                "target_id": target_id, "tab_id": tab_id, "text": "hi",
                "_session_id": "run-1"
            }))
            .await;
        assert_eq!(
            structured(&result)["refusal"]["code"],
            "browser_wrong_target_refused",
            "heuristic bindings are read-only"
        );
    }

    #[tokio::test]
    async fn stale_fingerprint_refuses_before_any_cdp_traffic() {
        use crate::browser::types::{BindingQuality, Rect};
        use indexmap::IndexMap;
        use std::collections::HashMap;

        let e = engine();
        let mut tabs = IndexMap::new();
        let tab_id = e.store.mint_tab_id();
        tabs.insert(
            tab_id.clone(),
            crate::browser::store::TabRecord {
                tab_id: tab_id.clone(),
                cdp_target_id: "CDPX".into(),
                title: "Mock".into(),
                url: "https://example.test".into(),
                active: Some(true),
                generation: 0,
                snapshots: HashMap::new(),
            },
        );
        // Bound fingerprint has start_time 999; MockPlatform now reports 1.
        let target_id = e.store.mint_target(
            "run-1",
            crate::browser::store::TargetRecord {
                target_id: String::new(),
                pid: 1,
                window_id: 7,
                ws_url: "ws://127.0.0.1:9222/devtools/browser/x".into(),
                endpoint_owner_pid: 1,
                endpoint_transport: crate::browser::types::EndpointTransport::LegacyJsonVersion,
                endpoint_access_class:
                    crate::browser::types::EndpointAccessClass::EmbeddedApplication,
                generation: 0,
                transport_session: None,
                fingerprint: ProcessFingerprint {
                    pid: 1,
                    start_time: Some(999),
                    executable: None,
                },
                native_title: "Mock - Chrome".into(),
                native_bounds: Rect::new(0.0, 0.0, 800.0, 600.0),
                cdp_target_id: "CDPX".into(),
                cdp_window_id: Some(5),
                quality: BindingQuality::Exact,
                tabs,
            },
        );

        let result = BrowserNavigateTool::new(e)
            .invoke(json!({
                "target_id": target_id, "tab_id": tab_id,
                "url": "https://example.test", "_session_id": "run-1"
            }))
            .await;
        assert_eq!(
            structured(&result)["refusal"]["code"],
            "browser_binding_stale"
        );
    }

    #[tokio::test]
    async fn session_end_hook_drops_the_capability_namespace() {
        use crate::browser::types::{BindingQuality, Rect};

        let e = engine();
        let sid = "browser-store-cleanup-session-771";
        e.store.mint_target(
            sid,
            crate::browser::store::TargetRecord {
                target_id: String::new(),
                pid: 1,
                window_id: 7,
                ws_url: "ws://127.0.0.1:9222/devtools/browser/x".into(),
                endpoint_owner_pid: 1,
                endpoint_transport: crate::browser::types::EndpointTransport::LegacyJsonVersion,
                endpoint_access_class:
                    crate::browser::types::EndpointAccessClass::EmbeddedApplication,
                generation: 0,
                transport_session: None,
                fingerprint: ProcessFingerprint {
                    pid: 1,
                    start_time: Some(1),
                    executable: None,
                },
                native_title: "T".into(),
                native_bounds: Rect::new(0.0, 0.0, 1.0, 1.0),
                cdp_target_id: "C".into(),
                cdp_window_id: Some(1),
                quality: BindingQuality::Exact,
                tabs: indexmap::IndexMap::new(),
            },
        );
        assert_eq!(e.store.target_count(sid), 1);
        crate::session::fire_session_end(sid);
        assert_eq!(
            e.store.target_count(sid),
            0,
            "session end must clean the store"
        );
    }
}
