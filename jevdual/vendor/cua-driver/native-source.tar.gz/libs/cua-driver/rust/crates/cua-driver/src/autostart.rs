// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Cua AI, Inc.

//! `cua-driver autostart {enable|disable|status|kick}` — register / inspect /
//! trigger the platform-native auto-start mechanism so `cua-driver serve`
//! comes up on every interactive logon without the user pasting a
//! startup one-liner.
//!
//! ## Platform mapping
//!
//! - **Windows**: Scheduled Task `cua-driver-serve` registered with
//!   `LogonType: Interactive` so it lands in a Session 1+ logon (never
//!   Session 0). Equivalent to what `scripts/install.ps1 -AutoStart`
//!   does — the install script can call out to this subcommand to
//!   keep the registration logic in one place.
//! - **macOS / Linux**: not implemented yet. Returns an error pointing
//!   the user at the manual recipe (`launchctl` / `systemctl --user`).
//!   `scripts/install-local.sh --autostart` covers the manual path
//!   today.
//!
//! ## Why shell out (Windows)
//!
//! The Task Scheduler 2.0 COM surface (`ITaskService`, `ITaskDefinition`,
//! `ITaskFolder`, `IPrincipal`, ...) is ~10 nested COM-wrapper calls in
//! Rust before you've even configured the principal, with multiple BSTR
//! marshalling steps and a lot of "this method takes a VARIANT, that
//! one takes a BSTR" footguns. Shelling out to PowerShell's
//! `Register-ScheduledTask` cmdlet — which itself uses Task Scheduler
//! 2.0 under the hood — gets us identical behavior in 5 lines and stays
//! exactly in lock-step with what `scripts/install.ps1` does (literally
//! the same command). When `install.ps1` evolves, this code follows it
//! for free.

use anyhow::{anyhow, Result};

/// Canonical task name for this installed product.
pub fn task_name() -> &'static str {
    #[cfg(target_os = "windows")]
    {
        crate::bundle::autostart_task_name()
    }
    #[cfg(not(target_os = "windows"))]
    {
        "cua-driver-serve"
    }
}

/// Reported by `status`.
///
/// `#[allow(dead_code)]` on the variants because they're constructed
/// only inside the `#[cfg(target_os = "windows")]` `platform::status`
/// (schtasks-backed), while the enum itself is cross-platform — the
/// non-Windows stub returns `Err(NOT_YET)` instead. The variants ARE
/// reachable from `Status::tag` on every platform via the match, but
/// rustc's dead-code analysis runs after cfg-stripping, so on
/// macOS/Linux it sees the variants without a constructor and warns.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[allow(dead_code)]
pub enum Status {
    /// No autostart entry registered.
    NotRegistered,
    /// Entry registered but not currently running.
    RegisteredIdle,
    /// Entry registered AND a `cua-driver serve` process is live.
    RegisteredRunning,
}

impl Status {
    pub fn tag(self) -> &'static str {
        match self {
            Status::NotRegistered => "not-registered",
            Status::RegisteredIdle => "registered (not running)",
            Status::RegisteredRunning => "registered (running)",
        }
    }
}

/// Outcome of asking `schtasks /HRESULT` whether the autostart task exists.
///
/// Keep query failures separate from `Status::NotRegistered`: a caller that
/// cannot inspect Task Scheduler must not report that the task is absent.
#[cfg(any(target_os = "windows", test))]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum TaskQueryOutcome {
    Registered,
    NotRegistered,
    PermissionDenied,
    Unknown,
}

#[cfg(any(target_os = "windows", test))]
const HRESULT_FILE_NOT_FOUND: u32 = 0x8007_0002;

#[cfg(any(target_os = "windows", test))]
const HRESULT_ACCESS_DENIED: u32 = 0x8007_0005;

/// What a post-registration Task Scheduler query proves about `enable()`.
///
/// `enable()` used to report success whenever the elevation helper exited 0,
/// and a declined UAC prompt exited 0 (#3179). Verifying the task independently
/// of the exit code keeps that class of regression from surfacing as success
/// again — but a query that cannot be answered must not be turned into a false
/// failure either, hence the third variant.
#[cfg(any(target_os = "windows", test))]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum RegistrationCheck {
    /// The task exists: registration really happened.
    Confirmed,
    /// Task Scheduler answered, and the task is not there.
    Missing,
    /// Task Scheduler could not be inspected; neither prove nor disprove.
    Unverifiable,
}

#[cfg(any(target_os = "windows", test))]
fn classify_registration_check(outcome: TaskQueryOutcome) -> RegistrationCheck {
    match outcome {
        TaskQueryOutcome::Registered => RegistrationCheck::Confirmed,
        TaskQueryOutcome::NotRegistered => RegistrationCheck::Missing,
        TaskQueryOutcome::PermissionDenied | TaskQueryOutcome::Unknown => {
            RegistrationCheck::Unverifiable
        }
    }
}

#[cfg(any(target_os = "windows", test))]
fn classify_task_query(success: bool, exit_code: Option<i32>) -> TaskQueryOutcome {
    if success {
        return TaskQueryOutcome::Registered;
    }

    // `/HRESULT` makes the process exit code carry the original Windows error
    // instead of collapsing every failure to exit 1. Interpret the i32 as its
    // raw u32 bit pattern because Windows HRESULTs have the high bit set.
    match exit_code.map(|code| code as u32) {
        Some(HRESULT_FILE_NOT_FOUND) => TaskQueryOutcome::NotRegistered,
        Some(HRESULT_ACCESS_DENIED) => TaskQueryOutcome::PermissionDenied,
        _ => TaskQueryOutcome::Unknown,
    }
}

// ── Public API ────────────────────────────────────────────────────────────

/// Register the platform-native autostart entry for `cua-driver serve`.
/// Idempotent: any existing entry with the same name is replaced.
pub fn enable() -> Result<()> {
    let exe = current_exe_for_autostart()?;
    platform::enable(&exe)
}

/// Remove the autostart entry. No-op if none is registered.
pub fn disable() -> Result<()> {
    platform::disable()
}

/// Report whether the entry is registered and whether the daemon is running.
pub fn status() -> Result<Status> {
    platform::status()
}

/// Run the autostart entry immediately without waiting for a fresh logon.
/// Errors if the entry isn't registered.
pub fn kick() -> Result<()> {
    platform::kick()
}

/// Find the cua-driver executable to bake into the autostart entry. The
/// resolved path is what gets stored in the Scheduled Task / LaunchAgent /
/// unit file.
///
/// On Windows the path is used **as invoked**, without canonicalisation.
/// Canonicalising resolves the `bin -> current -> releases/<version>` junction
/// chain down to a versioned release path, which then gets baked into the
/// Scheduled Task — so the next upgrade (which only flips `current`) leaves the
/// task launching the previous build. Keeping the junction path is what makes a
/// versioned upgrade transparent to the registered task.
///
/// Elsewhere the path is canonicalised (best-effort — on error the path is
/// used as invoked) to resolve symlink chains.
fn current_exe_for_autostart() -> Result<String> {
    let exe = std::env::current_exe()
        .map_err(|e| anyhow!("could not resolve current executable: {e}"))?;
    #[cfg(target_os = "windows")]
    let resolved = exe;
    #[cfg(not(target_os = "windows"))]
    let resolved = std::fs::canonicalize(&exe).unwrap_or(exe);
    let path = resolved.to_string_lossy().into_owned();
    // Defensive: should the path ever arrive in the `\\?\C:\...`
    // extended-length form, strip the prefix for readability. PowerShell and
    // the Task Scheduler XML schema handle both forms correctly, but the
    // prefixed one looks alarming in `schtasks /Query` output.
    //
    // Only the plain drive-letter form is stripped, and only while the result
    // still fits MAX_PATH: `\\?\UNC\server\share\...` is a different namespace
    // (stripping it yields a bogus `UNC\server\...`), and a path longer than
    // 260 chars needs the prefix to remain addressable.
    #[cfg(target_os = "windows")]
    let path = windows_task_path(path);
    Ok(path)
}

#[cfg(any(target_os = "windows", test))]
fn windows_task_path(path: String) -> String {
    match path.strip_prefix(r"\\?\") {
        Some(stripped) if stripped.len() < 260 && starts_with_drive_letter(stripped) => {
            stripped.to_owned()
        }
        _ => path,
    }
}

/// `true` when the path opens with a plain `<drive>:` — i.e. not the
/// `UNC\server\share` form the extended-length namespace also carries.
#[cfg(any(target_os = "windows", test))]
fn starts_with_drive_letter(path: &str) -> bool {
    matches!(path.as_bytes(), [drive, b':', ..] if drive.is_ascii_alphabetic())
}

// ── Windows self-elevation helper script ──────────────────────────────────

/// PowerShell that re-launches this executable elevated (UAC) and forwards the
/// elevated child's exit code.
///
/// **Every failure path must exit non-zero.** The original one-liner was
/// `$p = Start-Process ... -Verb RunAs -Wait -PassThru; exit $p.ExitCode`.
/// A declined UAC prompt makes `Start-Process` raise a *non-terminating*
/// error, so `$p` stayed unset, `$null.ExitCode` was `$null`, and `exit $null`
/// exits **0** — a dismissed prompt was reported as a registered autostart
/// entry (#3179). Two independent guards now cover that:
///
/// 1. `-ErrorAction Stop` promotes the declined-UAC error to a terminating one
///    so the `catch` runs and exits 1.
/// 2. The explicit `$null` check, because `exit $null` silently meaning
///    `exit 0` is precisely the trap that produced the bug. It also covers a
///    process object that came back without an exit code.
///
/// `__INNER_COMMAND__` is substituted with the single-quoted PowerShell string
/// holding the elevated child's `-Command` argument.
#[cfg(any(target_os = "windows", test))]
const ELEVATE_PS: &str = r#"
$p = $null
try {
    $p = Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-NonInteractive','-Command',__INNER_COMMAND__) -Verb RunAs -Wait -PassThru -ErrorAction Stop
} catch {
    [Console]::Error.WriteLine("cua-driver: UAC elevation for autostart registration failed: " + $_.Exception.Message)
    exit 1
}
if ($null -eq $p -or $null -eq $p.ExitCode) {
    [Console]::Error.WriteLine("cua-driver: UAC elevation for autostart registration returned no process.")
    exit 1
}
exit $p.ExitCode
"#;

/// Build the self-elevation script for `exe`.
///
/// The elevated child runs `<exe> autostart enable` so the registration happens
/// inside the elevated process, where the first (direct) attempt succeeds and
/// does not re-enter the elevation branch.
#[cfg(any(target_os = "windows", test))]
fn elevation_script(exe: &str) -> String {
    // `& "<exe>" autostart enable` — PowerShell escapes `"` as `` `" `` inside
    // a double-quoted string.
    let inner = format!("& \"{}\" autostart enable", exe.replace('"', "`\""));
    // Embed that as a single-quoted PowerShell string (PS escapes `'` as `''`
    // inside `'`-strings).
    let inner_quoted = format!("'{}'", inner.replace('\'', "''"));
    ELEVATE_PS.replace("__INNER_COMMAND__", &inner_quoted)
}

// ── Windows impl ──────────────────────────────────────────────────────────

#[cfg(target_os = "windows")]
mod platform {
    use super::*;
    use std::process::Command;

    /// Inline PowerShell that mirrors `install.ps1::Register-CuaDriverAutostart`
    /// exactly. Kept as a single one-liner so a quick `gh-blame` diff against
    /// install.ps1 surfaces any divergence; the moment install.ps1 changes
    /// shape, this script needs the same edit.
    ///
    /// **Hidden-console launch (issue #1645):** the task action wraps
    /// `cua-driver.exe serve` in `powershell -WindowStyle Hidden` +
    /// `Start-Process -WindowStyle Hidden`. Without this, Task Scheduler
    /// allocates a new CUI console window (because `cua-driver.exe` is a
    /// console-subsystem binary) that stays visible on the user's desktop
    /// for the lifetime of the daemon. The PowerShell wrapper exits
    /// immediately after spawning the child, leaving only `cua-driver.exe`
    /// in the process tree.
    ///
    /// **RunLevel = Highest** (since 2026-05-21): the daemon is registered to
    /// run at the user's elevated/admin token rather than the filtered
    /// standard-user token. This is what lets the daemon drive UWP /
    /// AppContainer apps (Calculator, modern Settings, Photos, …) — at
    /// Medium IL the cross-AppContainer UIA RPC returns a stub (~1 element
    /// instead of the full tree, see #1602 / #1601). High IL crosses that
    /// boundary cleanly. Trade-off: `Register-ScheduledTask -RunLevel
    /// Highest` requires the caller to already be at High IL, so this
    /// function emits an actionable error when invoked from a non-elevated
    /// shell. Users opt into autostart via the installer's `-AutoStart`
    /// flag or `cua-driver autostart enable`, both of which prompt for
    /// elevation when needed.
    ///
    /// **Account-name format**: on domain-joined machines USERDOMAIN holds the
    /// AD domain name (e.g. CORP) and the principal must be `CORP\username`.
    /// On workgroup machines USERDOMAIN holds either the literal string
    /// "WORKGROUP" or the COMPUTERNAME, and the principal must be
    /// `COMPUTERNAME\username` — `WORKGROUP\username` errors with
    /// "No mapping between account names and security IDs was done". The
    /// $domain selector below picks USERDOMAIN when it's a real
    /// (non-WORKGROUP, non-COMPUTERNAME) domain and falls back to
    /// COMPUTERNAME otherwise, covering both shapes.
    const REGISTER_PS: &str = r#"
$ErrorActionPreference = 'Stop'
if ($env:USERDOMAIN -and $env:USERDOMAIN -ne 'WORKGROUP' -and $env:USERDOMAIN -ne $env:COMPUTERNAME) {
    $domain = $env:USERDOMAIN
} else {
    $domain = $env:COMPUTERNAME
}
$user = "$domain\$env:USERNAME"
# Use a hidden PowerShell wrapper as the task action so Windows never
# allocates a visible console window when the daemon is launched at
# logon. cua-driver.exe is a CUI (console-subsystem) binary: without
# this wrapper, Task Scheduler allocates a new console and the window
# stays on the user's desktop for the lifetime of the daemon (issue #1645).
# Start-Process -WindowStyle Hidden spawns the child fully detached;
# the powershell.exe wrapper exits immediately after, leaving only the
# cua-driver.exe daemon in the process tree.
$action = New-ScheduledTaskAction `
    -Execute 'powershell.exe' `
    -Argument "-NoProfile -WindowStyle Hidden -NonInteractive -Command `"Start-Process -FilePath '$env:CUA_DRIVER_AS_EXE' -ArgumentList 'serve' -WindowStyle Hidden -WorkingDirectory '$env:USERPROFILE'`"" `
    -WorkingDirectory $env:USERPROFILE
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $user
$principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Highest
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit (New-TimeSpan -Hours 0)
# -Force replaces an existing task in one Task Scheduler call. Never
# unregister first: if the new registration then failed (for example as
# SYSTEM or without elevation), the machine would be left with no task
# (#4090). A failed replacement keeps the existing task.
Register-ScheduledTask -Force -TaskName $env:CUA_DRIVER_AS_TASK -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description "${env:CUA_DRIVER_AS_CLI}: serve daemon, auto-start at interactive logon, RunLevel=Highest for UWP/AppContainer support" | Out-Null

# The uiAccess worker (`cua-driver-uia.exe`) has no public client route and is
# not started by this task. The High-IL daemon is the supported path for
# elevated/AppContainer pixel input. A future worker path must be forwarded by
# the authorized parent daemon rather than exposed to public clients. See #1602.
"#;

    pub fn enable(exe: &str) -> Result<()> {
        // First attempt: register directly. Works when called from an
        // already-elevated context (install.ps1's self-elevated child shell,
        // or a user running cua-driver autostart enable from an admin
        // PowerShell). Pass the binary path via env var so the script
        // doesn't need shell-quoting acrobatics for paths with spaces.
        let out = Command::new("powershell")
            .args(["-NoProfile", "-NonInteractive", "-Command", REGISTER_PS])
            .env("CUA_DRIVER_AS_EXE", exe)
            .env("CUA_DRIVER_AS_TASK", task_name())
            .env("CUA_DRIVER_AS_CLI", crate::bundle::cli_name())
            .output()
            .map_err(|e| anyhow!("failed to invoke powershell: {e}"))?;
        if out.status.success() {
            return confirm_registered();
        }

        let stderr = String::from_utf8_lossy(&out.stderr);
        let stderr_lower = stderr.to_lowercase();
        let looks_like_access_denied = stderr_lower.contains("access is denied")
            || stderr_lower.contains("0x80070005")
            || stderr_lower.contains("permission")
            || stderr_lower.contains("requires elevation");

        if !looks_like_access_denied {
            return Err(anyhow!(
                "PowerShell Register-ScheduledTask failed (exit {}): {}",
                out.status.code().unwrap_or(-1),
                stderr.trim()
            ));
        }

        // Access-denied — caller is at Medium IL but the task wants Highest.
        // Self-elevate via ShellExecute "runas" verb, which fires the UAC
        // prompt. The elevated child runs the same registration via
        // powershell -Command, with the registered binary path injected as
        // an env var (durable across the elevation boundary).
        eprintln!("cua-driver: registering autostart at RunLevel=Highest needs admin.");
        eprintln!("cua-driver: triggering UAC prompt — accept it to register the task.");

        let elevated_status = {
            use std::os::windows::process::CommandExt;
            // CREATE_NO_WINDOW = 0x08000000 — keep the elevated child's
            // console out of the foreground; PowerShell already runs hidden
            // via Start-Process -Verb RunAs's WindowStyle Hidden.
            const CREATE_NO_WINDOW: u32 = 0x08000000;

            // Start-Process -Verb RunAs elevates; -Wait so we can capture the
            // child's exit code. See `ELEVATE_PS` for why every failure path
            // there has to exit non-zero.
            let outer = elevation_script(exe);
            Command::new("powershell")
                .args(["-NoProfile", "-NonInteractive", "-Command", &outer])
                .creation_flags(CREATE_NO_WINDOW)
                .status()
                .map_err(|e| anyhow!("failed to spawn elevation helper: {e}"))?
        };

        if elevated_status.success() {
            confirm_registered()
        } else {
            Err(anyhow!(
                "self-elevation for autostart registration failed (exit {}). The UAC \
                 prompt was probably dismissed. Re-run `cua-driver autostart enable` \
                 and accept the prompt, or run install.ps1 -AutoStart which has the \
                 same self-elevation flow. See https://github.com/trycua/cua/issues/1602.",
                elevated_status.code().unwrap_or(-1)
            ))
        }
    }

    /// Result of one `schtasks /Query` against the autostart task.
    struct TaskQuery {
        outcome: TaskQueryOutcome,
        exit_code: Option<i32>,
        diagnostic: String,
    }

    /// Ask Task Scheduler whether the autostart task exists.
    ///
    /// Without `/HRESULT`, schtasks collapses "task not found", permission
    /// failures, and other Task Scheduler errors to exit 1. `/HRESULT` keeps
    /// those cases distinct and is locale-independent: ERROR_FILE_NOT_FOUND
    /// means the named task is absent, while ERROR_PATH_NOT_FOUND means the
    /// scheduler namespace could not be inspected and therefore stays unknown.
    fn query_task() -> Result<TaskQuery> {
        let out = Command::new("schtasks")
            .args(["/Query", "/TN", task_name(), "/HRESULT"])
            .output()
            .map_err(|e| anyhow!("failed to invoke schtasks: {e}"))?;

        let stdout = String::from_utf8_lossy(&out.stdout);
        let stderr = String::from_utf8_lossy(&out.stderr);
        let diagnostic = match (stdout.trim(), stderr.trim()) {
            ("", "") => "no diagnostic output".to_owned(),
            (stdout, "") => stdout.to_owned(),
            ("", stderr) => stderr.to_owned(),
            (stdout, stderr) => format!("{stdout}\n{stderr}"),
        };
        Ok(TaskQuery {
            outcome: classify_task_query(out.status.success(), out.status.code()),
            exit_code: out.status.code(),
            diagnostic,
        })
    }

    /// Postcondition for `enable`: the task has to actually exist afterwards.
    ///
    /// Reporting success is a promise that `cua-driver serve` will come up at
    /// the next logon, and until #3179 that promise rested entirely on the exit
    /// code of the elevation helper — which a declined UAC prompt left at 0.
    /// Asking Task Scheduler directly makes the promise independent of the
    /// exit-code plumbing. A query that cannot be answered (permission denied,
    /// scheduler unreachable) is reported as unverified rather than converted
    /// into a failure: registration may well have succeeded, and a false
    /// negative here is its own kind of misleading.
    fn confirm_registered() -> Result<()> {
        let query = match query_task() {
            Ok(query) => query,
            Err(e) => {
                eprintln!("cua-driver: could not verify autostart registration: {e}");
                return Ok(());
            }
        };
        match classify_registration_check(query.outcome) {
            RegistrationCheck::Confirmed => Ok(()),
            RegistrationCheck::Missing => Err(anyhow!(
                "autostart registration reported success but scheduled task '{}' does not \
                 exist. If a UAC prompt appeared, it was dismissed or the elevated \
                 registration failed. Re-run `{} autostart enable` from an elevated shell. \
                 See https://github.com/trycua/cua/issues/3179.",
                task_name(),
                crate::bundle::cli_name()
            )),
            RegistrationCheck::Unverifiable => {
                eprintln!(
                    "cua-driver: registered autostart task '{}' but could not verify it with \
                     schtasks: {}",
                    task_name(),
                    query.diagnostic
                );
                Ok(())
            }
        }
    }

    pub fn disable() -> Result<()> {
        // Tear down the legacy release `cua-driver-uia` task only when
        // managing the release product. Older versions registered a separate
        // task for the worker; current versions retain no worker autostart.
        // Local management must never alter that release task.
        if !crate::bundle::is_local_installation() {
            let _ = Command::new("schtasks")
                .args(["/Delete", "/TN", "cua-driver-uia", "/F"])
                .output();
        }

        // schtasks /Delete returns 0 on success, 1 on "task not found"
        // (which we treat as success: the goal is "no task registered"
        // and it already isn't). Match on stderr text rather than exit
        // code because schtasks doesn't distinguish "doesn't exist" from
        // "permission denied" via exit code.
        let out = Command::new("schtasks")
            .args(["/Delete", "/TN", task_name(), "/F"])
            .output()
            .map_err(|e| anyhow!("failed to invoke schtasks: {e}"))?;
        if out.status.success() {
            return Ok(());
        }
        let stderr = String::from_utf8_lossy(&out.stderr);
        let stdout = String::from_utf8_lossy(&out.stdout);
        let combined = format!("{stdout}{stderr}").to_lowercase();
        if combined.contains("does not exist")
            || combined.contains("cannot find the file specified")
            || combined.contains("the system cannot find")
        {
            return Ok(());
        }
        Err(anyhow!(
            "schtasks /Delete failed (exit {}): {}",
            out.status.code().unwrap_or(-1),
            stderr.trim()
        ))
    }

    pub fn status() -> Result<Status> {
        let query = query_task().map_err(|e| anyhow!("unknown: {e}"))?;
        match query.outcome {
            TaskQueryOutcome::Registered => {}
            TaskQueryOutcome::NotRegistered => return Ok(Status::NotRegistered),
            outcome @ (TaskQueryOutcome::PermissionDenied | TaskQueryOutcome::Unknown) => {
                let tag = match outcome {
                    TaskQueryOutcome::PermissionDenied => "permission-denied",
                    TaskQueryOutcome::Unknown => "unknown",
                    _ => unreachable!(),
                };
                let diagnostic = query.diagnostic;
                let hresult = query
                    .exit_code
                    .map(|code| format!("0x{:08X}", code as u32))
                    .unwrap_or_else(|| "unavailable".to_owned());
                return Err(anyhow!(
                    "{tag}: schtasks /Query /HRESULT failed (HRESULT {hresult}): {diagnostic}"
                ));
            }
        }

        // Registered — now check whether `cua-driver serve` is running.
        // Avoid invoking `tasklist` (slow ~200ms on first run); use the
        // same registry the daemon's own status command uses via a
        // direct check on the named pipe.
        if crate::serve::is_daemon_listening(&crate::serve::default_socket_path()) {
            Ok(Status::RegisteredRunning)
        } else {
            Ok(Status::RegisteredIdle)
        }
    }

    pub fn kick() -> Result<()> {
        let out = Command::new("schtasks")
            .args(["/Run", "/TN", task_name()])
            .output()
            .map_err(|e| anyhow!("failed to invoke schtasks: {e}"))?;
        if !out.status.success() {
            let stderr = String::from_utf8_lossy(&out.stderr);
            return Err(anyhow!(
                "schtasks /Run failed (exit {}): {}",
                out.status.code().unwrap_or(-1),
                stderr.trim()
            ));
        }
        Ok(())
    }
}

// ── macOS / Linux stubs ───────────────────────────────────────────────────

#[cfg(not(target_os = "windows"))]
mod platform {
    use super::*;

    const NOT_YET: &str = "cua-driver autostart is currently Windows-only. macOS users: see \
         libs/cua-driver/scripts/install-local.sh --autostart for the \
         LaunchAgent recipe. Linux users: same script registers a systemd \
         --user unit. A cross-platform impl is tracked as a follow-up.";

    pub fn enable(_exe: &str) -> Result<()> {
        Err(anyhow!(NOT_YET))
    }
    pub fn disable() -> Result<()> {
        Err(anyhow!(NOT_YET))
    }
    pub fn status() -> Result<Status> {
        Err(anyhow!(NOT_YET))
    }
    pub fn kick() -> Result<()> {
        Err(anyhow!(NOT_YET))
    }
}

// ── CLI dispatcher ────────────────────────────────────────────────────────

/// `cua-driver autostart <subcommand>` entry point. Prints user-facing
/// output and exits the process via `std::process::exit` so the caller
/// (main) doesn't need to plumb back an exit code for every subcommand.
pub fn run_autostart_cmd(subcommand: &str) {
    let (verb_result, success_text): (Result<()>, String) = match subcommand {
        "enable" => (
            enable(),
            format!(
                "Registered autostart entry '{}'.\n  \
             {} serve will start at every interactive logon.",
                task_name(),
                crate::bundle::cli_name()
            ),
        ),
        "disable" => (
            disable(),
            format!(
                "Removed autostart entry '{}' (no-op if it was already absent).",
                task_name()
            ),
        ),
        "status" => match status() {
            Ok(s) => {
                println!("{}", s.tag());
                std::process::exit(0);
            }
            Err(e) => {
                eprintln!("cua-driver autostart status: {e}");
                std::process::exit(1);
            }
        },
        "kick" => (
            kick(),
            format!(
                "Started autostart entry '{}' for the current session.",
                task_name()
            ),
        ),
        other => {
            eprintln!("Unknown autostart subcommand: {other:?}");
            eprintln!("Usage: cua-driver autostart {{enable|disable|status|kick}}");
            std::process::exit(64);
        }
    };
    match verb_result {
        Ok(()) => {
            println!("{success_text}");
            std::process::exit(0);
        }
        Err(e) => {
            eprintln!("cua-driver autostart {subcommand}: {e}");
            std::process::exit(1);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn windows_task_path_strips_short_extended_drive_prefix() {
        assert_eq!(
            windows_task_path(r"\\?\C:\Users\Example\cua-driver.exe".to_owned()),
            r"C:\Users\Example\cua-driver.exe"
        );
    }

    #[test]
    fn windows_task_path_preserves_extended_unc_path() {
        let path = r"\\?\UNC\server\share\cua-driver.exe";
        assert_eq!(windows_task_path(path.to_owned()), path);
    }

    #[test]
    fn windows_task_path_preserves_extended_long_drive_path() {
        let path = format!(r"\\?\C:\{}\cua-driver.exe", "nested".repeat(50));
        assert!(path.len() >= 260);
        assert_eq!(windows_task_path(path.clone()), path);
    }

    #[cfg(target_os = "windows")]
    #[test]
    fn child_reports_current_exe_for_junction_probe() {
        let Ok(output_path) = std::env::var("CUA_CURRENT_EXE_PROBE_OUTPUT") else {
            return;
        };
        std::fs::write(output_path, current_exe_for_autostart().unwrap()).unwrap();
    }

    #[cfg(target_os = "windows")]
    #[test]
    fn current_exe_preserves_installer_junction_chain() {
        use std::process::Command;

        let temp = tempfile::tempdir().unwrap();
        let releases = temp.path().join("packages").join("releases");
        let release = releases.join("probe-v1");
        let current = temp.path().join("packages").join("current");
        let visible = temp.path().join("bin");
        std::fs::create_dir_all(&release).unwrap();

        let test_exe = std::env::current_exe().unwrap();
        let exe_name = test_exe.file_name().unwrap();
        std::fs::copy(&test_exe, release.join(exe_name)).unwrap();

        for (link, target) in [(&current, &release), (&visible, &current)] {
            let output = Command::new("cmd")
                .args(["/C", "mklink", "/J"])
                .arg(link)
                .arg(target)
                .output()
                .unwrap();
            assert!(
                output.status.success(),
                "failed to create junction {} -> {}: {}{}",
                link.display(),
                target.display(),
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            );
        }

        let visible_exe = visible.join(exe_name);
        let probe_output = temp.path().join("current-exe.txt");
        let child = Command::new(&visible_exe)
            .args([
                "--exact",
                "autostart::tests::child_reports_current_exe_for_junction_probe",
                "--nocapture",
            ])
            .env("CUA_CURRENT_EXE_PROBE_OUTPUT", &probe_output)
            .output()
            .unwrap();
        assert!(
            child.status.success(),
            "junction-launched child failed: {}{}",
            String::from_utf8_lossy(&child.stdout),
            String::from_utf8_lossy(&child.stderr)
        );

        let observed = std::fs::read_to_string(&probe_output).unwrap();
        let observed = windows_task_path(observed.trim().to_owned());
        let expected = visible_exe.to_string_lossy();
        assert_eq!(
            observed.to_ascii_lowercase(),
            expected.to_ascii_lowercase(),
            "Windows resolved the invoked installer junction path to a release path"
        );
    }

    // ── Self-elevation exit-code semantics (#3179) ────────────────────────

    #[test]
    fn elevation_script_guards_every_failure_path() {
        let script = elevation_script(r"C:\Cua\cua-driver.exe");

        // Promotes the declined-UAC non-terminating error to a terminating one.
        assert!(script.contains("-ErrorAction Stop"), "{script}");
        assert!(script.contains("catch {"), "{script}");
        // Defence in depth: `exit $null` exits 0, which is the trap that made a
        // dismissed prompt look like a successful registration.
        assert!(
            script.contains("if ($null -eq $p -or $null -eq $p.ExitCode)"),
            "{script}"
        );
        assert!(!script.contains("__INNER_COMMAND__"), "{script}");
        assert!(
            script.contains(r#"'& "C:\Cua\cua-driver.exe" autostart enable'"#),
            "{script}"
        );
    }

    #[test]
    fn elevation_script_escapes_quotes_in_the_executable_path() {
        let script = elevation_script("C:\\o'brien\\a\"b\\cua-driver.exe");

        // `'` doubled for the single-quoted PowerShell string, `"` backtick-
        // escaped for the double-quoted call operator argument.
        assert!(script.contains("o''brien"), "{script}");
        assert!(script.contains("a`\"b"), "{script}");
    }

    /// Run the shipped elevation script against a stubbed `Start-Process`.
    ///
    /// A PowerShell function shadows the cmdlet of the same name, so the script
    /// under test runs verbatim — no real UAC prompt, which is what makes the
    /// exit-code contract testable in CI at all.
    #[cfg(target_os = "windows")]
    fn elevation_script_exit_code(stub_body: &str) -> i32 {
        use std::process::Command;

        let temp = tempfile::tempdir().unwrap();
        let script_path = temp.path().join("elevation-probe.ps1");
        let contents = format!(
            "function Start-Process {{\n\
             [CmdletBinding()]\n\
             param([string]$FilePath,[string[]]$ArgumentList,[string]$Verb,\
             [switch]$Wait,[switch]$PassThru)\n\
             {stub_body}\n\
             }}\n{}",
            elevation_script(r"C:\Cua\cua-driver.exe")
        );
        std::fs::write(&script_path, contents).unwrap();

        let status = Command::new("powershell")
            .args([
                "-NoProfile",
                "-NonInteractive",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
            ])
            .arg(&script_path)
            .status()
            .unwrap();
        status.code().expect("powershell reported no exit code")
    }

    /// The regression itself: declining UAC raises a non-terminating error, so
    /// the pre-fix `$p = Start-Process ...; exit $p.ExitCode` exited 0 and
    /// `enable()` reported a registered autostart entry (#3179).
    #[cfg(target_os = "windows")]
    #[test]
    fn declined_uac_exits_non_zero() {
        let declined = "Write-Error 'This command cannot be run due to the error: \
                        The operation was canceled by the user.'";
        assert_eq!(elevation_script_exit_code(declined), 1);
    }

    #[cfg(target_os = "windows")]
    #[test]
    fn absent_process_object_exits_non_zero() {
        assert_eq!(elevation_script_exit_code("return $null"), 1);
    }

    #[cfg(target_os = "windows")]
    #[test]
    fn absent_child_exit_code_exits_non_zero() {
        assert_eq!(
            elevation_script_exit_code("return [pscustomobject]@{ ExitCode = $null }"),
            1
        );
    }

    #[cfg(target_os = "windows")]
    #[test]
    fn accepted_uac_forwards_the_child_exit_code() {
        assert_eq!(
            elevation_script_exit_code("return [pscustomobject]@{ ExitCode = 0 }"),
            0
        );
        assert_eq!(
            elevation_script_exit_code("return [pscustomobject]@{ ExitCode = 3 }"),
            3
        );
    }

    // ── Post-registration verification ────────────────────────────────────

    #[test]
    fn present_task_confirms_registration() {
        assert_eq!(
            classify_registration_check(TaskQueryOutcome::Registered),
            RegistrationCheck::Confirmed
        );
    }

    #[test]
    fn absent_task_contradicts_reported_success() {
        assert_eq!(
            classify_registration_check(TaskQueryOutcome::NotRegistered),
            RegistrationCheck::Missing
        );
    }

    #[test]
    fn unanswerable_query_is_never_a_false_failure() {
        assert_eq!(
            classify_registration_check(TaskQueryOutcome::PermissionDenied),
            RegistrationCheck::Unverifiable
        );
        assert_eq!(
            classify_registration_check(TaskQueryOutcome::Unknown),
            RegistrationCheck::Unverifiable
        );
    }

    #[test]
    fn successful_task_query_is_registered() {
        assert_eq!(
            classify_task_query(true, Some(0)),
            TaskQueryOutcome::Registered
        );
        assert_eq!(
            classify_task_query(true, Some(HRESULT_ACCESS_DENIED as i32)),
            TaskQueryOutcome::Registered
        );
    }

    #[test]
    fn file_not_found_is_not_registered() {
        assert_eq!(
            classify_task_query(false, Some(HRESULT_FILE_NOT_FOUND as i32)),
            TaskQueryOutcome::NotRegistered
        );
    }

    #[test]
    fn access_failure_is_permission_denied() {
        assert_eq!(
            classify_task_query(false, Some(HRESULT_ACCESS_DENIED as i32)),
            TaskQueryOutcome::PermissionDenied
        );
    }

    #[test]
    fn unrecognized_failure_is_unknown() {
        const HRESULT_PATH_NOT_FOUND: u32 = 0x8007_0003;
        const HRESULT_RPC_SERVER_UNAVAILABLE: u32 = 0x8007_06BA;

        assert_eq!(
            classify_task_query(false, Some(HRESULT_PATH_NOT_FOUND as i32)),
            TaskQueryOutcome::Unknown
        );
        assert_eq!(
            classify_task_query(false, Some(HRESULT_RPC_SERVER_UNAVAILABLE as i32)),
            TaskQueryOutcome::Unknown
        );
        assert_eq!(
            classify_task_query(false, Some(1)),
            TaskQueryOutcome::Unknown
        );
        assert_eq!(classify_task_query(false, None), TaskQueryOutcome::Unknown);
    }
}
