use std::io::Write;
use std::sync::{Arc, Mutex};
use std::time::Duration;

use async_trait::async_trait;
use serde_json::{json, Value};

use crate::{
    authorization::PermissionMode,
    protocol::ToolResult,
    session_authorization::{
        EffectiveAuthorizationContext, SessionAuthorizationRegistry, SessionModeCeiling,
    },
    tool::{Tool, ToolDef, ToolRegistry},
};

/// A stand-in platform tool that records every call it receives and fails
/// when asked to (`{"fail": true}`).
struct Probe {
    def: ToolDef,
    calls: Arc<Mutex<Vec<Value>>>,
    pacings: Arc<Mutex<Vec<(String, crate::step_pacing::StepPacing)>>>,
}

#[async_trait]
impl Tool for Probe {
    fn def(&self) -> &ToolDef {
        &self.def
    }

    async fn invoke(&self, args: Value) -> ToolResult {
        self.calls.lock().unwrap().push(args.clone());
        self.pacings
            .lock()
            .unwrap()
            .push((self.def.name.clone(), crate::step_pacing::current()));
        if let Some(message) = args["fail_message"].as_str() {
            return ToolResult::error(message.to_owned());
        }
        if args["fail"] == true {
            ToolResult::error(format!("{} refused: probe asked to fail", self.def.name))
        } else {
            ToolResult::text(format!("{} done", self.def.name))
        }
    }
}

struct Harness {
    registry: Arc<ToolRegistry>,
    calls: std::collections::HashMap<&'static str, Arc<Mutex<Vec<Value>>>>,
    pacings: Arc<Mutex<Vec<(String, crate::step_pacing::StepPacing)>>>,
}

impl Harness {
    fn new() -> Self {
        let mut registry = ToolRegistry::new();
        let mut calls = std::collections::HashMap::new();
        let pacings: Arc<Mutex<Vec<(String, crate::step_pacing::StepPacing)>>> = Arc::default();
        for name in super::BATCHABLE_TOOLS.iter().copied().chain([
            "get_window_state",
            "zoom",
            "invoke_menu",
        ]) {
            let log = Arc::new(Mutex::new(Vec::new()));
            calls.insert(name, log.clone());
            registry.register(Box::new(Probe {
                def: ToolDef {
                    name: name.into(),
                    description: "probe".into(),
                    input_schema: json!({
                        "type": "object",
                        "properties": {
                            "pid": {"type": "integer"},
                            "window_id": {"type": "integer"},
                            "text": {"type": "string"},
                            "fail": {"type": "boolean"},
                            "fail_message": {"type": "string"},
                            "element_token": {"type": "string"},
                            "value": {"type": "string"},
                            "key": {"type": "string"},
                            "keys": {"type": "array", "items": {"type": "string"}, "minItems": 2},
                            "modifiers": {"type": "array", "items": {"type": "string"}},
                            "count": {"type": "integer", "minimum": 1},
                            "query": {"type": "string"},
                            "delivery_mode": {"type": "string"},
                            "path": {"type": "array", "items": {"type": "string"}},
                            "x1": {"type": "number"}, "y1": {"type": "number"},
                            "x2": {"type": "number"}, "y2": {"type": "number"},
                            "include_screenshot": {"type": "boolean"},
                            "since": {"type": "string"},
                            "direction": {"type": "string", "enum": ["up", "down", "left", "right"]},
                            "amount": {"type": "integer", "minimum": 1, "maximum": 50},
                            "x": {"type": "number"},
                            "y": {"type": "number"},
                            "button": {"type": "string", "enum": ["left", "right", "middle"]},
                            "target": {"type": "object"},
                            "full_output": {"type": "boolean"},
                            "max_elements": {"type": "integer", "minimum": 1}
                        },
                        "additionalProperties": false
                    }),
                    read_only: matches!(name, "get_window_state" | "zoom"),
                    destructive: false,
                    idempotent: false,
                    open_world: false,
                },
                calls: log,
                pacings: pacings.clone(),
            }));
        }
        registry.register_session_tools();
        let registry = Arc::new(registry);
        registry.init_self_weak();
        Self {
            registry,
            calls,
            pacings,
        }
    }

    fn hits(&self, tool: &str) -> usize {
        self.calls[tool].lock().unwrap().len()
    }

    fn last(&self, tool: &str) -> Value {
        self.calls[tool]
            .lock()
            .unwrap()
            .last()
            .cloned()
            .expect("tool was called")
    }

    async fn run(&self, args: Value) -> ToolResult {
        self.registry
            .invoke_with_context(super::RUN_STEPS_TOOL, args, context(None))
            .await
    }
}

fn context(manifest: Option<&str>) -> Arc<EffectiveAuthorizationContext> {
    let mode = if manifest.is_some() {
        PermissionMode::Bounded
    } else {
        PermissionMode::Unrestricted
    };
    let ceiling = SessionModeCeiling::for_trusted_sessions(
        [mode],
        mode == PermissionMode::Unrestricted,
        Duration::from_secs(60),
        Duration::from_secs(30),
    )
    .unwrap();
    let manifest = manifest.map(|source| {
        let mut file = tempfile::NamedTempFile::new().unwrap();
        file.write_all(source.as_bytes()).unwrap();
        Arc::new(crate::session_manifest::load_manifest(file.path()).expect("manifest loads"))
    });
    SessionAuthorizationRegistry::with_ceiling(ceiling)
        .compatibility_context(mode, manifest)
        .unwrap()
}

fn text(result: &ToolResult) -> String {
    result
        .content
        .iter()
        .filter_map(|content| match content {
            crate::protocol::Content::Text { text, .. } => Some(text.as_str()),
            _ => None,
        })
        .collect::<Vec<_>>()
        .join("\n")
}

#[tokio::test]
async fn every_step_but_the_last_is_paced_as_a_batched_step() {
    use crate::step_pacing::StepPacing::{Batched, Single};
    let harness = Harness::new();
    let result = harness
        .run(json!({"steps": [
            {"tool": "click", "args": {"pid": 42, "window_id": 7}},
            {"tool": "type_text", "args": {"pid": 42, "text": "b"}},
            {"tool": "press_key", "args": {"pid": 42}},
        ]}))
        .await;
    assert_ne!(result.is_error, Some(true), "{}", text(&result));
    let pacings: Vec<_> = harness
        .pacings
        .lock()
        .unwrap()
        .iter()
        .map(|(tool, pacing)| (tool.clone(), *pacing))
        .collect();
    assert_eq!(
        pacings,
        vec![
            ("click".to_owned(), Batched),
            ("type_text".to_owned(), Batched),
            ("press_key".to_owned(), Single),
        ]
    );
}

#[tokio::test]
async fn a_one_step_batch_keeps_the_full_waits() {
    use crate::step_pacing::StepPacing::Single;
    let harness = Harness::new();
    let result = harness
        .run(json!({"steps": [
            {"tool": "click", "args": {"pid": 42, "window_id": 7}},
        ]}))
        .await;
    assert_ne!(result.is_error, Some(true), "{}", text(&result));
    let pacings = harness.pacings.lock().unwrap().clone();
    assert_eq!(pacings, vec![("click".to_owned(), Single)]);
}

#[tokio::test]
async fn runs_steps_in_order_and_reports_each() {
    let harness = Harness::new();
    let result = harness
        .run(json!({"steps": [
            {"tool": "set_value", "args": {"pid": 42, "window_id": 7, "text": "a"}},
            {"tool": "type_text", "args": {"pid": 42, "text": "b"}},
            {"tool": "press_key", "args": {"pid": 42}},
        ]}))
        .await;
    assert_ne!(result.is_error, Some(true), "{}", text(&result));
    let structured = result.structured_content.unwrap();
    assert_eq!(structured["ok"], true);
    assert_eq!(structured["executed"], 3);
    let tools: Vec<_> = structured["steps"]
        .as_array()
        .unwrap()
        .iter()
        .map(|step| step["tool"].as_str().unwrap().to_owned())
        .collect();
    assert_eq!(tools, ["set_value", "type_text", "press_key"]);
    assert_eq!(structured.get("observation"), None);
    assert_eq!(harness.hits("get_window_state"), 0, "no observe, no read");
}

#[tokio::test]
async fn stops_at_the_first_failure_and_still_observes() {
    let harness = Harness::new();
    let result = harness
        .run(json!({
            "steps": [
                {"tool": "click", "args": {"pid": 42, "window_id": 7}},
                {"tool": "set_value", "args": {"pid": 42, "window_id": 7, "fail": true}},
                {"tool": "press_key", "args": {"pid": 42}},
            ],
            "observe": {}
        }))
        .await;
    assert_eq!(result.is_error, Some(true));
    let structured = result.structured_content.clone().unwrap();
    assert_eq!(structured["failed_step"], 1);
    assert_eq!(structured["executed"], 2);
    assert_eq!(structured["steps"][1]["ok"], false);
    assert!(structured["steps"][1]["message"]
        .as_str()
        .unwrap()
        .contains("probe asked to fail"));
    assert_eq!(
        harness.hits("press_key"),
        0,
        "steps after the failure must not run"
    );
    assert!(text(&result).contains("step 2 of 3 failed"));
    assert_eq!(harness.hits("get_window_state"), 1);
    assert_eq!(structured["observation"]["ok"], true);
}

#[tokio::test]
async fn validates_every_step_before_running_any() {
    let harness = Harness::new();
    let cases = [
        (
            json!({"tool": "run_steps", "args": {}}),
            "cannot run in a batch",
        ),
        (
            json!({"tool": "click", "args": {"pid": "forty-two"}}),
            "invalid arguments",
        ),
        (
            json!({"tool": "click", "args": {"bogus": 1}}),
            "invalid arguments",
        ),
        (
            json!({"tool": "click", "args": {"_session_id": "x"}}),
            "reserved",
        ),
        (
            json!({"tool": "click", "args": {"session": "other"}}),
            "differs from the batch",
        ),
        (json!({"tool": "click", "extra": 1}), "unknown field"),
        (json!({"tool": "click", "args": 5}), "must be an object"),
    ];
    for (bad, expected) in cases {
        let result = harness
            .run(json!({"steps": [
                {"tool": "click", "args": {"pid": 42}},
                {"tool": "press_key", "args": {"pid": 42}},
                bad.clone(),
            ]}))
            .await;
        assert_eq!(result.is_error, Some(true), "{bad}");
        let message = text(&result);
        assert!(message.contains("step 3"), "{bad}: {message}");
        assert!(message.contains(expected), "{bad}: {message}");
        assert_eq!(result.structured_content.unwrap()["code"], "invalid_batch");
    }
    assert_eq!(
        harness.hits("click"),
        0,
        "a rejected batch must execute nothing"
    );
    assert_eq!(harness.hits("press_key"), 0);
}

#[tokio::test]
async fn rejects_bad_batch_shapes() {
    let harness = Harness::new();
    for args in [
        json!({"steps": []}),
        json!({"steps": "click"}),
        json!({"steps": [{"tool": "click"}], "delay_ms": 5000}),
        json!({"steps": vec![json!({"tool": "click"}); super::MAX_STEPS + 1]}),
        json!({"steps": [{"tool": "click"}], "observe": {"pid": 1}}),
        json!({"steps": [{"tool": "click"}], "observe": {}}),
        json!({"steps": [{"tool": "click", "args": {"pid": 1, "window_id": 2}}], "observe": {"max_elements": 0}}),
    ] {
        let result = harness.run(args.clone()).await;
        assert_eq!(result.is_error, Some(true), "{args}");
    }
    assert_eq!(harness.hits("click"), 0);
}

#[tokio::test]
async fn observation_inherits_the_window_and_stays_bounded() {
    let harness = Harness::new();
    let result = harness
        .run(json!({
            "steps": [
                {"tool": "click", "args": {"pid": 42, "window_id": 7}},
                {"tool": "type_text", "args": {"pid": 42, "text": "x"}},
            ],
            "observe": {}
        }))
        .await;
    assert_ne!(result.is_error, Some(true), "{}", text(&result));
    let observed = harness.last("get_window_state");
    assert_eq!(observed["pid"], 42);
    assert_eq!(observed["window_id"], 7);
    assert_eq!(observed["include_screenshot"], false);
    assert_eq!(
        observed["max_elements"], 250,
        "the plain-read budget, so `latest` finds it"
    );
    assert_eq!(
        observed["since"], "latest",
        "the observation is a diff by default"
    );

    harness
        .run(json!({
            "steps": [{"tool": "click", "args": {"pid": 42, "window_id": 7}}],
            "observe": {"pid": 1, "window_id": 2, "include_screenshot": true, "max_elements": 10}
        }))
        .await;
    let observed = harness.last("get_window_state");
    assert_eq!(observed["pid"], 1);
    assert_eq!(observed["include_screenshot"], true);
    assert_eq!(observed["max_elements"], 10);
    assert_eq!(
        harness.hits("get_window_state"),
        2,
        "exactly one read per batch"
    );
}

#[tokio::test]
async fn pauses_between_steps_but_not_after_the_last() {
    let harness = Harness::new();
    let started = std::time::Instant::now();
    harness
        .run(json!({"delay_ms": 120, "steps": [
            {"tool": "click", "args": {"pid": 42}},
            {"tool": "click", "args": {"pid": 42}},
        ]}))
        .await;
    let elapsed = started.elapsed();
    assert!(elapsed >= Duration::from_millis(120), "{elapsed:?}");
    assert!(elapsed < Duration::from_millis(240), "{elapsed:?}");
}

#[tokio::test]
async fn every_step_runs_in_the_batch_session() {
    let harness = Harness::new();
    let result = harness
        .run(json!({"session": "batch-s1", "steps": [
            {"tool": "click", "args": {"pid": 42}},
            {"tool": "press_key", "args": {"pid": 42, "session": "batch-s1"}},
        ]}))
        .await;
    assert_ne!(result.is_error, Some(true), "{}", text(&result));
    for tool in ["click", "press_key"] {
        let session = harness.last(tool)["session"].as_str().unwrap().to_owned();
        assert!(session.ends_with("batch-s1"), "{tool}: {session}");
    }
}

#[tokio::test]
async fn each_step_is_held_to_the_capability_manifest() {
    let harness = Harness::new();
    let manifest = "version: 2\nmode: bounded\nexpires_after: 1h\nidle_timeout: 30m\nallow:\n  tools: [run_steps, click]\n";
    let result = harness
        .registry
        .invoke_with_context(
            super::RUN_STEPS_TOOL,
            json!({"steps": [
                {"tool": "click", "args": {"pid": 42}},
                {"tool": "set_value", "args": {"pid": 42, "text": "secret"}},
                {"tool": "click", "args": {"pid": 42}},
            ]}),
            context(Some(manifest)),
        )
        .await;
    assert_eq!(result.is_error, Some(true));
    let message = text(&result);
    let structured = result.structured_content.unwrap();
    // The manifest scopes pid-targeted input to declared applications, and
    // none is declared: the very first step is refused by the same gate a
    // direct call meets, so nothing reaches any tool.
    assert_eq!(structured["failed_step"], 0, "{message}");
    assert!(message.contains("capability manifest"), "{message}");
    assert_eq!(harness.hits("click"), 0);
    assert_eq!(harness.hits("set_value"), 0, "later steps never run");
}

#[tokio::test]
async fn the_batch_itself_needs_the_manifest_to_allow_it() {
    let harness = Harness::new();
    let manifest = "version: 2\nmode: bounded\nexpires_after: 1h\nidle_timeout: 30m\nallow:\n  tools: [click]\n";
    let result = harness
        .registry
        .invoke_with_context(
            super::RUN_STEPS_TOOL,
            json!({"steps": [{"tool": "click", "args": {"pid": 42}}]}),
            context(Some(manifest)),
        )
        .await;
    assert_eq!(result.is_error, Some(true));
    assert_eq!(harness.hits("click"), 0);
}

#[tokio::test]
async fn the_batch_is_advertised_with_its_schema() {
    let harness = Harness::new();
    let def = harness
        .registry
        .get_def(super::RUN_STEPS_TOOL)
        .expect("registered");
    assert_eq!(def.input_schema["required"], json!(["steps"]));
    let listed: Vec<_> = def.input_schema["properties"]["steps"]["items"]["properties"]["tool"]
        ["enum"]
        .as_array()
        .unwrap()
        .iter()
        .map(|value| value.as_str().unwrap())
        .collect();
    assert_eq!(listed, super::BATCHABLE_TOOLS);
}

#[tokio::test]
async fn the_old_name_run_actions_still_runs_but_is_not_listed() {
    let harness = Harness::new();
    assert!(harness.registry.get_def("run_actions").is_none());
    assert!(!harness
        .registry
        .tool_names()
        .any(|name| name == "run_actions"));

    let result = harness
        .registry
        .invoke_with_context(
            "run_actions",
            json!({"steps": [{"tool": "click", "args": {"pid": 42, "window_id": 7}}]}),
            context(None),
        )
        .await;
    assert_ne!(result.is_error, Some(true), "{}", text(&result));
    assert_eq!(harness.hits("click"), 1);
    let crate::protocol::Content::Text { text: note, .. } = result.content.last().unwrap() else {
        panic!("last content block is not text");
    };
    assert!(
        note.contains("`run_actions` is deprecated") && note.contains("`run_steps`"),
        "{note}"
    );
    assert_eq!(note.lines().count(), 1);

    // The new name carries no note.
    let current = harness
        .run(json!({"steps": [{"tool": "click", "args": {"pid": 42, "window_id": 7}}]}))
        .await;
    assert!(!text(&current).contains("deprecated"), "{}", text(&current));
}

#[tokio::test]
async fn a_manifest_that_allows_run_actions_allows_run_steps() {
    let harness = Harness::new();
    let manifest = "version: 2\nmode: bounded\nexpires_after: 1h\nidle_timeout: 30m\nallow:\n  tools: [run_actions, click]\n";
    let result = harness
        .registry
        .invoke_with_context(
            super::RUN_STEPS_TOOL,
            json!({"steps": [{"tool": "click", "args": {"pid": 42, "window_id": 7}}]}),
            context(Some(manifest)),
        )
        .await;
    // The batch itself is allowed: the refusal comes from its first step,
    // whose pid the manifest does not declare.
    let message = text(&result);
    assert_eq!(
        result.structured_content.unwrap()["failed_step"],
        0,
        "{message}"
    );
}

#[tokio::test]
async fn observe_true_reads_a_diff_and_since_null_reads_in_full() {
    let harness = Harness::new();
    let step = json!([{"tool": "click", "args": {"pid": 42, "window_id": 7}}]);

    let result = harness.run(json!({"steps": step, "observe": true})).await;
    assert_ne!(result.is_error, Some(true), "{}", text(&result));
    let observed = harness.last("get_window_state");
    assert_eq!(observed["window_id"], 7);
    assert_eq!(observed["since"], "latest");

    harness
        .run(json!({"steps": step, "observe": {"since": null}}))
        .await;
    assert!(harness.last("get_window_state").get("since").is_none());

    harness
        .run(json!({"steps": step, "observe": {"full_output": true}}))
        .await;
    assert!(harness.last("get_window_state").get("since").is_none());

    harness
        .run(json!({"steps": step, "observe": {"since": "s0000002a"}}))
        .await;
    assert_eq!(harness.last("get_window_state")["since"], "s0000002a");

    harness.run(json!({"steps": step, "observe": false})).await;
    assert_eq!(
        harness.hits("get_window_state"),
        4,
        "observe:false reads nothing"
    );
}

#[tokio::test]
async fn common_tool_name_slips_map_to_the_batchable_tool() {
    let harness = Harness::new();
    let result = harness
        .run(json!({"steps": [
            {"tool": "press", "args": {"pid": 1}},
            {"tool": "type", "args": {"pid": 1, "text": "x"}},
        ]}))
        .await;
    assert_ne!(result.is_error, Some(true), "{}", text(&result));
    assert_eq!(harness.hits("press_key"), 1);
    assert_eq!(harness.hits("type_text"), 1);

    let refused = harness
        .run(json!({"steps": [{"tool": "get_window_state", "args": {"pid": 1}}]}))
        .await;
    assert_eq!(refused.is_error, Some(true));
}

#[tokio::test]
async fn scroll_steps_accept_dx_dy_like_a_direct_call() {
    let harness = Harness::new();
    // The live-check shape: {"dy": 500} in a batch step.
    let result = harness
        .run(json!({"steps": [
            {"tool": "scroll", "args": {"pid": 1, "window_id": 2, "x": 600, "y": 500, "dy": 500}},
            {"tool": "scroll", "args": {"pid": 1, "window_id": 2, "x": 600, "y": 500, "dx": "-4"}},
        ]}))
        .await;
    assert_ne!(result.is_error, Some(true), "{}", text(&result));
    let calls = harness.calls["scroll"].lock().unwrap().clone();
    assert_eq!(calls.len(), 2);
    assert_eq!(
        (calls[0]["direction"].clone(), calls[0]["amount"].clone()),
        (json!("down"), json!(5))
    );
    assert_eq!(
        (calls[1]["direction"].clone(), calls[1]["amount"].clone()),
        (json!("left"), json!(4))
    );
    assert!(calls
        .iter()
        .all(|c| c.get("dy").is_none() && c.get("dx").is_none()));

    let refused = harness
        .run(json!({"steps": [{"tool": "scroll", "args": {"pid": 1, "dx": 1, "dy": 1}}]}))
        .await;
    assert_eq!(refused.is_error, Some(true));
    assert!(
        text(&refused).contains("one axis per call"),
        "{}",
        text(&refused)
    );
    assert_eq!(harness.hits("scroll"), 2, "a refused batch runs nothing");
}

#[tokio::test]
async fn a_trailing_read_becomes_the_observation_and_a_middle_one_points_to_observe() {
    let harness = Harness::new();
    // The v035 / live-check shape: act, act, then get_window_state as a step.
    let result = harness
        .run(json!({"steps": [
            {"tool": "click", "args": {"pid": 7, "window_id": 3}},
            {"tool": "click", "args": {"pid": 7, "window_id": 3, "text": "x"}},
            {"tool": "get_window_state", "args": {"pid": 7, "window_id": 3, "max_elements": 70}},
        ]}))
        .await;
    assert_ne!(result.is_error, Some(true), "{}", text(&result));
    let structured = result.structured_content.unwrap();
    assert_eq!(structured["total"], 2, "the read is not counted as a step");
    assert_eq!(structured["observation"]["ok"], true);
    let observed = harness.last("get_window_state");
    assert_eq!(observed["max_elements"], 70);
    assert_eq!(observed["since"], "latest");
    assert_eq!(harness.hits("click"), 2);

    // v036: a read between actions (act, read, act, read) is skipped with a
    // note instead of rejecting the whole batch; the last read is `observe`.
    let skipped = harness
        .run(json!({"steps": [
            {"tool": "click", "args": {"pid": 7, "window_id": 3}},
            {"tool": "get_window_state", "args": {"pid": 7, "window_id": 3, "query": "AXTextField"}},
            {"tool": "click", "args": {"pid": 7, "window_id": 3}},
            {"tool": "get_window_state", "args": {"pid": 7, "window_id": 3, "max_elements": 90}},
        ]}))
        .await;
    assert_ne!(skipped.is_error, Some(true), "{}", text(&skipped));
    let message = text(&skipped);
    assert!(message.contains("2. get_window_state skipped"), "{message}");
    assert_eq!(harness.hits("click"), 4);
    assert_eq!(harness.hits("get_window_state"), 2, "only the end read ran");
    assert_eq!(harness.last("get_window_state")["max_elements"], 90);

    // With no read at the end, the last skipped read is the end read.
    let looked = harness
        .run(json!({"steps": [
            {"tool": "click", "args": {"pid": 7, "window_id": 3}},
            {"tool": "get_window_state", "args": {"pid": 7, "window_id": 3, "query": "Wiki"}},
            {"tool": "click", "args": {"pid": 7, "window_id": 3}},
        ]}))
        .await;
    assert_ne!(looked.is_error, Some(true), "{}", text(&looked));
    assert_eq!(harness.hits("get_window_state"), 3);
    assert_eq!(harness.last("get_window_state")["query"], "Wiki");

    // v036: a trailing read plus an explicit observe merge; observe wins.
    let both = harness
        .run(json!({"steps": [
            {"tool": "click", "args": {"pid": 7, "window_id": 3}},
            {"tool": "get_window_state", "args": {"pid": 7, "window_id": 3, "max_elements": 40}},
        ], "observe": {"include_screenshot": true, "max_elements": 60}}))
        .await;
    assert_ne!(both.is_error, Some(true), "{}", text(&both));
    assert_eq!(harness.hits("get_window_state"), 4);
    let observed = harness.last("get_window_state");
    assert_eq!(observed["max_elements"], 60);
    assert_eq!(observed["include_screenshot"], true);

    // A batch of reads only still points at the direct call.
    let refused = harness
        .run(json!({"steps": [{"tool": "get_window_state", "args": {"pid": 7, "window_id": 3}}]}))
        .await;
    assert_eq!(refused.is_error, Some(true));
    assert!(
        text(&refused).contains("reads state and a batch only acts"),
        "{}",
        text(&refused)
    );
}

#[tokio::test]
async fn click_step_refuses_null_target_and_button_five() {
    let harness = Harness::new();
    let target = harness
        .run(json!({"steps": [{"click": {"x": 1, "y": 2, "target": null}}]}))
        .await;
    assert_eq!(target.is_error, Some(true));
    assert!(text(&target).contains("/target"), "{}", text(&target));
    let refused = harness
        .run(json!({"steps": [{"click": {"x": 1, "y": 2, "button": 5}}]}))
        .await;
    assert_eq!(refused.is_error, Some(true));
    assert!(text(&refused).contains("/button"), "{}", text(&refused));
}

#[cfg(test)]
#[path = "reliability_tests.rs"]
mod reliability_tests;

// The Linux runtime historically accepts JSON numbers for set_value. The
// provider-facing string schema must not narrow direct or batched calls.
#[cfg(target_os = "linux")]
#[tokio::test]
async fn numeric_set_value_matches_direct_and_batched_string_arguments() {
    for value in [
        json!(0),
        json!(-12),
        json!(4.5),
        json!(18446744073709551615u64),
    ] {
        let expected = Value::String(value.to_string());
        let harness = Harness::new();
        harness
            .registry
            .invoke_with_context(
                "set_value",
                json!({"pid": 42, "value": value}),
                context(None),
            )
            .await;
        assert_eq!(harness.last("set_value")["value"], expected);
        let result = harness
            .run(json!({"steps": [{
                "tool": "set_value", "args": {"pid": 42, "value": value}
            }]}))
            .await;
        assert_ne!(result.is_error, Some(true), "{}", text(&result));
        assert_eq!(harness.hits("set_value"), 2);
        assert_eq!(harness.last("set_value")["value"], expected);
    }
    // A numeric field with the same name on another tool is not rewritten.
    let unrelated = Harness::new();
    unrelated
        .registry
        .invoke_with_context("type_text", json!({"value": 4.5}), context(None))
        .await;
    assert_eq!(unrelated.last("type_text")["value"], json!(4.5));
    // Text must remain byte-for-byte unchanged, even when it looks numeric.
    let harness = Harness::new();
    let result = harness
        .run(json!({"steps": [{
            "tool": "set_value", "args": {"pid": 42, "value": " 004.50 "}
        }]}))
        .await;
    assert_ne!(result.is_error, Some(true), "{}", text(&result));
    assert_eq!(harness.last("set_value")["value"], " 004.50 ");
}

#[cfg(target_os = "linux")]
#[tokio::test]
async fn non_scalar_set_value_is_rejected_before_any_batch_action() {
    for value in [Value::Null, json!(true), json!([]), json!({})] {
        let harness = Harness::new();
        let result = harness
            .run(json!({"steps": [
                {"tool": "set_value", "args": {"pid": 42, "value": "valid"}},
                {"tool": "set_value", "args": {"pid": 42, "value": value}}
            ]}))
            .await;
        let structured = result.structured_content.as_ref().unwrap();
        assert_eq!(structured["code"], "invalid_batch");
        assert_eq!(structured["executed"], 0);
        assert_eq!(structured["failed_step"], 1);
        assert!(structured["detail"]
            .as_str()
            .unwrap()
            .starts_with("set_value: invalid arguments at /value:"));
        assert_eq!(harness.hits("set_value"), 0);
    }
}
