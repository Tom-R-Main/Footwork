// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Cua AI, Inc.

//! Multi-client / multi-cursor / overlay session tests.
//!
//! Concurrent driver processes, per-cursor instance state, cross-process
//! isolation, and the live overlay render loop. Cursor motion knobs are owned
//! by `protocol_schema_test::cursor_motion_knobs_are_applied`. Split out of the old monolithic `mcp_protocol_test.rs`;
//! mac/windows pairs merge and branch only where assertions differ.
//!
//! Note: the originals asserted process liveness with `child.try_wait()`.
//! `RawDriver` kills its child on drop and does not expose the handle, so the
//! liveness check is replaced with an equivalent post-sleep request probe — a
//! crashed process would EOF and panic inside `recv()`.

#![cfg(any(target_os = "macos", target_os = "windows"))]

use cua_driver_testkit::RawDriver;

fn spawn_unrestricted_with_overlay() -> Option<RawDriver> {
    RawDriver::spawn_with_overlay_and_env(&[
        ("CUA_DRIVER_PERMISSION_MODE", "unrestricted"),
        ("CUA_DRIVER_DANGEROUSLY_BYPASS_APPROVALS", "1"),
    ])
}

#[test]
#[cfg(any(target_os = "macos", target_os = "windows"))]
#[ignore = "host desktop: draws the agent-cursor overlay window on the real display; see libs/cua-driver/tests/manual-e2e-allowlist.txt"]
fn concurrent_multi_driver_isolation() {
    //! Two cua-driver processes running simultaneously with different declared
    //! sessions. Each process must retain its own session-owned cursor state.
    let Some(mut child_a) = spawn_unrestricted_with_overlay() else {
        return;
    };
    let Some(mut child_b) = spawn_unrestricted_with_overlay() else {
        return;
    };

    // Initialize both.
    child_a.send(&serde_json::json!({"jsonrpc":"2.0","id":1,"method":"initialize","params":{}}));
    child_b.send(&serde_json::json!({"jsonrpc":"2.0","id":1,"method":"initialize","params":{}}));
    child_a.recv();
    child_b.recv();

    child_a.send(&serde_json::json!({
        "jsonrpc":"2.0","id":2,"method":"tools/call",
        "params":{"name":"start_session","arguments":{"session":"alpha"}}
    }));
    child_b.send(&serde_json::json!({
        "jsonrpc":"2.0","id":2,"method":"tools/call",
        "params":{"name":"start_session","arguments":{"session":"beta"}}
    }));
    assert!(!child_a.recv()["result"]["isError"]
        .as_bool()
        .unwrap_or(false));
    assert!(!child_b.recv()["result"]["isError"]
        .as_bool()
        .unwrap_or(false));

    child_a.send(&serde_json::json!({
        "jsonrpc":"2.0","id":3,"method":"tools/call",
        "params":{"name":"set_agent_cursor_enabled","arguments":{"session":"alpha","enabled":true}}
    }));
    child_b.send(&serde_json::json!({
        "jsonrpc":"2.0","id":3,"method":"tools/call",
        "params":{"name":"set_agent_cursor_enabled","arguments":{"session":"beta","enabled":false}}
    }));
    let resp_a = child_a.recv();
    let resp_b = child_b.recv();
    assert!(
        resp_a["error"].is_null(),
        "Driver A set_agent_cursor_enabled failed: {resp_a:?}"
    );
    assert!(
        resp_b["error"].is_null(),
        "Driver B set_agent_cursor_enabled failed: {resp_b:?}"
    );

    // Each driver queries its own session-owned cursor state.
    child_a.send(&serde_json::json!({
        "jsonrpc":"2.0","id":4,"method":"tools/call",
        "params":{"name":"get_agent_cursor_state","arguments":{"session":"alpha"}}
    }));
    child_b.send(&serde_json::json!({
        "jsonrpc":"2.0","id":4,"method":"tools/call",
        "params":{"name":"get_agent_cursor_state","arguments":{"session":"beta"}}
    }));
    let state_a = child_a.recv();
    let state_b = child_b.recv();
    assert!(
        state_a["error"].is_null(),
        "Driver A get_agent_cursor_state failed: {state_a:?}"
    );
    assert!(
        state_b["error"].is_null(),
        "Driver B get_agent_cursor_state failed: {state_b:?}"
    );

    assert_eq!(
        state_a["result"]["structuredContent"]["enabled"].as_bool(),
        Some(true),
        "Session alpha should be enabled in driver A"
    );
    assert_eq!(
        state_b["result"]["structuredContent"]["enabled"].as_bool(),
        Some(false),
        "Session beta should be disabled in driver B"
    );

    // macOS additionally exercises move_cursor on both drivers to confirm
    // neither crashes the other (the Windows variant stops after the state check).
    if !cfg!(target_os = "windows") {
        child_a.send(&serde_json::json!({
            "jsonrpc":"2.0","id":5,"method":"tools/call",
            "params":{"name":"move_cursor","arguments":{"session":"alpha","x":100,"y":100}}
        }));
        child_b.send(&serde_json::json!({
            "jsonrpc":"2.0","id":5,"method":"tools/call",
            "params":{"name":"move_cursor","arguments":{"session":"beta","x":200,"y":200}}
        }));
        let mv_a = child_a.recv();
        let mv_b = child_b.recv();
        assert!(
            !mv_a["result"]["isError"].as_bool().unwrap_or(false),
            "Driver A move_cursor failed: {mv_a:?}"
        );
        assert!(
            !mv_b["result"]["isError"].as_bool().unwrap_or(false),
            "Driver B move_cursor failed: {mv_b:?}"
        );

        // Both processes must survive the concurrent overlay moves: probe each
        // once more after the render loop ticks (a crashed process would EOF
        // and panic in recv()).
        std::thread::sleep(std::time::Duration::from_millis(100));
        for (label, driver) in [("A", &mut child_a), ("B", &mut child_b)] {
            driver.send(&serde_json::json!({
                "jsonrpc":"2.0","id":6,"method":"tools/call",
                "params":{"name":"get_config","arguments":{}}
            }));
            let alive = driver.recv();
            assert_eq!(
                alive["id"], 6,
                "Driver {label} crashed during concurrent cursor moves: {alive:?}"
            );
        }
    }
}

#[test]
#[cfg(any(target_os = "macos", target_os = "windows"))]
#[ignore = "host desktop: draws the agent-cursor overlay window on the real display; see libs/cua-driver/tests/manual-e2e-allowlist.txt"]
fn session_owned_cursor_state_is_independent() {
    let Some(mut driver) = spawn_unrestricted_with_overlay() else {
        return;
    };

    driver.send(&serde_json::json!({
        "jsonrpc":"2.0","id":1,"method":"initialize","params":{}
    }));
    driver.recv();

    for (id, session) in [(2, "agent1"), (3, "agent2")] {
        driver.send(&serde_json::json!({
            "jsonrpc":"2.0","id":id,"method":"tools/call",
            "params":{"name":"start_session","arguments":{"session":session}}
        }));
        let response = driver.recv();
        assert!(
            !response["result"]["isError"].as_bool().unwrap_or(false),
            "start_session failed: {response:?}"
        );
    }

    driver.send(&serde_json::json!({
        "jsonrpc":"2.0","id":4,"method":"tools/call",
        "params":{"name":"set_agent_cursor_motion","arguments":{
            "session":"agent1","spring":0.7,"style":"dc-magnetic","timing":"fitts",
            "effects":{"ripple":false}
        }}
    }));
    let motion = driver.recv();
    assert!(!motion["result"]["isError"].as_bool().unwrap_or(false));
    let echoed = &motion["result"]["structuredContent"]["motion"];
    assert_eq!(echoed["style"], "magnetic");
    assert_eq!(echoed["timing"], "fitts");
    assert_eq!(echoed["effects"]["ripple"], false);
    assert_eq!(echoed["effects"]["magnet"], true);

    driver.send(&serde_json::json!({
        "jsonrpc":"2.0","id":40,"method":"tools/call",
        "params":{"name":"set_agent_cursor_motion","arguments":{
            "session":"agent1","style":"zigzag"
        }}
    }));
    let rejected = driver.recv();
    assert!(
        rejected["result"]["isError"].as_bool().unwrap_or(false),
        "unknown style was accepted: {rejected:?}"
    );

    driver.send(&serde_json::json!({
        "jsonrpc":"2.0","id":5,"method":"tools/call",
        "params":{"name":"set_agent_cursor_enabled","arguments":{
            "session":"agent2","enabled":false
        }}
    }));
    let hidden = driver.recv();
    assert!(!hidden["result"]["isError"].as_bool().unwrap_or(false));

    for (id, session, expected_enabled) in [(6, "agent1", true), (7, "agent2", false)] {
        driver.send(&serde_json::json!({
            "jsonrpc":"2.0","id":id,"method":"tools/call",
            "params":{"name":"get_agent_cursor_state","arguments":{"session":session}}
        }));
        let response = driver.recv();
        assert!(
            !response["result"]["isError"].as_bool().unwrap_or(false),
            "get_agent_cursor_state failed: {response:?}"
        );
        let state = &response["result"]["structuredContent"];
        assert_eq!(state["session"].as_str(), Some(session));
        assert_eq!(state["enabled"].as_bool(), Some(expected_enabled));
        assert_eq!(state["theme"]["id"].as_str(), Some("cua.default"));
        let expected_style = if session == "agent1" {
            "magnetic"
        } else {
            "signature_arc"
        };
        assert_eq!(state["motion"]["style"].as_str(), Some(expected_style));
    }
}

#[test]
#[cfg(any(target_os = "macos", target_os = "windows"))]
#[ignore = "host desktop: draws the agent-cursor overlay window on the real display; see libs/cua-driver/tests/manual-e2e-allowlist.txt"]
fn overlay_move_cursor_stays_alive() {
    //! Verify that calling move_cursor with the overlay enabled does not crash the process.
    //! The overlay renders to a transparent NSWindow on the main thread; the MCP server
    //! sends commands via the global channel.  Any crash in the render thread (e.g. wrong
    //! GCD queue pointer, bad CGImage argument types) would cause this test to fail with
    //! an early EOF or a non-zero exit code.
    let Some(mut d) = spawn_unrestricted_with_overlay() else {
        return;
    };

    d.send(&serde_json::json!({"jsonrpc":"2.0","id":1,"method":"initialize","params":{}}));
    d.recv();

    // Call move_cursor several times to drive the overlay render loop.
    for (id, (x, y)) in [
        (2u64, (100.0_f64, 200.0_f64)),
        (3, (400.0, 300.0)),
        (4, (800.0, 600.0)),
    ] {
        d.send(&serde_json::json!({
            "jsonrpc": "2.0",
            "id": id,
            "method": "tools/call",
            "params": { "name": "move_cursor", "arguments": { "x": x, "y": y } }
        }));
        let resp = d.recv();
        assert_eq!(resp["id"], id);
        // Should succeed (isError absent or false).
        let is_error = resp["result"]["isError"].as_bool().unwrap_or(false);
        assert!(!is_error, "move_cursor failed: {:?}", resp);
    }

    // Also call get_agent_cursor_state — should report the last position.
    d.send(&serde_json::json!({
        "jsonrpc": "2.0",
        "id": 5,
        "method": "tools/call",
        "params": { "name": "get_agent_cursor_state", "arguments": {} }
    }));
    let resp = d.recv();
    assert_eq!(resp["id"], 5);
    assert!(!resp["result"]["isError"].as_bool().unwrap_or(false));

    // Give the render loop a chance to tick (two frames ≈ 33 ms).
    std::thread::sleep(std::time::Duration::from_millis(100));

    // Process must still be alive: probe with one more request (a crashed
    // process would EOF and panic in recv()).
    d.send(&serde_json::json!({
        "jsonrpc": "2.0",
        "id": 99,
        "method": "tools/call",
        "params": { "name": "get_agent_cursor_state", "arguments": {} }
    }));
    let resp = d.recv();
    assert_eq!(
        resp["id"], 99,
        "cua-driver crashed during overlay move_cursor test"
    );
}
