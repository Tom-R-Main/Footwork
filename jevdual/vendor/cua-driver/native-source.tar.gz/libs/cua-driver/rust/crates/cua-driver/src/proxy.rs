// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Cua AI, Inc.

//! Stdio MCP adapters for direct SDK-owned and service-owned runtimes.
//!
//! The client side always sees a normal stdio server. Depending on platform
//! and explicit launch options, this adapter either owns the SDK runtime
//! directly or forwards to a service that owns it.
//!
//! On macOS the CLI can ensure a daemon is running under `LaunchServices`
//! (which gives it the right TCC attribution). Embedded hosts may also start a
//! private service explicitly. The MCP client never sees that ownership
//! boundary — it receives the same JSON-RPC envelope.
//!
//! Why this lives in `cua-driver` and not `mcp-server`:
//!   `cua_driver_core::server` defines the shared JSON-RPC protocol. The
//!   proxy speaks that protocol on the client side, while the server side is the daemon's
//!   line-delimited JSON UDS protocol, owned by `crate::serve`.
//!   Putting the proxy here avoids `mcp-server → cua-driver` reverse
//!   coupling.

use std::sync::Arc;

use cua_driver_core::mcp_wire::{self, ProtocolSession};
use cua_driver_core::policy::{authorize_tool_call, validate_configured_policy};
use cua_driver_core::protocol::{initialize_result, Request, Response};
use cua_driver_core::server::{
    observe_proxy_session_started, observe_proxy_tool_completed, tool_observation_timer,
    StdioExecutionPath,
};
use tokio::io::{AsyncBufRead, AsyncBufReadExt, AsyncWrite, AsyncWriteExt, BufReader};
use tracing::{debug, error, warn};

use crate::serve::{
    is_daemon_listening, send_request, DaemonRequest, DaemonResponse, ToolObservationOrigin,
};

/// Run stdio MCP directly over an SDK-owned runtime.
///
/// Windows and Linux use this when no explicit service endpoint was selected.
/// The runtime lives exactly as long as stdin: EOF ends every observed public
/// session, drains admitted work through `shutdown`, and releases process
/// ownership before returning.
pub async fn run_direct(driver: Arc<cua_driver_sdk::CuaDriver>) -> anyhow::Result<()> {
    // Direct stdio is an action endpoint just like `serve`; enforce the same
    // admin lock, bounded-manifest approval/expiry, and legacy-approval
    // consistency before the first request can be read.
    cua_driver_core::authorization::validate_startup_authorization()?;
    validate_configured_policy()?;
    let sdk = crate::sdk_adapter::SdkAdapter::load(driver.clone()).await?;
    if crate::mcp_envelope::configured()? {
        let result = crate::mcp_envelope::run(
            sdk.clone(),
            BufReader::new(tokio::io::stdin()),
            tokio::io::stdout(),
        )
        .await;
        sdk.shutdown().await.map_err(anyhow::Error::msg)?;
        return result;
    }
    let stdin = tokio::io::stdin();
    let stdout = tokio::io::stdout();
    let mut reader = BufReader::new(stdin);
    let mut writer = tokio::io::BufWriter::new(stdout);
    let mut line = String::new();
    let mut session_observed = false;
    let mut protocol_session = ProtocolSession::default();
    let transport_session = format!("mcp-{}", uuid::Uuid::new_v4());
    struct DirectTransportCleanup {
        sdk: Arc<crate::sdk_adapter::SdkAdapter>,
        transport_session: String,
    }
    impl Drop for DirectTransportCleanup {
        fn drop(&mut self) {
            self.sdk.end_transport_sessions(&self.transport_session);
        }
    }
    let _cleanup = DirectTransportCleanup {
        sdk: sdk.clone(),
        transport_session: transport_session.clone(),
    };

    loop {
        line.clear();
        if reader.read_line(&mut line).await? == 0 {
            break;
        }
        let trimmed = line.trim();
        if trimmed.is_empty() {
            continue;
        }
        let response = match serde_json::from_str::<Request>(trimmed) {
            Err(error) => {
                error!("JSON parse error: {error}");
                Response::parse_error()
            }
            Ok(request) if request.is_notification() => continue,
            Ok(mut request) => {
                let admission = protocol_session.validate(&request).and_then(|era| {
                    if request.method == "tools/call" {
                        mcp_wire::validate_tool_call(
                            &request,
                            request.id.clone().unwrap_or_default(),
                            era,
                            &sdk.tools_list(),
                        )?;
                    }
                    Ok(era)
                });
                if let Err(response) = admission {
                    writer
                        .write_all(serde_json::to_string(&response)?.as_bytes())
                        .await?;
                    writer.write_all(b"\n").await?;
                    writer.flush().await?;
                    continue;
                }
                apply_direct_session_identity(&mut request, &transport_session);
                let initialize_metadata = (!session_observed)
                    .then(|| request.initialize_metadata())
                    .flatten();
                let session_context = request.tool_call().ok().and_then(|call| {
                    sdk.begin_tool_call(
                        &call.name,
                        &call.args,
                        cua_driver_core::session::SessionTransport::McpStdio,
                        cua_driver_core::session::SessionClientKind::Mcp,
                    )
                });
                let timer = tool_observation_timer(
                    &request,
                    |name| sdk.is_known_tool(name),
                    StdioExecutionPath::DirectDaemon,
                );
                let id = request.id.clone().unwrap_or(serde_json::Value::Null);
                let response = cua_driver_core::server::handle_request_with_transport_session(
                    request,
                    id,
                    sdk.as_ref(),
                    &transport_session,
                )
                .await;
                if let Some(metadata) = initialize_metadata {
                    observe_proxy_session_started(metadata);
                    session_observed = true;
                }
                if let Some(timer) = timer {
                    let outcome = timer.finish(&response);
                    if let Some(context) = session_context {
                        context.complete(&outcome);
                    }
                    observe_proxy_tool_completed(outcome);
                }
                response
            }
        };
        let serialized = serde_json::to_string(&response).unwrap_or_else(|error| {
            format!(
                r#"{{"jsonrpc":"2.0","id":null,"error":{{"code":-32603,"message":"serialize error: {error}"}}}}"#
            )
        });
        writer.write_all(serialized.as_bytes()).await?;
        writer.write_all(b"\n").await?;
        writer.flush().await?;
    }

    sdk.shutdown().await.map_err(anyhow::Error::msg)
}

pub(crate) fn apply_direct_session_identity(request: &mut Request, transport_session: &str) {
    let Some(arguments) = request
        .params
        .as_mut()
        .and_then(|params| params.get_mut("arguments"))
        .and_then(serde_json::Value::as_object_mut)
    else {
        return;
    };
    let effective = arguments
        .get("session")
        .and_then(serde_json::Value::as_str)
        .filter(|session| !session.is_empty())
        .unwrap_or(transport_session)
        .to_owned();
    arguments.insert("_session_id".into(), serde_json::Value::String(effective));
    arguments.insert(
        "_transport_session_id".into(),
        serde_json::Value::String(transport_session.to_owned()),
    );
}

/// Run the MCP stdio proxy. Reads JSON-RPC lines from stdin, forwards
/// the body of each `tools/list` / `tools/call` to the daemon at
/// `socket_path`, and writes the daemon's response back as a proper
/// JSON-RPC envelope.
///
/// Implements the core protocol's EOF, parse-error, notification, and
/// response rules while forwarding method dispatch to the daemon.
///
/// Fails fast if the daemon isn't reachable, so MCP clients see a
/// clear startup error instead of a "successful" handshake that
/// advertises zero tools and then errors on every call. Matches
/// Swift `makeProxy`'s `fetchProxyToolList` pre-check.
pub async fn run_proxy(socket_path: String) -> anyhow::Result<()> {
    validate_configured_policy()?;
    if !is_daemon_listening(&socket_path) {
        anyhow::bail!(
            "cua-driver-rs daemon not reachable on {socket_path}. Start it \
             with `cua-driver permissions grant` and retry."
        );
    }
    // A selected service may outlive the CLI package that launched this
    // proxy. Refuse an incompatible contract before creating the control
    // binding or forwarding any action.
    let compatibility_client = cua_driver_sdk::CuaDriver::connect(Some(socket_path.clone()))?;
    compatibility_client.metadata().await?;
    if crate::mcp_envelope::configured()? {
        return crate::mcp_envelope::proxy(&socket_path).await;
    }

    // Mint this MCP session's identity once at proxy startup. One proxy process
    // == one MCP session; the daemon outlives it. We stamp this id on every
    // forwarded request so the daemon can OWN and CLEAN UP this session's
    // state (recording, config overrides) and tear it down on disconnect via
    // a `session_end` signal. Dep-free `pid + start-nanos` is sufficient for
    // daemon-local uniqueness over this proxy's lifetime (no `uuid` crate dep
    // for one mint).
    let session_id = mint_session_id();
    debug!(session_id = %session_id, "proxy session minted");

    // Open ONE long-lived "control" connection to the daemon and hold it open
    // for this proxy's entire lifetime (separate from the per-call connections
    // that `send_request` opens and closes per tool call). It sends a single
    // `session_begin` line and then parks reading — it never writes again and
    // never closes until this process dies.
    //
    // This is the reaper: when the proxy exits (graceful stdin EOF) OR is
    // SIGKILLed/crashes, the kernel closes this socket; the daemon's
    // per-connection reader hits EOF and fires `session_end` for `session_id`,
    // tearing down every piece of state this session owns (overlay cursor,
    // config overrides, recording). Liveness is connection-based, so an
    // alive-but-idle session — one issuing zero tool calls — is never reaped:
    // its control connection stays parked open.
    //
    // The daemon must acknowledge `session_begin` before the proxy accepts tool
    // calls. Besides lifecycle cleanup, that registered control channel is the
    // trust boundary used by destructive `browser_prepare` calls.
    let (control_ready_tx, control_ready_rx) = tokio::sync::oneshot::channel();
    let control = run_control_connection(socket_path.clone(), session_id.clone(), control_ready_tx);
    tokio::pin!(control);
    supervise_control_connection(&mut control, async {
        tokio::time::timeout(std::time::Duration::from_secs(4), control_ready_rx)
            .await
            .map_err(|_| anyhow::anyhow!("daemon did not acknowledge the MCP control session"))?
            .map_err(|_| anyhow::anyhow!("daemon control session closed before acknowledgement"))
    })
    .await?;

    // Cache the tool list once at startup. The daemon's registry is
    // static for the lifetime of the daemon, so polling on every
    // `tools/list` would waste a round-trip per call. Swift does the
    // same caching in `fetchProxyToolList`.
    let (cached_tools_list, daemon_observes_tool_calls) =
        fetch_tools_list_from_daemon(&socket_path, &session_id)?;
    let cached_tools_list = Arc::new(cached_tools_list);

    let stdin = tokio::io::stdin();
    let stdout = tokio::io::stdout();
    supervise_control_connection(
        &mut control,
        run_proxy_io(
            BufReader::new(stdin),
            tokio::io::BufWriter::new(stdout),
            &socket_path,
            &cached_tools_list,
            &session_id,
            daemon_observes_tool_calls,
        ),
    )
    .await
}

/// Keep the MCP transport alive only while its daemon-owned identity is live.
/// Dropping the scoped control future also closes its socket on stdin EOF,
/// startup failure, or cancellation; no detached task can retain the session.
async fn supervise_control_connection<T>(
    control: impl std::future::Future<Output = ()>,
    work: impl std::future::Future<Output = anyhow::Result<T>>,
) -> anyhow::Result<T> {
    tokio::select! {
        biased;
        _ = control => anyhow::bail!("daemon control session closed; reconnect the MCP client"),
        result = work => result,
    }
}

/// Run the service-owned stdio loop over caller-provided I/O.
///
/// A clean reader EOF must return `Ok(())` promptly. The caller then drops the
/// persistent control connection, allowing the daemon to reap the MCP session
/// and its recording, preview, and overlay state (issue #2002).
async fn run_proxy_io<R, W>(
    mut reader: R,
    mut writer: W,
    socket_path: &str,
    cached_tools_list: &Arc<serde_json::Value>,
    session_id: &str,
    daemon_observes_tool_calls: bool,
) -> anyhow::Result<()>
where
    R: AsyncBufRead + Unpin,
    W: AsyncWrite + Unpin,
{
    let mut line = String::new();
    let mut session_observed = false;
    let mut protocol_session = ProtocolSession::default();

    loop {
        line.clear();
        let n = reader.read_line(&mut line).await?;
        if n == 0 {
            break; // EOF — MCP client disconnected (stdin closed).
        }
        let trimmed = line.trim();
        if trimmed.is_empty() {
            continue;
        }
        debug!(raw = trimmed, "→ proxy request");

        let response = match serde_json::from_str::<Request>(trimmed) {
            Err(e) => {
                error!("JSON parse error: {e}");
                Response::parse_error()
            }
            Ok(req) if req.is_notification() => {
                // Notifications are intentionally dropped by the stdio adapter.
                continue;
            }
            Ok(req) => {
                let admission = protocol_session.validate(&req).and_then(|era| {
                    mcp_wire::validate_tool_call(
                        &req,
                        req.id.clone().unwrap_or_default(),
                        era,
                        cached_tools_list,
                    )?;
                    Ok(era)
                });
                if let Err(response) = admission {
                    writer
                        .write_all(serde_json::to_string(&response)?.as_bytes())
                        .await?;
                    writer.write_all(b"\n").await?;
                    writer.flush().await?;
                    continue;
                }
                let initialize_metadata = (!session_observed)
                    .then(|| req.initialize_metadata())
                    .flatten();
                let session_context = (!daemon_observes_tool_calls)
                    .then(|| {
                        req.tool_call().ok().and_then(|call| {
                            let known_tool = proxy_knows_tool(cached_tools_list, &call.name);
                            cua_driver_core::session::begin_tool_call(
                                &call.name,
                                &call.args,
                                known_tool,
                                cua_driver_core::session::SessionTransport::McpStdio,
                                cua_driver_core::session::SessionClientKind::Mcp,
                            )
                        })
                    })
                    .flatten();
                let tool_timer = (!daemon_observes_tool_calls)
                    .then(|| {
                        tool_observation_timer(
                            &req,
                            |name| proxy_knows_tool(cached_tools_list, name),
                            StdioExecutionPath::DaemonProxy,
                        )
                    })
                    .flatten();
                let id = req.id.clone().unwrap_or(serde_json::Value::Null);
                let response = handle_proxy_request(
                    req,
                    id,
                    socket_path,
                    cached_tools_list,
                    session_id,
                    daemon_observes_tool_calls,
                )
                .await;
                if let Some(metadata) = initialize_metadata {
                    observe_proxy_session_started(metadata);
                    session_observed = true;
                }
                if let Some(timer) = tool_timer {
                    let outcome = timer.finish(&response);
                    if let Some(context) = session_context {
                        context.complete(&outcome);
                    }
                    observe_proxy_tool_completed(outcome);
                }
                response
            }
        };

        let serialized = serde_json::to_string(&response).unwrap_or_else(|e| {
            format!(
                r#"{{"jsonrpc":"2.0","id":null,"error":{{"code":-32603,"message":"serialize error: {e}"}}}}"#
            )
        });
        debug!(raw = %serialized, "← proxy response");

        writer.write_all(serialized.as_bytes()).await?;
        writer.write_all(b"\n").await?;
        writer.flush().await?;
    }

    // Reached on a clean stdin EOF (the `n == 0` break above) — the normal
    // "MCP client disconnected" seam. Session teardown is NO LONGER done here:
    // it's fully subsumed by the persistent control connection spawned at
    // startup. On any proxy exit — graceful stdin EOF (this path), an I/O
    // error propagated via `?`, OR a SIGKILL/crash — the kernel closes the
    // control socket, the daemon's reader hits EOF, and it fires
    // `session_end(session_id)` once (idempotent). That single path reliably
    // covers the ungraceful-death case the old best-effort exit hook missed.
    Ok(())
}

fn proxy_knows_tool(cached_tools_list: &serde_json::Value, name: &str) -> bool {
    if name == "type_text_chars" || cua_driver_core::tool::renamed_tool(name).is_some() {
        return true;
    }
    cached_tools_list
        .get("tools")
        .and_then(serde_json::Value::as_array)
        .is_some_and(|tools| {
            tools
                .iter()
                .any(|tool| tool.get("name").and_then(serde_json::Value::as_str) == Some(name))
        })
}

/// Own the proxy's single long-lived control connection. Connects directly to
/// the daemon socket (its OWN async open — `send_request` is sync, blocking,
/// and one-shot, so it cannot be reused here), sends one `session_begin` line
/// carrying `session_id`, then parks in a read loop until the connection
/// closes. It never writes again. The daemon records `session_id` from
/// `session_begin` and fires `session_end` when this connection EOFs — which
/// the kernel triggers on proxy exit AND on kill -9.
///
/// On EOF/error (daemon-side close, broken pipe), this future completes and
/// its supervisor closes the MCP proxy. Per-call connections must never keep
/// serving the ended identity. Startup connection failures follow the same path.
async fn run_control_connection(
    socket_path: String,
    session_id: String,
    control_ready: tokio::sync::oneshot::Sender<()>,
) {
    let begin = DaemonRequest {
        method: "session_begin".into(),
        name: None,
        args: None,
        session_id: Some(session_id.clone()),
        observation_origin: None,
        client_kind: None,
    };
    let line = match serde_json::to_string(&begin) {
        Ok(s) => s + "\n",
        Err(e) => {
            warn!("control connection: serialize session_begin failed: {e}");
            return;
        }
    };

    #[cfg(unix)]
    {
        use tokio::net::UnixStream;
        // Retry the connect briefly — the daemon may still be spinning up
        // (mirrors the windows pipe-open retry below). The is_daemon_listening
        // precheck makes the window tiny, but keep both paths symmetric.
        let deadline = std::time::Instant::now() + std::time::Duration::from_secs(3);
        let mut stream = loop {
            match UnixStream::connect(&socket_path).await {
                Ok(s) => break s,
                Err(_) if std::time::Instant::now() < deadline => {
                    tokio::time::sleep(std::time::Duration::from_millis(50)).await;
                }
                Err(e) => {
                    debug!(session_id = %session_id, "control connect failed (daemon starting?): {e}");
                    return;
                }
            }
        };
        if let Err(e) = stream.write_all(line.as_bytes()).await {
            debug!("control connection: write session_begin failed: {e}");
            return;
        }
        let _ = stream.flush().await;
        debug!(session_id = %session_id, "control connection established (session_begin sent)");

        // Park: read until the daemon closes (it ACKs session_begin then keeps
        // the conn open; we drain anything and only return on EOF/error). The
        // proxy never writes here again — the connection lives until process
        // death, when the kernel closes it and the daemon reaps the session.
        let mut reader = BufReader::new(stream);
        let mut buf = String::new();
        match reader.read_line(&mut buf).await {
            Ok(0) | Err(_) => return,
            Ok(_) => {
                if let Err(error) = validate_session_begin_ack(&buf) {
                    warn!("control connection: {error}");
                    return;
                }
                let _ = control_ready.send(());
            }
        }
        loop {
            buf.clear();
            match reader.read_line(&mut buf).await {
                Ok(0) | Err(_) => break, // daemon closed or error — task done.
                Ok(_) => continue,       // ACK / stray line — ignore, keep parked.
            }
        }
        debug!(session_id = %session_id, "control connection closed");
    }

    #[cfg(all(not(unix), target_os = "windows"))]
    {
        use tokio::net::windows::named_pipe::ClientOptions;
        // Retry the pipe open briefly — the daemon may still be spinning up its
        // next instance (mirrors send_request's open-retry).
        let deadline = std::time::Instant::now() + std::time::Duration::from_secs(3);
        let client = loop {
            match ClientOptions::new().open(&socket_path) {
                Ok(c) => break Some(c),
                Err(_) if std::time::Instant::now() < deadline => {
                    tokio::time::sleep(std::time::Duration::from_millis(50)).await;
                }
                Err(e) => {
                    debug!(session_id = %session_id, "control pipe open failed (daemon starting?): {e}");
                    break None;
                }
            }
        };
        let mut client = match client {
            Some(c) => c,
            None => return,
        };
        if let Err(e) = client.write_all(line.as_bytes()).await {
            debug!("control connection: write session_begin failed: {e}");
            return;
        }
        let _ = client.flush().await;
        debug!(session_id = %session_id, "control connection established (session_begin sent)");

        let mut reader = BufReader::new(client);
        let mut buf = String::new();
        match reader.read_line(&mut buf).await {
            Ok(0) | Err(_) => return,
            Ok(_) => {
                if let Err(error) = validate_session_begin_ack(&buf) {
                    warn!("control connection: {error}");
                    return;
                }
                let _ = control_ready.send(());
            }
        }
        loop {
            buf.clear();
            match reader.read_line(&mut buf).await {
                Ok(0) | Err(_) => break,
                Ok(_) => continue,
            }
        }
        debug!(session_id = %session_id, "control connection closed");
    }

    #[cfg(all(not(unix), not(target_os = "windows")))]
    {
        let _ = (line, session_id, socket_path, control_ready);
    }
}

fn validate_session_begin_ack(line: &str) -> Result<(), String> {
    let response: DaemonResponse = serde_json::from_str(line)
        .map_err(|_| "malformed session_begin acknowledgement".to_owned())?;
    if !response.ok
        || response
            .result
            .as_ref()
            .and_then(|result| result.get("session_begin"))
            != Some(&serde_json::Value::Bool(true))
    {
        return Err("daemon did not acknowledge session_begin".to_owned());
    }
    Ok(())
}

/// Mint a session id unique among the live proxies sharing one daemon, for the
/// lifetime of this proxy process. `pid + process-start nanos` is dep-free and
/// sufficient: two proxies can't share a pid concurrently, and the nanos guard
/// disambiguates pid reuse across the daemon's lifetime. We deliberately avoid
/// the `uuid` crate — a single v4 mint isn't worth a new dependency.
fn mint_session_id() -> String {
    let pid = std::process::id();
    let nanos = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    format!("mcp-{pid}-{nanos}")
}

/// One-shot daemon `list` over the UDS, reshaped into a MCP
/// `tools/list` result. The daemon now returns the full ToolDef
/// (`name`, `description`, `input_schema`, annotation hints) per
/// commit 3's `serve.rs` change.
fn fetch_tools_list_from_daemon(
    socket_path: &str,
    session_id: &str,
) -> anyhow::Result<(serde_json::Value, bool)> {
    let req = DaemonRequest {
        method: "list".into(),
        name: None,
        args: None,
        session_id: Some(session_id.to_owned()),
        observation_origin: None,
        client_kind: None,
    };
    let resp = send_request(socket_path, &req)?;
    if !resp.ok {
        anyhow::bail!(
            "daemon refused tool list on {socket_path}: {}",
            resp.error.unwrap_or_else(|| "(no error message)".into())
        );
    }
    let result = resp
        .result
        .ok_or_else(|| anyhow::anyhow!("daemon list response missing `result` field"))?;
    let tools_array = result
        .get("tools")
        .and_then(|v| v.as_array())
        .ok_or_else(|| anyhow::anyhow!("daemon list response missing `tools` array"))?;

    validate_daemon_output_schemas(tools_array)?;

    // Reshape the daemon's `{name, description, input_schema, output_schema,
    // read_only, ..., capabilities}` envelope into MCP's `{name, description,
    // inputSchema, outputSchema, annotations: {...}, capabilities}` shape.
    // Same translation `ToolDef::to_list_entry` defines for the core protocol.
    //
    // `capabilities` is passed through verbatim when the daemon
    // provides it; older daemons that don't emit the field fall back
    // to a name-keyed lookup so the proxy still surfaces capability
    // metadata without an extra round-trip.
    let mcp_tools: Vec<serde_json::Value> = tools_array
        .iter()
        .map(|t| {
            let name = t.get("name").cloned().unwrap_or(serde_json::Value::Null);
            let description = t
                .get("description")
                .cloned()
                .unwrap_or(serde_json::Value::String(String::new()));
            let input_schema = t
                .get("input_schema")
                .cloned()
                .unwrap_or_else(|| serde_json::json!({"type": "object", "properties": {}}));
            let read_only = t
                .get("read_only")
                .and_then(|v| v.as_bool())
                .unwrap_or(false);
            let destructive = t
                .get("destructive")
                .and_then(|v| v.as_bool())
                .unwrap_or(false);
            let idempotent = t
                .get("idempotent")
                .and_then(|v| v.as_bool())
                .unwrap_or(false);
            let open_world = t
                .get("open_world")
                .and_then(|v| v.as_bool())
                .unwrap_or(false);
            let capabilities = t
                .get("capabilities")
                .and_then(|v| v.as_array())
                .cloned()
                .unwrap_or_else(|| {
                    // Fallback: derive from the centralised name + schema
                    // resolver. Keeps the proxy compatible with daemon
                    // builds that pre-date the capabilities field.
                    name.as_str()
                        .map(|name| {
                            cua_driver_core::tool::advertised_capabilities_for(name, &input_schema)
                        })
                        .unwrap_or_default()
                        .into_iter()
                        .map(serde_json::Value::String)
                        .collect()
                });
            let risk = t.get("risk").cloned().unwrap_or_else(|| {
                name.as_str()
                    .map(cua_driver_core::authorization::risk_metadata_json)
                    .unwrap_or_else(|| {
                        serde_json::json!({
                            "class": "unclassified",
                            "enforcement": "metadata_only",
                            "operation_sensitive": false,
                            "version": cua_driver_core::authorization::RISK_METADATA_VERSION,
                        })
                    })
            });
            let mut tool = serde_json::json!({
                "name": name,
                "description": description,
                "inputSchema": input_schema,
                "annotations": {
                    "readOnlyHint": read_only,
                    "destructiveHint": destructive,
                    "idempotentHint": idempotent,
                    "openWorldHint": open_world,
                },
                "capabilities": capabilities,
                "risk": risk,
            });
            // Do not derive a new schema when an older daemon omitted it:
            // mixed-version proxies must advertise only the result contract
            // that the executing daemon actually owns.
            if let Some(output_schema) = t.get("output_schema") {
                tool.as_object_mut()
                    .expect("MCP tool entry is an object")
                    .insert("outputSchema".into(), output_schema.clone());
            }
            tool
        })
        .collect();

    // `capability_version` and `schema_version` are passed through
    // when the daemon emits them; older daemons fall back to the
    // proxy's compiled-in `CAPABILITY_VERSION` so MCP clients always
    // see the envelope keys.
    let capability_version = result
        .get("capability_version")
        .cloned()
        .unwrap_or_else(|| {
            serde_json::Value::String(cua_driver_core::tool::CAPABILITY_VERSION.to_owned())
        });
    let schema_version = result.get("schema_version").cloned().unwrap_or_else(|| {
        serde_json::Value::String(cua_driver_core::tool::TOOLS_LIST_SCHEMA_VERSION.to_owned())
    });

    let daemon_observes_tool_calls = daemon_owns_tool_observation(&result);

    Ok((
        serde_json::json!({
            "tools": mcp_tools,
            "capability_version": capability_version,
            "schema_version": schema_version,
        }),
        daemon_observes_tool_calls,
    ))
}

fn validate_daemon_output_schemas(tools: &[serde_json::Value]) -> anyhow::Result<()> {
    for tool in tools {
        let name = tool
            .get("name")
            .and_then(serde_json::Value::as_str)
            .ok_or_else(|| anyhow::anyhow!("daemon tool entry missing name"))?;
        cua_driver_core::mcp_result::validate_proxy_output_schema(name, tool.get("output_schema"))
            .map_err(anyhow::Error::msg)?;
    }
    Ok(())
}

fn proxy_output_schema<'a>(
    tools: &'a serde_json::Value,
    name: &str,
) -> Option<&'a serde_json::Value> {
    let tools = tools.get("tools")?.as_array()?;
    tools
        .iter()
        .find(|tool| tool.get("name").and_then(serde_json::Value::as_str) == Some(name))
        .or_else(|| {
            let current = if name == "type_text_chars" {
                Some("type_text")
            } else {
                cua_driver_core::tool::renamed_tool(name)
            }?;
            tools
                .iter()
                .find(|tool| tool.get("name").and_then(serde_json::Value::as_str) == Some(current))
        })?
        .get("outputSchema")
}

fn proxy_tool_result_response(
    id: serde_json::Value,
    result: Result<serde_json::Value, String>,
) -> Response {
    match result {
        Ok(result) => Response::ok(id, result),
        Err(error) => Response::error(id, -32603, error),
    }
}

fn daemon_owns_tool_observation(result: &serde_json::Value) -> bool {
    result
        .get("tool_observation_owner")
        .and_then(serde_json::Value::as_str)
        == Some("daemon")
}

/// JSON-RPC method dispatcher for the proxy. Mirrors
/// `cua_driver_core::server::handle_request`:
/// - `initialize` → static `initialize_result()` (same envelope as the core
///   protocol server; the daemon's identity is hidden from the MCP client).
/// - `tools/list` → return the cached daemon tool list.
/// - `tools/call` → forward to the daemon and reshape the response into MCP's
///   `CallTool.Result`.
/// - other → method-not-found.
async fn handle_proxy_request(
    req: Request,
    id: serde_json::Value,
    socket_path: &str,
    cached_tools_list: &Arc<serde_json::Value>,
    session_id: &str,
    daemon_observes_tool_calls: bool,
) -> Response {
    let era = match mcp_wire::classify_request(&req) {
        Ok(era) => era,
        Err(response) => return response,
    };
    if let Err(response) = mcp_wire::validate_tool_call(&req, id.clone(), era, cached_tools_list) {
        return response;
    }
    let method = req.method.clone();
    let response = if let Some(response) = mcp_wire::handle_metadata_request(&req, id.clone()) {
        response
    } else {
        handle_proxy_tool_request(
            req,
            id,
            socket_path,
            cached_tools_list,
            session_id,
            daemon_observes_tool_calls,
        )
        .await
    };
    mcp_wire::finish_response(era, &method, response)
}

async fn handle_proxy_tool_request(
    req: Request,
    id: serde_json::Value,
    socket_path: &str,
    cached_tools_list: &Arc<serde_json::Value>,
    session_id: &str,
    daemon_observes_tool_calls: bool,
) -> Response {
    match req.method.as_str() {
        "initialize"
            if mcp_wire::classify_request(&req).ok() == Some(mcp_wire::ProtocolEra::Legacy) =>
        {
            Response::ok(id, initialize_result())
        }

        "tools/list" => Response::ok(id, (**cached_tools_list).clone()),

        "tools/call" => match req.tool_call() {
            Err(e) => Response::error(id, -32602, format!("Invalid params: {e}")),
            Ok(call) => {
                if let Err(error) = authorize_tool_call(&call.name, &call.args) {
                    return proxy_tool_result_response(
                        id,
                        cua_driver_core::mcp_result::conforming_proxy_tool_result(
                            &call.name,
                            cua_driver_core::mcp_result::tool_error_result(
                                error.to_string(),
                                serde_json::json!({"code": "permission_denied"}),
                            ),
                            proxy_output_schema(cached_tools_list, &call.name),
                        ),
                    );
                }
                forward_tool_call(
                    id,
                    call.name.clone(),
                    call.args,
                    socket_path,
                    session_id,
                    daemon_observes_tool_calls,
                    proxy_output_schema(cached_tools_list, &call.name).cloned(),
                )
                .await
            }
        },

        other => {
            warn!(method = other, "unknown method");
            Response::method_not_found(id, other)
        }
    }
}

/// Forward a single MCP `tools/call` to the daemon as a `call`
/// request, then translate the `DaemonResponse` back into an MCP
/// `CallTool.Result` envelope.
///
/// Error mapping:
///   - Tool ran and reported failure (`!resp.ok`, including unknown
///     tool / bad params) → JSON-RPC success with `result.isError =
///     true`. Mirrors the core protocol's tool-error envelope.
///   - Transport failure (UDS unreachable, decode error, blocking
///     task panic) → JSON-RPC error (`-32603`), because the MCP
///     client really does need to distinguish "tool said no" from
///     "I couldn't reach the tool at all."
async fn forward_tool_call(
    id: serde_json::Value,
    name: String,
    mut args: serde_json::Value,
    socket_path: &str,
    session_id: &str,
    daemon_observes_tool_calls: bool,
    output_schema: Option<serde_json::Value>,
) -> Response {
    cua_driver_core::tool_args::sanitize_reserved_args(&mut args);
    let req = DaemonRequest {
        method: "call".into(),
        name: Some(name.clone()),
        args: Some(args),
        session_id: Some(session_id.to_owned()),
        observation_origin: daemon_observes_tool_calls.then_some(ToolObservationOrigin::McpProxy),
        client_kind: None,
    };

    // The daemon client is sync, so jump to a blocking thread to keep
    // the tokio reactor responsive while the AX-heavy call (e.g.
    // `get_window_state`) does its thing on the daemon
    // side.
    let socket = socket_path.to_owned();
    let blocking = tokio::task::spawn_blocking(move || send_request(&socket, &req)).await;

    let resp = match blocking {
        Err(join_err) => {
            return Response::error(
                id,
                -32603,
                format!("internal join error forwarding to daemon: {join_err}"),
            );
        }
        Ok(Err(e)) => {
            return Response::error(
                id,
                -32603,
                format!("daemon transport error forwarding `{name}`: {e}"),
            );
        }
        Ok(Ok(r)) => r,
    };

    proxy_tool_result_response(
        id,
        daemon_response_to_tool_result(&name, resp, output_schema.as_ref()),
    )
}

/// Translate one `DaemonResponse` into the `CallTool.Result` the MCP client
/// receives.
///
/// MCP separates two failure modes:
///   - JSON-RPC errors → `Response::error(...)`, used for transport /
///     protocol failures (unknown method, bad params shape, server crash).
///     Those are handled by the caller, above.
///   - Tool-level errors → `Response::ok(...)` carrying a `CallTool.Result`
///     with `isError: true` and the error message in `content[]`. The tool
///     ran, returned a well-formed result that says "I failed."
///
/// A non-`ok` daemon response means the tool call reached the daemon and the
/// daemon decided the tool returned an error (or rejected the call). That's
/// tool-level, not transport-level, so the core protocol surfaces it as
/// `Response::ok` with `isError: true`. Mirror that shape here — CodeRabbit #2.
///
/// Every branch — including the empty result synthesised for an `ok` response
/// that carries none — leaves through the same boundary the direct dispatch
/// uses, so a daemon-backed call is held to the tool's advertised
/// `outputSchema` exactly as a direct one is.
fn daemon_response_to_tool_result(
    name: &str,
    resp: DaemonResponse,
    output_schema: Option<&serde_json::Value>,
) -> Result<serde_json::Value, String> {
    let result = if resp.ok {
        resp.result.unwrap_or_else(|| {
            serde_json::json!({
                "content": [],
                "isError": false
            })
        })
    } else {
        let msg = resp
            .error
            .unwrap_or_else(|| "daemon reported failure".into());
        let exit_code = resp.exit_code.unwrap_or(1);
        cua_driver_core::mcp_result::tool_error_result(
            msg,
            serde_json::json!({ "exit_code": exit_code }),
        )
    };
    cua_driver_core::mcp_result::conforming_proxy_tool_result(name, result, output_schema)
}

// ── Tests ────────────────────────────────────────────────────────────────────
//
// The daemon-backed integration harness exercises the full proxy lifecycle.
// These tests lock in the I/O loop's transport contract and the per-branch
// response reshaping without requiring a live daemon.

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn modern_proxy_metadata_and_rejections_need_no_daemon_call() {
        use serde_json::json;
        let meta = json!({
            mcp_wire::PROTOCOL_VERSION_KEY: mcp_wire::MODERN_PROTOCOL_VERSION,
            mcp_wire::CLIENT_CAPABILITIES_KEY: {}
        });
        let mut input = Vec::new();
        for (id, method, mut params) in [
            (1, "server/discover", json!({})),
            (2, "skills/list", json!({})),
            (
                3,
                "resources/read",
                json!({"uri":"skill://cua-driver/SKILL.md"}),
            ),
            (4, "tools/call", json!({"name":"get_config","arguments":[]})),
            (
                5,
                "tools/call",
                json!({"name":"unknown_tool","arguments":{"session":"must-not-start"}}),
            ),
        ] {
            params["_meta"] = meta.clone();
            serde_json::to_writer(
                &mut input,
                &json!({"jsonrpc":"2.0","id":id,"method":method,"params":params}),
            )
            .unwrap();
            input.push(b'\n');
        }
        let inventory = Arc::new(json!({"tools":[{"name":"get_config"}]}));
        let mut output = Vec::new();
        run_proxy_io(
            BufReader::new(input.as_slice()),
            &mut output,
            "unreachable-test-endpoint",
            &inventory,
            "modern-test",
            false,
        )
        .await
        .unwrap();
        let replies: Vec<serde_json::Value> = String::from_utf8(output)
            .unwrap()
            .lines()
            .map(|line| serde_json::from_str(line).unwrap())
            .collect();
        assert_eq!(replies.len(), 5);
        assert_eq!(
            replies[0]["result"]["supportedVersions"],
            json!(["2026-07-28"])
        );
        assert_eq!(
            replies[1]["result"]["skills"][0]["uri"],
            "skill://cua-driver/SKILL.md"
        );
        assert!(replies[2]["result"]["contents"][0]["text"]
            .as_str()
            .unwrap()
            .starts_with("---"));
        for reply in &replies[..3] {
            assert_eq!(reply["result"]["resultType"], "complete");
            assert_eq!(reply["result"]["cacheScope"], "private");
        }
        for reply in &replies[3..] {
            assert_eq!(reply["error"]["code"], -32602);
        }
    }

    #[tokio::test]
    async fn proxy_authorization_refusal_is_a_tool_error_without_forwarding() {
        const CHILD_ENV: &str = "CUA_DRIVER_PROXY_REFUSAL_TEST_CHILD";
        if std::env::var_os(CHILD_ENV).is_none() {
            // Policy configuration is process-wide and immutable; keep this
            // denial out of other tests without mutating the parent environment.
            let directory = tempfile::tempdir().expect("temporary policy directory");
            let policy = directory.path().join("deny.yaml");
            std::fs::write(&policy, "deny:\n  tools: [click]\n").expect("write policy");
            let output = std::process::Command::new(std::env::current_exe().unwrap())
                .args([
                    "--exact",
                    "proxy::tests::proxy_authorization_refusal_is_a_tool_error_without_forwarding",
                    "--nocapture",
                ])
                .env(CHILD_ENV, "1")
                .env(cua_driver_core::policy::POLICY_FILE_ENV, &policy)
                .env_remove(cua_driver_core::policy::MANAGED_POLICY_FILE_ENV)
                .output()
                .expect("run isolated refusal test");
            assert!(
                output.status.success(),
                "isolated refusal test failed: {}{}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            );
            return;
        }

        let directory = tempfile::tempdir().expect("temporary socket directory");
        let socket = directory.path().join("daemon.sock");
        #[cfg(unix)]
        let listener = tokio::net::UnixListener::bind(&socket).expect("bind test daemon");
        let request = serde_json::from_value(serde_json::json!({
            "jsonrpc": "2.0", "id": 19, "method": "tools/call",
            "params": {"name": "click", "arguments": {"pid": 42, "x": 10, "y": 20}}
        }))
        .expect("valid tool request");
        let cached_tools = Arc::new(serde_json::json!({"tools": [{"name": "click"}]}));
        let response = handle_proxy_request(
            request,
            serde_json::json!(19),
            socket.to_str().unwrap(),
            &cached_tools,
            "refusal-test-session",
            false,
        );
        #[cfg(unix)]
        let response = tokio::select! {
            response = response => response,
            connection = listener.accept() => {
                drop(connection);
                panic!("a locally denied call must never connect to the daemon");
            }
        };
        #[cfg(not(unix))]
        let response = response.await;
        let value = serde_json::to_value(response).expect("serialize response");
        assert_eq!(value["id"], 19);
        assert!(value.get("error").is_none(), "{value}");
        let result = &value["result"];
        assert_eq!(result["isError"], true);
        assert_eq!(result["structuredContent"]["code"], "permission_denied");
        assert_eq!(result["content"][0]["type"], "text");
        assert!(result["content"][0]["text"]
            .as_str()
            .unwrap()
            .contains("explicitly denied"));
    }

    #[test]
    fn control_disconnect_exits_with_stdin_open() {
        const CHILD_ENV: &str = "CUA_TEST_MCP_CONTROL_STDIN_CHILD";
        if std::env::var_os(CHILD_ENV).is_some() {
            let result = crate::cli::run_mcp_runtime(async {
                let cached_tools = Arc::new(serde_json::json!({"tools": []}));
                supervise_control_connection(
                    // Let run_proxy_io park in the real blocking stdin read.
                    tokio::time::sleep(std::time::Duration::from_millis(100)),
                    run_proxy_io(
                        BufReader::new(tokio::io::stdin()),
                        tokio::io::sink(),
                        "unused.sock",
                        &cached_tools,
                        "disconnect",
                        false,
                    ),
                )
                .await
            });
            assert!(result.is_err());
            return;
        }
        let mut child = std::process::Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "proxy::tests::control_disconnect_exits_with_stdin_open",
                "--nocapture",
            ])
            .env(CHILD_ENV, "1")
            .stdin(std::process::Stdio::piped())
            .stdout(std::process::Stdio::piped())
            .stderr(std::process::Stdio::piped())
            .spawn()
            .unwrap();
        let deadline = std::time::Instant::now() + std::time::Duration::from_secs(5);
        loop {
            if let Some(status) = child.try_wait().unwrap() {
                assert!(
                    status.success(),
                    "MCP runtime subprocess failed: {:?}",
                    child.wait_with_output().unwrap()
                );
                break;
            }
            if std::time::Instant::now() >= deadline {
                child.kill().unwrap();
                child.wait().unwrap();
                panic!("control disconnect left the MCP process waiting for client stdin EOF");
            }
            std::thread::sleep(std::time::Duration::from_millis(10));
        }
    }

    #[tokio::test]
    async fn control_disconnect_ends_idle_proxy() {
        let (control, daemon) = tokio::io::duplex(64);
        let control = async move {
            let mut reader = BufReader::new(control);
            let mut line = String::new();
            let _ = reader.read_line(&mut line).await;
        };
        let proxy =
            supervise_control_connection(control, std::future::pending::<anyhow::Result<()>>());
        tokio::pin!(proxy);
        assert!(
            tokio::time::timeout(std::time::Duration::from_millis(25), &mut proxy)
                .await
                .is_err(),
            "an idle live control connection must remain usable"
        );
        drop(daemon);
        let error = tokio::time::timeout(std::time::Duration::from_millis(250), proxy)
            .await
            .expect("control EOF must end the proxy promptly")
            .unwrap_err();
        assert!(error.to_string().contains("reconnect the MCP client"));
    }

    #[tokio::test]
    async fn proxy_eof_drops_its_control_connection() {
        let (control, daemon) = tokio::io::duplex(64);
        let control = async move {
            let mut reader = BufReader::new(control);
            let mut line = String::new();
            let _ = reader.read_line(&mut line).await;
        };
        let cached_tools = Arc::new(serde_json::json!({"tools": []}));
        let mut writer = Vec::new();
        supervise_control_connection(
            control,
            run_proxy_io(
                BufReader::new(&b""[..]),
                &mut writer,
                "unused.sock",
                &cached_tools,
                "eof",
                false,
            ),
        )
        .await
        .unwrap();
        let mut daemon = BufReader::new(daemon);
        let mut line = String::new();
        assert_eq!(
            tokio::time::timeout(
                std::time::Duration::from_millis(250),
                daemon.read_line(&mut line)
            )
            .await
            .expect("proxy EOF must release daemon session ownership")
            .unwrap(),
            0
        );
    }

    #[tokio::test]
    async fn closed_control_prevents_ready_request_dispatch() {
        let dispatched = std::sync::atomic::AtomicBool::new(false);
        let result = supervise_control_connection(async {}, async {
            dispatched.store(true, std::sync::atomic::Ordering::SeqCst);
            Ok(())
        })
        .await;
        assert!(result.is_err());
        assert!(!dispatched.load(std::sync::atomic::Ordering::SeqCst));
    }

    #[tokio::test]
    async fn proxy_loop_returns_promptly_on_clean_eof() {
        let reader = BufReader::new(&b""[..]);
        let mut writer = Vec::new();
        let cached_tools = Arc::new(serde_json::json!({"tools": []}));

        let result = tokio::time::timeout(
            std::time::Duration::from_millis(250),
            run_proxy_io(
                reader,
                &mut writer,
                "unused.sock",
                &cached_tools,
                "eof-test-session",
                false,
            ),
        )
        .await
        .expect("clean EOF must return promptly");

        assert!(result.is_ok(), "clean EOF must not error: {result:?}");
        assert!(writer.is_empty(), "no request means no output");
    }

    #[tokio::test]
    async fn proxy_loop_serves_initialize_before_eof() {
        let input = b"{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"initialize\"}\n";
        let reader = BufReader::new(&input[..]);
        let mut writer = Vec::new();
        let cached_tools = Arc::new(serde_json::json!({"tools": []}));

        let result = tokio::time::timeout(
            std::time::Duration::from_millis(250),
            run_proxy_io(
                reader,
                &mut writer,
                "unused.sock",
                &cached_tools,
                "initialize-test-session",
                false,
            ),
        )
        .await
        .expect("initialize followed by EOF must return promptly");

        assert!(
            result.is_ok(),
            "initialize exchange must not error: {result:?}"
        );
        let response: serde_json::Value =
            serde_json::from_slice(&writer).expect("response must be JSON");
        assert_eq!(response["id"], 1);
        assert!(response.get("result").is_some());
    }

    #[test]
    fn session_begin_requires_a_positive_typed_acknowledgement() {
        assert!(
            validate_session_begin_ack(r#"{"ok":true,"result":{"session_begin":true}}"#).is_ok()
        );
        for line in [
            "not JSON",
            r#"{"ok":false,"error":"denied"}"#,
            r#"{"ok":false,"result":{"session_begin":true}}"#,
            r#"{"ok":true}"#,
            r#"{"ok":true,"result":{"session_begin":false}}"#,
            r#"{"ok":true,"result":{"session_begin":"true"}}"#,
            r#"{"ok":true,"result":{"other":true}}"#,
        ] {
            assert!(validate_session_begin_ack(line).is_err(), "accepted {line}");
        }
    }

    #[test]
    fn incompatible_daemon_schema_is_rejected_before_advertising() {
        let schema = serde_json::json!({"type": "object", "required": ["legacy_clicked"]});
        let tools = vec![serde_json::json!({"name": "click", "output_schema": schema})];
        let error = validate_daemon_output_schemas(&tools)
            .unwrap_err()
            .to_string();
        assert!(error.contains("incompatible daemon output schema for click"));
        assert!(error.contains("matching proxy and daemon versions"));

        let daemon_resp = DaemonResponse {
            ok: true,
            result: Some(serde_json::json!({
                "content": [], "structuredContent": {"legacy_clicked": true}
            })),
            error: None,
            exit_code: None,
        };
        let response = proxy_tool_result_response(
            serde_json::json!(1),
            daemon_response_to_tool_result("click", daemon_resp, Some(&schema)),
        );
        let response = serde_json::to_value(response).unwrap();
        assert_eq!(response["error"]["code"], -32603);
        assert!(response.get("result").is_none());
    }

    #[test]
    fn daemon_without_schema_preserves_legacy_success() {
        let tools = vec![serde_json::json!({"name": "click"})];
        validate_daemon_output_schemas(&tools).unwrap();
        for result in [
            serde_json::json!({"content": [], "isError": false}),
            serde_json::json!({
                "content": [], "isError": false,
                "structuredContent": {"legacy_clicked": true}
            }),
        ] {
            let daemon_resp = DaemonResponse {
                ok: true,
                result: Some(result.clone()),
                error: None,
                exit_code: None,
            };
            assert_eq!(
                daemon_response_to_tool_result("click", daemon_resp, None).unwrap(),
                result
            );
        }
    }

    #[test]
    fn matching_daemon_schema_retains_local_output_validation() {
        let tools =
            vec![serde_json::json!({"name": "click", "output_schema": click_output_schema()})];
        validate_daemon_output_schemas(&tools).unwrap();
    }

    fn click_output_schema() -> Option<serde_json::Value> {
        cua_driver_contract::advertised_tool_output_schema("click")
    }

    /// Serialize the production conversion the way the proxy answers it, so
    /// these assertions run against `forward_tool_call`'s own branch without
    /// spinning up a real daemon.
    fn tool_call_response(id: serde_json::Value, resp: DaemonResponse) -> Response {
        Response::ok(
            id,
            daemon_response_to_tool_result("click", resp, click_output_schema().as_ref()).unwrap(),
        )
    }

    #[test]
    fn daemon_tool_failure_wraps_as_jsonrpc_success_with_iserror_true() {
        let daemon_resp = DaemonResponse {
            ok: false,
            result: None,
            error: Some("missing required field `pid`".into()),
            exit_code: Some(64),
        };
        let resp = tool_call_response(serde_json::json!(7), daemon_resp);
        let value = serde_json::to_value(&resp).expect("serialize");

        // Top-level JSON-RPC envelope: success (`result`), not error.
        assert_eq!(value["jsonrpc"], "2.0");
        assert_eq!(value["id"], serde_json::json!(7));
        assert!(
            value.get("error").is_none(),
            "tool-level failure must NOT surface as JSON-RPC error: got {value}"
        );
        assert!(
            value.get("result").is_some(),
            "tool-level failure must carry a `result` payload: got {value}"
        );

        // CallTool.Result inside `result`: isError + content text.
        let result = &value["result"];
        assert_eq!(result["isError"], serde_json::json!(true));
        assert_eq!(result["content"][0]["type"], "text");
        assert_eq!(result["content"][0]["text"], "missing required field `pid`");
        assert_eq!(result["structuredContent"]["exit_code"], 64);
        // Strict MCP clients validate this payload against the tool's
        // advertised `outputSchema`. The refusal marker is what keeps the
        // response readable instead of being discarded as `-32602`.
        assert_eq!(
            result["structuredContent"]["code"],
            cua_driver_core::TOOL_INVOCATION_FAILED_CODE
        );
    }

    #[test]
    fn daemon_failure_with_no_error_message_uses_fallback_text() {
        let daemon_resp = DaemonResponse {
            ok: false,
            result: None,
            error: None,
            exit_code: None,
        };
        let resp = tool_call_response(serde_json::json!("abc"), daemon_resp);
        let value = serde_json::to_value(&resp).expect("serialize");
        assert_eq!(value["result"]["isError"], serde_json::json!(true));
        assert_eq!(
            value["result"]["content"][0]["text"],
            "daemon reported failure"
        );
        assert_eq!(value["result"]["structuredContent"]["exit_code"], 1);
        assert_eq!(
            value["result"]["structuredContent"]["code"],
            cua_driver_core::TOOL_INVOCATION_FAILED_CODE
        );
    }

    /// An `ok` daemon response that carries no result used to be forwarded as
    /// an empty success. For a tool that declares an `outputSchema` that is a
    /// response a strict client rejects outright (`-32600`), so the boundary
    /// converts it into an error the client can actually read.
    #[test]
    fn an_ok_daemon_response_with_no_result_becomes_a_conforming_error() {
        let daemon_resp = DaemonResponse {
            ok: true,
            result: None,
            error: None,
            exit_code: None,
        };

        let result =
            daemon_response_to_tool_result("click", daemon_resp, click_output_schema().as_ref())
                .unwrap();

        assert_eq!(result["isError"], serde_json::json!(true));
        assert_eq!(
            result["structuredContent"]["code"],
            cua_driver_core::mcp_result::TOOL_OUTPUT_INVALID_CODE
        );
    }

    /// A daemon result that already conforms is forwarded untouched.
    #[test]
    fn a_conforming_daemon_success_is_forwarded_unchanged() {
        let result = serde_json::json!({
            "content": [{ "type": "text", "text": "clicked" }],
            "isError": false,
            "structuredContent": {
                "effect": "confirmed",
                "route": "accessibility",
                "delivery": { "mode": "background" },
                "evidence": [{ "kind": "value_readback" }],
            },
        });
        let daemon_resp = DaemonResponse {
            ok: true,
            result: Some(result.clone()),
            error: None,
            exit_code: None,
        };

        assert_eq!(
            daemon_response_to_tool_result("click", daemon_resp, click_output_schema().as_ref())
                .unwrap(),
            result
        );
    }

    #[test]
    fn cached_proxy_tool_allowlist_is_exact() {
        let cached = serde_json::json!({
            "tools": [
                {"name":"click"},
                {"name":"type_text"}
            ]
        });
        assert!(proxy_knows_tool(&cached, "click"));
        assert!(
            proxy_knows_tool(&cached, "type_text_chars"),
            "deprecated alias stays bounded/known"
        );
        assert!(!proxy_knows_tool(&cached, "click/private-user-value"));
        assert!(!proxy_knows_tool(&cached, ""));
    }

    #[test]
    fn observation_ownership_requires_the_daemon_capability() {
        assert!(daemon_owns_tool_observation(&serde_json::json!({
            "tool_observation_owner": "daemon"
        })));
        assert!(!daemon_owns_tool_observation(&serde_json::json!({})));
        assert!(!daemon_owns_tool_observation(&serde_json::json!({
            "tool_observation_owner": "proxy"
        })));
    }
}
