// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Cua AI, Inc.

//! Application-state snapshots used by trajectory recording on Linux.

#[cfg(target_os = "linux")]
use cua_driver_core::video::{VideoBackend, VideoBackendFactory};

#[cfg(target_os = "linux")]
pub(crate) fn install() {
    cua_driver_core::recording::set_classified_screenshot_fn(screenshot_for_recording);
    cua_driver_core::recording::set_click_marker_fn(|png_bytes, x, y| {
        crate::capture::crosshair_png_bytes(png_bytes, x, y).ok()
    });
    cua_driver_core::recording::set_budgeted_ax_snapshot_fn(app_state_json_for);
    cua_driver_core::recording::set_element_bounds_fn(element_window_local_xy);
    cua_driver_core::video::set_video_backend_factory(Box::new(LinuxVideoBackendFactory));
}

#[cfg(target_os = "linux")]
struct LinuxVideoBackendFactory;

#[cfg(target_os = "linux")]
impl VideoBackendFactory for LinuxVideoBackendFactory {
    fn start(&self, output_path: &std::path::Path) -> anyhow::Result<Box<dyn VideoBackend>> {
        if crate::wayland::is_wayland() {
            crate::video_wayland::WaylandVideoBackendFactory.start(output_path)
        } else {
            cua_driver_core::video_ffmpeg::FfmpegVideoBackendFactory.start(output_path)
        }
    }
}

/// Per-turn application state for trajectory recording, walked under the
/// shared `get_window_state` budget. The walk reports the shared walk fields so
/// the turn evidence says when the tree is partial.
#[cfg(target_os = "linux")]
pub fn app_state_json_for(
    window_id: Option<u64>,
    pid: Option<i64>,
    budget: cua_driver_core::recording::StateCaptureBudget,
) -> Option<Vec<u8>> {
    if tokio::runtime::Handle::try_current().is_ok() {
        return std::thread::spawn(move || app_state_json_for_blocking(window_id, pid, budget))
            .join()
            .ok()
            .flatten();
    }
    app_state_json_for_blocking(window_id, pid, budget)
}

#[cfg(target_os = "linux")]
fn app_state_json_for_blocking(
    window_id: Option<u64>,
    pid: Option<i64>,
    budget: cua_driver_core::recording::StateCaptureBudget,
) -> Option<Vec<u8>> {
    let pid = u32::try_from(pid?).ok()?;
    let window_id = if crate::wayland::is_inject_mode() {
        // Most injected actions already carry the protocol-verified window id.
        // Process-scoped setup calls such as browser_prepare do not, so resolve
        // their single target here instead of classifying required AX evidence
        // as a capture failure.
        match window_id {
            Some(window_id) => window_id,
            None => resolve_window_for_recording(pid, None)?.xid,
        }
    } else {
        resolve_window_for_recording(pid, window_id)?.xid
    };
    let timeout = std::time::Duration::from_millis(budget.timeout_ms);
    let result = if crate::wayland::is_inject_mode() {
        // Evidence capture runs inside the daemon call. One attempt only, so
        // an unresponsive renderer cannot block input past the budget.
        crate::atspi::walk_tree_for_recording(pid, window_id, timeout)
    } else {
        crate::atspi::walk_tree_bounded_within(pid, window_id, None, None, None, timeout)
    };
    if result.nodes.is_empty() || result.tree_markdown.trim().is_empty() {
        return None;
    }
    let element_count = result
        .nodes
        .iter()
        .filter(|node| node.element_index.is_some())
        .count();
    let mut payload = serde_json::json!({
        "pid": pid,
        "window_id": window_id,
        "element_count": element_count,
        "tree_markdown": result.tree_markdown,
        // The shared walk fields (see cua_driver_core::walk_budget).
        "truncated": result.truncated,
        "nodes_visited": result.nodes_visited,
        "nodes_pending": result.nodes_pending,
        "walk_elapsed_ms": result.elapsed_ms as u64,
        "timeout_ms": budget.timeout_ms,
    });
    if let Some(reason) = result.truncation_reason {
        payload["truncation_reason"] = serde_json::json!(reason);
    }
    serde_json::to_vec_pretty(&payload).ok()
}

#[cfg(target_os = "linux")]
pub fn screenshot_for_recording(
    window_id: Option<u64>,
    pid: Option<i64>,
) -> cua_driver_core::recording::ScreenshotCapture {
    use cua_driver_core::recording::ScreenshotCapture;
    let capture = |png: Option<Vec<u8>>| match png {
        Some(png) => ScreenshotCapture::captured(png),
        None => ScreenshotCapture::unavailable("capture_failed"),
    };
    let target_pid = pid.and_then(|pid| u32::try_from(pid).ok());
    if let (None, Some(pid)) = (window_id, target_pid) {
        // A pid with no window has nothing to photograph. Name that outcome
        // instead of reporting a capture failure, so a deliberate no-window
        // turn is told apart from a broken capture path.
        if crate::wayland::list_windows_dispatch(Some(pid)).is_empty() {
            return ScreenshotCapture::unavailable(cua_driver_core::recording::TARGET_UNAVAILABLE);
        }
    }
    if crate::wayland::is_wayland() {
        // Wayland surface ids are connection-scoped, so a later recording hook
        // cannot safely re-attest the action call's per-window crop. Preserve
        // ownership by recording the compositor's complete rendered output.
        return capture(crate::wayland::screenshot_display_dispatch().ok());
    }
    if let Some(window_id) = window_id {
        capture(crate::wayland::screenshot_dispatch(window_id).ok())
    } else if target_pid.is_some() {
        let windows = crate::wayland::list_windows_dispatch(target_pid);
        capture(
            windows
                .first()
                .and_then(|window| crate::wayland::screenshot_dispatch(window.xid).ok()),
        )
    } else {
        capture(crate::capture::screenshot_display_bytes().ok())
    }
}

#[cfg(target_os = "linux")]
pub fn element_window_local_xy(
    pid: i64,
    args: &serde_json::Value,
    capture_point: bool,
) -> Option<(u64, Option<(f64, f64)>)> {
    let cache = cua_driver_core::snapshot_store::current_runtime_store::<
        crate::atspi::snapshot::AtspiSnapshot,
    >()?;
    let resolved = cache.resolve(i32::try_from(pid).ok()?, args).ok()?;
    let (index, window, _) = resolved.into_parts(None);
    let window_id = window?;
    let element_index = u32::try_from(index?).ok()?;
    let point = if !capture_point {
        None
    } else if tokio::runtime::Handle::try_current().is_ok() {
        std::thread::spawn(move || element_window_local_xy_blocking(window_id, pid, element_index))
            .join()
            .ok()
            .flatten()
    } else {
        element_window_local_xy_blocking(window_id, pid, element_index)
    };
    Some((window_id, point))
}

#[cfg(target_os = "linux")]
fn element_window_local_xy_blocking(
    window_id: u64,
    pid: i64,
    element_index: u32,
) -> Option<(f64, f64)> {
    let pid = u32::try_from(pid).ok()?;
    let (screen_x, screen_y, width, height) =
        crate::atspi::get_element_bounds_for_window(pid, window_id, element_index as usize).ok()?;
    let window = resolve_window_for_recording(pid, Some(window_id))?;
    if crate::wayland::is_wayland() && crate::wayland::hyprland::is_session() {
        let (display_width, display_height, _) = crate::wayland::hyprland::screen_size().ok()?;
        // This hook retains the whole output, not the window-local tool image.
        return hyprland_recording_point(
            (screen_x, screen_y, width, height),
            (window.x, window.y, window.width, window.height),
            (display_width, display_height),
        );
    }
    Some((
        f64::from(screen_x) - f64::from(window.x) + f64::from(width) / 2.0,
        f64::from(screen_y) - f64::from(window.y) + f64::from(height) / 2.0,
    ))
}

#[cfg(any(target_os = "linux", test))]
fn hyprland_recording_point(
    element: (i32, i32, u32, u32),
    window: (i32, i32, u32, u32),
    display: (u32, u32),
) -> Option<(f64, f64)> {
    let (x, y, width, height) = element;
    if width == 0 || height == 0 || window.2 == 0 || window.3 == 0 {
        return None;
    }
    let cx = f64::from(x) + f64::from(width) / 2.0;
    let cy = f64::from(y) + f64::from(height) / 2.0;
    hyprland_output_point((cx, cy), window, display)
}

#[cfg(any(target_os = "linux", test))]
fn hyprland_output_point(
    (cx, cy): (f64, f64),
    window: (i32, i32, u32, u32),
    display: (u32, u32),
) -> Option<(f64, f64)> {
    let in_window = cx >= f64::from(window.0)
        && cy >= f64::from(window.1)
        && cx < f64::from(window.0) + f64::from(window.2)
        && cy < f64::from(window.1) + f64::from(window.3);
    let in_display =
        cx >= 0.0 && cy >= 0.0 && cx < f64::from(display.0) && cy < f64::from(display.1);
    (in_window && in_display).then_some((cx, cy))
}

#[cfg(target_os = "linux")]
pub fn hyprland_pixel_recording_point(
    window_id: Option<u64>,
    pid: Option<i64>,
    x: f64,
    y: f64,
) -> Option<(f64, f64)> {
    // The recorded image is the desktop frame. Window geometry is in layout
    // coordinates, so move a window point into the frame before placing it.
    let frame = crate::wayland::hyprland::desktop_frame().ok()?;
    let (width, height) = (frame.width, frame.height);
    match (window_id, pid) {
        (Some(window_id), Some(pid)) => {
            let pid = u32::try_from(pid).ok()?;
            let window = resolve_window_for_recording(pid, Some(window_id))?;
            if window.pid != Some(pid) {
                return None;
            }
            let (frame_x, frame_y) = frame.from_layout(window.x, window.y);
            hyprland_output_point(
                (f64::from(frame_x) + x, f64::from(frame_y) + y),
                (frame_x, frame_y, window.width, window.height),
                (width, height),
            )
        }
        (None, None) => hyprland_output_point((x, y), (0, 0, width, height), (width, height)),
        _ => None,
    }
}

#[cfg(target_os = "linux")]
fn resolve_window_for_recording(
    pid: u32,
    window_id: Option<u64>,
) -> Option<crate::x11::WindowInfo> {
    let windows = crate::wayland::list_windows_dispatch(Some(pid));
    // Hyprland addresses and niri window ids are stable compositor ids.
    if crate::wayland::is_wayland()
        && (crate::wayland::hyprland::is_session() || crate::wayland::niri::is_session())
    {
        return match window_id {
            Some(id) => windows.into_iter().find(|window| window.xid == id),
            None if windows.len() == 1 => windows.into_iter().next(),
            _ => None,
        };
    }
    if crate::wayland::is_wayland() {
        // Foreign-toplevel protocol object ids are scoped to one Wayland
        // connection. Recording hooks open a fresh connection, so re-resolve
        // the target by pid instead of comparing an id from the action call.
        windows.into_iter().next()
    } else if let Some(window_id) = window_id {
        windows.into_iter().find(|window| window.xid == window_id)
    } else {
        windows.into_iter().next()
    }
}

#[cfg(not(target_os = "linux"))]
pub fn app_state_json_for(
    _window_id: Option<u64>,
    _pid: Option<i64>,
    _budget: cua_driver_core::recording::StateCaptureBudget,
) -> Option<Vec<u8>> {
    None
}

#[cfg(not(target_os = "linux"))]
pub fn screenshot_for_recording(
    _window_id: Option<u64>,
    _pid: Option<i64>,
) -> cua_driver_core::recording::ScreenshotCapture {
    cua_driver_core::recording::ScreenshotCapture::unavailable("capture_failed")
}

#[cfg(not(target_os = "linux"))]
pub fn element_window_local_xy(
    _pid: i64,
    _args: &serde_json::Value,
    _capture_point: bool,
) -> Option<(u64, Option<(f64, f64)>)> {
    None
}

#[cfg(test)]
mod tests {
    use super::{hyprland_output_point, hyprland_recording_point};

    #[test]
    fn hyprland_marker_uses_retained_output_coordinates() {
        assert_eq!(
            hyprland_recording_point((130, 250, 20, 30), (100, 200, 940, 780), (1920, 1080)),
            Some((140.0, 265.0))
        );
    }

    #[test]
    fn hyprland_marker_does_not_invent_an_offscreen_point() {
        for element in [(10, 800, 20, 20), (-30, 10, 20, 20), (10, 10, 0, 20)] {
            assert_eq!(
                hyprland_recording_point(element, (0, 0, 940, 780), (1920, 1080)),
                None
            );
        }
        assert_eq!(
            hyprland_recording_point((1900, 10, 80, 20), (1800, 0, 940, 780), (1920, 1080)),
            None
        );
    }

    #[test]
    fn hyprland_pixel_marker_keeps_fractional_output_coordinates() {
        assert_eq!(
            hyprland_output_point((130.5, 250.25), (100, 200, 940, 780), (1920, 1080)),
            Some((130.5, 250.25))
        );
        for point in [(f64::NAN, 200.0), (100.0, f64::INFINITY), (99.0, 200.0)] {
            assert_eq!(
                hyprland_output_point(point, (100, 200, 940, 780), (1920, 1080)),
                None
            );
        }
    }
}
