// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Cua AI, Inc.

//! `health_report` — single-call end-to-end driver diagnostics.
//!
//! The point of this tool is to let downstream consumers ship one stable
//! diagnostic call and never have to know cua-driver internals: specific
//! MCP tool names, TCC field names, bundle IDs, per-platform check
//! matrix. cua-driver owns the health model entirely; consumers stay
//! thin and the driver evolves freely.
//!
//! ## Stability
//!
//! Output shape is the stable contract — documented inline in the
//! tool's `description`. `schema_version: "1"` is the commitment;
//! future breaking changes go to `"2"`. Adding new `name` values to
//! `checks[]` under the same `schema_version` is non-breaking;
//! consumers must tolerate unknown check names.
//!
//! ## Architecture
//!
//! This module ports the Swift `HealthReportTool` (closed PR #1905) to
//! the canonical Rust workspace. The check matrix differs per platform,
//! so the per-platform crates (`platform-macos`, `platform-windows`,
//! `platform-linux`) supply a [`HealthCheckProvider`] and a list of
//! check names; this module owns the cross-platform skeleton:
//! schema shape, status rollup, include/skip filtering, JSON-RPC tool
//! plumbing, and the text summary.

use async_trait::async_trait;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::collections::BTreeSet;
use std::sync::Arc;

use crate::{
    protocol::ToolResult,
    tool::{Tool, ToolDef},
};

// ── Canonical check names ────────────────────────────────────────────────────
//
// Constants live here (not on each platform) so the wire format stays
// consistent and downstream consumers can hard-code these strings
// against the documented `schema_version=1` contract.

pub const NAME_BINARY_VERSION: &str = "binary_version";
pub const NAME_PLATFORM_SUPPORTED: &str = "platform_supported";
pub const NAME_SESSION_ACTIVE: &str = "session_active";
pub const NAME_BUNDLE_IDENTITY: &str = "bundle_identity";
pub const NAME_TCC_ACCESSIBILITY: &str = "tcc_accessibility";
pub const NAME_TCC_SCREEN_RECORDING: &str = "tcc_screen_recording";
pub const NAME_AX_CAPABILITY: &str = "ax_capability";
pub const NAME_SCREEN_CAPTURE_CAPABILITY: &str = "screen_capture_capability";
pub const NAME_WINDOWSERVER_CONNECTION: &str = "windowserver_connection";

/// Checks whose failure marks the whole report as `failed` (vs
/// `degraded`). Binary, platform, and the MCP session itself are
/// non-negotiable; everything else is degraded.
///
/// This list is fixed across platforms — a "core" check that doesn't
/// apply on a platform simply isn't present in that platform's `names`
/// vector, so the overall rollup ignores it.
pub fn core_check_names() -> &'static [&'static str] {
    &[
        NAME_BINARY_VERSION,
        NAME_PLATFORM_SUPPORTED,
        NAME_SESSION_ACTIVE,
    ]
}

// ── Output model ─────────────────────────────────────────────────────────────

/// Per-check status. Serialized lowercase to match the documented contract.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum CheckStatus {
    Pass,
    Fail,
    Skip,
}

/// Aggregate health verdict. Lowercase wire format.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Overall {
    Ok,
    Degraded,
    Failed,
}

/// Per-check structured data. Kept as a fixed set of optional fields —
/// not a free-form map — so the JSON shape is statically known. Adding
/// new optional fields here is non-breaking under `schema_version="1"`;
/// removing any documented field would break consumers and gates a
/// version bump.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct CheckData {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub bundle_identifier: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub configured_bundle_identifier: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub executable_path: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub identity_source: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub parent_process_id: Option<u32>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub os_version: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub architecture: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub display_count: Option<u32>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub error_detail: Option<String>,
}

impl CheckData {
    /// True if no field is set. Used by check authors so an empty
    /// `data` block is omitted from the wire format rather than
    /// serialized as `{}`.
    pub fn is_empty(&self) -> bool {
        self.bundle_identifier.is_none()
            && self.configured_bundle_identifier.is_none()
            && self.executable_path.is_none()
            && self.identity_source.is_none()
            && self.parent_process_id.is_none()
            && self.os_version.is_none()
            && self.architecture.is_none()
            && self.display_count.is_none()
            && self.error_detail.is_none()
    }
}

/// One entry in `report.checks[]`.
///
/// `hint` is required on `Fail` (the documented "fail entries carry a
/// remediation step" contract), optional on `Pass`/`Skip`.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CheckEntry {
    pub name: String,
    pub status: CheckStatus,
    pub message: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub hint: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub data: Option<CheckData>,
}

impl CheckEntry {
    /// Build a `Pass` entry with no hint and no structured data.
    pub fn pass(name: impl Into<String>, message: impl Into<String>) -> Self {
        Self {
            name: name.into(),
            status: CheckStatus::Pass,
            message: message.into(),
            hint: None,
            data: None,
        }
    }

    /// Build a `Fail` entry. `hint` is required on the contract level —
    /// taking it as a non-`Option` argument makes the requirement
    /// explicit at the call site rather than catching it in a test.
    pub fn fail(
        name: impl Into<String>,
        message: impl Into<String>,
        hint: impl Into<String>,
    ) -> Self {
        Self {
            name: name.into(),
            status: CheckStatus::Fail,
            message: message.into(),
            hint: Some(hint.into()),
            data: None,
        }
    }

    /// Build a `Skip` entry — used when a check is filtered out by the
    /// caller's `include`/`skip` or doesn't apply to this platform.
    pub fn skip(name: impl Into<String>, message: impl Into<String>) -> Self {
        Self {
            name: name.into(),
            status: CheckStatus::Skip,
            message: message.into(),
            hint: None,
            data: None,
        }
    }

    /// Attach structured `data`. Empty payloads are dropped so the wire
    /// format stays clean.
    pub fn with_data(mut self, data: CheckData) -> Self {
        if !data.is_empty() {
            self.data = Some(data);
        }
        self
    }

    /// The `binary_version` check. The version is a compiled-in constant, so
    /// reaching this code already implies the binary built; it always passes.
    pub fn binary_version() -> Self {
        Self::pass(
            NAME_BINARY_VERSION,
            format!("cua-driver {}", env!("CARGO_PKG_VERSION")),
        )
    }

    /// The `session_active` check. The server is servicing this MCP call, so
    /// by construction the session is up. The check exists so consumers can
    /// hard-code a canonical "is the server reachable?" signal.
    pub fn session_active() -> Self {
        Self::pass(NAME_SESSION_ACTIVE, "MCP session is active.")
    }
}

/// Top-level `health_report` payload.
///
/// JSON shape is the consumer-facing contract documented in the tool's
/// description. Field-rename in serde keeps the snake_case wire format
/// regardless of Rust naming.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Report {
    pub schema_version: String,
    pub platform: String,
    pub driver_version: String,
    pub overall: Overall,
    pub checks: Vec<CheckEntry>,
    /// Build identity of the running process (source revision and the
    /// sha256 of the executable actually running). Additive under
    /// `schema_version="1"`; absent from older drivers.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub build: Option<crate::build_info::BuildInfo>,
}

// ── Provider trait ───────────────────────────────────────────────────────────

/// Per-platform contract: list the canonical check names this platform
/// supports, and run a single check by name.
///
/// Implementations live in each `platform-*` crate so the
/// platform-specific TCC / UIA / AT-SPI / SCK plumbing stays out of the
/// core. Implementations must return entries for every name in their
/// `check_names()`; the dispatcher does not synthesize results.
#[async_trait]
pub trait HealthCheckProvider: Send + Sync {
    /// The platform tag for the `Report.platform` field — `"darwin"`,
    /// `"win32"`, or `"linux"`. The documented stable contract.
    fn platform(&self) -> &'static str;

    /// Canonical check names, in the run order the consumer should see
    /// reflected back in `report.checks[]`.
    fn check_names(&self) -> &'static [&'static str];

    /// Run a single check by name. The dispatcher only forwards names
    /// from `check_names()`; provider authors do not need to handle
    /// unknown names defensively.
    ///
    /// Calls MAY OVERLAP: the dispatcher polls every selected check
    /// concurrently within one task, so a check must not depend on
    /// another check having run first, and probes that share
    /// thread-unsafe native state must serialize internally. Overlap
    /// is concurrency at await points, not parallelism — a provider
    /// whose check bodies never yield still runs them one at a time,
    /// and moving a blocking probe onto a worker thread is a per-probe
    /// decision that requires knowing the native call is thread-safe.
    async fn run_check(&self, name: &str) -> CheckEntry;
}

// ── Filter / rollup logic ────────────────────────────────────────────────────

/// Decide which checks the call should actually run.
///
///   - `include` wins if non-empty: run exactly the canonical names
///     that intersect `include`. Unknown names in `include` are
///     silently ignored (forward-compat — a consumer may know a name
///     from a newer driver build).
///   - Otherwise `skip` filters out from the full canonical list.
///   - Empty filters → run everything.
pub fn select_checks(
    all_checks: &[&str],
    include: &BTreeSet<String>,
    skip: &BTreeSet<String>,
) -> BTreeSet<String> {
    let all: BTreeSet<String> = all_checks.iter().map(|s| (*s).to_owned()).collect();
    if !include.is_empty() {
        return all.intersection(include).cloned().collect();
    }
    if !skip.is_empty() {
        return all.difference(skip).cloned().collect();
    }
    all
}

/// Roll per-check statuses up into the documented overall verdict.
pub fn compute_overall(checks: &[CheckEntry]) -> Overall {
    let core: BTreeSet<&str> = core_check_names().iter().copied().collect();
    let mut any_fail = false;
    let mut any_core_fail = false;
    for entry in checks {
        if entry.status != CheckStatus::Fail {
            continue;
        }
        any_fail = true;
        if core.contains(entry.name.as_str()) {
            any_core_fail = true;
        }
    }
    if any_core_fail {
        return Overall::Failed;
    }
    if any_fail {
        return Overall::Degraded;
    }
    Overall::Ok
}

/// Pull a `BTreeSet<String>` out of a JSON value, treating non-array
/// inputs and non-string items as empty. Used to parse the optional
/// `include` / `skip` arguments.
pub fn parse_string_set(v: Option<&Value>) -> BTreeSet<String> {
    let mut out = BTreeSet::new();
    let Some(Value::Array(items)) = v else {
        return out;
    };
    for item in items {
        if let Some(s) = item.as_str() {
            out.insert(s.to_owned());
        }
    }
    out
}

// ── Text summary ─────────────────────────────────────────────────────────────

/// Compact human-readable summary of a report, for clients squinting at
/// MCP traces. `structuredContent` is the authoritative wire format;
/// this text is decorative.
pub fn text_summary(report: &Report) -> String {
    let overall_icon = match report.overall {
        Overall::Ok => "✅",
        Overall::Degraded => "⚠️",
        Overall::Failed => "❌",
    };
    let overall_word = match report.overall {
        Overall::Ok => "ok",
        Overall::Degraded => "degraded",
        Overall::Failed => "failed",
    };
    let mut lines = vec![format!(
        "{overall_icon} cua-driver {} on {} — {overall_word}",
        report.driver_version, report.platform
    )];
    for entry in &report.checks {
        let icon = match entry.status {
            CheckStatus::Pass => "✅",
            CheckStatus::Fail => "❌",
            CheckStatus::Skip => "⏭",
        };
        lines.push(format!("  {icon} {}: {}", entry.name, entry.message));
    }
    lines.join("\n")
}

// ── The MCP tool ─────────────────────────────────────────────────────────────

/// Cross-platform `health_report` MCP tool. The platform-specific bits
/// (which checks to run, how to run each one) are supplied by the
/// `HealthCheckProvider` passed at construction time.
pub struct HealthReportTool {
    provider: Arc<dyn HealthCheckProvider>,
}

impl HealthReportTool {
    pub fn new(provider: Arc<dyn HealthCheckProvider>) -> Self {
        Self { provider }
    }
}

static DEF: std::sync::OnceLock<ToolDef> = std::sync::OnceLock::new();

fn def() -> &'static ToolDef {
    DEF.get_or_init(|| ToolDef {
        name: "health_report".into(),
        // The description is part of the public contract — downstream
        // consumers depend on it spelling out `schema_version="1"` and the per-
        // platform check matrix. A test pins this commitment.
        description: r#"Single-call end-to-end driver diagnostics. Designed to let downstream consumers ship one stable call instead of stitching together check_permissions, doctor, version, bundle attribution, and platform capability status. On macOS, prompt-capable direct capture is deliberately skipped. For standalone CuaDriver, use `cua-driver permissions grant` to verify it explicitly. For an embedded or linked driver, use the host's permission flow for the app or executable macOS attributes this process's permission request to; the standalone command does not verify the host's capture readiness. cua-driver owns the health model; consumers stay thin.

Input — all optional:
  {
    "include": ["<check_name>", ...],   // run only these
    "skip":    ["<check_name>", ...]    // skip these
  }
If both are given, `include` wins.

Canonical check names:
  macOS  : binary_version, platform_supported, session_active,
           bundle_identity, tcc_accessibility, tcc_screen_recording,
           ax_capability, screen_capture_capability, windowserver_connection
  Windows: binary_version, platform_supported, session_active,
           ax_capability (via UIA), screen_capture_capability (via DXGI)
  Linux  : binary_version, platform_supported, session_active,
           ax_capability (via AT-SPI), screen_capture_capability (via X11)

Output — stable contract, schema_version="1":
  {
    "schema_version": "1",
    "platform": "darwin" | "win32" | "linux",
    "driver_version": "<semver>",
    "overall": "ok" | "degraded" | "failed",
    "checks": [
      {
        "name": "<one of the canonical names above>",
        "status": "pass" | "fail" | "skip",
        "message": "<one-line summary, always present>",
        "hint": "<remediation step, present when status=fail>",
        "data": { /* check-specific structured fields */ }
      },
      ...
    ]
  }

`overall` rules:
  - `ok`       — every non-skipped check passes
  - `degraded` — at least one non-core check fails (binary is still usable)
  - `failed`   — any core check fails (binary_version, platform_supported, session_active)

Stability: schema_version="1" is the contract. Future breaking changes will be `"2"`. Adding new check names under the same schema_version is non-breaking; consumers must tolerate unknown check names."#.into(),
        input_schema: json!({
            "type": "object",
            "properties": {
                "include": {
                    "type": "array",
                    "items": { "type": "string" },
                    "description":
                        "Only run these checks (canonical names). Wins over `skip`."
                },
                "skip": {
                    "type": "array",
                    "items": { "type": "string" },
                    "description":
                        "Skip these checks (canonical names). Ignored when `include` is set."
                }
            },
            "additionalProperties": false,
        }),
        // This is a diagnostic probe; it never mutates driver state.
        read_only: true,
        destructive: false,
        idempotent: true,
        open_world: false,
    })
}

#[async_trait]
impl Tool for HealthReportTool {
    fn def(&self) -> &ToolDef {
        def()
    }

    async fn invoke(&self, args: Value) -> ToolResult {
        let include = parse_string_set(args.get("include"));
        let skip = parse_string_set(args.get("skip"));

        let all = self.provider.check_names();
        let to_run = select_checks(all, &include, &skip);

        // Every canonical check appears in the output, even if filtered
        // out — consumers get a complete map of what was considered.
        //
        // Checks run concurrently: each is an independent probe, and the
        // sequential version paid the sum of their latencies (the slowest
        // probes dominate a full report). `join_all` polls every future
        // within this one task — no extra threads, no new Send/Sync
        // requirements on the provider — and returns results in input
        // order, so the report keeps its canonical check order.
        //
        // Scope: this overlaps only the checks that YIELD (async
        // probes, subprocess waits, spawn_blocking work). A provider
        // whose run_check bodies are synchronous still runs them back
        // to back; migrating such probes to worker threads is per-probe
        // work gated on native thread-safety and is tracked separately.
        let checks: Vec<CheckEntry> =
            futures_util::future::join_all(all.iter().map(|name| async {
                if !to_run.contains(*name) {
                    CheckEntry::skip(*name, "Skipped by include/skip filter.")
                } else {
                    self.provider.run_check(name).await
                }
            }))
            .await;

        let report = Report {
            schema_version: "1".to_owned(),
            platform: self.provider.platform().to_owned(),
            driver_version: env!("CARGO_PKG_VERSION").to_owned(),
            overall: compute_overall(&checks),
            checks,
            build: Some(crate::build_info::current()),
        };

        let text = text_summary(&report);
        let structured = serde_json::to_value(&report)
            .unwrap_or_else(|_| json!({ "schema_version": "1", "error": "serialize_failed" }));

        // health_report is the consumer's "what's broken?" probe — it
        // must NEVER itself set isError, regardless of how degraded
        // the report is, or consumers can't tell apart "tool broken"
        // from "driver degraded".
        ToolResult::text(text).with_structured(structured)
    }
}

// ── Tests ────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    #[test]
    fn shared_constant_checks_always_pass_with_canonical_names() {
        let version = CheckEntry::binary_version();
        assert_eq!(version.name, NAME_BINARY_VERSION);
        assert_eq!(version.status, CheckStatus::Pass);
        assert_eq!(
            version.message,
            format!("cua-driver {}", env!("CARGO_PKG_VERSION"))
        );

        let session = CheckEntry::session_active();
        assert_eq!(session.name, NAME_SESSION_ACTIVE);
        assert_eq!(session.status, CheckStatus::Pass);
        assert_eq!(session.message, "MCP session is active.");
    }

    // A platform-agnostic fixture provider used to exercise the
    // dispatcher, filter, and rollup logic without touching any real
    // TCC / UIA / SCK plumbing.
    struct FixtureProvider {
        names: &'static [&'static str],
        platform: &'static str,
        // Per-name override: if Some, return this entry; if None, return
        // a vanilla Pass with the canonical name.
        fail_names: BTreeSet<String>,
    }

    #[async_trait]
    impl HealthCheckProvider for FixtureProvider {
        fn platform(&self) -> &'static str {
            self.platform
        }
        fn check_names(&self) -> &'static [&'static str] {
            self.names
        }
        async fn run_check(&self, name: &str) -> CheckEntry {
            if self.fail_names.contains(name) {
                CheckEntry::fail(name, format!("{name} failed in fixture"), "remediate")
            } else {
                CheckEntry::pass(name, format!("{name} ok"))
            }
        }
    }

    fn macos_names() -> &'static [&'static str] {
        &[
            NAME_BINARY_VERSION,
            NAME_PLATFORM_SUPPORTED,
            NAME_SESSION_ACTIVE,
            NAME_BUNDLE_IDENTITY,
            NAME_TCC_ACCESSIBILITY,
            NAME_TCC_SCREEN_RECORDING,
            NAME_AX_CAPABILITY,
            NAME_SCREEN_CAPTURE_CAPABILITY,
        ]
    }

    // ── select_checks ────────────────────────────────────────────────

    #[test]
    fn include_wins_over_skip() {
        let mut include = BTreeSet::new();
        include.insert(NAME_BINARY_VERSION.to_owned());
        let mut skip = BTreeSet::new();
        skip.insert(NAME_BINARY_VERSION.to_owned());
        let chosen = select_checks(macos_names(), &include, &skip);
        assert_eq!(
            chosen.into_iter().collect::<Vec<_>>(),
            vec![NAME_BINARY_VERSION.to_owned()]
        );
    }

    #[test]
    fn include_filters_out_unknowns_silently() {
        let mut include = BTreeSet::new();
        include.insert(NAME_BINARY_VERSION.to_owned());
        include.insert("tomorrows_check_name".to_owned());
        let chosen = select_checks(macos_names(), &include, &BTreeSet::new());
        assert_eq!(
            chosen.into_iter().collect::<Vec<_>>(),
            vec![NAME_BINARY_VERSION.to_owned()]
        );
    }

    #[test]
    fn empty_filters_runs_everything() {
        let chosen = select_checks(macos_names(), &BTreeSet::new(), &BTreeSet::new());
        let expected: BTreeSet<String> = macos_names().iter().map(|s| (*s).to_owned()).collect();
        assert_eq!(chosen, expected);
    }

    #[test]
    fn skip_removes_named() {
        let mut skip = BTreeSet::new();
        skip.insert(NAME_TCC_ACCESSIBILITY.to_owned());
        let chosen = select_checks(macos_names(), &BTreeSet::new(), &skip);
        assert!(!chosen.contains(NAME_TCC_ACCESSIBILITY));
        assert!(chosen.contains(NAME_BINARY_VERSION));
    }

    #[test]
    fn advertised_capture_remediation_is_owner_scoped() {
        let description = &def().description;
        assert!(description.contains("For standalone CuaDriver"));
        assert!(description.contains("does not verify"));
        assert!(def().read_only);
    }

    // ── compute_overall ──────────────────────────────────────────────

    #[test]
    fn all_pass_is_ok() {
        let checks: Vec<_> = macos_names()
            .iter()
            .map(|n| CheckEntry::pass(*n, "ok"))
            .collect();
        assert_eq!(compute_overall(&checks), Overall::Ok);
    }

    #[test]
    fn all_skip_is_ok() {
        let checks: Vec<_> = macos_names()
            .iter()
            .map(|n| CheckEntry::skip(*n, "skipped"))
            .collect();
        assert_eq!(compute_overall(&checks), Overall::Ok);
    }

    #[test]
    fn non_core_fail_is_degraded() {
        // bundle_identity is non-core.
        let checks: Vec<_> = macos_names()
            .iter()
            .map(|n| {
                if *n == NAME_BUNDLE_IDENTITY {
                    CheckEntry::fail(*n, "no bundle", "relaunch in .app")
                } else {
                    CheckEntry::pass(*n, "ok")
                }
            })
            .collect();
        assert_eq!(compute_overall(&checks), Overall::Degraded);
    }

    #[test]
    fn core_fail_is_failed() {
        let checks: Vec<_> = macos_names()
            .iter()
            .map(|n| {
                if *n == NAME_BINARY_VERSION {
                    CheckEntry::fail(*n, "no version", "rebuild")
                } else {
                    CheckEntry::pass(*n, "ok")
                }
            })
            .collect();
        assert_eq!(compute_overall(&checks), Overall::Failed);
    }

    // ── parse_string_set ─────────────────────────────────────────────

    #[test]
    fn parse_string_set_ignores_non_string_items() {
        let v = json!(["a", 7, true, "b"]);
        let parsed = parse_string_set(Some(&v));
        let expected: BTreeSet<String> = ["a".to_owned(), "b".to_owned()].into_iter().collect();
        assert_eq!(parsed, expected);
    }

    #[test]
    fn parse_string_set_handles_nil_and_scalars() {
        assert!(parse_string_set(None).is_empty());
        assert!(parse_string_set(Some(&json!("x"))).is_empty());
        assert!(parse_string_set(Some(&json!(3))).is_empty());
    }

    // ── invoke end-to-end via the fixture provider ───────────────────

    #[tokio::test]
    async fn invoke_no_args_produces_documented_schema() {
        let provider = Arc::new(FixtureProvider {
            names: macos_names(),
            platform: "darwin",
            fail_names: BTreeSet::new(),
        });
        let tool = HealthReportTool::new(provider);
        let result = tool.invoke(json!({})).await;
        assert!(
            result.is_error.is_none(),
            "health_report must never set isError"
        );
        let structured = result.structured_content.expect("structured payload");
        // Top-level keys must match the documented schema verbatim.
        assert_eq!(structured["schema_version"], "1");
        assert_eq!(structured["platform"], "darwin");
        assert!(structured["driver_version"].is_string());
        assert!(structured["overall"].is_string());
        let checks = structured["checks"].as_array().expect("checks array");
        assert!(!checks.is_empty());
        for entry in checks {
            assert!(entry["name"].is_string());
            assert!(entry["message"].is_string());
            let status = entry["status"].as_str().unwrap();
            assert!(matches!(status, "pass" | "fail" | "skip"));
        }
    }

    #[tokio::test]
    async fn skip_filter_marks_check_as_skip_end_to_end() {
        let provider = Arc::new(FixtureProvider {
            names: macos_names(),
            platform: "darwin",
            fail_names: BTreeSet::new(),
        });
        let tool = HealthReportTool::new(provider);
        let result = tool
            .invoke(json!({ "skip": [NAME_TCC_ACCESSIBILITY] }))
            .await;
        let structured = result.structured_content.expect("structured");
        let checks = structured["checks"].as_array().unwrap();
        let entry = checks
            .iter()
            .find(|c| c["name"] == NAME_TCC_ACCESSIBILITY)
            .expect("tcc_accessibility appears even when skipped");
        assert_eq!(entry["status"], "skip");
    }

    #[tokio::test]
    async fn include_filter_runs_only_named_check() {
        let provider = Arc::new(FixtureProvider {
            names: macos_names(),
            platform: "darwin",
            fail_names: BTreeSet::new(),
        });
        let tool = HealthReportTool::new(provider);
        let result = tool
            .invoke(json!({ "include": [NAME_BINARY_VERSION] }))
            .await;
        let structured = result.structured_content.expect("structured");
        let checks = structured["checks"].as_array().unwrap();
        let ran: Vec<&str> = checks
            .iter()
            .filter(|c| c["status"] != "skip")
            .map(|c| c["name"].as_str().unwrap())
            .collect();
        assert_eq!(ran, vec![NAME_BINARY_VERSION]);
    }

    #[tokio::test]
    async fn fail_mode_does_not_set_is_error() {
        // Every check fails — overall should be Failed but the tool
        // result itself must NOT set isError.
        let mut fail = BTreeSet::new();
        for n in macos_names() {
            fail.insert((*n).to_owned());
        }
        let provider = Arc::new(FixtureProvider {
            names: macos_names(),
            platform: "darwin",
            fail_names: fail,
        });
        let tool = HealthReportTool::new(provider);
        let result = tool.invoke(json!({})).await;
        assert!(
            result.is_error.is_none(),
            "health_report must never set isError even on total failure"
        );
        let structured = result.structured_content.expect("structured");
        assert_eq!(structured["overall"], "failed");
        // Every entry must carry hint + message.
        for entry in structured["checks"].as_array().unwrap() {
            assert_eq!(entry["status"], "fail");
            assert!(!entry["hint"].as_str().unwrap_or("").is_empty());
            assert!(!entry["message"].as_str().unwrap_or("").is_empty());
        }
    }

    // ── tool description contract ────────────────────────────────────

    #[test]
    fn description_commits_to_schema_version_1() {
        // The PR description and downstream consumers bake
        // `schema_version: "1"` into their expectations. A future
        // change that drops this commitment from the schema text
        // without bumping the version would silently break consumers
        // — this test fails loudly the moment that drift starts.
        let description = &def().description;
        assert!(
            description.contains(r#"schema_version="1""#)
                || description.contains(r#"schema_version: "1""#),
            "schema_version=1 must be documented in the tool description"
        );
    }

    // ── Concurrency contract ─────────────────────────────────────────

    // Instrumented provider: every check yields (tokio sleep), overlap
    // is recorded as an active-counter high-water mark, completion
    // order is recorded, and an RAII guard does the release bookkeeping
    // so a CANCELLED check is still counted down (a dropped future
    // never runs code after its await).
    struct DelayedProvider {
        names: &'static [&'static str],
        delays_ms: &'static [u64],
        active: std::sync::Arc<std::sync::atomic::AtomicUsize>,
        max_active: std::sync::Arc<std::sync::atomic::AtomicUsize>,
        started: std::sync::Arc<std::sync::Mutex<Vec<String>>>,
        completed: std::sync::Arc<std::sync::Mutex<Vec<String>>>,
    }

    impl DelayedProvider {
        fn new(names: &'static [&'static str], delays_ms: &'static [u64]) -> Self {
            Self {
                names,
                delays_ms,
                active: Default::default(),
                max_active: Default::default(),
                started: Default::default(),
                completed: Default::default(),
            }
        }
    }

    struct ActiveGuard(std::sync::Arc<std::sync::atomic::AtomicUsize>);
    impl Drop for ActiveGuard {
        fn drop(&mut self) {
            self.0.fetch_sub(1, std::sync::atomic::Ordering::SeqCst);
        }
    }

    #[async_trait]
    impl HealthCheckProvider for DelayedProvider {
        fn platform(&self) -> &'static str {
            "fixture"
        }
        fn check_names(&self) -> &'static [&'static str] {
            self.names
        }
        async fn run_check(&self, name: &str) -> CheckEntry {
            use std::sync::atomic::Ordering;
            let idx = self.names.iter().position(|n| *n == name).unwrap();
            self.started.lock().unwrap().push(name.to_owned());
            let now = self.active.fetch_add(1, Ordering::SeqCst) + 1;
            self.max_active.fetch_max(now, Ordering::SeqCst);
            let _guard = ActiveGuard(self.active.clone());
            tokio::time::sleep(std::time::Duration::from_millis(self.delays_ms[idx])).await;
            self.completed.lock().unwrap().push(name.to_owned());
            CheckEntry::pass(name, format!("{name} ok"))
        }
    }

    /// The dispatcher must actually overlap yielding checks (the old
    /// sequential loop fails this: its high-water mark is 1), complete
    /// them in delay order rather than declaration order, and still
    /// report entries in canonical `check_names()` order.
    #[tokio::test]
    async fn yielding_checks_overlap_and_report_in_canonical_order() {
        let provider = DelayedProvider::new(&["slow", "mid", "fast"], &[120, 60, 10]);
        let max_active = provider.max_active.clone();
        let completed = provider.completed.clone();
        let tool = HealthReportTool::new(Arc::new(provider));

        let result = tool.invoke(json!({})).await;
        let checks = result.structured_content.unwrap()["checks"].clone();
        let reported: Vec<String> = checks
            .as_array()
            .unwrap()
            .iter()
            .map(|c| c["name"].as_str().unwrap().to_owned())
            .collect();
        assert_eq!(reported, vec!["slow", "mid", "fast"], "canonical order");

        let done = completed.lock().unwrap().clone();
        assert_eq!(
            done,
            vec!["fast", "mid", "slow"],
            "completion follows delays"
        );
        assert!(
            max_active.load(std::sync::atomic::Ordering::SeqCst) >= 2,
            "checks never overlapped — high-water mark {}",
            max_active.load(std::sync::atomic::Ordering::SeqCst)
        );
    }

    /// A skipped name must never reach the provider, and its Skip entry
    /// must still hold its canonical position in the report.
    #[tokio::test]
    async fn skipped_checks_never_reach_the_provider() {
        let provider = DelayedProvider::new(&["slow", "mid", "fast"], &[5, 5, 5]);
        let started = provider.started.clone();
        let tool = HealthReportTool::new(Arc::new(provider));

        let result = tool.invoke(json!({ "skip": ["mid"] })).await;
        let checks = result.structured_content.unwrap()["checks"].clone();
        let entries = checks.as_array().unwrap();
        assert_eq!(entries[1]["name"], "mid");
        assert_eq!(entries[1]["status"], "skip");
        assert!(
            !started.lock().unwrap().contains(&"mid".to_owned()),
            "skipped check reached the provider"
        );
    }

    /// Cancelling the report mid-flight must drop every started check
    /// cleanly: the RAII guards release the active counter, nothing
    /// panics, and only the checks whose delays elapsed completed.
    #[tokio::test]
    async fn cancellation_releases_started_checks() {
        let provider = DelayedProvider::new(&["fast", "slow_a", "slow_b"], &[5, 30_000, 30_000]);
        let active = provider.active.clone();
        let started = provider.started.clone();
        let completed = provider.completed.clone();
        let tool = HealthReportTool::new(Arc::new(provider));

        let out = tokio::time::timeout(
            std::time::Duration::from_millis(150),
            tool.invoke(json!({})),
        )
        .await;
        assert!(out.is_err(), "expected the report to be cancelled");
        assert_eq!(started.lock().unwrap().len(), 3, "all checks had started");
        assert_eq!(completed.lock().unwrap().clone(), vec!["fast"]);
        assert_eq!(
            active.load(std::sync::atomic::Ordering::SeqCst),
            0,
            "cancelled checks did not release the active counter"
        );
    }
}
