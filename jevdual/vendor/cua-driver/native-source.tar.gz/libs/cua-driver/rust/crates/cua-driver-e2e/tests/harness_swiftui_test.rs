// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Cua AI, Inc.

//! Integration test against the CuaTestHarness.SwiftUI Swift app.
//!
//! macOS equivalent of `harness_winui3_test.rs` — SwiftUI plays the same
//! role on macOS that WinUI3 plays on Windows: the modern declarative
//! UI hosting pattern with retained-mode AX exposed via a different
//! backend than the older AppKit one.
//!
//! Scenarios (see scenarios.json `swiftui` section):
//!   - counter   : SwiftUI Button increments State<Int>
//!   - text_body : Text with HARNESS_TEXT_MARKER_v1
//!   - text_input: TextField with mirror Text
//!   - popover   : .popover() — SwiftUI analogue of WinUI3 CommandBarFlyout
//!
//! Run locally (after `libs/cua-driver/tests/fixtures/build/macos.sh`):
//!   cargo test --test harness_swiftui_test -- --ignored --nocapture

#![cfg(target_os = "macos")]

use std::path::PathBuf;
use std::process::{Child, Command, Stdio};
use std::time::Duration;

use cua_driver_testkit::ax::{element_index_by_id, has_id, looks_empty};
use cua_driver_testkit::e2e::{
    execute_case, native_background_case, native_foreground_case, native_readonly_case,
    recording_evidence, DriverRoute, Evidence, Observation, OracleKind, Targeting,
};
use cua_driver_testkit::observer::TargetWindow;
use cua_driver_testkit::sentinel::run_with_background_oracles;
use cua_driver_testkit::{harness_app, Driver, McpDriver, ToolResponse};

fn harness_exe() -> PathBuf {
    if let Ok(p) = std::env::var("HARNESS_SWIFTUI_APP") {
        let pb = PathBuf::from(p).join("Contents/MacOS/CuaTestHarness.SwiftUI");
        if pb.exists() {
            return pb;
        }
    }
    harness_app(
        "harness-swiftui",
        "CuaTestHarness.SwiftUI.app/Contents/MacOS/CuaTestHarness.SwiftUI",
    )
}

struct Harness {
    _app: Child,
    pid: u32,
}

impl Harness {
    fn launch() -> Self {
        let exe = harness_exe();
        assert!(exe.exists(), "required SwiftUI harness is missing: {exe:?}");
        let app = Command::new(&exe)
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .spawn()
            .unwrap_or_else(|error| panic!("launch SwiftUI harness {exe:?}: {error}"));
        let pid = app.id();
        std::thread::sleep(Duration::from_millis(900));
        Self { _app: app, pid }
    }
}

impl Drop for Harness {
    fn drop(&mut self) {
        let _ = self._app.kill();
        let _ = self._app.wait();
        std::thread::sleep(Duration::from_millis(200));
    }
}

fn snapshot_elements(driver: &mut McpDriver, pid: u32, window_id: u64) -> ToolResponse {
    driver.call(
        "get_window_state",
        serde_json::json!({
            "pid": pid as i64,
            "window_id": window_id,
            "capture_mode": "ax"
        }),
    )
}

fn run_case(
    case: cua_driver_testkit::e2e::CaseSpec,
    test: impl FnOnce(u32, u64, &mut McpDriver) -> Observation,
) {
    let cell_id = case.cell_id.clone();
    let delivery = case.delivery;
    execute_case(case, |evidence| {
        let mut driver = McpDriver::spawn_macos_daemon_proxy_named(&cell_id)
            .expect("start installed macOS daemon proxy");
        *evidence = recording_evidence(driver.recording_dir());
        let harness = Harness::launch();
        let (wid, _) = driver
            .find_window(harness.pid as i64, "CuaTestHarness SwiftUI")
            .expect("SwiftUI main window not found");
        if delivery != cua_driver_testkit::e2e::Delivery::Background {
            driver.start_behavior_recording();
        }
        test(harness.pid, wid, &mut driver)
    });
}

fn run_foreground_case(action: &str, test: impl FnOnce(u32, u64, &mut McpDriver)) {
    run_case(
        native_foreground_case("swiftui", action, Targeting::Ax, DriverRoute::MacosAxAction),
        |pid, wid, driver| {
            test(pid, wid, driver);
            Observation::delivered_with_fixture_state(Vec::new())
        },
    );
}

fn run_background_case(
    action: &str,
    route: DriverRoute,
    test: impl FnOnce(u32, u64, &mut McpDriver),
) {
    run_case(
        native_background_case("swiftui", action, Targeting::Ax, route),
        |pid, wid, driver| {
            let (_, passed) = run_with_background_oracles(
                driver,
                TargetWindow {
                    pid,
                    native_id: wid,
                },
                |driver| test(pid, wid, driver),
            )
            .unwrap_or_else(|error| panic!("background desktop contract failed: {error}"));
            Observation::delivered_with_fixture_state(passed)
        },
    );
}

#[test]
#[ignore]
fn harness_swiftui_smoke() {
    run_case(
        native_readonly_case(
            "swiftui",
            "ax_tree",
            Targeting::Ax,
            DriverRoute::AxRead,
            vec![OracleKind::AxState],
        ),
        |pid, wid, driver| {
            let snap = snapshot_elements(driver, pid, wid);
            assert!(
                !looks_empty(snap.tree_text()),
                "required SwiftUI AX tree is empty"
            );
            let text = snap.tree_text();
            println!("snapshot:\n{text}");

            // SwiftUI Text views render as AXStaticText leaves and don't propagate
            // accessibilityIdentifier into the AX tree's identifier slot (same
            // quirk as AppKit's NSTextField label mode + WPF's TextBlock). Assert
            // on text content for labels, AX-id only for actionable controls.
            for aid in [
                "btn-increment",
                "btn-reset",
                "txt-input",
                "btn-open-popover",
                "btn-exit",
            ] {
                assert!(
                    has_id(snap.tree_text(), aid),
                    "missing AX identifier {aid} in SwiftUI snapshot"
                );
            }

            assert!(
                text.contains("HARNESS_TEXT_MARKER_v1"),
                "text_body marker not in SwiftUI snapshot"
            );
            Observation::delivered(vec![OracleKind::AxState], Evidence::default())
        },
    );
}

#[test]
#[ignore]
fn harness_swiftui_verify_state() {
    run_case(
        native_readonly_case(
            "swiftui",
            "verify_state",
            Targeting::Ax,
            DriverRoute::AxRead,
            vec![OracleKind::AxState],
        ),
        |pid, wid, driver| {
            let verified = driver.call(
                "verify_state",
                serde_json::json!({
                    "pid": pid as i64,
                    "window_id": wid,
                    "expect": [
                        {"window": {"exists": true}},
                        {"element": {
                            "selector": {"label_contains": "Increment"},
                            "exists": true,
                            "enabled": true
                        }},
                        {"element": {
                            "selector": {"label_contains": "I agree"},
                            "exists": true,
                            "selected": false
                        }}
                    ],
                    "timeout_ms": 10_000,
                    "stable_samples": 2,
                    "include_screenshot": true
                }),
            );
            assert!(
                !verified.is_error(),
                "SwiftUI verify_state failed: {}",
                verified.text()
            );
            assert_eq!(
                verified.structured()["status"],
                "satisfied",
                "verify_state outcome: {}",
                verified.structured()
            );
            assert_eq!(
                verified.structured()["stable"],
                true,
                "verify_state outcome: {}",
                verified.structured()
            );
            assert!(
                verified.structured()["samples"].as_u64().unwrap_or(0) >= 2,
                "verify_state did not enforce consecutive stable samples: {}",
                verified.structured()
            );
            assert!(
                verified.raw["result"]["content"]
                    .as_array()
                    .is_some_and(|content| content.iter().any(|item| {
                        item["type"] == "image" && item["mimeType"] == "image/png"
                    })),
                "verify_state did not return final visual evidence"
            );
            Observation::delivered(vec![OracleKind::AxState], Evidence::default())
        },
    );
}

#[test]
#[ignore]
fn harness_swiftui_counter_background() {
    run_background_case(
        "left_click",
        DriverRoute::MacosAxAction,
        |pid, wid, driver| {
            let pre = snapshot_elements(driver, pid, wid);
            assert!(pre.tree_text().contains("counter=0"));
            let index = element_index_by_id(pre.tree_text(), "btn-increment")
                .expect("btn-increment element_index not found");
            let response = driver.call(
                "click",
                serde_json::json!({
                    "pid": pid as i64,
                    "window_id": wid,
                    "element_token": pre.element_token(index),
                    "action": "press",
                    "delivery_mode": "background"
                }),
            );
            assert!(
                !response.is_error(),
                "SwiftUI counter click failed: {}",
                response.text()
            );
            std::thread::sleep(Duration::from_millis(200));
            assert!(
                snapshot_elements(driver, pid, wid)
                    .tree_text()
                    .contains("counter=1"),
                "SwiftUI background AX click did not advance counter"
            );
        },
    );
}

#[test]
#[ignore]
fn harness_swiftui_set_value_background() {
    run_background_case(
        "set_value",
        DriverRoute::MacosAxValue,
        |pid, wid, driver| {
            let pre = snapshot_elements(driver, pid, wid);
            let index = element_index_by_id(pre.tree_text(), "txt-input")
                .expect("txt-input element_index not found");
            let response = driver.call(
                "set_value",
                serde_json::json!({
                    "pid": pid as i64,
                    "window_id": wid,
                    "element_token": pre.element_token(index),
                    "value": "swiftui-cua"
                }),
            );
            assert!(
                !response.is_error(),
                "SwiftUI set_value failed: {}",
                response.text()
            );
            std::thread::sleep(Duration::from_millis(200));
            assert!(
                snapshot_elements(driver, pid, wid)
                    .tree_text()
                    .contains("swiftui-cua"),
                "SwiftUI background AX value did not reach the field"
            );
        },
    );
}

/// Popover activation: click the trigger and verify fixture-owned state changes.
/// Transient-window AX discovery is observed separately so it cannot hide a
/// correctly delivered action.
#[test]
#[ignore]
fn harness_swiftui_popover_foreground() {
    run_foreground_case("popover_open", |pid, wid, driver| {
        let snap_pre = snapshot_elements(driver, pid, wid);
        assert!(
            !looks_empty(snap_pre.tree_text()),
            "required SwiftUI AX tree is empty"
        );
        // Verify popover body is NOT yet in the tree.
        let pre_text = snap_pre.tree_text().to_owned();
        assert!(
            !pre_text.contains("POPOVER_MARKER_v1"),
            "popover body unexpectedly present BEFORE open"
        );
        assert!(
            pre_text.contains("popover_open=false"),
            "popover state was not false before open"
        );

        let trigger_idx = element_index_by_id(snap_pre.tree_text(), "btn-open-popover")
            .expect("popover trigger not found");
        let click = driver.call(
            "click",
            serde_json::json!({
                "pid": pid as i64,
                "window_id": wid,
                "element_token": snap_pre.element_token(trigger_idx),
                "action": "press",
                "delivery_mode": "foreground"
            }),
        );
        assert!(
            !click.is_error(),
            "SwiftUI popover click failed: {}",
            click.text()
        );
        println!("popover trigger click: {}", click.text());

        // First prove the button action reached SwiftUI's state independently
        // of whether AX can enumerate the transient panel.
        let deadline = std::time::Instant::now() + Duration::from_secs(3);
        let mut state_open = false;
        let mut found_marker = false;
        while !state_open && std::time::Instant::now() < deadline {
            let owner = snapshot_elements(driver, pid, wid);
            state_open = owner.tree_text().contains("popover_open=true");
            found_marker = owner.tree_text().contains("POPOVER_MARKER_v1");
            let resp = driver.call("list_windows", serde_json::json!({ "pid": pid as i64 }));
            if let Some(wins) = resp.structured()["windows"].as_array() {
                for w in wins {
                    if let Some(other_wid) = w["window_id"].as_u64() {
                        if other_wid == wid {
                            continue;
                        }
                        let s = snapshot_elements(driver, pid, other_wid);
                        if s.tree_text().contains("POPOVER_MARKER_v1") {
                            found_marker = true;
                            break;
                        }
                    }
                }
            }
            if !state_open {
                std::thread::sleep(Duration::from_millis(100));
            }
        }
        assert!(state_open, "popover trigger did not change fixture state");
        if !found_marker {
            eprintln!(
                "SwiftUI popover opened, but its transient panel remains absent from targeted AX enumeration"
            );
        }
    });
}
