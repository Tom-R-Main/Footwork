//! Bounded row-recipient predicates. Graphs are SDK-owned observations, never public tool inputs.
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, BTreeSet};

#[derive(Debug, Clone, Serialize, Deserialize, JsonSchema, PartialEq, Eq, uniffi::Record)]
#[serde(deny_unknown_fields)]
pub struct ExpectedRow {
    pub version: u32,
    pub pid: u32,
    pub window_id: u64,
    pub document_url: String,
    pub table_headers: Vec<String>,
    pub key_column: String,
    pub key_value: String,
    pub role: String,
    pub name: String,
    pub action: String,
}
impl ExpectedRow {
    pub fn validate(&self) -> Result<(), String> {
        let text = [
            &self.document_url,
            &self.key_column,
            &self.key_value,
            &self.name,
        ];
        if self.version != 1
            || self.pid == 0
            || self.window_id == 0
            || text.iter().any(|s| s.is_empty() || s.len() > 2048)
            || !matches!(self.role.as_str(), "AXButton" | "AXPopUpButton")
            || self.action != "AXPress"
            || self.table_headers.is_empty()
            || self.table_headers.len() > 64
            || self.table_headers.iter().any(|s| s.len() > 2048)
            || self
                .table_headers
                .iter()
                .filter(|s| **s == self.key_column)
                .count()
                != 1
        {
            return Err("invalid expected-row predicate".into());
        }
        Ok(())
    }
}

// The native adapter interns CFEqual objects, including row/column aliases. IDs
// stay within an owned snapshot lifetime; they are not exposed as AX endpoints.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RowNode {
    pub id: u64,
    pub pid: u32,
    pub window_id: u64,
    pub role: String,
    pub name: String,
    pub value: Option<String>,
    pub url: Option<String>,
    pub parent: Option<u64>,
    pub children: Vec<u64>,
    pub rows: Option<Vec<u64>>,
    pub columns: Option<Vec<u64>>,
    pub header: Option<u64>,
    pub enabled: Option<bool>,
    pub actions: Vec<String>,
    pub error: Option<String>,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RowGraph {
    pub root: u64,
    pub nodes: Vec<RowNode>,
    pub complete: bool,
}
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(deny_unknown_fields)]
pub struct RowBinding {
    pub predicate: ExpectedRow,
    pub window: u64,
    pub document: u64,
    pub table: u64,
    pub row: u64,
    pub key_cell: u64,
    pub key_column: u64,
    pub header: u64,
    pub recipient: u64,
}
struct Census<'a> {
    graph: &'a RowGraph,
    nodes: BTreeMap<u64, &'a RowNode>,
}
impl<'a> Census<'a> {
    fn new(graph: &'a RowGraph, pid: u32, window_id: u64) -> Result<Self, String> {
        if !graph.complete || graph.nodes.is_empty() || graph.nodes.len() > 2048 {
            return Err("row census incomplete".into());
        }
        let nodes: BTreeMap<_, _> = graph.nodes.iter().map(|n| (n.id, n)).collect();
        let c = Self { graph, nodes };
        if c.nodes.len() != graph.nodes.len()
            || c.node(graph.root)?.role != "AXWindow"
            || c.node(graph.root)?.parent.is_some()
        {
            return Err("invalid row census root/aliases".into());
        }
        for n in &graph.nodes {
            if n.pid != pid
                || n.window_id != window_id
                || n.error.is_some()
                || n.role.is_empty()
                || n.name.len() > 2048
                || n.value.as_ref().is_some_and(|v| v.len() > 2048)
                || n.children.len() > 2048
                || n.actions.len() > 64
            {
                return Err("row census peer unreadable or wrong owner".into());
            }
            if n.id != graph.root {
                c.ancestors(n.id)?;
            }
            for id in n
                .children
                .iter()
                .chain(n.rows.iter().flatten())
                .chain(n.columns.iter().flatten())
                .chain(n.header.iter())
            {
                c.node(*id)?;
            }
            // Every non-root object's actual parent must expose it. A column may
            // additionally expose the very same cell whose actual parent is a row.
            if let Some(p) = n.parent {
                if !c.node(p)?.children.contains(&n.id) {
                    return Err("row parent/child mismatch".into());
                }
            }
        }
        Ok(c)
    }
    fn node(&self, id: u64) -> Result<&'a RowNode, String> {
        self.nodes
            .get(&id)
            .copied()
            .ok_or_else(|| "row census missing reference".into())
    }
    fn ancestors(&self, id: u64) -> Result<Vec<u64>, String> {
        let mut out = Vec::new();
        let mut current = id;
        while current != self.graph.root {
            let parent = self
                .node(current)?
                .parent
                .ok_or("row ancestry ends before window")?;
            if out.len() >= 32 || out.contains(&parent) || parent == id {
                return Err("row ancestry cyclic/overlong".into());
            }
            out.push(parent);
            current = parent;
        }
        Ok(out)
    }
    fn unique(&self, ids: &[u64]) -> Vec<u64> {
        ids.iter()
            .copied()
            .collect::<BTreeSet<_>>()
            .into_iter()
            .collect()
    }
    fn text(&self, id: u64) -> Result<String, String> {
        let mut stack = vec![id];
        let mut seen = BTreeSet::new();
        let mut text = BTreeSet::new();
        while let Some(next) = stack.pop() {
            if !seen.insert(next) {
                continue;
            }
            if seen.len() > 64 {
                return Err("row cell text exceeds bound".into());
            }
            let n = self.node(next)?;
            if next != id && !matches!(n.role.as_str(), "AXStaticText" | "AXGroup" | "AXButton") {
                return Err("unsupported row cell content".into());
            }
            for value in [Some(&n.name), n.value.as_ref()].into_iter().flatten() {
                if !value.is_empty() {
                    text.insert(value.clone());
                }
            }
            for child in &n.children {
                if self.node(*child)?.parent != Some(next) {
                    return Err("cell text belongs to another parent".into());
                }
                stack.push(*child);
            }
        }
        if text.len() > 1 {
            return Err("row cell text is not singular".into());
        }
        Ok(text.into_iter().next().unwrap_or_default())
    }
    fn table(&self, id: u64) -> Result<(Vec<u64>, Vec<String>, Vec<u64>), String> {
        let n = self.node(id)?;
        if n.role != "AXTable" {
            return Err("row table missing".into());
        }
        let columns = n.columns.as_ref().ok_or("row columns unreadable")?;
        let rows = self.unique(n.rows.as_ref().ok_or("table rows unreadable")?);
        if columns.is_empty()
            || columns.len() > 64
            || rows.is_empty()
            || rows.len() > 256
            || self.unique(columns).len() != columns.len()
        {
            return Err("row table census invalid".into());
        }
        if self
            .nodes
            .values()
            .any(|p| p.parent == Some(n.id) && p.role == "AXColumn" && !columns.contains(&p.id))
        {
            return Err("omitted table column".into());
        }
        let mut headers = Vec::new();
        let mut header_rows = BTreeSet::new();
        for id in columns {
            let col = self.node(*id)?;
            if col.role != "AXColumn" || col.parent != Some(n.id) {
                return Err("column belongs to another table".into());
            }
            let header = col.header.ok_or("explicit column header absent")?;
            let cell = self.node(header)?;
            let parent = cell.parent.ok_or("header row absent")?;
            if cell.role != "AXCell"
                || self.node(parent)?.role != "AXRow"
                || self.node(parent)?.parent != Some(n.id)
                || !col.children.contains(&header)
            {
                return Err("header/cell relationship unqualified".into());
            }
            header_rows.insert(parent);
            headers.push(self.text(header)?);
            for cell_id in self.unique(&col.children) {
                let cell = self.node(cell_id)?;
                let row_id = cell.parent.ok_or("column cell row absent")?;
                if cell.role != "AXCell"
                    || self.node(row_id)?.role != "AXRow"
                    || self.node(row_id)?.parent != Some(n.id)
                    || (!rows.contains(&row_id) && row_id != parent)
                {
                    return Err("column cell escaped table row census".into());
                }
            }
        }
        if header_rows.len() != 1
            || headers
                .iter()
                .filter(|s| !s.is_empty())
                .collect::<BTreeSet<_>>()
                .len()
                != headers.iter().filter(|s| !s.is_empty()).count()
        {
            return Err("column headers ambiguous".into());
        }
        let data_rows: Vec<_> = rows
            .into_iter()
            .filter(|r| !header_rows.contains(r))
            .collect();
        if data_rows.is_empty() {
            return Err("no data rows".into());
        }
        // AXRows must cover every actual direct row, including hidden peers.
        for peer in self
            .nodes
            .values()
            .filter(|p| p.parent == Some(n.id) && p.role == "AXRow")
        {
            if !data_rows.contains(&peer.id) && !header_rows.contains(&peer.id) {
                return Err("omitted table row".into());
            }
        }
        for row in &data_rows {
            if self.node(*row)?.role != "AXRow" || self.node(*row)?.parent != Some(n.id) {
                return Err("wrong table row".into());
            }
        }
        Ok((columns.clone(), headers, data_rows))
    }
    fn qualify(&self, recipient: u64, key_column: &str) -> Result<RowBinding, String> {
        let action = self.node(recipient)?;
        if !matches!(action.role.as_str(), "AXButton" | "AXPopUpButton")
            || action.name.is_empty()
            || action.enabled != Some(true)
            || !action.actions.iter().any(|a| a == "AXPress")
        {
            return Err("row recipient does not offer enabled AXPress".into());
        }
        let ancestry = self.ancestors(recipient)?;
        let find = |role: &str| -> Result<u64, String> {
            let ids: Vec<_> = ancestry
                .iter()
                .filter(|id| self.nodes[id].role == role)
                .copied()
                .collect();
            if ids.len() != 1 {
                return Err(format!("row recipient lacks unique {role} ancestry"));
            }
            Ok(ids[0])
        };
        let row = find("AXRow")?;
        let table = find("AXTable")?;
        let document = find("AXWebArea")?;
        if self.node(row)?.parent != Some(table) {
            return Err("nested row/table ancestry".into());
        }
        let url = self
            .node(document)?
            .url
            .as_ref()
            .filter(|s| !s.is_empty())
            .ok_or("document URL absent")?;
        if self
            .nodes
            .values()
            .filter(|n| n.role == "AXWebArea" && n.url.as_ref() == Some(url))
            .count()
            != 1
        {
            return Err("document URL ambiguous".into());
        }
        let (cols, headers, rows) = self.table(table)?;
        if !rows.contains(&row) {
            return Err("recipient is outside data rows".into());
        }
        let keys: Vec<_> = headers
            .iter()
            .enumerate()
            .filter(|(_, h)| *h == key_column && !h.is_empty())
            .collect();
        if keys.len() != 1 {
            return Err("key column unqualified".into());
        }
        for peer in self
            .nodes
            .values()
            .filter(|n| n.role == "AXTable" && n.id != table)
        {
            if self.ancestors(peer.id)?.contains(&document) {
                // Unreadable peer tables cannot silently disappear from uniqueness.
                if self.table(peer.id)?.1 == headers {
                    return Err("table signature ambiguous".into());
                }
            }
        }
        let col = self.node(cols[keys[0].0])?;
        let mut values = BTreeSet::new();
        let mut selected = None;
        for id in rows {
            let cells: Vec<_> = self
                .unique(&self.node(id)?.children)
                .into_iter()
                .filter(|c| col.children.contains(c))
                .collect();
            if cells.len() != 1
                || self.node(cells[0])?.role != "AXCell"
                || self.node(cells[0])?.parent != Some(id)
            {
                return Err("key cell relationship ambiguous".into());
            }
            let value = self.text(cells[0])?;
            if value.is_empty() || !values.insert(value.clone()) {
                return Err("row key missing or duplicated".into());
            }
            if id == row {
                selected = Some((cells[0], value));
            }
        }
        let matching: Vec<_> = self
            .nodes
            .values()
            .filter(|n| n.role == action.role && n.name == action.name)
            .filter_map(|n| {
                self.ancestors(n.id)
                    .ok()
                    .filter(|a| a.contains(&row))
                    .map(|_| n.id)
            })
            .collect();
        if matching != [recipient] {
            return Err("row action is not unique".into());
        }
        let (key_cell, key_value) = selected.ok_or("key cell missing")?;
        let predicate = ExpectedRow {
            version: 1,
            pid: action.pid,
            window_id: action.window_id,
            document_url: url.clone(),
            table_headers: headers,
            key_column: key_column.into(),
            key_value,
            role: action.role.clone(),
            name: action.name.clone(),
            action: "AXPress".into(),
        };
        predicate.validate()?;
        Ok(RowBinding {
            predicate,
            window: self.graph.root,
            document,
            table,
            row,
            key_cell,
            key_column: col.id,
            header: col.header.ok_or("header absent")?,
            recipient,
        })
    }
}

pub fn qualify_row(
    graph: &RowGraph,
    pid: u32,
    window: u64,
    recipient: u64,
    key: &str,
) -> Result<RowBinding, String> {
    Census::new(graph, pid, window)?.qualify(recipient, key)
}
pub fn discover_row(
    graph: &RowGraph,
    pid: u32,
    window: u64,
    recipient: u64,
) -> Result<RowBinding, String> {
    let c = Census::new(graph, pid, window)?;
    let table = c
        .ancestors(recipient)?
        .into_iter()
        .find(|id| c.nodes[id].role == "AXTable")
        .ok_or("not a table action")?;
    for header in c.table(table)?.1 {
        if !header.is_empty() {
            if let Ok(binding) = c.qualify(recipient, &header) {
                return Ok(binding);
            }
        }
    }
    Err("no unambiguous named key column".into())
}

#[derive(Debug, Clone, Serialize, Deserialize, JsonSchema, PartialEq, Eq, uniffi::Record)]
#[serde(deny_unknown_fields)]
pub struct RowReceipt {
    pub version: u32,
    pub predicate: ExpectedRow,
    pub dispatched: bool,
    pub acknowledged: bool,
    pub delivered_count: u32,
    pub effect: String,
    pub error: Option<String>,
}
impl RowReceipt {
    pub fn validate(&self) -> Result<(), String> {
        self.predicate.validate()?;
        if self.version != 1
            || self.delivered_count != u32::from(self.acknowledged)
            || (!self.dispatched && (self.acknowledged || self.effect != "refused"))
            || (self.dispatched && self.effect != "unverifiable")
            || (self.acknowledged && self.error.is_some())
            || (!self.acknowledged && self.error.as_ref().is_none_or(|e| e.is_empty()))
        {
            return Err("inconsistent row dispatch receipt".into());
        }
        Ok(())
    }
}

/// Used by the native adapter and the offline fixture. The closure is the only
/// dispatch site. A returned AX error proves an attempt, not acknowledgement.
pub fn dispatch_row<A, F>(
    graph: Result<RowGraph, String>,
    binding: &RowBinding,
    expected: Option<&ExpectedRow>,
    pid: u32,
    window: u64,
    recipient: u64,
    admit: A,
    press: F,
) -> RowReceipt
where
    A: FnOnce() -> Result<(), String>,
    F: FnOnce() -> Result<(), String>,
{
    let mut receipt = RowReceipt {
        version: 1,
        predicate: binding.predicate.clone(),
        dispatched: false,
        acknowledged: false,
        delivered_count: 0,
        effect: "refused".into(),
        error: None,
    };
    let gate = (|| {
        let expected = expected.ok_or("row predicate required by snapshot")?;
        expected.validate()?;
        if expected != &binding.predicate
            || pid != expected.pid
            || window != expected.window_id
            || recipient != binding.recipient
        {
            return Err("row predicate differs from held recipient".into());
        }
        let current = qualify_row(&graph?, pid, window, recipient, &expected.key_column)?;
        if &current != binding {
            return Err("row predicate or held objects changed".into());
        }
        admit()
    })();
    if let Err(error) = gate {
        receipt.error = Some(error);
        return receipt;
    }
    receipt.dispatched = true;
    receipt.effect = "unverifiable".into();
    match press() {
        Ok(()) => {
            receipt.acknowledged = true;
            receipt.delivered_count = 1;
        }
        Err(error) => receipt.error = Some(error),
    }
    receipt
}

pub fn predicate_schema() -> serde_json::Value {
    serde_json::to_value(schemars::schema_for!(ExpectedRow)).expect("record schema serializes")
}
