//! Non-Linux stubs — return a helpful "not implemented" message.
//! Schemas match the macOS platform-macos implementations (cross-platform interface).

use async_trait::async_trait;
use cua_driver_core::{
    protocol::ToolResult,
    tool::{Tool, ToolDef},
};
use serde_json::Value;

fn not_impl(name: &str) -> ToolResult {
    ToolResult::error(format!(
        "{name}: Linux implementation is only available when compiled for Linux (target_os = \"linux\")."
    ))
}

macro_rules! stub_tool {
    ($mod_name:ident, $struct_name:ident, $tool_name:literal, $desc:expr, $schema:expr) => {
        mod $mod_name {
            use super::*;
            pub struct $struct_name;
            static DEF: std::sync::OnceLock<ToolDef> = std::sync::OnceLock::new();
            impl $struct_name {
                pub fn def_static() -> &'static ToolDef {
                    DEF.get_or_init(|| ToolDef {
                        name: $tool_name.into(),
                        description: $desc.into(),
                        input_schema: $schema,
                        read_only: false,
                        destructive: false,
                        idempotent: false,
                        open_world: false,
                    })
                }
            }
            #[async_trait]
            impl Tool for $struct_name {
                fn def(&self) -> &ToolDef {
                    Self::def_static()
                }
                async fn invoke(&self, _args: Value) -> ToolResult {
                    not_impl($tool_name)
                }
            }
        }
        pub use $mod_name::$struct_name;
    };
}

macro_rules! contract_stub_tool {
    ($mod_name:ident, $struct_name:ident, $tool_name:literal) => {
        mod $mod_name {
            use super::*;
            pub struct $struct_name;
            static DEF: std::sync::OnceLock<ToolDef> = std::sync::OnceLock::new();
            impl $struct_name {
                pub fn def_static() -> &'static ToolDef {
                    DEF.get_or_init(|| {
                        let contract = cua_driver_contract::tool_contract($tool_name)
                            .expect("canonical cursor contract exists");
                        ToolDef::from_contract(&contract)
                    })
                }
            }
            #[async_trait]
            impl Tool for $struct_name {
                fn def(&self) -> &ToolDef {
                    Self::def_static()
                }
                async fn invoke(&self, _args: Value) -> ToolResult {
                    not_impl($tool_name)
                }
            }
        }
        pub use $mod_name::$struct_name;
    };
}

stub_tool!(
    list_apps_m,
    ListAppsTool,
    "list_apps",
    "List running regular-UI applications.",
    serde_json::json!({"type":"object","properties":{},"additionalProperties":false})
);

stub_tool!(
    list_windows_m,
    ListWindowsTool,
    "list_windows",
    "List top-level windows, optionally filtered by pid.",
    serde_json::json!({"type":"object","properties":{"pid":{"type":"integer"}},"additionalProperties":false})
);

stub_tool!(
    get_window_state_m,
    GetWindowStateTool,
    "get_window_state",
    "Walk a running app's AT-SPI tree and return BOTH the element tree AND a \
     screenshot — ground on both and cross-check (the tree lies on some surfaces). \
     Choose the modality at ACTION time: an element ax action (element_token) or an \
     element px action (x,y) off the screenshot. capture_mode is deprecated and ignored.",
    serde_json::json!({"type":"object","required":["pid","window_id"],"properties":{"session": cua_driver_core::tool_schema::session_schema(),"pid":{"type":"integer"},"window_id":{"type":"integer"},"query":{"type":"string"},"include_screenshot":{"type":"boolean","description":"Default true — returns a grounding screenshot alongside the tree. Set false to skip the grab and return tree only (the cheap path for re-indexing before an element ax action)."},"capture_mode": cua_driver_core::capture_mode::capture_mode_schema()},"additionalProperties":false})
);

stub_tool!(
    launch_app_m,
    LaunchAppTool,
    "launch_app",
    "Launch an app in the background. Provide name or bundle_id.",
    serde_json::json!({"type":"object","properties":{"bundle_id":{"type":"string"},"name":{"type":"string"},"urls":{"type":"array","items":{"type":"string"}}},"additionalProperties":false})
);

stub_tool!(kill_app_m, KillAppTool, "kill_app",
    "Force-terminate a process by pid (taskkill /F on Windows, kill -9 on macOS / Linux). Use as escalation when the cooperative close path didn't make the process exit.",
    serde_json::json!({"type":"object","required":["pid"],"properties":{"pid":{"type":"integer","description":"PID of the process to terminate."}},"additionalProperties":false}));

stub_tool!(
    click_m,
    ClickTool,
    "click",
    "Click at (x, y) or on an AT-SPI element by element_token.",
    serde_json::json!({"type":"object","required":[],"properties":{"session": cua_driver_core::tool_schema::session_schema(),"pid":{"type":"integer"},"window_id":{"type":"integer"},"element_token": cua_driver_core::tool_schema::element_token_schema(),"x":{"type":"number"},"y":{"type":"number"},"modifier": cua_driver_core::tool_schema::modifier_schema(),"from_zoom":{"type":"boolean"}},"additionalProperties":false})
);

stub_tool!(
    double_click_m,
    DoubleClickTool,
    "double_click",
    "Double-click at (x, y) or on an AT-SPI element by element_token.",
    serde_json::json!({"type":"object","required":["pid"],"properties":{"session": cua_driver_core::tool_schema::session_schema(),"pid":{"type":"integer"},"x":{"type":"number"},"y":{"type":"number"},"window_id":{"type":"integer"},"element_token": cua_driver_core::tool_schema::element_token_schema()},"additionalProperties":false})
);

stub_tool!(
    right_click_m,
    RightClickTool,
    "right_click",
    "Right-click (AT-SPI action on element, or synthesized event at x,y).",
    serde_json::json!({"type":"object","required":["pid"],"properties":{"session": cua_driver_core::tool_schema::session_schema(),"pid":{"type":"integer"},"element_token": cua_driver_core::tool_schema::element_token_schema(),"window_id":{"type":"integer"},"x":{"type":"number"},"y":{"type":"number"},"modifier": cua_driver_core::tool_schema::modifier_schema()},"additionalProperties":false})
);

stub_tool!(
    type_text_m,
    TypeTextTool,
    "type_text",
    "Insert text into the target pid via AT-SPI SetTextContents or XSendEvent keystrokes.",
    serde_json::json!({"type":"object","required":["pid","text"],"properties":{"session": cua_driver_core::tool_schema::session_schema(),"pid":{"type":"integer"},"text":{"type":"string"},"element_token": cua_driver_core::tool_schema::element_token_schema(),"window_id":{"type":"integer"},"x":{"type":"number","description":"Screenshot-pixel X of the field to type into — the element px action form: pixel-click there to focus, then type. Pass with y, no element_token."},"y":{"type":"number","description":"Screenshot-pixel Y of the field (see x)."}},"additionalProperties":false})
);

stub_tool!(
    type_chars_m,
    TypeTextCharsTool,
    "type_text_chars",
    "Type text character-by-character with configurable per-character delay.",
    serde_json::json!({"type":"object","required":["pid","text"],"properties":{"pid":{"type":"integer"},"text":{"type":"string"},"delay_ms":{"type":"integer"},"window_id":{"type":"integer"},"element_token": cua_driver_core::tool_schema::element_token_schema()},"additionalProperties":false})
);

stub_tool!(
    press_key_m,
    PressKeyTool,
    "press_key",
    "Press and release a single key delivered directly to the target pid. No focus steal.",
    serde_json::json!({"type":"object","required":["pid","key"],"properties":{"session": cua_driver_core::tool_schema::session_schema(),"pid":{"type":"integer"},"key":{"type":"string"},"modifiers":{"type":"array","items":{"type":"string"}},"window_id":{"type":"integer"},"element_token": cua_driver_core::tool_schema::element_token_schema(),"x":{"type":"number","description":"Screenshot-pixel X — the element px action form: pixel-click there to focus, then send the key. Pass with y, no element_token."},"y":{"type":"number","description":"Screenshot-pixel Y (see x)."}},"additionalProperties":false})
);

stub_tool!(
    hotkey_m,
    HotkeyTool,
    "hotkey",
    "Press a combination of keys simultaneously, e.g. [\"ctrl\",\"c\"] for Copy.",
    serde_json::json!({"type":"object","required":["pid","keys"],"properties":{"session": cua_driver_core::tool_schema::session_schema(),"pid":{"type":"integer"},"keys":{"type":"array","items":{"type":"string"},"minItems":2},"x":{"type":"number","description":"Screenshot-pixel X — the element px action form: pixel-click there to focus, then send the combo. Pass with y."},"y":{"type":"number","description":"Screenshot-pixel Y (see x)."}},"additionalProperties":false})
);

stub_tool!(
    set_value_m,
    SetValueTool,
    "set_value",
    "Set the value of an AT-SPI element (text field, dropdown, checkbox).",
    serde_json::json!({"type":"object","required":["pid","value"],"properties":{"session": cua_driver_core::tool_schema::session_schema(),"pid":{"type":"integer"},"window_id":{"type":"integer"},"element_token": cua_driver_core::tool_schema::element_token_schema(),"value":{"type":"string"}},"additionalProperties":false})
);

stub_tool!(scroll_m, ScrollTool, "scroll",
    "Scroll the target pid's focused region. direction required; by defaults to line, amount defaults to 3.",
    serde_json::json!({"type":"object","required":["direction"],"properties":{"session": cua_driver_core::tool_schema::session_schema(),"cursor_id":{"type":"string"},"pid":{"type":"integer"},"direction":{"type":"string","enum":["up","down","left","right"]},"by":{"type":"string","enum":["line","page"]},"amount":{"type":"integer","minimum":1,"maximum":50},"window_id":{"type":"integer"},"element_token": cua_driver_core::tool_schema::element_token_schema()},"additionalProperties":false}));

stub_tool!(
    get_screen_size_m,
    GetScreenSizeTool,
    "get_screen_size",
    "Return the main screen's width and height in points.",
    serde_json::json!({"type":"object","properties":{},"additionalProperties":false})
);

stub_tool!(
    get_cursor_position_m,
    GetCursorPositionTool,
    "get_cursor_position",
    "Return the current real mouse cursor position.",
    serde_json::json!({"type":"object","properties":{},"additionalProperties":false})
);

contract_stub_tool!(
    cursor_enabled_v2_m,
    SetAgentCursorEnabledV2Tool,
    "set_agent_cursor_enabled"
);
contract_stub_tool!(
    cursor_motion_v2_m,
    SetAgentCursorMotionV2Tool,
    "set_agent_cursor_motion"
);
contract_stub_tool!(
    get_cursor_state_v2_m,
    GetAgentCursorStateV2Tool,
    "get_agent_cursor_state"
);
contract_stub_tool!(
    cursor_theme_m,
    SetAgentCursorThemeTool,
    "set_agent_cursor_theme"
);
pub struct InvokeMenuTool;

#[async_trait]
impl Tool for InvokeMenuTool {
    fn def(&self) -> &ToolDef {
        static DEF: std::sync::OnceLock<ToolDef> = std::sync::OnceLock::new();
        DEF.get_or_init(|| {
            // Menu schemas are portable subsets, not canonical runtime schemas.
            // Match the native menu definition without using the cursor bridge.
            let contract =
                cua_driver_contract::tool_contract("invoke_menu").expect("invoke_menu contract");
            ToolDef {
                name: contract.name,
                description: contract.description,
                input_schema: contract.input_schema,
                read_only: contract.annotations.read_only,
                destructive: contract.annotations.destructive,
                idempotent: contract.annotations.idempotent,
                open_world: contract.annotations.open_world,
            }
        })
    }

    async fn invoke(&self, _args: Value) -> ToolResult {
        not_impl("invoke_menu")
    }
}

stub_tool!(
    check_perms_m,
    CheckPermissionsTool,
    "check_permissions",
    "Check required permissions.",
    serde_json::json!({"type":"object","properties":{"prompt":{"type":"boolean"}},"additionalProperties":false})
);

stub_tool!(
    get_config_m,
    GetConfigTool,
    "get_config",
    "Return current cua-driver-rs configuration.",
    serde_json::json!({"type":"object","properties":{},"additionalProperties":false})
);

stub_tool!(
    set_config_m,
    SetConfigTool,
    "set_config",
    "Update cua-driver-rs configuration.",
    serde_json::json!({"type":"object","properties":{"capture_mode":{"type":"string","enum":["ax","vision"]},"max_image_dimension":{"type":"integer"}},"additionalProperties":false})
);

stub_tool!(get_ax_tree_m, GetAccessibilityTreeTool, "get_accessibility_tree",
    "Lightweight desktop snapshot: running apps and visible windows. For per-window AT-SPI tree, use get_window_state.",
    serde_json::json!({"type":"object","properties":{},"additionalProperties":false}));

stub_tool!(
    zoom_m,
    ZoomTool,
    "zoom",
    "Crop a window region to JPEG with 20% padding, max 500px wide.",
    serde_json::json!({"type":"object","required":["window_id","x1","y1","x2","y2"],"properties":{"window_id":{"type":"integer"},"x1":{"type":"number"},"y1":{"type":"number"},"x2":{"type":"number"},"y2":{"type":"number"},"pid":{"type":"integer"}},"additionalProperties":false})
);

// move_cursor and set_agent_cursor_enabled route through the overlay channel.

mod move_cursor_m {
    use super::*;
    pub struct MoveCursorTool;
    static DEF: std::sync::OnceLock<ToolDef> = std::sync::OnceLock::new();
    impl MoveCursorTool {
        pub fn def_static() -> &'static ToolDef {
            DEF.get_or_init(|| ToolDef {
                name: "move_cursor".into(),
                description: "Move the agent cursor overlay to (x, y). Does NOT move the real \
                    mouse cursor — the user's cursor stays where it is.".into(),
                input_schema: serde_json::json!({"type":"object","required":["x","y"],"properties":{"x":{"type":"number"},"y":{"type":"number"},"session": cua_driver_core::tool_schema::session_schema(),"cursor_id":{"type":"string"}},"additionalProperties":false}),
                read_only: false, destructive: false, idempotent: true, open_world: false,
            })
        }
    }
    #[async_trait]
    impl Tool for MoveCursorTool {
        fn def(&self) -> &ToolDef {
            Self::def_static()
        }
        async fn invoke(&self, args: Value) -> ToolResult {
            let x = args.get("x").and_then(|v| v.as_f64()).unwrap_or(0.0);
            let y = args.get("y").and_then(|v| v.as_f64()).unwrap_or(0.0);
            let cursor_id = args
                .get("cursor_id")
                .and_then(|v| v.as_str())
                .unwrap_or("default");
            crate::overlay::send_command(cursor_overlay::OverlayCommand::MoveTo {
                x,
                y,
                end_heading_radians: 0.0,
                target: None,
            });
            ToolResult::text(format!(
                "Agent cursor '{cursor_id}' moved to ({x:.1}, {y:.1})."
            ))
        }
    }
}
pub use move_cursor_m::MoveCursorTool;

pub fn build_registry() -> cua_driver_core::tool::ToolRegistry {
    let mut r = cua_driver_core::tool::ToolRegistry::new();
    r.register(Box::new(ListAppsTool));
    r.register(Box::new(ListWindowsTool));
    r.register(Box::new(GetWindowStateTool));
    r.register(Box::new(
        cua_driver_core::expectation::VerifyStateTool::new(std::sync::Arc::new(
            cua_driver_core::expectation::ToolObservationProvider::new(
                std::sync::Arc::new(ListWindowsTool),
                std::sync::Arc::new(GetWindowStateTool),
            ),
        )),
    ));
    r.register(Box::new(LaunchAppTool));
    r.register(Box::new(KillAppTool));
    r.register(Box::new(ClickTool));
    r.register(Box::new(DoubleClickTool));
    r.register(Box::new(RightClickTool));
    r.register(Box::new(TypeTextTool));
    r.register(Box::new(PressKeyTool));
    r.register(Box::new(HotkeyTool));
    r.register(Box::new(SetValueTool));
    r.register(Box::new(InvokeMenuTool));
    r.register(Box::new(ScrollTool));
    r.register(Box::new(GetScreenSizeTool));
    r.register(Box::new(GetCursorPositionTool));
    r.register(Box::new(MoveCursorTool));
    r.register(Box::new(SetAgentCursorEnabledV2Tool));
    r.register(Box::new(SetAgentCursorMotionV2Tool));
    r.register(Box::new(GetAgentCursorStateV2Tool));
    r.register(Box::new(SetAgentCursorThemeTool));
    r.register(Box::new(CheckPermissionsTool));
    // health_report is cross-platform — the Linux provider here lets
    // non-Linux hosts running the stubbed registry still advertise
    // the documented schema_version="1" contract.
    r.register(Box::new(
        cua_driver_core::health_report::HealthReportTool::new(std::sync::Arc::new(
            crate::health_report::LinuxHealthProvider,
        )),
    ));
    r.register(Box::new(GetConfigTool));
    r.register(Box::new(SetConfigTool));
    r.register(Box::new(GetAccessibilityTreeTool));
    r.register(Box::new(ZoomTool));
    // `type_text_chars` remains accepted as an invoke-time alias, but is not
    // advertised as a separate tool on any platform.
    let _: &TypeTextCharsTool = &TypeTextCharsTool;
    r.register_recording_tools();
    r.register_session_tools();
    r
}
