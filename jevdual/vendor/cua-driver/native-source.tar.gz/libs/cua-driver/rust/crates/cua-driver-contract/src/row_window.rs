//! Window membership over SDK-held canonical object identities, never coordinates.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum WindowReference {
    Direct(u64),
    NoValue,
}

pub trait WindowMembership {
    fn checkpoint(&mut self) -> Result<(), String>;
    fn pid(&mut self, id: u64) -> Result<u32, String>;
    fn window(&mut self, id: u64) -> Result<WindowReference, String>;
    fn parent(&mut self, id: u64) -> Result<u64, String>;
    fn children(&mut self, id: u64) -> Result<Vec<u64>, String>;
}

/// Direct window references keep their original requirement. Only NoValue invokes
/// the bounded parent proof. IDs denote SDK-held CFEqual-canonical references;
/// this proves membership within this census, not continuity across commands.
pub fn prove_window_member<P: WindowMembership>(
    p: &mut P,
    id: u64,
    root: u64,
    pid: u32,
) -> Result<bool, String> {
    p.checkpoint()?;
    if p.pid(id)? != pid {
        return Err("row peer PID mismatch".into());
    }
    p.checkpoint()?;
    match p.window(id)? {
        WindowReference::Direct(window) if window == root => {
            p.checkpoint()?;
            return Ok(false);
        }
        WindowReference::Direct(_) => return Err("row peer window mismatch".into()),
        WindowReference::NoValue => {}
    }
    let mut current = id;
    let mut seen = std::collections::BTreeSet::from([id]);
    // The existing row ancestry contract permits at most 32 parent edges.
    for _ in 0..32 {
        p.checkpoint()?;
        let parent = p.parent(current)?;
        if !seen.insert(parent) {
            return Err("row parent cycle".into());
        }
        p.checkpoint()?;
        if p.pid(parent)? != pid {
            return Err("row parent PID mismatch".into());
        }
        if parent != root {
            p.checkpoint()?;
            match p.window(parent)? {
                WindowReference::Direct(window) if window != root => {
                    return Err("row parent window mismatch".into())
                }
                WindowReference::Direct(_) | WindowReference::NoValue => {}
            }
        }
        p.checkpoint()?;
        let children = p.children(parent)?;
        let mut member = false;
        for child in children {
            p.checkpoint()?;
            member |= child == current;
        }
        if !member {
            return Err("row parent/child mismatch".into());
        }
        p.checkpoint()?;
        if parent == root {
            return Ok(true);
        }
        current = parent;
    }
    Err("row parent depth limit".into())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::BTreeMap;
    #[derive(Clone)]
    struct Node {
        pid: u32,
        window: Result<WindowReference, String>,
        parent: Result<u64, String>,
        children: Result<Vec<u64>, String>,
    }
    struct Fixture {
        nodes: BTreeMap<u64, Node>,
        budget: usize,
        reads: usize,
    }
    impl WindowMembership for Fixture {
        fn checkpoint(&mut self) -> Result<(), String> {
            if self.budget == 0 {
                return Err("row census equality budget".into());
            }
            self.budget -= 1;
            Ok(())
        }
        fn pid(&mut self, id: u64) -> Result<u32, String> {
            self.reads += 1;
            self.nodes
                .get(&id)
                .map(|n| n.pid)
                .ok_or("missing peer".into())
        }
        fn window(&mut self, id: u64) -> Result<WindowReference, String> {
            self.reads += 1;
            self.nodes.get(&id).ok_or("missing peer")?.window.clone()
        }
        fn parent(&mut self, id: u64) -> Result<u64, String> {
            self.reads += 1;
            self.nodes.get(&id).ok_or("missing peer")?.parent.clone()
        }
        fn children(&mut self, id: u64) -> Result<Vec<u64>, String> {
            self.reads += 1;
            self.nodes.get(&id).ok_or("missing peer")?.children.clone()
        }
    }
    fn fixture() -> Fixture {
        // Synthetic chain only. The live trace establishes NoValue, not this topology.
        Fixture {
            budget: 500000,
            reads: 0,
            nodes: [
                (
                    1,
                    Node {
                        pid: 77,
                        window: Ok(WindowReference::Direct(1)),
                        parent: Err("root".into()),
                        children: Ok(vec![2]),
                    },
                ),
                (
                    2,
                    Node {
                        pid: 77,
                        window: Ok(WindowReference::Direct(1)),
                        parent: Ok(1),
                        children: Ok(vec![6]),
                    },
                ),
                (
                    6,
                    Node {
                        pid: 77,
                        window: Ok(WindowReference::NoValue),
                        parent: Ok(2),
                        children: Ok(vec![]),
                    },
                ),
            ]
            .into_iter()
            .collect(),
        }
    }
    #[test]
    fn direct_window_unchanged() {
        let mut f = fixture();
        assert_eq!(prove_window_member(&mut f, 2, 1, 77), Ok(false));
        assert_eq!(f.reads, 2);
    }
    #[test]
    fn live_error_synthetic_chain_positive() {
        let mut f = fixture();
        assert_eq!(prove_window_member(&mut f, 6, 1, 77), Ok(true));
    }
    #[test]
    fn multiple_no_value_parents() {
        let mut f = fixture();
        f.nodes.get_mut(&2).unwrap().window = Ok(WindowReference::NoValue);
        assert_eq!(prove_window_member(&mut f, 6, 1, 77), Ok(true));
    }
    #[test]
    fn decisive_chain_refusals() {
        for fault in [
            "foreign",
            "ancestor_foreign",
            "pid",
            "root_pid",
            "missing_parent",
            "unreadable_parent",
            "cycle",
            "nonreciprocal",
            "children_error",
            "unsupported",
            "timeout",
            "budget",
        ] {
            let mut f = fixture();
            match fault {
                "foreign" => f.nodes.get_mut(&6).unwrap().window = Ok(WindowReference::Direct(99)),
                "ancestor_foreign" => {
                    f.nodes.get_mut(&2).unwrap().window = Ok(WindowReference::Direct(99))
                }
                "pid" => f.nodes.get_mut(&2).unwrap().pid = 78,
                "root_pid" => f.nodes.get_mut(&1).unwrap().pid = 78,
                "missing_parent" => f.nodes.get_mut(&6).unwrap().parent = Ok(99),
                "unreadable_parent" => {
                    f.nodes.get_mut(&6).unwrap().parent = Err("AXParent unreadable".into())
                }
                "cycle" => {
                    f.nodes.get_mut(&2).unwrap().parent = Ok(6);
                    f.nodes.get_mut(&6).unwrap().children = Ok(vec![2]);
                }
                "nonreciprocal" => f.nodes.get_mut(&2).unwrap().children = Ok(vec![]),
                "children_error" => {
                    f.nodes.get_mut(&2).unwrap().children = Err("AXChildren unreadable".into())
                }
                "unsupported" => {
                    f.nodes.get_mut(&6).unwrap().window = Err("AXWindow unreadable (-25205)".into())
                }
                "timeout" => {
                    f.nodes.get_mut(&6).unwrap().window = Err("AXWindow unreadable (-25204)".into())
                }
                "budget" => f.budget = 1,
                _ => unreachable!(),
            }
            assert!(prove_window_member(&mut f, 6, 1, 77).is_err(), "{fault}");
        }
    }
    #[test]
    fn existing_ancestry_bound_and_final_work_are_enforced() {
        for edges in [32, 33] {
            let mut f = fixture();
            f.nodes.clear();
            for id in 0..=edges {
                f.nodes.insert(
                    id,
                    Node {
                        pid: 77,
                        window: Ok(WindowReference::NoValue),
                        parent: if id == 0 {
                            Err("root".into())
                        } else {
                            Ok(id - 1)
                        },
                        children: Ok(if id == edges { vec![] } else { vec![id + 1] }),
                    },
                );
            }
            assert_eq!(
                prove_window_member(&mut f, edges, 0, 77).is_ok(),
                edges == 32
            );
        }
        let mut f = fixture();
        assert_eq!(prove_window_member(&mut f, 6, 1, 77), Ok(true));
        let charged = 500000 - f.budget;
        let mut f = fixture();
        f.budget = charged - 1;
        assert!(prove_window_member(&mut f, 6, 1, 77).is_err());
        let mut f = fixture();
        f.budget = charged;
        assert_eq!(prove_window_member(&mut f, 6, 1, 77), Ok(true));
    }
}
