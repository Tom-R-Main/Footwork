// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Cua AI, Inc.

//! Full-desktop foreground sentinel used by background E2E cells.

use std::fs;
use std::net::TcpListener;
use std::process::{Command, Stdio};
use std::time::{Duration, Instant};

use crate::e2e::OracleKind;
use crate::observer::{DesktopObserver, NativeObserver, TargetWindow};
use crate::{harness_app, spawn_in_job, BehaviorRecording, ChildReaper, Driver};

/// How late the sentinel's 100 ms main-process timer may tick before the
/// harness treats the sentinel as stalled. Its heartbeat and, on Linux, its
/// fullscreen state file both come from that timer, which runs late on a
/// loaded GPU-less runner.
pub(crate) const SENTINEL_TICK_LIVENESS: Duration = Duration::from_secs(2);

#[cfg(any(target_os = "linux", test))]
#[path = "sentinel_hyprland.rs"]
mod hyprland;

/// A foreground Electron window that journals focus and leaked input while it
/// fully occludes the background target.
pub struct ForegroundSentinel {
    cursor_calibrated: bool,
    evidence_dir: Option<std::path::PathBuf>,
    journal_path: std::path::PathBuf,
    target: TargetWindow,
    _reaper: ChildReaper,
    _user_data: tempfile::TempDir,
}

#[cfg(target_os = "linux")]
impl Drop for ForegroundSentinel {
    fn drop(&mut self) {
        crate::observer::linux::niri_register_sentinel(None);
    }
}

impl ForegroundSentinel {
    pub fn launch(driver: &mut impl Driver) -> Self {
        let mut last_error = None;
        for attempt in 1..=2 {
            match Self::try_launch(driver) {
                Ok(sentinel) => return sentinel,
                Err(error) => {
                    eprintln!(
                        "[testkit] foreground sentinel launch attempt {attempt}/2 failed: {error}"
                    );
                    last_error = Some(error);
                    if attempt < 2 {
                        std::thread::sleep(Duration::from_millis(300));
                    }
                }
            }
        }
        panic!(
            "could not launch foreground sentinel after bounded retry: {}",
            last_error.unwrap_or_else(|| "unknown launch error".to_owned())
        );
    }

    fn try_launch(driver: &mut impl Driver) -> Result<Self, String> {
        let electron = electron_fixture();
        if !electron.path.exists() {
            return Err(format!(
                "Electron sentinel fixture is missing at {}",
                electron.path.display()
            ));
        }
        let user_data = tempfile::Builder::new()
            .prefix("cua-e2e-sentinel-")
            .tempdir()
            .map_err(|error| format!("create sentinel user-data directory: {error}"))?;
        let journal_path = user_data.path().join("sentinel-events.jsonl");
        fs::write(&journal_path, "")
            .map_err(|error| format!("initialize sentinel event journal: {error}"))?;
        let cdp_port = TcpListener::bind(("127.0.0.1", 0))
            .and_then(|listener| listener.local_addr())
            .map_err(|error| format!("allocate sentinel CDP port: {error}"))?
            .port();
        let mut command = Command::new(&electron.path);
        command
            .args(&electron.args)
            .env("CUA_E2E_SENTINEL", "1")
            .env("CUA_E2E_SENTINEL_JOURNAL", &journal_path)
            .env(
                "CUA_E2E_SENTINEL_CONTROL",
                journal_path.with_extension("control.json"),
            )
            .env("CUA_E2E_USER_DATA_DIR", user_data.path())
            .env("CUA_ELECTRON_CDP_PORT", cdp_port.to_string())
            .stdout(Stdio::null())
            .stderr(Stdio::null());
        // Only the niri observer reads the fullscreen state file, so other
        // platforms never pay for the sentinel rewriting it every tick.
        #[cfg(target_os = "linux")]
        command.env(
            "CUA_E2E_SENTINEL_STATE",
            user_data.path().join("sentinel-state.json"),
        );
        let child = spawn_in_job(&mut command)
            .map_err(|error| format!("launch foreground sentinel: {error}"))?;
        let launched_pid = child.id();
        let mut reaper = ChildReaper::new();
        reaper.push(child);
        let expected_title = format!("CuaTestHarness Sentinel [cdp={cdp_port}]");

        let window_deadline = Instant::now() + Duration::from_secs(15);
        let target = loop {
            let windows = driver.call("list_windows", serde_json::json!({}));
            if let Some(target) = windows.structured()["windows"]
                .as_array()
                .and_then(|windows| {
                    windows.iter().find_map(|window| {
                        let id = window["window_id"].as_u64()?;
                        let title = window["title"].as_str().unwrap_or("");
                        title.contains(&expected_title).then(|| TargetWindow {
                            pid: window["pid"].as_u64().unwrap_or(launched_pid as u64) as u32,
                            native_id: id,
                        })
                    })
                })
            {
                assert_ne!(
                    target.pid, 0,
                    "foreground sentinel window has no process id"
                );
                break target;
            }
            if Instant::now() >= window_deadline {
                return Err("foreground sentinel window did not appear".to_owned());
            }
            std::thread::sleep(Duration::from_millis(100));
        };
        reaper.track_pid(target.pid);

        let focus_deadline = Instant::now() + Duration::from_secs(10);
        if is_wayland_session() {
            wait_for_journal(&journal_path, focus_deadline, r#""kind":"ready""#, "ready");
            #[cfg(target_os = "linux")]
            if hyprland::is_session() {
                target
                    .wait_for_hyprland_sentinel_geometry()
                    .map_err(|error| error.to_string())?;
            }
            activate_and_drain_setup_click(driver, target, &journal_path)?;
            // Electron may already be focused before its preload listener is ready.
            // The compositor observation is the authoritative Wayland focus gate.
            wait_for_native_focus_stable(target);
        } else {
            wait_for_journal(&journal_path, focus_deadline, r#""kind":"ready""#, "ready");
            activate_and_drain_setup_click(driver, target, &journal_path)?;
            wait_for_native_focus_stable(target);
            // On macOS the Electron renderer can report `document.hasFocus()`
            // as false at DOMContentLoaded, then become natively focused
            // without emitting a later DOM `focus` event. Require the setup
            // click below to reach the WebContents instead: that proves the
            // renderer is the input target before the journal is reset.
            #[cfg(not(target_os = "macos"))]
            wait_for_journal(&journal_path, focus_deadline, r#""kind":"focus""#, "focus");
            #[cfg(target_os = "macos")]
            wait_for_journal(
                &journal_path,
                focus_deadline,
                r#""kind":"click""#,
                "focused by setup click",
            );
        }
        let cursor_calibrated = !is_wayland_session();
        #[cfg(target_os = "linux")]
        let cursor_calibrated = if hyprland::is_session() {
            hyprland::calibrate(driver, target)?;
            true
        } else {
            cursor_calibrated
        };
        fs::write(&journal_path, "")
            .map_err(|error| format!("reset focused sentinel journal: {error}"))?;
        #[cfg(target_os = "linux")]
        crate::observer::linux::niri_register_sentinel(Some((
            target,
            user_data.path().join("sentinel-state.json"),
        )));

        Ok(Self {
            evidence_dir: None,
            cursor_calibrated,
            journal_path,
            target,
            _reaper: reaper,
            _user_data: user_data,
        })
    }

    pub fn observe(&self) -> (Vec<OracleKind>, Vec<String>) {
        std::thread::sleep(Duration::from_millis(200));
        let events = match read_journal_events(&self.journal_path) {
            Ok(events) => events,
            Err(error) => {
                return (
                    Vec::new(),
                    vec![format!("foreground sentinel journal is invalid: {error}")],
                )
            }
        };
        let mut passed = Vec::new();
        let mut violations = Vec::new();
        if !events
            .iter()
            .any(|event| event_kind(event) == Some("heartbeat"))
        {
            violations.push("foreground sentinel heartbeat stopped".to_owned());
        }
        if !is_wayland_session() {
            if events.iter().any(|event| {
                event_kind(event) == Some("blur")
                    || (event_kind(event) == Some("visibility")
                        && event["state"].as_str() == Some("hidden"))
            }) {
                violations.push("foreground sentinel lost focus".to_owned());
            } else {
                passed.push(OracleKind::Focus);
            }
        }
        let leaked = events
            .iter()
            .filter_map(|event| event_kind(event))
            .filter(|kind| {
                matches!(
                    *kind,
                    "keydown"
                        | "keyup"
                        | "pointerdown"
                        | "pointerup"
                        | "click"
                        | "wheel"
                        | "contextmenu"
                        | "input"
                )
            })
            .collect::<Vec<_>>();
        if leaked.is_empty() {
            passed.push(OracleKind::NoLeakedInput);
        } else {
            violations.push(format!(
                "foreground sentinel received input events: {}",
                leaked.join(", ")
            ));
        }
        (passed, violations)
    }

    /// Prove once per canonical lane that the foreground guard can detect both
    /// leaked input and transient focus loss. A guard that cannot observe its
    /// deliberate violations must never be trusted to certify background rows.
    pub fn assert_guard_canaries(
        &self,
        driver: &mut impl Driver,
        background_target: TargetWindow,
    ) -> Result<(), String> {
        wait_for_event(&self.journal_path, "heartbeat", SENTINEL_TICK_LIVENESS)?;
        reset_journal(&self.journal_path)?;

        let canary_key = if std::env::var("CUA_E2E_WAYLAND_SESSION")
            .is_ok_and(|session| session == "cua-compositor")
        {
            // The intentionally small injection protocol exposes navigation
            // and control keys, not printable letters. Space still exercises
            // the renderer keydown leak detector without broadening it.
            "space"
        } else {
            "a"
        };
        let leaked_key = driver.call(
            "press_key",
            serde_json::json!({
                "pid": self.target.pid,
                "window_id": self.target.native_id,
                "key": canary_key,
                "delivery_mode": "foreground",
            }),
        );
        if leaked_key.is_error() {
            return Err(format!(
                "foreground input canary could not inject a key: {}",
                leaked_key.text()
            ));
        }
        wait_for_event(&self.journal_path, "keydown", Duration::from_secs(2))?;
        let (_, leaked_input_violations) = self.observe();
        if !leaked_input_violations
            .iter()
            .any(|violation| violation.contains("received input events"))
        {
            return Err(format!(
                "foreground input canary was not detected: {leaked_input_violations:?}"
            ));
        }
        reset_journal(&self.journal_path)?;

        #[cfg(target_os = "linux")]
        set_sway_fullscreen(driver, self.target, false)?;
        raise_for_focus_canary(driver, background_target)?;
        #[cfg(target_os = "linux")]
        focus_sway_target(driver, background_target)?;
        #[cfg(target_os = "linux")]
        focus_niri_target(background_target)?;
        if is_wayland_session() {
            wait_for_native_focus_lost(self.target, background_target)?;
        } else {
            wait_for_event(&self.journal_path, "blur", Duration::from_secs(3))?;
            let (_, focus_violations) = self.observe();
            if !focus_violations
                .iter()
                .any(|violation| violation.contains("lost focus"))
            {
                return Err(format!(
                    "focus-loss canary was not detected: {focus_violations:?}"
                ));
            }
        }

        activate_and_drain_setup_click(driver, self.target, &self.journal_path)?;
        #[cfg(target_os = "linux")]
        set_sway_fullscreen(driver, self.target, true)?;
        wait_for_native_focus_stable(self.target);
        #[cfg(target_os = "linux")]
        if is_niri_session() {
            assert_niri_transient_focus_detected(self.target, background_target)?;
            wait_for_native_focus_stable(self.target);
        }
        std::thread::sleep(Duration::from_millis(150));
        reset_journal(&self.journal_path)?;
        wait_for_event(&self.journal_path, "heartbeat", SENTINEL_TICK_LIVENESS)?;
        reset_journal(&self.journal_path)?;
        self.assert_background_posture(background_target)
    }

    pub fn persist_evidence_to(&mut self, dir: &std::path::Path) {
        self.evidence_dir = Some(dir.to_owned());
    }

    pub fn target(&self) -> TargetWindow {
        self.target
    }

    /// Confirm the target is fully behind the ready foreground sentinel before
    /// the behavioral video boundary is crossed.
    pub fn assert_background_posture(&self, target: TargetWindow) -> Result<(), String> {
        let deadline = Instant::now() + Duration::from_secs(2);
        loop {
            let observer = DesktopObserver::new(NativeObserver::new(), target);
            let before = observer.snapshot().map_err(|error| error.to_string())?;
            if before.target_z == crate::observer::TargetZ::BackgroundOccluded {
                return Ok(());
            }
            if Instant::now() >= deadline {
                return Err(format!(
                    "background target was not fully occluded before recording: {:?}",
                    before.target_z
                ));
            }
            // Native maximize/fullscreen transitions can report focus before
            // their final geometry. This wait is outside the action boundary;
            // dispatch-time occlusion remains an immediate strict assertion.
            std::thread::sleep(Duration::from_millis(50));
        }
    }

    /// Re-establish the observation boundary after video capture starts.
    /// Capture backends may briefly perturb foreground state while they attach;
    /// those setup events are not part of the action under test.
    pub fn prepare_background_observation(
        &self,
        driver: &mut impl Driver,
        target: TargetWindow,
    ) -> Result<(), String> {
        activate_and_drain_setup_click(driver, self.target, &self.journal_path)?;
        wait_for_native_focus_stable(self.target);
        std::thread::sleep(Duration::from_millis(100));
        reset_journal(&self.journal_path)?;
        // This heartbeat checks liveness only. Windows setup input has already
        // crossed its explicit renderer/main journal barrier before the reset.
        wait_for_event(&self.journal_path, "heartbeat", SENTINEL_TICK_LIVENESS)?;
        reset_journal(&self.journal_path)?;
        self.assert_background_posture(target)
    }

    /// Run one background action while checking the native desktop and the
    /// sentinel journal. The returned oracle list is suitable for a typed E2E
    /// result; any unsupported observation or side effect is an error.
    pub fn observe_background<R>(
        &self,
        target: TargetWindow,
        action: impl FnOnce() -> R,
    ) -> Result<(R, Vec<OracleKind>), String> {
        self.observe_target(target, true, NativeObserver::new(), action)
    }

    /// Observe a desktop-wide action against the foreground sentinel itself.
    /// Launch and cursor-overlay cells have no pre-existing background target,
    /// so they verify desktop stability without the target-occlusion precondition.
    pub fn observe_desktop<R>(
        &self,
        action: impl FnOnce() -> R,
    ) -> Result<(R, Vec<OracleKind>), String> {
        self.observe_target(self.target, false, NativeObserver::new(), action)
    }

    fn observe_target<R>(
        &self,
        target: TargetWindow,
        require_occluded_target: bool,
        backend: impl crate::observer::ObserverBackend,
        action: impl FnOnce() -> R,
    ) -> Result<(R, Vec<OracleKind>), String> {
        let mut native_evidence = String::new();
        let outcome = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            let mut observer = DesktopObserver::new(backend, target);
            let before = observer.snapshot().map_err(|error| error.to_string())?;
            native_evidence = format!("{before:#?}");
            if require_occluded_target
                && before.target_z != crate::observer::TargetZ::BackgroundOccluded
            {
                return Err(format!(
                    "background target was not fully occluded before dispatch: {:?}",
                    before.target_z
                ));
            }
            let mut native_oracles = vec![OracleKind::Focus, OracleKind::ZOrder];
            if self.cursor_calibrated {
                native_oracles.push(OracleKind::Cursor);
            }
            let (result, delta) = observer
                .observe(&native_oracles, action)
                .map_err(|error| error.to_string())?;
            native_evidence = format!("{delta:#?}");
            if require_occluded_target
                && delta.before.target_z != crate::observer::TargetZ::BackgroundOccluded
            {
                return Err(format!(
                    "background target was not fully occluded at dispatch: {:?}",
                    delta.before.target_z
                ));
            }
            delta
                .ensure_supported()
                .map_err(|error| error.to_string())?;

            let mut passed = delta.passed().to_vec();
            let mut violations = delta.violations().to_vec();
            let (sentinel_passed, sentinel_violations) = self.observe();
            passed.extend(sentinel_passed);
            violations.extend(sentinel_violations);
            passed.sort();
            passed.dedup();
            if violations.is_empty() {
                Ok((result, passed))
            } else {
                Err(violations.join("; "))
            }
        }));
        if let Some(dir) = &self.evidence_dir {
            fs::create_dir_all(dir).map_err(|error| error.to_string())?;
            fs::copy(&self.journal_path, dir.join("sentinel-events.jsonl"))
                .map_err(|error| error.to_string())?;
            match &outcome {
                Ok(Err(error)) => native_evidence.push_str(&format!("\nERROR: {error}\n")),
                Err(_) => native_evidence.push_str("\nERROR: action panicked\n"),
                _ => {}
            }
            fs::write(dir.join("desktop-observation.txt"), native_evidence)
                .map_err(|error| error.to_string())?;
        }
        match outcome {
            Ok(result) => result,
            Err(payload) => std::panic::resume_unwind(payload),
        }
    }
}

fn wait_for_journal(path: &std::path::Path, deadline: Instant, marker: &str, state: &str) {
    loop {
        let journal = fs::read_to_string(path).unwrap_or_default();
        if journal.contains(marker) {
            return;
        }
        assert!(
            Instant::now() < deadline,
            "foreground sentinel did not become {state}: {journal}"
        );
        std::thread::sleep(Duration::from_millis(100));
    }
}

fn reset_journal(path: &std::path::Path) -> Result<(), String> {
    fs::write(path, "").map_err(|error| format!("reset foreground sentinel journal: {error}"))
}

fn read_journal_events(path: &std::path::Path) -> Result<Vec<serde_json::Value>, String> {
    let journal =
        fs::read_to_string(path).map_err(|error| format!("read {}: {error}", path.display()))?;
    journal
        .lines()
        .filter(|line| !line.trim().is_empty())
        .map(|line| {
            serde_json::from_str(line)
                .map_err(|error| format!("parse sentinel event {line:?}: {error}"))
        })
        .collect()
}

fn event_kind(event: &serde_json::Value) -> Option<&str> {
    event["kind"].as_str()
}

fn wait_for_event(path: &std::path::Path, kind: &str, timeout: Duration) -> Result<(), String> {
    let deadline = Instant::now() + timeout;
    loop {
        let events = read_journal_events(path)?;
        if events.iter().any(|event| event_kind(event) == Some(kind)) {
            return Ok(());
        }
        if Instant::now() >= deadline {
            return Err(format!(
                "foreground sentinel did not emit {kind:?} within {timeout:?}: {events:?}"
            ));
        }
        std::thread::sleep(Duration::from_millis(25));
    }
}

fn is_wayland_session() -> bool {
    cfg!(target_os = "linux")
        && std::env::var("XDG_SESSION_TYPE")
            .is_ok_and(|session| session.eq_ignore_ascii_case("wayland"))
}

fn activate_and_drain_setup_click(
    driver: &mut impl Driver,
    target: TargetWindow,
    _journal_path: &std::path::Path,
) -> Result<(), String> {
    #[cfg(target_os = "windows")]
    let token = {
        use std::sync::atomic::{AtomicU64, Ordering};
        static NEXT_TOKEN: AtomicU64 = AtomicU64::new(1);
        let token = NEXT_TOKEN.fetch_add(1, Ordering::Relaxed).to_string();
        fs::write(
            _journal_path.with_extension("control.json"),
            serde_json::json!({ "token": token }).to_string(),
        )
        .map_err(|error| format!("arm sentinel setup click: {error}"))?;
        wait_for_setup_click_marker(_journal_path, "setup-click-armed", &token)?;
        token
    };
    try_activate_native_foreground(driver, target)?;
    #[cfg(target_os = "windows")]
    wait_for_setup_click_marker(_journal_path, "setup-click-drained", &token)?;
    Ok(())
}

#[cfg(target_os = "windows")]
fn wait_for_setup_click_marker(
    path: &std::path::Path,
    kind: &str,
    token: &str,
) -> Result<(), String> {
    let deadline = Instant::now() + Duration::from_secs(3);
    loop {
        let events = read_journal_events(path)?;
        if events
            .iter()
            .any(|event| event_kind(event) == Some(kind) && event["token"].as_str() == Some(token))
        {
            return Ok(());
        }
        if Instant::now() >= deadline {
            return Err(format!(
                "sentinel setup barrier {kind:?} token {token:?} timed out: {events:?}"
            ));
        }
        std::thread::sleep(Duration::from_millis(25));
    }
}

fn raise_for_focus_canary(driver: &mut impl Driver, target: TargetWindow) -> Result<(), String> {
    #[cfg(target_os = "linux")]
    if hyprland::is_session() {
        return hyprland::activate(driver, target).map_err(|error| {
            format!("Hyprland focus-loss canary could not raise target over fullscreen sentinel: {error}")
        });
    }
    let raised = driver.call(
        "bring_to_front",
        serde_json::json!({ "pid": target.pid, "window_id": target.native_id }),
    );
    if raised.is_error() {
        return Err(format!(
            "focus-loss canary could not raise the background target: {}",
            raised.text()
        ));
    }
    Ok(())
}

fn try_activate_native_foreground(
    driver: &mut impl Driver,
    target: TargetWindow,
) -> Result<(), String> {
    #[cfg(target_os = "linux")]
    if hyprland::is_session() {
        return hyprland::activate(driver, target);
    }
    let response = driver.call(
        "bring_to_front",
        serde_json::json!({
            "pid": target.pid,
            "window_id": target.native_id,
        }),
    );
    if response.is_error() {
        return Err(format!(
            "{}; activation_observation={}",
            response.text(),
            response.structured()
        ));
    }
    #[cfg(target_os = "linux")]
    focus_sway_target(driver, target).map_err(|error| {
        format!("could not focus foreground sentinel through Sway IPC: {error}")
    })?;
    #[cfg(target_os = "linux")]
    focus_niri_target(target).map_err(|error| {
        format!("could not focus foreground sentinel through niri IPC: {error}")
    })?;
    #[cfg(target_os = "windows")]
    physically_focus_windows_sentinel(target);
    #[cfg(target_os = "macos")]
    focus_macos_sentinel_contents(driver, target)?;
    Ok(())
}

#[cfg(target_os = "macos")]
fn focus_macos_sentinel_contents(
    driver: &mut impl Driver,
    _target: TargetWindow,
) -> Result<(), String> {
    // A native app activation can leave Electron's renderer without keyboard
    // focus even though WindowServer reports its window at the front. This
    // bounded desktop-HID setup click lands in the already-proven foreground
    // window and is cleared from the journal before any behavioral action
    // begins. Do not use the pid-routed path here: reaching foreground
    // Chromium WebContents is the setup condition, not the behavior under test.
    let response = driver.call(
        "click",
        serde_json::json!({
            "x": 320.0,
            "y": 240.0,
            "scope": "desktop",
        }),
    );
    if response.is_error() {
        return Err(format!(
            "could not focus foreground sentinel WebContents: {}",
            response.text()
        ));
    }
    Ok(())
}

#[cfg(target_os = "linux")]
fn focus_sway_target(driver: &mut impl Driver, target: TargetWindow) -> Result<(), String> {
    let is_sway = is_wayland_session()
        && std::env::var("CUA_E2E_WAYLAND_SESSION").is_ok_and(|session| session == "sway");
    if !is_sway {
        return Ok(());
    }

    let (_, con_id) = sway_tree_and_container_for_target(driver, target)?;
    run_sway_container_command(con_id, &["focus"], "focus canary")
}

/// niri's focus oracle must see a focus that leaves the sentinel and returns
/// inside one observation, where both endpoint snapshots agree. Only the
/// action-time journal can report it.
#[cfg(target_os = "linux")]
fn assert_niri_transient_focus_detected(
    sentinel: TargetWindow,
    background: TargetWindow,
) -> Result<(), String> {
    use crate::observer::linux::{niri_focus, niri_wait_for_focus_transfer};

    let mut observer = DesktopObserver::new(NativeObserver::new(), background);
    let (moved, delta) = observer
        .observe(&[OracleKind::Focus], || {
            niri_focus(background)?;
            niri_wait_for_focus_transfer(sentinel, background)?;
            niri_focus(sentinel)?;
            niri_wait_for_focus_transfer(background, sentinel)
        })
        .map_err(|error| error.to_string())?;
    moved.map_err(|error| format!("niri transient focus canary could not move focus: {error}"))?;
    if delta.before.foreground != delta.after.foreground
        || !delta
            .violations()
            .iter()
            .any(|violation| violation.contains("changed transiently"))
    {
        return Err(format!(
            "niri transient focus canary was not detected: {:?}",
            delta.violations()
        ));
    }
    Ok(())
}

#[cfg(target_os = "linux")]
fn is_niri_session() -> bool {
    is_wayland_session()
        && std::env::var("CUA_E2E_WAYLAND_SESSION").is_ok_and(|session| session == "niri")
}

/// niri shows a focused floating window above the fullscreen sentinel, so the
/// niri canary needs no fullscreen toggle, only the compositor's own focus.
#[cfg(target_os = "linux")]
fn focus_niri_target(target: TargetWindow) -> Result<(), String> {
    if !is_niri_session() {
        return Ok(());
    }
    crate::observer::linux::niri_focus(target).map_err(|error| error.to_string())
}

#[cfg(target_os = "linux")]
fn set_sway_fullscreen(
    driver: &mut impl Driver,
    target: TargetWindow,
    enabled: bool,
) -> Result<(), String> {
    let is_sway = is_wayland_session()
        && std::env::var("CUA_E2E_WAYLAND_SESSION").is_ok_and(|session| session == "sway");
    if !is_sway {
        return Ok(());
    }

    let (tree, view_id) = sway_tree_and_container_for_target(driver, target)?;
    let con_id = if enabled {
        view_id
    } else {
        sway_fullscreen_holder_id(&tree, view_id).unwrap_or(view_id)
    };
    let state = if enabled { "enable" } else { "disable" };
    run_sway_container_command(con_id, &["fullscreen", state], "fullscreen canary")?;
    if !enabled {
        wait_for_sway_fullscreen_cleared(view_id)?;
    }
    Ok(())
}

#[cfg(target_os = "linux")]
fn sway_tree_and_container_for_target(
    driver: &mut impl Driver,
    target: TargetWindow,
) -> Result<(serde_json::Value, i64), String> {
    let tree = read_sway_tree()?;

    let windows = driver.call("list_windows", serde_json::json!({}));
    if windows.is_error() {
        return Err(format!(
            "list windows before Sway focus canary: {}",
            windows.text()
        ));
    }
    let title = sway_target_title(windows.structured(), target);
    let con_id = title
        .and_then(|title| sway_container_id(&tree, title))
        .or_else(|| sway_container_id_by_unique_pid(&tree, target.pid))
        .ok_or_else(|| {
            format!(
                "Sway focus canary could not resolve container for pid {} window {}",
                target.pid, target.native_id
            )
        })?;
    Ok((tree, con_id))
}

#[cfg(target_os = "linux")]
fn read_sway_tree() -> Result<serde_json::Value, String> {
    let tree_output = Command::new("swaymsg")
        .args(["-r", "-t", "get_tree"])
        .output()
        .map_err(|error| format!("read Sway tree for focus canary: {error}"))?;
    if !tree_output.status.success() {
        return Err(format!(
            "read Sway tree for focus canary: {}",
            String::from_utf8_lossy(&tree_output.stderr).trim()
        ));
    }
    serde_json::from_slice(&tree_output.stdout)
        .map_err(|error| format!("parse Sway tree for focus canary: {error}"))
}

#[cfg(target_os = "linux")]
fn sway_path_to_container<'a>(
    node: &'a serde_json::Value,
    con_id: i64,
    path: &mut Vec<&'a serde_json::Value>,
) -> bool {
    path.push(node);
    if node["id"].as_i64() == Some(con_id) {
        return true;
    }
    for key in ["nodes", "floating_nodes"] {
        if let Some(children) = node[key].as_array() {
            for child in children {
                if sway_path_to_container(child, con_id, path) {
                    return true;
                }
            }
        }
    }
    path.pop();
    false
}

#[cfg(target_os = "linux")]
fn sway_fullscreen_holder_id(tree: &serde_json::Value, view_id: i64) -> Option<i64> {
    let mut path = Vec::new();
    sway_path_to_container(tree, view_id, &mut path).then_some(())?;
    path.into_iter()
        .rev()
        .find(|node| node["fullscreen_mode"].as_i64().unwrap_or(0) != 0)
        .and_then(|node| node["id"].as_i64())
}

#[cfg(target_os = "linux")]
fn sway_container_fullscreen_mode(tree: &serde_json::Value, con_id: i64) -> Option<i64> {
    if tree["id"].as_i64() == Some(con_id) {
        return Some(tree["fullscreen_mode"].as_i64().unwrap_or(0));
    }
    ["nodes", "floating_nodes"].into_iter().find_map(|key| {
        tree[key].as_array().and_then(|children| {
            children
                .iter()
                .find_map(|child| sway_container_fullscreen_mode(child, con_id))
        })
    })
}

#[cfg(target_os = "linux")]
fn wait_for_sway_fullscreen_cleared(view_id: i64) -> Result<(), String> {
    let deadline = Instant::now() + Duration::from_secs(1);
    loop {
        let tree = read_sway_tree()?;
        let fullscreen_mode = sway_container_fullscreen_mode(&tree, view_id)
            .ok_or_else(|| format!("Sway fullscreen canary lost view {view_id}"))?;
        if fullscreen_mode == 0 {
            return Ok(());
        }
        if Instant::now() >= deadline {
            return Err(format!(
                "Sway fullscreen canary did not clear fullscreen mode {fullscreen_mode} for view {view_id}"
            ));
        }
        std::thread::sleep(Duration::from_millis(25));
    }
}

#[cfg(target_os = "linux")]
fn run_sway_container_command(con_id: i64, command: &[&str], purpose: &str) -> Result<(), String> {
    let criterion = format!("[con_id={con_id}]");
    let output = Command::new("swaymsg")
        .arg("-r")
        .arg(criterion.as_str())
        .args(command)
        .output()
        .map_err(|error| format!("run Sway {purpose} for con_id {con_id}: {error}"))?;
    let result: serde_json::Value = serde_json::from_slice(&output.stdout)
        .map_err(|error| format!("parse Sway {purpose} result for con_id {con_id}: {error}"))?;
    let succeeded = output.status.success()
        && result.as_array().is_some_and(|results| {
            !results.is_empty() && results.iter().all(|item| item["success"] == true)
        });
    if !succeeded {
        Err(format!(
            "Sway {purpose} for con_id {con_id} failed: stdout={} stderr={}",
            String::from_utf8_lossy(&output.stdout).trim(),
            String::from_utf8_lossy(&output.stderr).trim(),
        ))
    } else {
        if std::env::var_os("CUA_E2E_DEBUG_SWAY").is_some() {
            let tree = read_sway_tree()?;
            let mut rows = Vec::new();
            collect_sway_debug_rows(&tree, &mut rows);
            eprintln!(
                "[testkit] Sway {purpose}: con_id={con_id} command={command:?} tree={rows:?}"
            );
        }
        Ok(())
    }
}

#[cfg(target_os = "linux")]
fn collect_sway_debug_rows(node: &serde_json::Value, rows: &mut Vec<String>) {
    let focused = node["focused"].as_bool().unwrap_or(false);
    let fullscreen = node["fullscreen_mode"].as_i64().unwrap_or(0);
    if focused || fullscreen != 0 || node["pid"].as_u64().is_some() {
        rows.push(format!(
            "id={} pid={} name={:?} focused={focused} fullscreen={fullscreen}",
            node["id"].as_i64().unwrap_or_default(),
            node["pid"].as_u64().unwrap_or_default(),
            node["name"].as_str().unwrap_or("")
        ));
    }
    for key in ["nodes", "floating_nodes"] {
        if let Some(children) = node[key].as_array() {
            for child in children {
                collect_sway_debug_rows(child, rows);
            }
        }
    }
}

#[cfg(target_os = "linux")]
fn sway_target_title(windows: &serde_json::Value, target: TargetWindow) -> Option<&str> {
    let windows = windows["windows"].as_array()?;
    windows
        .iter()
        .find(|window| {
            window["pid"].as_u64() == Some(target.pid as u64)
                && window["window_id"].as_u64() == Some(target.native_id)
        })
        .and_then(|window| window["title"].as_str())
        .or_else(|| {
            let mut titles = windows
                .iter()
                .filter(|window| window["pid"].as_u64() == Some(target.pid as u64))
                .filter_map(|window| window["title"].as_str())
                .filter(|title| !title.is_empty());
            let title = titles.next()?;
            titles.next().is_none().then_some(title)
        })
}

#[cfg(target_os = "linux")]
fn collect_sway_container_ids_by_pid(node: &serde_json::Value, pid: u32, ids: &mut Vec<i64>) {
    if node["pid"].as_u64() == Some(pid as u64) {
        if let Some(id) = node["id"].as_i64() {
            ids.push(id);
        }
    }
    for key in ["nodes", "floating_nodes"] {
        if let Some(children) = node[key].as_array() {
            for child in children {
                collect_sway_container_ids_by_pid(child, pid, ids);
            }
        }
    }
}

#[cfg(target_os = "linux")]
fn sway_container_id_by_unique_pid(node: &serde_json::Value, pid: u32) -> Option<i64> {
    let mut ids = Vec::new();
    collect_sway_container_ids_by_pid(node, pid, &mut ids);
    (ids.len() == 1).then(|| ids[0])
}

#[cfg(target_os = "linux")]
fn sway_container_id(node: &serde_json::Value, title: &str) -> Option<i64> {
    let raw_title = title
        .rsplit_once(" [")
        .map(|(candidate, _)| candidate)
        .unwrap_or(title);
    if node["name"]
        .as_str()
        .is_some_and(|name| name == title || name == raw_title)
    {
        return node["id"].as_i64();
    }
    ["nodes", "floating_nodes"].into_iter().find_map(|key| {
        node[key].as_array().and_then(|children| {
            children
                .iter()
                .find_map(|child| sway_container_id(child, title))
        })
    })
}

#[cfg(all(test, target_os = "linux"))]
mod sway_tests {
    use super::*;

    #[test]
    fn observation_evidence_survives_violations_and_unsupported_oracles() {
        use crate::observer::*;
        struct Backend(bool);
        impl ObserverBackend for Backend {
            fn capabilities(&self) -> ObserverCapabilities {
                ObserverCapabilities {
                    focus: self.0,
                    z_order: true,
                    cursor: true,
                    leaked_input: true,
                }
            }
            fn snapshot(&self, _: TargetWindow) -> Result<DesktopSnapshot, ObserverError> {
                Ok(DesktopSnapshot {
                    foreground: Some(1),
                    input_focus: Some(1),
                    target_z: TargetZ::BackgroundOccluded,
                    cursor_pos: Some((2.0, 3.0)),
                })
            }
            fn start_journal(&mut self) -> Result<(), ObserverError> {
                Ok(())
            }
            fn drain_journal(&mut self) -> Result<DesktopJournal, ObserverError> {
                Ok(DesktopJournal {
                    focus_events: vec![FocusEvent {
                        from: Some(1),
                        to: Some(2),
                    }],
                    leaked_input_events: vec![],
                })
            }
        }
        for supported in [true, false] {
            let scratch = tempfile::tempdir().unwrap();
            let evidence = tempfile::tempdir().unwrap();
            let journal = scratch.path().join("sentinel-events.jsonl");
            fs::write(&journal, "{\"kind\":\"heartbeat\"}\n").unwrap();
            let target = TargetWindow {
                pid: 10,
                native_id: 20,
            };
            let mut sentinel = ForegroundSentinel {
                cursor_calibrated: true,
                journal_path: journal,
                target,
                _reaper: ChildReaper::new(),
                _user_data: scratch,
                evidence_dir: None,
            };
            sentinel.persist_evidence_to(evidence.path());
            let result = sentinel.observe_target(target, true, Backend(supported), || ());
            let error = result.unwrap_err();
            assert!(error.contains(if supported {
                "transiently"
            } else {
                "does not support"
            }));
            drop(sentinel);
            assert!(
                fs::read_to_string(evidence.path().join("sentinel-events.jsonl"))
                    .unwrap()
                    .contains("heartbeat")
            );
            let native =
                fs::read_to_string(evidence.path().join("desktop-observation.txt")).unwrap();
            assert!(native.contains("cursor_pos"));
            assert!(native.contains("focus_events"));
            assert!(native.contains(&error));
        }
    }

    #[test]
    fn fullscreen_command_targets_the_holder_ancestor() {
        let tree = serde_json::json!({
            "id": 1,
            "nodes": [{
                "id": 30,
                "fullscreen_mode": 1,
                "nodes": [{
                    "id": 31,
                    "pid": 1234,
                    "name": "CuaTestHarness Sentinel",
                    "focused": true,
                    "fullscreen_mode": 0
                }]
            }]
        });
        assert_eq!(sway_fullscreen_holder_id(&tree, 31), Some(30));
    }

    #[test]
    fn fullscreen_command_prefers_the_actionable_view() {
        let tree = serde_json::json!({
            "id": 1,
            "fullscreen_mode": 1,
            "nodes": [{
                "id": 30,
                "fullscreen_mode": 1,
                "nodes": [{
                    "id": 31,
                    "pid": 1234,
                    "name": "CuaTestHarness Sentinel",
                    "focused": true,
                    "fullscreen_mode": 1
                }]
            }]
        });
        assert_eq!(sway_fullscreen_holder_id(&tree, 31), Some(31));
    }

    #[test]
    fn fullscreen_clear_checks_the_view_not_inherited_workspace_state() {
        let tree = serde_json::json!({
            "id": 1,
            "fullscreen_mode": 1,
            "nodes": [{
                "id": 30,
                "fullscreen_mode": 1,
                "nodes": [{
                    "id": 31,
                    "pid": 1234,
                    "name": "CuaTestHarness Sentinel",
                    "focused": true,
                    "fullscreen_mode": 0
                }]
            }]
        });
        assert_eq!(sway_container_fullscreen_mode(&tree, 31), Some(0));
    }

    #[test]
    fn focus_target_uses_unique_sway_pid_when_title_is_unavailable() {
        let tree = serde_json::json!({
            "id": 1,
            "nodes": [{
                "id": 9,
                "nodes": [{
                    "id": 42,
                    "pid": 1234,
                    "name": "CuaTestHarness Electron"
                }]
            }]
        });
        assert_eq!(sway_container_id_by_unique_pid(&tree, 1234), Some(42));
    }

    #[test]
    fn focus_target_does_not_guess_when_pid_owns_multiple_windows() {
        let tree = serde_json::json!({
            "id": 1,
            "nodes": [
                {"id": 41, "pid": 1234, "name": "First"},
                {"id": 42, "pid": 1234, "name": "Second"}
            ]
        });
        assert_eq!(sway_container_id_by_unique_pid(&tree, 1234), None);
        assert_eq!(sway_container_id(&tree, "Second"), Some(42));
    }

    #[test]
    fn focus_target_uses_unique_same_process_title_when_window_id_changes() {
        let windows = serde_json::json!({
            "windows": [{
                "pid": 1234,
                "window_id": 88,
                "title": "CuaTestHarness Electron [cdp=9223]"
            }]
        });
        let target = TargetWindow {
            pid: 1234,
            native_id: 99,
        };
        assert_eq!(
            sway_target_title(&windows, target),
            Some("CuaTestHarness Electron [cdp=9223]")
        );
    }
}

#[cfg(target_os = "windows")]
fn physically_focus_windows_sentinel(target: TargetWindow) {
    use windows::Win32::Foundation::{HWND, POINT, RECT};
    use windows::Win32::UI::Input::KeyboardAndMouse::{
        SendInput, INPUT, INPUT_0, INPUT_MOUSE, MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP,
        MOUSEINPUT,
    };
    use windows::Win32::UI::WindowsAndMessaging::{GetCursorPos, GetWindowRect, SetCursorPos};

    let hwnd = HWND(target.native_id as *mut _);
    let mut rect = RECT::default();
    let mut original_cursor = POINT::default();
    unsafe {
        GetWindowRect(hwnd, &mut rect).expect("read foreground sentinel bounds");
        GetCursorPos(&mut original_cursor).expect("read cursor before focusing sentinel");
    }
    let x = (rect.left + rect.right) / 2;
    let y = (rect.top + rect.bottom) / 2;
    assert!(
        rect.right > rect.left && rect.bottom > rect.top,
        "foreground sentinel has invalid bounds: {rect:?}"
    );

    let inputs = [
        INPUT {
            r#type: INPUT_MOUSE,
            Anonymous: INPUT_0 {
                mi: MOUSEINPUT {
                    dwFlags: MOUSEEVENTF_LEFTDOWN,
                    ..Default::default()
                },
            },
        },
        INPUT {
            r#type: INPUT_MOUSE,
            Anonymous: INPUT_0 {
                mi: MOUSEINPUT {
                    dwFlags: MOUSEEVENTF_LEFTUP,
                    ..Default::default()
                },
            },
        },
    ];
    unsafe {
        SetCursorPos(x, y).expect("move cursor onto foreground sentinel");
        let sent = SendInput(&inputs, std::mem::size_of::<INPUT>() as i32);
        assert_eq!(sent, inputs.len() as u32, "click foreground sentinel");
        SetCursorPos(original_cursor.x, original_cursor.y)
            .expect("restore cursor after focusing sentinel");
    }
}

#[cfg(any(target_os = "windows", target_os = "linux"))]
fn wait_for_native_focus_stable(target: TargetWindow) {
    use crate::observer::{ObserverBackend, TargetZ};

    let backend = NativeObserver::new();
    let deadline = Instant::now() + Duration::from_secs(3);
    let mut stable_since = None;
    loop {
        let foreground = backend
            .snapshot(target)
            .map(|snapshot| snapshot.target_z == TargetZ::Foreground)
            .unwrap_or(false);
        if foreground {
            let since = stable_since.get_or_insert_with(Instant::now);
            if since.elapsed() >= Duration::from_millis(300) {
                return;
            }
        } else {
            stable_since = None;
        }
        assert!(
            Instant::now() < deadline,
            "foreground sentinel did not remain natively focused"
        );
        std::thread::sleep(Duration::from_millis(20));
    }
}

#[cfg(target_os = "linux")]
fn wait_for_native_focus_lost(
    target: TargetWindow,
    background_target: TargetWindow,
) -> Result<(), String> {
    use crate::observer::{ObserverBackend, TargetZ};

    if hyprland::is_session() {
        return hyprland::wait_for_focus_transfer(target, background_target);
    }
    if is_niri_session() {
        return crate::observer::linux::niri_wait_for_focus_transfer(target, background_target)
            .map_err(|error| error.to_string());
    }

    let backend = NativeObserver::new();
    let deadline = Instant::now() + Duration::from_secs(3);
    loop {
        let snapshot = backend.snapshot(target).ok();
        let lost = snapshot
            .as_ref()
            .is_some_and(|snapshot| snapshot.target_z != TargetZ::Foreground);
        if lost {
            return Ok(());
        }
        if Instant::now() >= deadline {
            return Err(format!(
                "native Wayland focus-loss canary was not detected; last snapshot: {snapshot:?}"
            ));
        }
        std::thread::sleep(Duration::from_millis(25));
    }
}

#[cfg(not(target_os = "linux"))]
fn wait_for_native_focus_lost(
    _target: TargetWindow,
    _background_target: TargetWindow,
) -> Result<(), String> {
    Err("native Wayland focus observation is only available on Linux".to_owned())
}

#[cfg(not(any(target_os = "windows", target_os = "linux")))]
fn wait_for_native_focus_stable(_target: TargetWindow) {}

pub fn run_with_background_oracles<D: Driver + BehaviorRecording, R>(
    driver: &mut D,
    target: TargetWindow,
    action: impl FnOnce(&mut D) -> R,
) -> Result<(R, Vec<OracleKind>), String> {
    let sentinel = ForegroundSentinel::launch(driver);
    sentinel.assert_background_posture(target)?;
    driver.start_behavior_recording();
    sentinel.prepare_background_observation(driver, target)?;
    sentinel.observe_background(target, || action(driver))
}

struct ElectronFixture {
    path: std::path::PathBuf,
    args: Vec<&'static str>,
}

fn electron_fixture() -> ElectronFixture {
    #[cfg(target_os = "windows")]
    {
        ElectronFixture {
            path: harness_app("harness-electron", "CuaTestHarness.Electron.exe"),
            args: vec![
                "--no-sandbox",
                "--disable-gpu",
                "--force-renderer-accessibility",
            ],
        }
    }
    #[cfg(target_os = "macos")]
    {
        ElectronFixture {
            path: harness_app(
                "harness-electron",
                "CuaTestHarness.Electron.app/Contents/MacOS/Electron",
            ),
            args: vec!["--force-renderer-accessibility"],
        }
    }
    #[cfg(target_os = "linux")]
    {
        ElectronFixture {
            path: harness_app("harness-electron", "CuaTestHarness.Electron"),
            args: vec![
                "--no-sandbox",
                "--disable-gpu",
                "--force-renderer-accessibility",
            ],
        }
    }
}
