// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Cua AI, Inc.

//! `cua-driver doctor` — environment + install diagnostic probes.
//!
//! The doctor subcommand runs a battery of platform-aware probes and emits
//! a structured report (plain text by default, JSON via `--json`). Each probe
//! produces one line tagged `[ok]`, `[warn]`, or `[err]` so the output is
//! grep-friendly without losing detail.
//!
//! Exit code: `0` when every probe is `[ok]` or `[warn]`. Non-zero only when
//! at least one `[err]` probe failed — e.g. the binary cannot read its own
//! install dir. Warnings (e.g. running outside an interactive desktop on
//! Windows) do not fail because they are sometimes the expected state (CI
//! invocations of `doctor` to render the report).
//!
//! ## Probe categories
//!
//! - **Cross-platform**: version + arch, install layout, home dir,
//!   telemetry state.
//! - **Windows**: interactive desktop session detection (Session 0 warning),
//!   UI Automation COM availability, top-level window enumeration count.
//! - **Linux**: `DISPLAY` / `WAYLAND_DISPLAY` presence, X11 connection
//!   reachability, AT-SPI bus availability hint.
//! - **macOS**: existing legacy-cleanup steps (LaunchAgent plist + update
//!   script), plus a hint to run `cua-driver diagnose` for a full
//!   TCC / cdhash / install layout dump.

use std::path::{Path, PathBuf};

/// Probe outcome.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Status {
    Ok,
    Warn,
    Err,
}

impl Status {
    fn tag(self) -> &'static str {
        match self {
            Status::Ok => "ok",
            Status::Warn => "warn",
            Status::Err => "err",
        }
    }
}

/// One probe result.
#[derive(Debug, Clone)]
pub struct Probe {
    /// Short stable label (e.g. `"binary"`, `"home dir"`).
    pub label: String,
    pub status: Status,
    /// One-line summary printed next to the tag.
    pub message: String,
    /// Optional multi-line detail (continuation lines indented under the
    /// summary in text mode, separate JSON field in `--json` mode).
    pub detail: Option<String>,
}

impl Probe {
    pub fn ok(label: impl Into<String>, message: impl Into<String>) -> Self {
        Self {
            label: label.into(),
            status: Status::Ok,
            message: message.into(),
            detail: None,
        }
    }
    pub fn warn(label: impl Into<String>, message: impl Into<String>) -> Self {
        Self {
            label: label.into(),
            status: Status::Warn,
            message: message.into(),
            detail: None,
        }
    }
    pub fn err(label: impl Into<String>, message: impl Into<String>) -> Self {
        Self {
            label: label.into(),
            status: Status::Err,
            message: message.into(),
            detail: None,
        }
    }
    pub fn with_detail(mut self, detail: impl Into<String>) -> Self {
        self.detail = Some(detail.into());
        self
    }
}

/// Aggregated probe results for one `doctor` run.
#[derive(Debug, Clone, Default)]
pub struct Report {
    pub probes: Vec<Probe>,
}

impl Report {
    pub fn push(&mut self, probe: Probe) {
        self.probes.push(probe);
    }

    /// True iff at least one probe is `Status::Err`. Drives the process
    /// exit code — warnings never fail the run.
    pub fn has_errors(&self) -> bool {
        self.probes.iter().any(|p| p.status == Status::Err)
    }

    /// Plain-text rendering. Each probe is one summary line; multi-line
    /// `detail` blocks are indented underneath.
    pub fn to_text(&self) -> String {
        let mut out = String::new();
        for probe in &self.probes {
            out.push_str(&format!(
                "[{tag:<4}] {label}: {msg}\n",
                tag = probe.status.tag(),
                label = probe.label,
                msg = probe.message,
            ));
            if let Some(detail) = &probe.detail {
                for line in detail.lines() {
                    out.push_str("         ");
                    out.push_str(line);
                    out.push('\n');
                }
            }
        }
        out
    }

    /// JSON rendering: `{ "probes": [...], "ok": bool }`. Each probe is
    /// `{ "label", "status", "message", "detail" }`.
    pub fn to_json(&self) -> serde_json::Value {
        let probes: Vec<serde_json::Value> = self
            .probes
            .iter()
            .map(|p| {
                let mut obj = serde_json::Map::new();
                obj.insert("label".into(), serde_json::Value::String(p.label.clone()));
                obj.insert(
                    "status".into(),
                    serde_json::Value::String(p.status.tag().into()),
                );
                obj.insert(
                    "message".into(),
                    serde_json::Value::String(p.message.clone()),
                );
                if let Some(d) = &p.detail {
                    obj.insert("detail".into(), serde_json::Value::String(d.clone()));
                }
                serde_json::Value::Object(obj)
            })
            .collect();
        serde_json::json!({
            "ok": !self.has_errors(),
            "probes": probes,
            // The running binary's identity (source revision, sha256 of the
            // executable): what `cua doctor --expect cua-driver=...` checks.
            "build": cua_driver_core::build_info::current(),
        })
    }
}

// ── Cross-platform probes ─────────────────────────────────────────────────

/// Probe: version + target triple — the same string `cua-driver --version`
/// returns, plus the build-time target so the user can sanity-check arch.
fn probe_version() -> Probe {
    let version = env!("CARGO_PKG_VERSION");
    let target = build_target_triple();
    let build = cua_driver_core::build_info::current();
    let git = if build.git_sha.is_empty() {
        "unknown".to_owned()
    } else {
        build.git_sha.chars().take(12).collect()
    };
    Probe::ok("binary", format!("cua-driver {version} ({target})")).with_detail(format!(
        "git: {git}\nsha256: {}",
        if build.exe_sha256.is_empty() {
            "unreadable"
        } else {
            &build.exe_sha256
        }
    ))
}

/// Build-time target triple. We don't have a `built` crate dependency, so
/// we synthesise `<arch>-<os>` which is enough to disambiguate the host
/// without adding a new transitive dep.
fn build_target_triple() -> String {
    format!("{}-{}", std::env::consts::ARCH, std::env::consts::OS)
}

/// Probe: where the binary lives on disk. Resolves symlinks (e.g. the
/// `~/.local/bin/cua-driver -> packages/current/cua-driver` chain) so the
/// user sees the actual versioned release dir.
fn probe_install_layout() -> Probe {
    let exe = std::env::current_exe();
    match exe {
        Err(e) => Probe::err("install dir", format!("could not resolve current_exe: {e}")),
        Ok(path) => {
            let canonical = std::fs::canonicalize(&path).unwrap_or_else(|_| path.clone());
            let mut detail = String::new();
            if path != canonical {
                detail.push_str(&format!("argv exe:  {}\n", path.display()));
                detail.push_str(&format!("resolved:  {}", canonical.display()));
            } else {
                detail.push_str(&format!("path: {}", canonical.display()));
            }
            Probe::ok("install dir", canonical.display().to_string()).with_detail(detail)
        }
    }
}

/// Probe: package-home directory (`~/.cua-driver`) — counts cached
/// release dirs so the user can sanity-check
/// `CUA_DRIVER_RS_KEEP_VERSIONS` is doing the right thing. Renamed from
/// `.cua-driver-rs/` in v0.2.16 to match the install-path rename (PR #1644).
fn probe_home_dir(home: Option<&Path>) -> Probe {
    let Some(home) = home else {
        return Probe::warn("home dir", "neither HOME nor USERPROFILE set");
    };
    let cua_home = home.join(crate::bundle::user_home_subdirectory());
    if !cua_home.exists() {
        return Probe::warn(
            "home dir",
            format!(
                "{} does not exist yet (created on first run)",
                cua_home.display()
            ),
        );
    }
    let releases = cua_home.join("packages").join("releases");
    // Only count subdirectories — bare files inside `releases/` (stray
    // download artifacts, lock files, .DS_Store) are not actual cached
    // versions and shouldn't inflate the "release dir(s) cached" metric.
    let release_count = std::fs::read_dir(&releases)
        .map(|entries| {
            entries
                .filter_map(Result::ok)
                .filter(|entry| entry.metadata().map(|m| m.is_dir()).unwrap_or(false))
                .count()
        })
        .unwrap_or(0);
    Probe::ok(
        "home dir",
        format!(
            "{} ({release_count} release dir{} cached)",
            cua_home.display(),
            if release_count == 1 { "" } else { "s" },
        ),
    )
}

/// Probe the same effective persisted/environment state as `telemetry status`.
fn probe_telemetry(status: &crate::telemetry::TelemetryStatus) -> Probe {
    if status.enabled {
        let identity = if status.installation_id_present {
            "install-id present"
        } else {
            "install-id not yet generated"
        };
        Probe::ok(
            "telemetry",
            format!("enabled via {} ({identity})", status.source),
        )
    } else {
        Probe::ok(
            "telemetry",
            format!("disabled via {} (installation ID retained)", status.source),
        )
    }
}

/// `$HOME` on Unix, `%USERPROFILE%` on Windows.
fn home_dir() -> Option<PathBuf> {
    std::env::var_os("HOME")
        .or_else(|| std::env::var_os("USERPROFILE"))
        .map(PathBuf::from)
}

// ── Platform-specific probe entry-points ──────────────────────────────────

/// Append every platform-specific probe to the report.
#[cfg(target_os = "windows")]
fn append_platform_probes(report: &mut Report) {
    use platform_windows::diagnostics as diag;

    // Interactive desktop session probe — the critical Windows check. SSH
    // (and most service contexts) land processes in Session 0 with no
    // attached WindowStation+Desktop, which silently breaks every
    // window-driving tool. Surface the misconfiguration directly so users
    // don't waste hours debugging tools that are working as designed.
    let desktop = diag::desktop_state();
    let in_session_0 = match desktop.session_id {
        Some(0) => {
            report.push(
                Probe::warn(
                    "interactive session",
                    "running in Session 0 (services); window-driving tools (list_windows, click, type_text, get_window_state, get_desktop_state) will return empty results — these APIs need an attached interactive desktop.",
                )
                .with_detail(
                    "re-run cua-driver from an interactive logon (RDP, console, or a scheduled task in the user's session) for the GUI tools to function.",
                ),
            );
            true
        }
        Some(sid) => {
            if desktop.has_foreground_window() {
                report.push(Probe::ok(
                    "interactive session",
                    format!(
                        "session {sid} has an attached interactive desktop ({})",
                        desktop.summary()
                    ),
                ));
            } else if desktop.input_desktop_is_default() {
                report.push(
                    Probe::warn(
                        "interactive session",
                        format!(
                            "session {sid}: Default input desktop is reachable but no window is foreground ({})",
                            desktop.summary()
                        ),
                    )
                    .with_detail(
                        "GUI tests can seed foreground by launching their focus sentinel; unattended runners should still validate that the sentinel becomes foreground.",
                    ),
                );
            } else {
                report.push(
                    Probe::warn(
                        "interactive session",
                        format!(
                            "session {sid}: input desktop is not the user Default desktop ({})",
                            desktop.summary()
                        ),
                    )
                    .with_detail(
                        "this usually means the RDP/console session is locked or disconnected; reconnect, use tscon-to-console, or boot the disposable GUI VM with an unlocked console session.",
                    ),
                );
            }
            false
        }
        None => {
            report.push(Probe::warn(
                "interactive session",
                format!(
                    "ProcessIdToSessionId failed — cannot determine session id ({})",
                    desktop.summary()
                ),
            ));
            false
        }
    };

    // COM / UI Automation availability.
    report.push(ui_automation_probe());

    // EnumWindows count — cross-check the session probe. When Session 0
    // is in play, this almost always reports zero visible windows, which
    // reinforces the warning above instead of looking like a separate bug.
    let visible = platform_windows::win32::list_windows(None).len();
    let probe = Probe::ok(
        "EnumWindows visible",
        format!("{visible} window{}", if visible == 1 { "" } else { "s" }),
    );
    let probe = if visible == 0 && in_session_0 {
        probe.with_detail(
            "consistent with the Session 0 warning above — EnumWindows is scoped to the calling session's desktop.",
        )
    } else {
        probe
    };
    report.push(probe);
}

#[cfg(target_os = "windows")]
fn ui_automation_probe() -> Probe {
    use platform_windows::diagnostics as diag;

    match diag::ui_automation_available() {
        Ok(()) => ui_automation_probe_from(Ok(()), false),
        Err(e) => {
            let degraded = diag::is_degraded_ui_automation_error(&e);
            ui_automation_probe_from(Err(e), degraded)
        }
    }
}

#[cfg(any(target_os = "windows", test))]
fn ui_automation_probe_from(result: Result<(), String>, degraded: bool) -> Probe {
    match result {
        Ok(()) => Probe::ok("UI Automation", "CoCreateInstance(CUIAutomation) succeeded"),
        Err(e) if degraded => Probe::warn("UI Automation", e),
        Err(e) => Probe::err(
            "UI Automation",
            format!("CoCreateInstance(CUIAutomation) failed: {e}"),
        ),
    }
}

/// Run `gdbus introspect` against the AT-SPI accessibility bus and report
/// whether it returned success within `timeout`. Any of: spawn failure,
/// timeout elapsed, non-zero exit — all collapse to `false` (the caller
/// only cares about reachability, not the failure mode).
///
/// Kept separate from `append_platform_probes` so it's straightforward to
/// unit-test the timeout path without invoking the full doctor run.
#[cfg(target_os = "linux")]
fn probe_at_spi_bus_via_gdbus(timeout: std::time::Duration) -> bool {
    use std::process::{Command, Stdio};

    let mut child = match Command::new("gdbus")
        .args([
            "introspect",
            "--session",
            "--dest",
            "org.a11y.Bus",
            "--object-path",
            "/org/a11y/bus",
        ])
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
    {
        Ok(c) => c,
        Err(_) => return false,
    };
    match wait_for_child(&mut child, timeout) {
        Ok(Some(status)) => status.success(),
        Ok(None) | Err(_) => {
            // Timed out or failed — kill the stuck child so we don't leave a
            // gdbus process hanging around after `doctor` exits.
            let _ = child.kill();
            let _ = child.wait();
            false
        }
    }
}

#[cfg(target_os = "linux")]
fn wait_for_child(
    child: &mut std::process::Child,
    timeout: std::time::Duration,
) -> std::io::Result<Option<std::process::ExitStatus>> {
    let deadline = std::time::Instant::now() + timeout;
    loop {
        if let Some(status) = child.try_wait()? {
            return Ok(Some(status));
        }

        let Some(remaining) = deadline.checked_duration_since(std::time::Instant::now()) else {
            return Ok(None);
        };
        if remaining.is_zero() {
            return Ok(None);
        }
        std::thread::sleep(remaining.min(std::time::Duration::from_millis(15)));
    }
}

#[cfg(target_os = "linux")]
fn append_platform_probes(report: &mut Report) {
    // Display server probe. Order matters: Wayland wins when both are set
    // (XWayland leaves DISPLAY pointing at the X server XWayland exposes,
    // but the actual session is still Wayland).
    let display = std::env::var("DISPLAY").ok().filter(|v| !v.is_empty());
    let wayland = std::env::var("WAYLAND_DISPLAY")
        .ok()
        .filter(|v| !v.is_empty());
    match (display.as_deref(), wayland.as_deref()) {
        (None, None) => report.push(
            Probe::warn(
                "display server",
                "neither DISPLAY nor WAYLAND_DISPLAY set — window-driving tools will fail",
            )
            .with_detail(
                "run from an interactive desktop session (X11 / Wayland with XWayland) or set DISPLAY explicitly.",
            ),
        ),
        (Some(d), None) => report.push(Probe::ok(
            "display server",
            format!("X11 (DISPLAY={d})"),
        )),
        (None, Some(w)) => report.push(
            Probe::warn(
                "display server",
                format!("Wayland only (WAYLAND_DISPLAY={w}, DISPLAY unset)"),
            )
            .with_detail(
                "X11 window discovery and capture (list_windows, get_window_state) need XWayland — start your session with XWayland enabled.",
            ),
        ),
        (Some(d), Some(w)) => report.push(Probe::ok(
            "display server",
            format!("Wayland+XWayland (WAYLAND_DISPLAY={w}, DISPLAY={d})"),
        )),
    }

    // X11 window enumeration probe. An empty result could mean either an
    // unreachable display or a healthy display with no top-level windows
    // open — `list_windows` doesn't distinguish the two — so the warning
    // hedges instead of asserting a connection failure.
    match platform_linux::x11::list_windows(None) {
        v if v.is_empty() => report.push(Probe::warn(
            "X11 connection",
            "no top-level windows returned (possible disconnected or inaccessible X11 display)",
        )),
        v => report.push(Probe::ok(
            "X11 connection",
            format!(
                "connected, {} visible top-level window{}",
                v.len(),
                if v.len() == 1 { "" } else { "s" }
            ),
        )),
    }

    // AT-SPI bus probe. We don't link D-Bus directly — instead, check for
    // the AT_SPI_BUS env var which the at-spi daemon advertises when
    // running, and fall back to checking gdbus's view of the
    // org.a11y.Bus name.
    let at_spi_env = std::env::var("AT_SPI_BUS").ok().filter(|v| !v.is_empty());
    match at_spi_env {
        Some(addr) => report.push(Probe::ok(
            "AT-SPI",
            format!("bus address present (AT_SPI_BUS={addr})"),
        )),
        None => {
            // Bounded wait — a hung session bus daemon would otherwise
            // block `doctor` indefinitely. 3s is enough for a healthy
            // gdbus introspect to complete (single round-trip on the
            // session bus) and short enough that a stuck bus surfaces
            // as a warning instead of looking like the binary froze.
            let bus_ok = probe_at_spi_bus_via_gdbus(std::time::Duration::from_secs(3));
            if bus_ok {
                report.push(Probe::ok(
                    "AT-SPI",
                    "org.a11y.Bus reachable via session bus",
                ));
            } else {
                report.push(
                    Probe::warn("AT-SPI", "accessibility bus not reachable")
                        .with_detail(
                            "install at-spi2-core and ensure the user session has D-Bus running for get_window_state to work.",
                        ),
                );
            }
        }
    }
}

#[cfg(target_os = "macos")]
fn append_platform_probes(report: &mut Report) {
    // The legacy cleanup behavior — preserved as opportunistic probes so
    // existing users on stale installs still get the cleanup, but the
    // output is now structured.
    let home = std::env::var("HOME").unwrap_or_else(|_| "/tmp".into());
    let legacy_plist = PathBuf::from(format!(
        "{home}/Library/LaunchAgents/com.trycua.cua_driver_updater.plist"
    ));
    append_legacy_cleanup_probes(
        report,
        &legacy_plist,
        Path::new("/usr/local/bin/cua-driver-update"),
    );
}

/// Remove a stale legacy updater LaunchAgent and script, reporting each.
#[cfg(target_os = "macos")]
fn append_legacy_cleanup_probes(report: &mut Report, legacy_plist: &Path, legacy_script: &Path) {
    let legacy_plist_text = legacy_plist.display().to_string();
    let legacy_plist = legacy_plist_text.as_str();
    let legacy_script_text = legacy_script.display().to_string();

    if std::path::Path::new(&legacy_plist).exists() {
        let _ = std::process::Command::new("launchctl")
            .args(["unload", legacy_plist])
            .status();
        match std::fs::remove_file(legacy_plist) {
            Ok(()) => report.push(Probe::ok(
                "legacy LaunchAgent",
                format!("removed stale {legacy_plist}"),
            )),
            Err(e) => report.push(Probe::warn(
                "legacy LaunchAgent",
                format!("could not remove {legacy_plist}: {e}"),
            )),
        }
    } else {
        report.push(Probe::ok("legacy LaunchAgent", "not present"));
    }

    let legacy_script = legacy_script_text.as_str();
    if std::path::Path::new(legacy_script).exists() {
        match std::fs::remove_file(legacy_script) {
            Ok(()) => report.push(Probe::ok(
                "legacy update script",
                format!("removed stale {legacy_script}"),
            )),
            Err(_) => report.push(
                Probe::warn(
                    "legacy update script",
                    format!("{legacy_script} present and root-owned — remove with `sudo rm -f {legacy_script}`"),
                ),
            ),
        }
    } else {
        report.push(Probe::ok("legacy update script", "not present"));
    }

    report.push(Probe::ok(
        "TCC + cdhash report",
        "for a full bundle / signature / TCC dump, run `cua-driver diagnose`",
    ));
}

#[cfg(not(any(target_os = "windows", target_os = "linux", target_os = "macos")))]
fn append_platform_probes(report: &mut Report) {
    report.push(Probe::warn(
        "platform",
        format!(
            "no platform-specific probes implemented for {}",
            std::env::consts::OS
        ),
    ));
}

// ── Public entry point ────────────────────────────────────────────────────

/// Run every probe and return the aggregated report. `fix` also repairs what
/// can be repaired safely: on macOS it makes LaunchServices forget every other
/// copy of the app (no files are deleted).
pub fn run(fix: bool) -> Report {
    #[cfg_attr(not(target_os = "macos"), allow(unused_mut))]
    let mut report = assemble(
        home_dir().as_deref(),
        &crate::telemetry::status(),
        append_platform_probes,
    );
    #[cfg(target_os = "macos")]
    append_install_hygiene_probes(&mut report, fix);
    #[cfg(not(target_os = "macos"))]
    let _ = fix;
    report
}

/// macOS: other copies of the app that macOS can launch instead of the
/// installed one, and permission rows tied to another path or version.
#[cfg(target_os = "macos")]
fn append_install_hygiene_probes(report: &mut Report, fix: bool) {
    use crate::duplicate_copies as copies;

    let active = PathBuf::from(crate::bundle::app_bundle_path());
    let bundle_id = crate::bundle::bundle_id();
    let (registered, indexed_only): (Vec<_>, Vec<_>) =
        copies::discover(&active, bundle_id, &copies::run_program)
            .into_iter()
            .partition(|copy| copy.registered);
    let fixed = if fix && !registered.is_empty() {
        let outcomes = copies::unregister(&registered, &copies::run_program);
        // What LaunchServices still has registered after the fix.
        let remaining: Vec<_> = copies::discover(&active, bundle_id, &copies::run_program)
            .into_iter()
            .filter(|copy| copy.registered)
            .collect();
        Some((outcomes, remaining))
    } else {
        None
    };
    report.push(copies::duplicate_probe(
        &active,
        crate::bundle::app_name(),
        &registered,
        &indexed_only,
        fixed
            .as_ref()
            .map(|(outcomes, remaining)| (outcomes.as_slice(), remaining.as_slice())),
    ));

    let executable = active
        .join("Contents/MacOS")
        .join(crate::bundle::cli_name());
    let rows = home_dir()
        .ok_or_else(|| "HOME is not set".to_owned())
        .and_then(|home| copies::read_tcc_rows(&home, &copies::run_program));
    report.push(copies::permission_row_probe(&executable, rows, |bundle| {
        copies::bundle_version_of(bundle, &copies::run_program)
    }));
}

/// The cross-platform probes over explicit host inputs, then `platform`'s.
fn assemble(
    home: Option<&Path>,
    telemetry: &crate::telemetry::TelemetryStatus,
    platform: impl FnOnce(&mut Report),
) -> Report {
    let mut report = Report::default();
    report.push(probe_version());
    report.push(probe_install_layout());
    report.push(probe_home_dir(home));
    report.push(probe_telemetry(telemetry));
    platform(&mut report);
    report
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn report_to_text_renders_status_tag_and_message() {
        let mut r = Report::default();
        r.push(Probe::ok("a", "alpha"));
        r.push(Probe::warn("b", "bravo").with_detail("two\nlines"));
        r.push(Probe::err("c", "charlie"));
        let text = r.to_text();
        assert!(text.contains("[ok  ] a: alpha"));
        assert!(text.contains("[warn] b: bravo"));
        assert!(text.contains("         two"));
        assert!(text.contains("         lines"));
        assert!(text.contains("[err ] c: charlie"));
    }

    #[test]
    fn report_to_json_marks_ok_false_when_any_error() {
        let mut r = Report::default();
        r.push(Probe::ok("a", "alpha"));
        r.push(Probe::err("b", "bravo"));
        let json = r.to_json();
        assert_eq!(json["ok"], serde_json::Value::Bool(false));
        assert_eq!(json["probes"].as_array().unwrap().len(), 2);
        assert_eq!(json["probes"][1]["status"], "err");
    }

    #[test]
    fn report_to_json_marks_ok_true_when_only_warnings() {
        let mut r = Report::default();
        r.push(Probe::ok("a", "alpha"));
        r.push(Probe::warn("b", "bravo"));
        let json = r.to_json();
        // Warnings do not fail the run — exit-code-driving flag stays true.
        assert_eq!(json["ok"], serde_json::Value::Bool(true));
    }

    #[cfg(target_os = "linux")]
    #[test]
    fn wait_for_child_reports_exit() {
        let mut child = std::process::Command::new("true").spawn().unwrap();
        let status = wait_for_child(&mut child, std::time::Duration::from_secs(1))
            .unwrap()
            .unwrap();
        assert!(status.success());
    }

    #[cfg(target_os = "linux")]
    #[test]
    fn wait_for_child_times_out() {
        let mut child = std::process::Command::new("sleep")
            .arg("5")
            .spawn()
            .unwrap();
        let status = wait_for_child(&mut child, std::time::Duration::from_millis(10)).unwrap();
        assert!(status.is_none());
        child.kill().unwrap();
        child.wait().unwrap();
    }

    fn telemetry_status() -> crate::telemetry::TelemetryStatus {
        crate::telemetry::TelemetryStatus {
            enabled: false,
            source: "test",
            installation_id_present: false,
            installation_id: None,
            registration_recorded: false,
            current_release_recorded: false,
        }
    }

    // Every probe runs over explicit inputs: a test must never read the real
    // home, run the telemetry home migration, or remove a real LaunchAgent.
    #[test]
    fn cross_platform_probes_always_emit_something() {
        // Smoke test: run the cross-platform probes and confirm they all
        // produced a probe (no silent dropouts).
        let home = tempfile::tempdir().unwrap();
        let v = probe_version();
        assert_eq!(v.label, "binary");
        let i = probe_install_layout();
        assert_eq!(i.label, "install dir");
        let h = probe_home_dir(Some(home.path()));
        assert_eq!(h.label, "home dir");
        assert_eq!(probe_home_dir(None).status, Status::Warn);
        let t = probe_telemetry(&telemetry_status());
        assert_eq!(t.label, "telemetry");
    }

    #[test]
    fn run_emits_at_least_cross_platform_probes() {
        let home = tempfile::tempdir().unwrap();
        let report = assemble(Some(home.path()), &telemetry_status(), |report| {
            report.push(Probe::ok("platform", "probed"))
        });
        // 4 cross-platform + the platform-specific ones.
        assert_eq!(report.probes.len(), 5);
        assert_eq!(report.probes[4].label, "platform");
    }

    #[cfg(target_os = "macos")]
    #[test]
    fn legacy_cleanup_removes_only_the_given_script() {
        let dir = tempfile::tempdir().unwrap();
        let plist = dir.path().join("absent.plist");
        let script = dir.path().join("cua-driver-update");
        std::fs::write(&script, "#!/bin/sh\n").unwrap();
        let mut report = Report::default();
        append_legacy_cleanup_probes(&mut report, &plist, &script);
        assert!(!script.exists(), "the stale script is removed");
        let labels: Vec<_> = report.probes.iter().map(|p| p.label.as_str()).collect();
        assert_eq!(
            labels,
            [
                "legacy LaunchAgent",
                "legacy update script",
                "TCC + cdhash report"
            ]
        );
        assert_eq!(report.probes[0].message, "not present");
        assert!(report.probes[1].message.starts_with("removed stale "));
    }

    #[test]
    fn degraded_ui_automation_does_not_fail_doctor() {
        let mut report = Report::default();
        for error in [
            "UI Automation desktop enumeration exceeded 4000ms; a UIA provider may be hung.",
            "UI Automation is busy with an earlier timed-out provider call; window tools are temporarily using Win32-only enumeration.",
        ] {
            let probe = ui_automation_probe_from(Err(error.to_owned()), true);
            assert_eq!(probe.status, Status::Warn);
            assert_eq!(probe.message, error);
            report.push(probe);
        }
        assert!(!report.has_errors());
        assert_eq!(report.to_json()["ok"], serde_json::Value::Bool(true));
    }

    #[test]
    fn genuine_ui_automation_failures_still_fail_doctor() {
        let probe = ui_automation_probe_from(
            Err("CoCreateInstance(CUIAutomation) failed".to_owned()),
            false,
        );
        assert_eq!(probe.status, Status::Err);
        assert!(probe
            .message
            .contains("CoCreateInstance(CUIAutomation) failed"));
    }
}
