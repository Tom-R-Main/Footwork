// SPDX-License-Identifier: MIT
// Copyright (c) 2026 Cua AI, Inc.

//! Shared tool-argument extraction helpers.
//!
//! Every tool in every platform crate does the same dance to pull
//! pid / window_id / element_index / text / etc. out of the inbound
//! JSON `Value`. Before this module they were 4-line `match` blocks
//! repeated 200+ times across the codebase with subtly different
//! error wording. The trait below consolidates those into one
//! consistent shape.
//!
//! Two flavours of accessor:
//!
//! - `require_*` — bails with a `ToolResult::error` if the field is
//!   missing or the wrong type. Narrowing casts (i64 → i32, u64 → u32)
//!   go through `try_from` and surface an actionable range error
//!   instead of silently truncating — the same CodeRabbit fix landed
//!   on PR #1666's page tool now applies uniformly.
//! - `opt_*` — returns `Option<T>` / `Result<Option<T>>` for callers
//!   that already have a sensible default. Range-checked variants
//!   return `Result<Option<T>>` because "the user passed a value but
//!   it's out of range" is still an error, just one we don't enforce
//!   when the field is absent.
//!
//! Error message format: `"Missing required {kind} field: {name}"`.
//! Used uniformly so MCP clients can pattern-match the wording.
//!
//! See `libs/cua-driver/rust/docs/dedup-audit.md` for the audit trail
//! that motivated this extraction.

use serde::de::DeserializeOwned;
use serde_json::{json, Value};

use crate::protocol::ToolResult;

/// Deserialize one transport-free Rust input type from MCP arguments.
///
/// Published SDK tools use this before invoking platform behavior, so the
/// generated schema and the live parser share the same Rust definition.
pub fn parse_typed_input<T: DeserializeOwned>(
    tool_name: &str,
    mut args: Value,
) -> Result<T, ToolResult> {
    // Public callers cannot supply reserved arguments: ingress strips them
    // before trusted session/approval context is injected. Keep that internal
    // transport metadata out of the transport-free contract types as well.
    sanitize_reserved_args(&mut args);
    serde_json::from_value(args).map_err(|error| {
        ToolResult::error(format!("{tool_name}: invalid arguments: {error}")).with_structured(
            json!({
                "code": "invalid_arguments",
                "tool": tool_name,
                "detail": error.to_string(),
            }),
        )
    })
}

/// Deserialize the portable portion of a richer live tool input.
///
/// Platform handlers may accept window-targeting or diagnostic fields that are
/// intentionally absent from the generated cross-platform SDK method. This
/// projects only fields owned by the portable Rust type, then deserializes that
/// type so both surfaces share field names, types, enums, and defaults without
/// rejecting legitimate platform-rich arguments.
pub fn parse_typed_projection<T: cua_driver_contract::ToolInput>(
    tool_name: &str,
    args: &Value,
) -> Result<T, ToolResult> {
    let Some(source) = args.as_object() else {
        return parse_typed_input(tool_name, args.clone());
    };
    let properties = cua_driver_contract::tool_input_fields(T::TOOL_NAME)
        .expect("typed tool input is indexed in the published contract");
    let projected = source
        .iter()
        .filter(|(name, _)| properties.contains(*name))
        .map(|(name, value)| (name.clone(), value.clone()))
        .collect();
    parse_typed_input(tool_name, Value::Object(projected))
}

/// Keep the released desktop-coordinate wire parser independent of the SDK's
/// explicit addressing API. Native handlers still accept legacy scope/defaults.
pub fn parse_legacy_click_input(
    args: &Value,
) -> Result<cua_driver_contract::LegacyClickInput, ToolResult> {
    const FIELDS: &[&str] = &["x", "y", "target", "scope", "session", "button", "count"];
    let Some(source) = args.as_object() else {
        return parse_typed_input("click", args.clone());
    };
    let projected = source
        .iter()
        .filter(|(name, _)| FIELDS.contains(&name.as_str()))
        .map(|(name, value)| (name.clone(), value.clone()))
        .collect();
    parse_typed_input("click", Value::Object(projected))
}

/// Remove transport-reserved arguments supplied by a public caller. Trusted
/// ingress code calls this before injecting session or approval context, so a
/// tool request cannot forge underscore-prefixed transport evidence.
pub fn sanitize_reserved_args(args: &mut Value) {
    if let Some(object) = args.as_object_mut() {
        object.retain(|key, _| !key.starts_with('_'));
    }
}

/// Resolve and apply the session identity for one tool call at a trusted
/// transport boundary, returning the effective `_session_id`.
///
/// Public naming and the transport's lifecycle identity resolve
/// independently. A non-empty `session` label is mirrored into the reserved
/// `_session_id`; otherwise the transport's own session (a per-connection
/// lease or MCP HTTP session) becomes the implicit lifecycle key.
/// `_transport_session_id` always carries the transport session. Any
/// caller-supplied value for either reserved key is replaced, never trusted.
/// With neither a label nor a transport session the call stays anonymous.
pub fn apply_session_identity(args: &mut Value, transport_session: Option<&str>) -> Option<String> {
    let object = args.as_object_mut()?;
    let effective = object
        .get("session")
        .and_then(Value::as_str)
        .filter(|session| !session.is_empty())
        .or(transport_session)
        .map(str::to_owned);
    object.remove("_session_id");
    object.remove("_transport_session_id");
    if let Some(id) = &effective {
        object.insert("_session_id".to_owned(), Value::String(id.clone()));
    }
    if let Some(id) = transport_session {
        object.insert(
            "_transport_session_id".to_owned(),
            Value::String(id.to_owned()),
        );
    }
    effective
}

#[cfg(test)]
mod session_identity_tests {
    use super::apply_session_identity;
    use serde_json::json;

    #[test]
    fn public_label_and_transport_session_resolve_independently() {
        // (args, transport session) -> (effective _session_id, _transport_session_id)
        for (mut args, transport, session_id, transport_id) in [
            (
                json!({ "x": 1, "session": "research-1" }),
                None,
                Some("research-1"),
                None,
            ),
            (
                json!({ "session": "capability-session" }),
                Some("proxy-session"),
                Some("capability-session"),
                Some("proxy-session"),
            ),
            // The transport session drives the implicit lifecycle without
            // manufacturing a caller-visible public `session` label.
            (
                json!({ "x": 1 }),
                Some("mcp-123"),
                Some("mcp-123"),
                Some("mcp-123"),
            ),
            (
                json!({ "session": "" }),
                Some("mcp-1"),
                Some("mcp-1"),
                Some("mcp-1"),
            ),
            (json!({ "x": 1 }), None, None, None),
            // Caller-supplied reserved keys are replaced or removed.
            (
                json!({ "_session_id": "caller-set", "_transport_session_id": "forged" }),
                Some("mcp-999"),
                Some("mcp-999"),
                Some("mcp-999"),
            ),
            (
                json!({ "_session_id": "caller-set", "_transport_session_id": "forged" }),
                None,
                None,
                None,
            ),
        ] {
            let before = args.clone();
            let effective = apply_session_identity(&mut args, transport);
            assert_eq!(effective.as_deref(), session_id, "{before}");
            assert_eq!(args["_session_id"].as_str(), session_id, "{before}");
            assert_eq!(
                args["_transport_session_id"].as_str(),
                transport_id,
                "{before}"
            );
            assert_eq!(args.get("session"), before.get("session"), "{before}");
        }

        let mut not_an_object = json!(["session"]);
        assert_eq!(
            apply_session_identity(&mut not_an_object, Some("mcp")),
            None
        );
    }
}

/// The session key an isolation-scoped state store should key on for this
/// call: the public `session` label, else the proxy-minted `_session_id`,
/// else the legacy `cursor_id`, else a shared `"default"` bucket for
/// anonymous calls. Mirrors the cursor/mouse-hold isolation convention so new
/// per-call state (e.g. desktop screenshot scale) doesn't invent its own.
pub fn resolve_session_key(args: &Value) -> String {
    session_key(args).unwrap_or_else(|| "default".to_owned())
}

/// The first non-empty of `session`, the proxy-minted `_session_id`, and the
/// legacy `cursor_id`, or `None` for an anonymous call. Callers pick their own
/// anonymous fallback: [`resolve_session_key`] uses a shared `"default"`
/// bucket, and the Windows cursor key stays cursor-less.
pub fn session_key(args: &Value) -> Option<String> {
    ["session", "_session_id", "cursor_id"]
        .into_iter()
        .filter_map(|key| args.get(key).and_then(Value::as_str))
        .find(|value| !value.is_empty())
        .map(str::to_owned)
}

#[cfg(test)]
mod session_key_tests {
    use super::{resolve_session_key, session_key};
    use serde_json::json;

    #[test]
    fn session_then_implicit_session_then_legacy_cursor_id() {
        for (args, expected) in [
            (json!({}), None),
            (json!({ "pid": 1 }), None),
            (json!({ "session": "research-run" }), Some("research-run")),
            (json!({ "_session_id": "mcp-1-2" }), Some("mcp-1-2")),
            (json!({ "cursor_id": "user-handle" }), Some("user-handle")),
            (
                json!({ "session": "s1", "_session_id": "implicit", "cursor_id": "c1" }),
                Some("s1"),
            ),
            (
                json!({ "_session_id": "implicit", "cursor_id": "c1" }),
                Some("implicit"),
            ),
            // Empty and non-string values fall through to the next source.
            (json!({ "session": "", "cursor_id": "c1" }), Some("c1")),
            (json!({ "session": 7, "_session_id": "mcp" }), Some("mcp")),
            (json!({ "session": "", "cursor_id": "" }), None),
        ] {
            assert_eq!(session_key(&args).as_deref(), expected, "{args}");
            assert_eq!(
                resolve_session_key(&args),
                expected.unwrap_or("default"),
                "{args}"
            );
        }
    }
}

#[cfg(test)]
mod reserved_args_tests {
    use super::{parse_legacy_click_input, parse_typed_input, sanitize_reserved_args};
    use cua_driver_contract::{ClickButton, GetScreenSizeInput, SetWindowFrameInput};
    use serde_json::json;

    #[test]
    fn removes_all_top_level_reserved_arguments_only() {
        let mut args = json!({
            "pid": 42,
            "_session_id": "forged",
            "_observation_only": true,
            "_cua_browser_prepare_mcp_host_approved": true,
            "profile": {"mode": "isolated_new", "_future_public_field": "retained"}
        });
        sanitize_reserved_args(&mut args);
        assert_eq!(
            args,
            json!({
                "pid": 42,
                "profile": {"mode": "isolated_new", "_future_public_field": "retained"}
            })
        );
    }

    #[test]
    fn typed_input_ignores_trusted_transport_metadata_but_rejects_public_unknown_fields() {
        let input = parse_typed_input::<GetScreenSizeInput>(
            "get_screen_size",
            json!({"session": "public", "_session_id": "trusted"}),
        )
        .expect("trusted transport metadata is not part of the public contract");
        assert_eq!(input.session.as_deref(), Some("public"));

        let error = parse_typed_input::<GetScreenSizeInput>(
            "get_screen_size",
            json!({"pid": 42, "_session_id": "trusted"}),
        )
        .expect_err("ordinary unknown fields remain invalid");
        assert_eq!(error.is_error, Some(true));
        assert!(matches!(
            &error.content[0],
            crate::protocol::Content::Text { text, .. }
                if text.contains("unknown field `pid`")
        ));
    }

    #[test]
    fn set_window_frame_typed_input_accepts_namespaced_session_metadata() {
        let input = parse_typed_input::<SetWindowFrameInput>(
            "set_window_frame",
            json!({
                "pid": 42,
                "window_id": 84,
                "x": 10,
                "y": 20,
                "width": 800,
                "height": 600,
                "session": "window-layout",
                "_public_session_label": "window-layout",
                "_session_id": "__cua_runtime_test:window-layout",
                "_transport_session_id": "transport-1"
            }),
        )
        .expect("trusted session metadata is not part of the public contract");

        assert_eq!(input.pid, 42);
        assert_eq!(input.window_id, 84);
        assert_eq!(input.session.as_deref(), Some("window-layout"));
    }

    #[test]
    fn legacy_click_projection_preserves_wire_defaults_and_validates_coordinates() {
        let input = parse_legacy_click_input(&json!({
            "x": 10,
            "y": 20.5,
            "scope": "desktop",
            "button": "right",
            "pid": 42,
            "delivery_mode": "foreground"
        }))
        .expect("rich fields are projected away");
        assert_eq!(input.x, 10.0);
        assert_eq!(input.button, Some(ClickButton::Right));

        assert!(input.target.is_none());
        let error =
            parse_legacy_click_input(&json!({"x": "10", "y": 20, "scope": "desktop", "pid": 42}))
                .expect_err("portable field types are still enforced");
        assert_eq!(error.is_error, Some(true));
        assert_eq!(
            error
                .structured_content
                .as_ref()
                .and_then(|value| value.get("code")),
            Some(&json!("invalid_arguments"))
        );
    }
}

/// Format the canonical "missing required field" error.
#[inline]
fn missing(kind: &str, name: &str) -> ToolResult {
    ToolResult::error(format!("Missing required {kind} field: {name}"))
}

/// Format the canonical "wrong type" error. Used when the field IS
/// present but a different JSON type than the caller asked for.
#[inline]
fn wrong_type(kind: &str, name: &str) -> ToolResult {
    ToolResult::error(format!("Field {name} has wrong type — expected {kind}"))
}

/// Format the canonical out-of-range error for narrowing casts.
#[inline]
fn out_of_range(kind: &str, name: &str, raw: i128) -> ToolResult {
    ToolResult::error(format!("Field {name} is out of range for {kind}: {raw}"))
}

/// Extension trait on `&serde_json::Value` (the MCP `arguments` blob)
/// that provides typed, error-formatted accessors for every field
/// shape the tool surface uses.
pub trait ArgsExt {
    // ── Required scalars ──────────────────────────────────────────────────
    fn require_i32(&self, name: &str) -> Result<i32, ToolResult>;
    fn require_i64(&self, name: &str) -> Result<i64, ToolResult>;
    fn require_u32(&self, name: &str) -> Result<u32, ToolResult>;
    fn require_u64(&self, name: &str) -> Result<u64, ToolResult>;
    fn require_f64(&self, name: &str) -> Result<f64, ToolResult>;
    fn require_str(&self, name: &str) -> Result<String, ToolResult>;
    fn require_bool(&self, name: &str) -> Result<bool, ToolResult>;

    // ── Optional scalars ──────────────────────────────────────────────────
    /// Returns `None` if the field is absent. Returns `Err` if the
    /// field is present but doesn't fit in i32 — silent truncation
    /// is the bug class this trait exists to prevent.
    fn opt_i32(&self, name: &str) -> Result<Option<i32>, ToolResult>;
    fn opt_u32(&self, name: &str) -> Result<Option<u32>, ToolResult>;
    fn opt_u64(&self, name: &str) -> Option<u64>;
    fn opt_i64(&self, name: &str) -> Option<i64>;
    fn opt_f64(&self, name: &str) -> Option<f64>;
    fn opt_str(&self, name: &str) -> Option<String>;
    fn opt_bool(&self, name: &str) -> Option<bool>;

    // ── Default-fallback scalars (the most common pattern) ────────────────
    fn u64_or(&self, name: &str, default: u64) -> u64;
    fn i64_or(&self, name: &str, default: i64) -> i64;
    fn f64_or(&self, name: &str, default: f64) -> f64;
    fn str_or<'a>(&'a self, name: &str, default: &'a str) -> String;
    fn bool_or(&self, name: &str, default: bool) -> bool;

    // ── Arrays ────────────────────────────────────────────────────────────
    /// Extract an array of strings (for `modifiers`, `keys`, `urls`,
    /// `attributes`, etc.). Returns an empty vec if the field is
    /// absent or not an array. Non-string elements are skipped.
    fn str_array(&self, name: &str) -> Vec<String>;
}

impl ArgsExt for Value {
    fn require_i32(&self, name: &str) -> Result<i32, ToolResult> {
        let raw = self
            .get(name)
            .and_then(|v| v.as_i64())
            .ok_or_else(|| missing("integer", name))?;
        i32::try_from(raw).map_err(|_| out_of_range("i32", name, raw as i128))
    }

    fn require_i64(&self, name: &str) -> Result<i64, ToolResult> {
        self.get(name)
            .and_then(|v| v.as_i64())
            .ok_or_else(|| missing("integer", name))
    }

    fn require_u32(&self, name: &str) -> Result<u32, ToolResult> {
        let raw = self
            .get(name)
            .and_then(|v| v.as_u64())
            .ok_or_else(|| missing("integer", name))?;
        u32::try_from(raw).map_err(|_| out_of_range("u32", name, raw as i128))
    }

    fn require_u64(&self, name: &str) -> Result<u64, ToolResult> {
        self.get(name)
            .and_then(|v| v.as_u64())
            .ok_or_else(|| missing("integer", name))
    }

    fn require_f64(&self, name: &str) -> Result<f64, ToolResult> {
        self.get(name)
            .and_then(|v| v.as_f64())
            .ok_or_else(|| missing("number", name))
    }

    fn require_str(&self, name: &str) -> Result<String, ToolResult> {
        self.get(name)
            .and_then(|v| v.as_str())
            .map(str::to_owned)
            .ok_or_else(|| missing("string", name))
    }

    fn require_bool(&self, name: &str) -> Result<bool, ToolResult> {
        self.get(name)
            .and_then(|v| v.as_bool())
            .ok_or_else(|| missing("boolean", name))
    }

    fn opt_i32(&self, name: &str) -> Result<Option<i32>, ToolResult> {
        match self.get(name) {
            None | Some(Value::Null) => Ok(None),
            Some(v) => {
                let raw = v.as_i64().ok_or_else(|| wrong_type("integer", name))?;
                i32::try_from(raw)
                    .map(Some)
                    .map_err(|_| out_of_range("i32", name, raw as i128))
            }
        }
    }

    fn opt_u32(&self, name: &str) -> Result<Option<u32>, ToolResult> {
        match self.get(name) {
            None | Some(Value::Null) => Ok(None),
            Some(v) => {
                let raw = v.as_u64().ok_or_else(|| wrong_type("integer", name))?;
                u32::try_from(raw)
                    .map(Some)
                    .map_err(|_| out_of_range("u32", name, raw as i128))
            }
        }
    }

    fn opt_u64(&self, name: &str) -> Option<u64> {
        self.get(name).and_then(|v| v.as_u64())
    }

    fn opt_i64(&self, name: &str) -> Option<i64> {
        self.get(name).and_then(|v| v.as_i64())
    }

    fn opt_f64(&self, name: &str) -> Option<f64> {
        self.get(name).and_then(|v| v.as_f64())
    }

    fn opt_str(&self, name: &str) -> Option<String> {
        self.get(name).and_then(|v| v.as_str()).map(str::to_owned)
    }

    fn opt_bool(&self, name: &str) -> Option<bool> {
        self.get(name).and_then(|v| v.as_bool())
    }

    fn u64_or(&self, name: &str, default: u64) -> u64 {
        self.opt_u64(name).unwrap_or(default)
    }

    fn i64_or(&self, name: &str, default: i64) -> i64 {
        self.opt_i64(name).unwrap_or(default)
    }

    fn f64_or(&self, name: &str, default: f64) -> f64 {
        self.opt_f64(name).unwrap_or(default)
    }

    fn str_or<'a>(&'a self, name: &str, default: &'a str) -> String {
        self.opt_str(name).unwrap_or_else(|| default.to_owned())
    }

    fn bool_or(&self, name: &str, default: bool) -> bool {
        self.opt_bool(name).unwrap_or(default)
    }

    fn str_array(&self, name: &str) -> Vec<String> {
        self.get(name)
            .and_then(|v| v.as_array())
            .map(|arr| {
                arr.iter()
                    .filter_map(|v| v.as_str().map(str::to_owned))
                    .collect()
            })
            .unwrap_or_default()
    }
}

// ── Tests ─────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    #[test]
    fn require_i32_happy_path() {
        let args = json!({ "pid": 1234 });
        assert_eq!(args.require_i32("pid").unwrap(), 1234);
    }

    #[test]
    fn require_i32_missing_returns_actionable_error() {
        let args = json!({});
        let err = args.require_i32("pid").unwrap_err();
        let body = format!("{:?}", err.content[0]);
        assert!(body.contains("Missing required integer field: pid"));
    }

    #[test]
    fn require_i32_out_of_range_rejected() {
        // i32::MAX + 1 doesn't fit in i32.
        let args = json!({ "pid": (i32::MAX as i64) + 1 });
        let err = args.require_i32("pid").unwrap_err();
        let body = format!("{:?}", err.content[0]);
        assert!(body.contains("out of range for i32"));
    }

    #[test]
    fn require_u32_out_of_range_rejected() {
        let args = json!({ "window_id": (u32::MAX as u64) + 1 });
        let err = args.require_u32("window_id").unwrap_err();
        let body = format!("{:?}", err.content[0]);
        assert!(body.contains("out of range for u32"));
    }

    #[test]
    fn require_str_missing_says_string() {
        let args = json!({});
        let err = args.require_str("text").unwrap_err();
        let body = format!("{:?}", err.content[0]);
        assert!(body.contains("Missing required string field: text"));
    }

    #[test]
    fn opt_u32_returns_none_when_absent() {
        let args = json!({});
        assert_eq!(args.opt_u32("window_id").unwrap(), None);
    }

    #[test]
    fn opt_u32_returns_none_when_null() {
        let args = json!({ "window_id": null });
        assert_eq!(args.opt_u32("window_id").unwrap(), None);
    }

    #[test]
    fn opt_u32_present_and_in_range() {
        let args = json!({ "window_id": 42 });
        assert_eq!(args.opt_u32("window_id").unwrap(), Some(42));
    }

    #[test]
    fn opt_u32_present_but_wrong_type_errors() {
        let args = json!({ "window_id": "not a number" });
        assert!(args.opt_u32("window_id").is_err());
    }

    #[test]
    fn opt_u32_present_but_out_of_range_errors() {
        let args = json!({ "window_id": (u32::MAX as u64) + 1 });
        let err = args.opt_u32("window_id").unwrap_err();
        let body = format!("{:?}", err.content[0]);
        assert!(body.contains("out of range for u32"));
    }

    #[test]
    fn u64_or_returns_default_when_absent() {
        let args = json!({});
        assert_eq!(args.u64_or("delay_ms", 30), 30);
    }

    #[test]
    fn u64_or_returns_value_when_present() {
        let args = json!({ "delay_ms": 100 });
        assert_eq!(args.u64_or("delay_ms", 30), 100);
    }

    #[test]
    fn str_or_uses_default_when_absent() {
        let args = json!({});
        assert_eq!(args.str_or("button", "left"), "left");
    }

    #[test]
    fn str_array_handles_absent_and_non_string_entries() {
        let args = json!({});
        assert_eq!(args.str_array("modifiers"), Vec::<String>::new());

        let args = json!({ "modifiers": ["ctrl", "shift", 42, "alt"] });
        assert_eq!(
            args.str_array("modifiers"),
            vec!["ctrl".to_owned(), "shift".to_owned(), "alt".to_owned()]
        );
    }

    #[test]
    fn bool_or_handles_typical_cases() {
        let args = json!({});
        assert!(!args.bool_or("from_zoom", false));
        let args = json!({ "from_zoom": true });
        assert!(args.bool_or("from_zoom", false));
    }
}

/// Description of the `app` filter that `list_windows` accepts on every
/// platform.
pub const LIST_WINDOWS_APP_FILTER_DESCRIPTION: &str = "Only windows of apps whose name contains this text (case-insensitive), or whose bundle id equals it. Prefer this or `pid` over an unfiltered call, which returns every window on the host.";

/// Whether a window owned by `app_name` (and, where known, `bundle_id`)
/// passes `list_windows`' `app` filter: a case-insensitive substring of the
/// app name, or the exact bundle id. An empty filter matches everything.
pub fn app_filter_matches(filter: &str, app_name: &str, bundle_id: Option<&str>) -> bool {
    let filter = filter.trim();
    if filter.is_empty() {
        return true;
    }
    if bundle_id.is_some_and(|id| id.eq_ignore_ascii_case(filter)) {
        return true;
    }
    app_name.to_lowercase().contains(&filter.to_lowercase())
}

#[cfg(test)]
mod app_filter_tests {
    use super::app_filter_matches;

    #[test]
    fn matches_name_substrings_and_exact_bundle_ids() {
        assert!(app_filter_matches("libreoffice", "LibreOffice", None));
        assert!(app_filter_matches("Office", "LibreOffice", None));
        assert!(app_filter_matches(
            "com.google.Chrome",
            "Google Chrome",
            Some("com.google.Chrome")
        ));
        assert!(app_filter_matches(
            "COM.GOOGLE.CHROME",
            "Google Chrome",
            Some("com.google.Chrome")
        ));
        assert!(app_filter_matches("  ", "Anything", None));
        assert!(!app_filter_matches(
            "Safari",
            "Google Chrome",
            Some("com.google.Chrome")
        ));
        assert!(!app_filter_matches("com.google", "Finder", None));
    }
}
