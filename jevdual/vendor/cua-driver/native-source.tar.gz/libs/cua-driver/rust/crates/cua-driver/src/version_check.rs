//! Startup "new version available" banner.
//!
//! On the interactive entry points (`mcp`, `serve`, `doctor`) we resolve the
//! latest release (see [`crate::release_source`]: the installer's own version
//! pin first, GitHub's REST API only as a fallback), cache the answer on disk
//! for an hour, and print a small two-line banner to **stderr** if a
//! strictly-newer release exists and the user hasn't dismissed it.
//!
//! Design constraints:
//!
//! - **Non-blocking.** [`maybe_announce_update`] returns instantly. The
//!   actual HTTP fetch runs on a background task (`tokio::task::spawn` when
//!   a runtime is already live, else a short-lived OS thread). If the
//!   network is slow, the daemon starts up regardless and the banner
//!   either lands on a later stderr line or appears next launch.
//! - **Silent on failure.** HTTP timeouts, 4xx/5xx, JSON-parse errors,
//!   refusal-to-write-cache — everything is `tracing::debug!` only. Never
//!   pollute the user's stderr with "couldn't check for updates" noise;
//!   the next launch just retries.
//! - **Cache-first, but never stale.** A cache younger than an hour
//!   short-circuits the network call, which bounds outbound requests on a hot
//!   reload loop. A cached answer is ignored when it was written by a
//!   different build (the binary was replaced since), or when it is older than
//!   the running version. Failed lookups are remembered for a few minutes so
//!   the background banner does not retry on every launch.
//! - **Opt-out at three layers.** Env var `CUA_DRIVER_RS_UPDATE_CHECK=false`
//!   (single invocation), persisted config `update_check_enabled = false`
//!   in `~/.cua-driver/config.json` (permanent), and an automatic skip when
//!   `CARGO_PKG_VERSION` carries any pre-release suffix (source / dev
//!   builds — there is no matching published release to recommend).
//! - **Skip in machine-readable contexts.** Only the long-running
//!   entry points call [`maybe_announce_update`]. `--version`,
//!   `list-tools`, `describe`, `call`, `dump-docs`, etc. are routinely
//!   piped through `jq` from scripts; a banner would corrupt parseable
//!   output. The decision lives at the call sites in `main.rs`, not here.

use std::path::PathBuf;
use std::time::{SystemTime, UNIX_EPOCH};

/// Disk-resident cache file (sibling of the telemetry artifacts under
/// `~/.cua-driver/`). Holds the last-seen latest version plus the list
/// of versions the user has actively dismissed.
const CACHE_FILE_NAME: &str = "version_check.json";

/// The pre-rename home. [`migrate_legacy_cache`] moves a cache written
/// there by an older build into the canonical home and drops the directory
/// once it is empty — same shape as the telemetry and skill-pack
/// migrations. Nothing in this module writes here.
const LEGACY_HOME_SUBDIRECTORY: &str = ".cua-driver-rs";

/// Single-invocation opt-out env var. Recognised values mirror the
/// telemetry opt-out: `0|false|no|off` disables the check, everything
/// else (including unset) leaves it on.
const ENV_UPDATE_CHECK: &str = "CUA_DRIVER_RS_UPDATE_CHECK";

/// Refresh threshold for a cached *result*. Short enough that a release
/// published today is visible within the hour; long enough to bound outbound
/// requests when the daemon restarts repeatedly.
const CACHE_REFRESH_SECONDS: u64 = 60 * 60; // 1 hour

/// How long the background banner waits after a failed lookup before trying
/// again. Explicit `check-update` / `update` calls ignore this.
const ERROR_BACKOFF_SECONDS: u64 = 5 * 60;

/// Tag-name prefix used by the Rust-port releases on the trycua/cua repo.
/// Releases tagged with anything else (e.g. the Swift port's
/// `cua-driver-v*`) are filtered out so we never recommend the wrong binary.
pub const RELEASE_TAG_PREFIX: &str = "cua-driver-rs-v";
pub const NIGHTLY_RELEASE_TAG_PREFIX: &str = "nightly-cua-driver-rs-v";

// ── Public API ───────────────────────────────────────────────────────────

/// Kick off a background "is there a newer release?" check.
///
/// **Returns immediately.** The actual network round-trip happens on a
/// `tokio::task::spawn` task (when a runtime is live) or a short-lived
/// OS thread (sync entry points). The two-line banner is printed to
/// **stderr** if/when the check completes and finds a strictly-newer
/// non-dismissed version.
///
/// No-op when:
/// - `CUA_DRIVER_RS_UPDATE_CHECK` env var is set to a falsy value
/// - The persisted config flag `update_check_enabled` is `false`
/// - `CARGO_PKG_VERSION` has a pre-release suffix (source / dev build —
///   nothing on GitHub will be "newer" in a meaningful way)
pub fn maybe_announce_update() {
    if !is_enabled() {
        tracing::debug!(target: "cua_driver::version_check",
                        "update check skipped (opt-out / pre-release build)");
        return;
    }

    let current = env!("CARGO_PKG_VERSION").to_owned();

    let task = move || {
        run_check_and_announce(
            &current,
            || fetch_latest_version().map_err(|e| e.to_string()),
            std::io::stderr(),
            true,
        );
    };

    if tokio::runtime::Handle::try_current().is_ok() {
        tokio::task::spawn_blocking(task);
    } else {
        std::thread::Builder::new()
            .name("cua-version-check".into())
            .spawn(task)
            .ok();
    }
}

/// Structured snapshot returned by [`check_update_state`] — the canonical
/// payload behind both `cua-driver check-update --json` and the
/// `check_for_update` MCP tool. Hermes branches on `update_available`.
///
/// Fields mirror the JSON schema documented in the user-facing
/// `getting-started/updating` page; field names use snake_case so a
/// serde-default JSON serialise round-trips cleanly into typed consumers
/// without a Deserialize impl on their side.
#[derive(serde::Serialize, Debug, Clone)]
pub struct UpdateState {
    pub current_version: String,
    pub current_channel: Option<&'static str>,
    pub selected_channel: Option<&'static str>,
    /// `None` when upstream checking is unavailable or failed without a cache —
    /// the `error` field carries the human-readable reason.
    pub latest_version: Option<String>,
    pub update_available: bool,
    /// Always `"github_releases"` today. A constant on the wire so future
    /// alternate sources (private registries, mirrors) can be slotted in
    /// without breaking existing consumers that key off this string.
    pub source: &'static str,
    /// ISO-8601 UTC timestamp of when this check ran (NOT when the cached
    /// result was originally fetched — see `cache_hit`).
    pub checked_at: String,
    /// `true` when the result came from the on-disk cache.
    pub cache_hit: bool,
    /// Shell one-liner to apply the update. `None` when already up-to-date
    /// or the check failed.
    pub install_command: Option<String>,
    /// URL of the release notes page on GitHub. `None` when already
    /// up-to-date or the check failed.
    pub release_notes_url: Option<String>,
    /// Human-readable reason an upstream check is unavailable or failed
    /// without a cache. `None` on success / cache fallback.
    pub error: Option<String>,
}

/// Emit the bounded result of an explicit update check. The structured state
/// remains the source of truth for CLI/MCP output; telemetry receives only a
/// closed outcome, a strict public release version, and the cache flag.
pub(crate) fn capture_update_state(
    state: &UpdateState,
    source: crate::telemetry::UpdateCheckSource,
) {
    let outcome = if state.update_available {
        crate::telemetry::UpdateCheckOutcome::Available
    } else if state.latest_version.is_some() {
        crate::telemetry::UpdateCheckOutcome::UpToDate
    } else {
        crate::telemetry::UpdateCheckOutcome::Unavailable
    };
    crate::telemetry::capture_update_checked(
        source,
        outcome,
        state.latest_version.as_deref(),
        state.cache_hit,
    );
}

/// Build the canonical install one-liner for the current target.
///
/// Lives here (rather than in the `cua-driver` crate's `updater.rs`) so the
/// MCP tool in this crate doesn't pull a circular dep. Both call sites
/// emit the same string as the docs' canonical install URL.
fn install_one_liner() -> String {
    #[cfg(windows)]
    {
        "irm https://cua.ai/driver/install.ps1 | iex".to_owned()
    }
    #[cfg(not(windows))]
    {
        "curl -fsSL https://cua.ai/driver/install.sh | bash".to_owned()
    }
}

/// Run a check and return a structured result.
///
/// Drives the same fetch + cache primitives the launch-time banner uses,
/// so the two paths never disagree on which tag is "latest". Respects the
/// 1-hour `CACHE_REFRESH_SECONDS` unless `no_cache=true`, which forces a
/// fresh lookup (and rewrites the cache on success).
///
/// Never panics, never returns an error type — fetch failures land in
/// `UpdateState.error` with a non-empty `current_version` so consumers
/// always get a well-formed payload they can branch on.
pub fn check_update_state(no_cache: bool) -> UpdateState {
    check_update_state_with_ownership(no_cache, crate::updater::is_pacman_managed())
}

pub(crate) fn check_update_state_with_ownership(no_cache: bool, managed: bool) -> UpdateState {
    let current = env!("CARGO_PKG_VERSION").to_owned();
    let now = unix_now();
    let checked_at = iso8601(now);

    let current_channel = crate::release_channel::ReleaseChannel::from_version(&current);
    if managed {
        return UpdateState {
            current_version: current,
            current_channel: current_channel.map(|channel| channel.as_str()),
            selected_channel: None,
            latest_version: None,
            update_available: false,
            source: "github_releases",
            checked_at,
            cache_hit: false,
            install_command: None,
            release_notes_url: None,
            error: Some(crate::updater::PACMAN_UPDATE_GUIDANCE.to_owned()),
        };
    }
    let selected_channel = match crate::release_channel::selected() {
        Ok(channel) => channel,
        Err(error) => {
            return UpdateState {
                current_version: current,
                current_channel: current_channel.map(|channel| channel.as_str()),
                selected_channel: None,
                latest_version: None,
                update_available: false,
                source: "github_releases",
                checked_at,
                cache_hit: false,
                install_command: None,
                release_notes_url: None,
                error: Some(format!(
                    "{error}; run `cua-driver channel set stable` or `cua-driver channel set nightly` to repair it"
                )),
            };
        }
    };

    let cached = read_cache().unwrap_or_default();

    // Honour the cache unless caller explicitly asked us to bypass it.
    // Mirrors `npm outdated --no-cache` / `brew update --force` semantics.
    let use_cache = !no_cache && cache_is_usable(&cached, now, &current, selected_channel);

    let (latest, cache_hit, fetch_error) = if use_cache {
        (cached.latest_version.clone(), true, None)
    } else {
        match fetch_latest_version_for(selected_channel) {
            Ok(v) => {
                // Persist on success so the next launch can reuse the answer.
                persist_result(&cached, now, &current, selected_channel, &v);
                (Some(v), false, None)
            }
            Err(e) => {
                tracing::debug!(target: "cua_driver::version_check",
                                "fetch failed: {e}");
                persist_error(&cached, now);
                // Fall back to a cached answer we still trust (same build and
                // channel, not behind the running version) — better a slightly
                // old answer than none. The error surfaces only otherwise.
                match cached
                    .latest_version
                    .clone()
                    .filter(|_| cache_is_trustworthy(&cached, &current, selected_channel))
                {
                    Some(v) => (Some(v), true, None),
                    None => (None, false, Some(e.to_string())),
                }
            }
        }
    };

    let update_available = latest
        .as_deref()
        .map(|latest| update_is_available(latest, &current, current_channel, selected_channel))
        .unwrap_or(false);

    let (install_command, release_notes_url) = if update_available {
        let l = latest.as_deref().unwrap_or("");
        (
            Some(install_one_liner()),
            Some(format!(
                "https://github.com/trycua/cua/releases/tag/{}{l}",
                tag_prefix(selected_channel)
            )),
        )
    } else {
        (None, None)
    };

    UpdateState {
        current_version: current,
        current_channel: current_channel.map(|channel| channel.as_str()),
        selected_channel: Some(selected_channel.as_str()),
        latest_version: latest,
        update_available,
        source: "github_releases",
        checked_at,
        cache_hit,
        install_command,
        release_notes_url,
        error: fetch_error,
    }
}

// ── Cache policy ─────────────────────────────────────────────────────────

/// The cache may be consulted for this build and channel at all.
///
/// Rejects an answer that cannot be right: it names another channel, it was
/// written by a different build (the binary was replaced since, so "latest"
/// has likely moved), or it is older than the running version.
fn cache_is_trustworthy(
    cached: &VersionCache,
    current: &str,
    channel: crate::release_channel::ReleaseChannel,
) -> bool {
    let Some(latest) = cached.latest_version.as_deref() else {
        return false;
    };
    let channel_matches = cached.channel.as_deref().unwrap_or("stable") == channel.as_str();
    let same_build = cached.checked_by_version.as_deref() == Some(current);
    let behind_installed = crate::release_channel::ReleaseChannel::from_version(current)
        == Some(channel)
        && is_newer(current, latest);
    channel_matches && same_build && !behind_installed
}

/// The cache is trustworthy *and* young enough to skip the lookup.
fn cache_is_usable(
    cached: &VersionCache,
    now: u64,
    current: &str,
    channel: crate::release_channel::ReleaseChannel,
) -> bool {
    let fresh = cached
        .last_checked_unix
        .map(|t| t <= now && now - t < CACHE_REFRESH_SECONDS)
        .unwrap_or(false);
    fresh && cache_is_trustworthy(cached, current, channel)
}

/// Record a successful lookup, keeping the user's dismissals.
fn persist_result(
    previous: &VersionCache,
    now: u64,
    current: &str,
    channel: crate::release_channel::ReleaseChannel,
    latest: &str,
) {
    let cache = VersionCache {
        last_checked_unix: Some(now),
        last_checked_at: Some(iso8601(now)),
        latest_version: Some(latest.to_owned()),
        channel: Some(channel.as_str().to_owned()),
        checked_by_version: Some(current.to_owned()),
        last_error_unix: None,
        dismissed_versions: previous.dismissed_versions.clone(),
    };
    if let Err(e) = write_cache(&cache) {
        tracing::debug!(target: "cua_driver::version_check", "failed to write cache: {e}");
    }
}

/// Record a failed lookup without disturbing the last good result.
fn persist_error(previous: &VersionCache, now: u64) {
    let cache = VersionCache {
        last_error_unix: Some(now),
        ..previous.clone()
    };
    if let Err(e) = write_cache(&cache) {
        tracing::debug!(target: "cua_driver::version_check", "failed to write cache: {e}");
    }
}

/// Drop the cached result (keeping dismissals) so the next check looks again.
///
/// Called after a successful install: the answer that was true before the
/// install says nothing about what is latest now.
pub(crate) fn invalidate_cache() {
    let Some(previous) = read_cache() else { return };
    let cache = VersionCache {
        dismissed_versions: previous.dismissed_versions,
        ..Default::default()
    };
    if let Err(e) = write_cache(&cache) {
        tracing::debug!(target: "cua_driver::version_check", "failed to invalidate cache: {e}");
    }
}

/// Record the result of an explicit `cua-driver update` lookup so the cache
/// reflects what the user was just told.
pub(crate) fn record_latest(channel: crate::release_channel::ReleaseChannel, latest: &str) {
    let previous = read_cache().unwrap_or_default();
    persist_result(
        &previous,
        unix_now(),
        env!("CARGO_PKG_VERSION"),
        channel,
        latest,
    );
}

// ── Core logic (testable seam) ───────────────────────────────────────────

/// Inner routine wired up by [`maybe_announce_update`].
///
/// Split out from the public entry point so tests can drive the check
/// against a stubbed fetcher and capture the banner into an in-memory
/// buffer. Errors here never propagate — the function consumes them
/// and converts to `tracing::debug!` lines.
fn run_check_and_announce<F, W>(current: &str, fetch: F, mut writer: W, capture_telemetry: bool)
where
    F: FnOnce() -> Result<String, String>,
    W: std::io::Write,
{
    run_check_and_announce_with_ownership(
        current,
        fetch,
        &mut writer,
        capture_telemetry,
        crate::updater::is_pacman_managed(),
    );
}

fn run_check_and_announce_with_ownership<F, W>(
    current: &str,
    fetch: F,
    mut writer: W,
    capture_telemetry: bool,
    managed: bool,
) where
    F: FnOnce() -> Result<String, String>,
    W: std::io::Write,
{
    if managed {
        return;
    }
    let now = unix_now();
    let Ok(selected_channel) = crate::release_channel::selected() else {
        return;
    };

    // Decide whether the cache is still good enough to skip the network.
    let cached = read_cache().unwrap_or_default();
    let trusted = cache_is_trustworthy(&cached, current, selected_channel);
    let needs_refresh = !cache_is_usable(&cached, now, current, selected_channel);
    let backing_off = cached
        .last_error_unix
        .map(|t| t <= now && now - t < ERROR_BACKOFF_SECONDS)
        .unwrap_or(false);

    let (latest, cache_hit) = if needs_refresh && !backing_off {
        match fetch() {
            Ok(v) => {
                // Persist on success so the next launch re-uses the answer.
                persist_result(&cached, now, current, selected_channel, &v);
                (v, false)
            }
            Err(e) => {
                tracing::debug!(target: "cua_driver::version_check",
                                "fetch failed: {e}");
                persist_error(&cached, now);
                // Fall back to a trusted cached value if any — better an old
                // banner than none on a brief network blip.
                match cached.latest_version.clone().filter(|_| trusted) {
                    Some(v) => (v, true),
                    None => return,
                }
            }
        }
    } else {
        match cached.latest_version.clone().filter(|_| trusted) {
            Some(v) => (v, true),
            None => return,
        }
    };

    // Re-read dismissals: another writer may have updated the cache between
    // our load and now.
    let dismissed = read_cache()
        .map(|c| c.dismissed_versions)
        .unwrap_or(cached.dismissed_versions);

    let current_channel = crate::release_channel::ReleaseChannel::from_version(current);
    if !update_is_available(&latest, current, current_channel, selected_channel) {
        return;
    }
    if dismissed.iter().any(|v| v == &latest) {
        tracing::debug!(target: "cua_driver::version_check",
                        "newer version {latest} dismissed; skipping banner");
        return;
    }

    // Background entry points can be hot-restarted. Record availability only
    // on the freshness-bounded network check, not on every cached banner.
    if capture_telemetry && !cache_hit {
        crate::telemetry::capture_update_checked(
            crate::telemetry::UpdateCheckSource::Background,
            crate::telemetry::UpdateCheckOutcome::Available,
            Some(&latest),
            false,
        );
    }

    let banner = format_banner(&latest, current, selected_channel);
    if let Err(e) = writer.write_all(banner.as_bytes()) {
        tracing::debug!(target: "cua_driver::version_check",
                        "failed to print banner: {e}");
    }
}

/// Format the two-line banner. Plain text, no ANSI colours — terminals
/// without UTF-8 still see the `✨` byte sequence but the text is
/// readable either way.
fn format_banner(
    latest: &str,
    current: &str,
    channel: crate::release_channel::ReleaseChannel,
) -> String {
    format!(
        "\n\u{2728} cua-driver v{latest} is available (you have v{current}).\n   \
         Update with: cua-driver update\n   \
         Release notes: https://github.com/trycua/cua/releases/tag/{prefix}{latest}\n\n",
        prefix = tag_prefix(channel),
    )
}

// ── Enable / disable logic ───────────────────────────────────────────────

/// True when the update check should run on this invocation.
///
/// Order of precedence (any one being "off" wins):
/// 1. Env var `CUA_DRIVER_RS_UPDATE_CHECK` (falsy → off)
/// 2. Persisted config `update_check_enabled` (false → off)
/// 3. Built `CARGO_PKG_VERSION` is a pre-release (`-dev`, `-rc.1`, …) → off
fn is_enabled() -> bool {
    if let Some(false) = parse_env_bool(ENV_UPDATE_CHECK) {
        return false;
    }
    if let Some(false) = read_config_flag() {
        return false;
    }
    if is_prerelease(env!("CARGO_PKG_VERSION"))
        && crate::release_channel::ReleaseChannel::from_version(env!("CARGO_PKG_VERSION"))
            != Some(crate::release_channel::ReleaseChannel::Nightly)
    {
        return false;
    }
    true
}

/// Read the `update_check_enabled` flag out of the same JSON config file
/// the `cua-driver config set` subcommand writes to. Returns `None` when
/// the file is missing, unreadable, or doesn't have the key.
fn read_config_flag() -> Option<bool> {
    let home = std::env::var_os("HOME").or_else(|| std::env::var_os("USERPROFILE"))?;
    let path = PathBuf::from(home)
        .join(crate::bundle::user_home_subdirectory())
        .join("config.json");
    let raw = std::fs::read_to_string(&path).ok()?;
    let json: serde_json::Value = serde_json::from_str(&raw).ok()?;
    json.get("update_check_enabled").and_then(|v| v.as_bool())
}

fn parse_env_bool(var: &str) -> Option<bool> {
    let raw = std::env::var(var).ok()?;
    match raw.trim().to_ascii_lowercase().as_str() {
        "0" | "false" | "no" | "off" => Some(false),
        "1" | "true" | "yes" | "on" => Some(true),
        _ => None,
    }
}

/// True when `version` carries any semver pre-release suffix.
///
/// Returns `true` (skip the check) for unparseable strings too — better
/// to silently skip than to print a banner against a malformed version.
pub(crate) fn is_prerelease(version: &str) -> bool {
    match semver::Version::parse(version) {
        Ok(v) => !v.pre.is_empty(),
        Err(_) => true,
    }
}

// ── Semver comparison ────────────────────────────────────────────────────

/// True when `latest` is strictly newer than `current` under semver.
///
/// Unparseable inputs return `false` so a broken release tag or
/// `CARGO_PKG_VERSION` quirk can never produce a spurious "update
/// available" banner. We'd rather miss a real update than nag the user
/// about a phantom one.
pub fn is_newer(latest: &str, current: &str) -> bool {
    let Ok(l) = semver::Version::parse(latest) else {
        return false;
    };
    let Ok(c) = semver::Version::parse(current) else {
        return false;
    };
    l > c
}

pub fn update_is_available(
    latest: &str,
    current: &str,
    current_channel: Option<crate::release_channel::ReleaseChannel>,
    selected_channel: crate::release_channel::ReleaseChannel,
) -> bool {
    current_channel
        .map(|channel| channel != selected_channel)
        .unwrap_or(false)
        || is_newer(latest, current)
}

// ── On-disk cache ────────────────────────────────────────────────────────

/// Serialised shape of `~/.cua-driver/version_check.json`.
///
/// `last_checked_unix` is the source of truth for cache-age decisions;
/// `last_checked_at` is the same instant rendered as ISO-8601 for human
/// inspection of the file. Both fields are optional so we can write
/// partial state (e.g. only a dismissed list) without forcing a sentinel.
#[derive(Debug, Default, Clone, serde::Serialize, serde::Deserialize)]
pub(crate) struct VersionCache {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub last_checked_unix: Option<u64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub last_checked_at: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub latest_version: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub channel: Option<String>,
    /// Version of the cua-driver build that wrote `latest_version`. A cache
    /// written by another build is not trusted: the binary was replaced since
    /// (an install or update), which is exactly when "latest" has moved.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub checked_by_version: Option<String>,
    /// When the last lookup failed. Lets the background banner back off.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub last_error_unix: Option<u64>,
    #[serde(default)]
    pub dismissed_versions: Vec<String>,
}

/// Read the cache file. Returns `None` when missing / unreadable / not
/// valid JSON — callers fall back to the default (empty) shape.
fn read_cache() -> Option<VersionCache> {
    migrate_legacy_cache();
    let path = cache_path()?;
    let raw = std::fs::read_to_string(&path).ok()?;
    serde_json::from_str(&raw).ok()
}

/// Write the cache file. Creates the parent directory if missing.
/// IO errors propagate so the caller can decide whether to log; the
/// fire-and-forget callers in this module always swallow them.
fn write_cache(cache: &VersionCache) -> std::io::Result<()> {
    let path = cache_path().ok_or_else(|| {
        std::io::Error::new(
            std::io::ErrorKind::NotFound,
            "no HOME / USERPROFILE — cannot resolve version_check cache path",
        )
    })?;
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let json = serde_json::to_string_pretty(cache)
        .map_err(|e| std::io::Error::new(std::io::ErrorKind::InvalidData, e))?;
    std::fs::write(&path, json)
}

fn home_root() -> Option<PathBuf> {
    let home = std::env::var_os("HOME").or_else(|| std::env::var_os("USERPROFILE"))?;
    Some(PathBuf::from(home))
}

fn cache_path() -> Option<PathBuf> {
    Some(
        home_root()?
            .join(crate::bundle::user_home_subdirectory())
            .join(CACHE_FILE_NAME),
    )
}

/// Pre-rename cache location. `None` for the source-build product, which
/// has always used its own `~/.cua-driver-local/` home and never wrote here.
fn legacy_cache_path() -> Option<PathBuf> {
    if crate::bundle::is_local_installation() {
        return None;
    }
    Some(
        home_root()?
            .join(LEGACY_HOME_SUBDIRECTORY)
            .join(CACHE_FILE_NAME),
    )
}

/// Move a pre-rename cache into the canonical home, then remove the legacy
/// directory if nothing else is left in it.
///
/// Best-effort and idempotent: every step is allowed to fail silently, and
/// the caller falls back to an empty cache exactly as it would for a missing
/// file. Keeping the dismissed-version list is the only reason to bother —
/// losing it would re-nag the user about a release they already dismissed.
fn migrate_legacy_cache() {
    let (Some(legacy), Some(current)) = (legacy_cache_path(), cache_path()) else {
        return;
    };
    if !legacy.is_file() {
        return;
    }
    if !current.is_file() {
        if let Some(parent) = current.parent() {
            if std::fs::create_dir_all(parent).is_err() {
                return;
            }
        }
        if std::fs::rename(&legacy, &current).is_err() {
            return;
        }
    }
    // The rename already took the source, or a canonical cache was already
    // present and wins. Only the latter path still has a stale copy to remove.
    let _ = std::fs::remove_file(&legacy);
    if let Some(parent) = legacy.parent() {
        let _ = std::fs::remove_dir(parent);
    }
}

// ── HTTP fetch (shared with the `update` subcommand) ─────────────────────

/// Resolve the latest release for the saved channel.
///
/// Delegates to [`crate::release_source::resolve_latest`]: for stable, the
/// version pinned in the installer (the source `install.sh` itself uses),
/// then the GitHub releases API (with `GH_TOKEN` / `GITHUB_TOKEN` when set),
/// then the releases feed. Tags that don't start with the channel's prefix
/// (Swift port, lume, SDK releases) and drafts are ignored; stable accepts
/// only plain `x.y.z`.
///
/// Returns the bare version string (e.g. `"0.1.4"`) on success. The error
/// distinguishes a GitHub API rate limit from a real network failure.
pub fn fetch_latest_version() -> Result<String, crate::release_source::FetchError> {
    let channel =
        crate::release_channel::selected().map_err(crate::release_source::FetchError::Other)?;
    fetch_latest_version_for(channel)
}

pub fn fetch_latest_version_for(
    channel: crate::release_channel::ReleaseChannel,
) -> Result<String, crate::release_source::FetchError> {
    if crate::updater::is_pacman_managed() {
        return Err(crate::release_source::FetchError::Other(
            crate::updater::PACMAN_UPDATE_GUIDANCE.to_owned(),
        ));
    }
    crate::release_source::resolve_latest(
        &crate::release_source::UreqClient::new(),
        &crate::release_source::Endpoints::default(),
        channel,
        crate::release_source::token_from_env().as_deref(),
    )
}

/// Pull the highest non-draft `cua-driver-rs-v*` tag out of the parsed
/// releases response. Split out so unit tests can feed in canned JSON
/// without hitting the network. Pre-release flag is intentionally
/// ignored — see `fetch_latest_version` doc-comment.
#[cfg(test)]
pub(crate) fn pick_latest_release(
    body: &serde_json::Value,
    channel: crate::release_channel::ReleaseChannel,
) -> Option<String> {
    pick_latest_release_excluding(body, channel, &[])
}

/// [`pick_latest_release`] that also skips withdrawn versions (bare, e.g.
/// `"0.28.3"`), as the installer does.
pub(crate) fn pick_latest_release_excluding(
    body: &serde_json::Value,
    channel: crate::release_channel::ReleaseChannel,
    withdrawn: &[String],
) -> Option<String> {
    let releases = body.as_array()?;
    let mut versions: Vec<semver::Version> = releases
        .iter()
        .filter_map(|r| {
            let tag = r.get("tag_name")?.as_str()?;
            let bare = tag.strip_prefix(tag_prefix(channel))?;
            if r.get("draft").and_then(|d| d.as_bool()).unwrap_or(false) {
                return None;
            }
            let version = semver::Version::parse(bare).ok()?;
            if withdrawn.iter().any(|w| w == bare) {
                return None;
            }
            match channel {
                crate::release_channel::ReleaseChannel::Stable
                    if !version.pre.is_empty() || !version.build.is_empty() =>
                {
                    return None
                }
                crate::release_channel::ReleaseChannel::Nightly
                    if !is_canonical_nightly(&version) =>
                {
                    return None
                }
                _ => {}
            }
            Some(version)
        })
        .collect();
    versions.sort();
    versions.last().map(|v| v.to_string())
}

pub(crate) fn tag_prefix(channel: crate::release_channel::ReleaseChannel) -> &'static str {
    match channel {
        crate::release_channel::ReleaseChannel::Stable => RELEASE_TAG_PREFIX,
        crate::release_channel::ReleaseChannel::Nightly => NIGHTLY_RELEASE_TAG_PREFIX,
    }
}

fn is_canonical_nightly(version: &semver::Version) -> bool {
    let parts: Vec<&str> = version.pre.as_str().split('.').collect();
    parts.len() == 3
        && parts[0] == "nightly"
        && parts[1].len() == 8
        && parts[1].bytes().all(|byte| byte.is_ascii_digit())
        && parts[2].parse::<u64>().map(|run| run > 0).unwrap_or(false)
        && version.build.is_empty()
}

// ── Time helpers ─────────────────────────────────────────────────────────

pub(crate) fn unix_now() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0)
}

/// Render a unix timestamp as `YYYY-MM-DDTHH:MM:SSZ`. Mirrors the
/// telemetry module's formatter so the on-disk cache file stays
/// human-readable without dragging in `chrono`.
pub(crate) fn iso8601(unix_secs: u64) -> String {
    let (year, month, day, hour, minute, second) = civil_from_unix(unix_secs);
    format!("{year:04}-{month:02}-{day:02}T{hour:02}:{minute:02}:{second:02}Z")
}

fn civil_from_unix(unix_secs: u64) -> (i32, u32, u32, u32, u32, u32) {
    let days = (unix_secs / 86_400) as i64;
    let secs_of_day = (unix_secs % 86_400) as u32;
    let hour = secs_of_day / 3600;
    let minute = (secs_of_day % 3600) / 60;
    let second = secs_of_day % 60;

    // Howard Hinnant's civil_from_days, shifted to 0000-03-01 era epoch.
    let z = days + 719_468;
    let era = z.div_euclid(146_097);
    let doe = (z - era * 146_097) as u32;
    let yoe = (doe - doe / 1460 + doe / 36_524 - doe / 146_096) / 365;
    let y = yoe as i64 + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let m = if mp < 10 { mp + 3 } else { mp - 9 };
    let year = (y + if m <= 2 { 1 } else { 0 }) as i32;
    (year, m, d, hour, minute, second)
}

// ── Tests ────────────────────────────────────────────────────────────────

/// All env-mutating tests serialise on this lock — `std::env::set_var`
/// is process-global, parallel tests would race.
#[cfg(test)]
pub(crate) static ENV_LOCK: std::sync::Mutex<()> = std::sync::Mutex::new(());

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Mutex;

    #[test]
    fn pacman_managed_check_ignores_upstream_cache_and_channel() {
        let _g = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        with_isolated_home(|home| {
            write_cache(&VersionCache {
                latest_version: Some("999.0.0".into()),
                last_checked_unix: Some(unix_now()),
                ..Default::default()
            })
            .unwrap();
            std::fs::write(
                home.join(crate::bundle::user_home_subdirectory())
                    .join("release-channel"),
                "invalid-channel\n",
            )
            .unwrap();
            let before = std::fs::read(cache_path().unwrap()).unwrap();
            for no_cache in [false, true] {
                let state = check_update_state_with_ownership(no_cache, true);
                assert!(!state.update_available);
                assert!(!state.cache_hit);
                assert!(state.latest_version.is_none());
                assert!(state.selected_channel.is_none());
                assert!(state.install_command.is_none());
                assert!(state.release_notes_url.is_none());
                assert!(state.error.unwrap().contains("sudo pacman -Syu"));
                assert_eq!(std::fs::read(cache_path().unwrap()).unwrap(), before);
            }
        });
    }

    #[test]
    fn pacman_managed_startup_never_fetches_or_prints_banner() {
        let mut banner = Vec::new();
        run_check_and_announce_with_ownership(
            "0.24.0",
            || panic!("managed startup must not fetch"),
            &mut banner,
            false,
            true,
        );
        assert!(banner.is_empty());
    }

    use super::ENV_LOCK;

    /// Redirect `HOME` / `USERPROFILE` to a fresh temp dir for the body
    /// of `f`, then restore. Ensures the cache file lives in an isolated
    /// directory and never touches the developer's real
    /// `~/.cua-driver/version_check.json`.
    fn with_isolated_home<R>(f: impl FnOnce(&std::path::Path) -> R) -> R {
        let tmp = tempfile::tempdir().expect("tempdir");
        let saved_home = std::env::var_os("HOME");
        let saved_userprofile = std::env::var_os("USERPROFILE");
        unsafe {
            std::env::set_var("HOME", tmp.path());
        }
        unsafe {
            std::env::set_var("USERPROFILE", tmp.path());
        }

        let result = f(tmp.path());

        match saved_home {
            Some(s) => unsafe {
                std::env::set_var("HOME", s);
            },
            None => unsafe {
                std::env::remove_var("HOME");
            },
        }
        match saved_userprofile {
            Some(s) => unsafe {
                std::env::set_var("USERPROFILE", s);
            },
            None => unsafe {
                std::env::remove_var("USERPROFILE");
            },
        }
        result
    }

    // ── is_newer ────────────────────────────────────────────────────────

    #[test]
    fn is_newer_recognises_strict_patch_bump() {
        assert!(is_newer("0.1.4", "0.1.3"));
    }

    #[test]
    fn is_newer_recognises_minor_bump_past_double_digit() {
        // 0.2.0 > 0.1.99 — naive lexicographic compare would fail here.
        assert!(is_newer("0.2.0", "0.1.99"));
    }

    #[test]
    fn is_newer_treats_pre_release_as_lower_than_release() {
        // 0.1.3 > 0.1.3-dev — semver rule: release > pre-release of same triple.
        assert!(is_newer("0.1.3", "0.1.3-dev"));
    }

    #[test]
    fn channel_mismatch_is_available_even_when_target_version_is_lower() {
        use crate::release_channel::ReleaseChannel::{Nightly, Stable};
        assert!(update_is_available(
            "0.19.3",
            "0.19.4-nightly.20260812.42",
            Some(Nightly),
            Stable,
        ));
        assert!(!update_is_available(
            "0.19.3",
            "0.19.4",
            Some(Stable),
            Stable,
        ));
    }

    #[test]
    fn is_newer_returns_false_for_equal_versions() {
        assert!(!is_newer("0.1.3", "0.1.3"));
    }

    #[test]
    fn is_newer_returns_false_for_older_candidate() {
        assert!(!is_newer("0.1.2", "0.1.3"));
        assert!(!is_newer("0.0.99", "0.1.0"));
    }

    #[test]
    fn is_newer_returns_false_for_unparseable_input() {
        // Garbage in → false out. Better to miss a real update than nag
        // about a phantom one.
        assert!(!is_newer("not-a-version", "0.1.3"));
        assert!(!is_newer("0.1.4", "broken"));
    }

    // ── Pre-release detection ───────────────────────────────────────────

    #[test]
    fn is_prerelease_flags_dev_and_rc_suffixes() {
        assert!(is_prerelease("0.1.4-dev"));
        assert!(is_prerelease("0.1.4-rc.1"));
        assert!(is_prerelease("0.1.4-beta"));
    }

    #[test]
    fn is_prerelease_passes_plain_release() {
        assert!(!is_prerelease("0.1.4"));
        assert!(!is_prerelease("1.0.0"));
    }

    #[test]
    fn is_prerelease_returns_true_for_garbage() {
        // Unparseable strings count as "pre-release" so the update check
        // skips them rather than blowing up.
        assert!(is_prerelease("not-a-version"));
        assert!(is_prerelease(""));
    }

    // ── Cache round-trip ────────────────────────────────────────────────

    #[test]
    fn cache_round_trips_through_tempdir() {
        let _g = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        with_isolated_home(|_| {
            let original = VersionCache {
                last_checked_unix: Some(1_700_000_000),
                last_checked_at: Some("2023-11-14T22:13:20Z".into()),
                latest_version: Some("0.1.4".into()),
                channel: Some("stable".into()),
                checked_by_version: Some("0.1.3".into()),
                last_error_unix: None,
                dismissed_versions: vec!["0.1.3".into()],
            };
            write_cache(&original).expect("write_cache");
            let read_back = read_cache().expect("read_cache");
            assert_eq!(read_back.last_checked_unix, Some(1_700_000_000));
            assert_eq!(read_back.latest_version.as_deref(), Some("0.1.4"));
            assert_eq!(read_back.dismissed_versions, vec!["0.1.3".to_owned()]);
        });
    }

    #[test]
    fn cache_lands_in_the_canonical_home() {
        let _g = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        with_isolated_home(|home| {
            write_cache(&VersionCache::default()).expect("write_cache");
            assert!(home
                .join(crate::bundle::user_home_subdirectory())
                .join(CACHE_FILE_NAME)
                .is_file());
            // The pre-rename home must not be re-created behind the
            // installer's back — sweeping it is what the installer does.
            assert!(!home.join(LEGACY_HOME_SUBDIRECTORY).exists());
        });
    }

    #[test]
    fn legacy_cache_is_migrated_and_its_home_removed() {
        let _g = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        with_isolated_home(|home| {
            let legacy_home = home.join(LEGACY_HOME_SUBDIRECTORY);
            std::fs::create_dir_all(&legacy_home).unwrap();
            std::fs::write(
                legacy_home.join(CACHE_FILE_NAME),
                r#"{"latest_version":"0.1.4","dismissed_versions":["0.1.4"]}"#,
            )
            .unwrap();

            let migrated = read_cache().expect("read_cache");
            assert_eq!(migrated.latest_version.as_deref(), Some("0.1.4"));
            assert_eq!(migrated.dismissed_versions, vec!["0.1.4".to_owned()]);
            assert!(home
                .join(crate::bundle::user_home_subdirectory())
                .join(CACHE_FILE_NAME)
                .is_file());
            assert!(!legacy_home.exists());
        });
    }

    #[test]
    fn migration_leaves_a_legacy_home_that_still_holds_other_files() {
        let _g = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        with_isolated_home(|home| {
            let legacy_home = home.join(LEGACY_HOME_SUBDIRECTORY);
            std::fs::create_dir_all(&legacy_home).unwrap();
            std::fs::write(legacy_home.join(CACHE_FILE_NAME), "{}").unwrap();
            std::fs::write(legacy_home.join(".telemetry_id"), "not-ours").unwrap();

            let _ = read_cache();

            // Our file is gone, somebody else's is untouched: the empty-dir
            // removal must never turn into a recursive delete.
            assert!(!legacy_home.join(CACHE_FILE_NAME).exists());
            assert!(legacy_home.join(".telemetry_id").is_file());
        });
    }

    #[test]
    fn failed_migration_preserves_the_legacy_cache() {
        let _g = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        with_isolated_home(|home| {
            let legacy_home = home.join(LEGACY_HOME_SUBDIRECTORY);
            let legacy_cache = legacy_home.join(CACHE_FILE_NAME);
            let legacy_json = r#"{"latest_version":"0.1.4","dismissed_versions":["0.1.4"]}"#;
            std::fs::create_dir_all(&legacy_home).unwrap();
            std::fs::write(&legacy_cache, legacy_json).unwrap();

            // A regular file at the canonical home prevents parent-directory
            // creation, making migration fail deterministically on every platform.
            std::fs::write(
                home.join(crate::bundle::user_home_subdirectory()),
                "not a directory",
            )
            .unwrap();

            assert!(read_cache().is_none());
            assert!(legacy_cache.is_file());
            let preserved = std::fs::read_to_string(legacy_cache).unwrap();
            assert_eq!(preserved, legacy_json);
        });
    }

    // ── 1h refresh threshold ────────────────────────────────────────────

    #[test]
    fn cache_older_than_threshold_triggers_refresh() {
        let _g = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        with_isolated_home(|_| {
            // Seed the cache 2 hours in the past.
            let now = unix_now();
            let stale = VersionCache {
                last_checked_unix: Some(now.saturating_sub(2 * 60 * 60)),
                last_checked_at: Some(iso8601(now.saturating_sub(2 * 60 * 60))),
                latest_version: Some("0.1.3".into()), // stale data
                channel: Some("stable".into()),
                checked_by_version: Some("0.1.3".into()),
                last_error_unix: None,
                dismissed_versions: vec![],
            };
            write_cache(&stale).unwrap();

            let mut buf: Vec<u8> = Vec::new();
            let fetch_calls = std::sync::atomic::AtomicUsize::new(0);
            run_check_and_announce(
                "0.1.3",
                || {
                    fetch_calls.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
                    Ok("0.1.4".to_owned()) // newer version returned by network
                },
                &mut buf,
                false,
            );

            assert_eq!(
                fetch_calls.load(std::sync::atomic::Ordering::SeqCst),
                1,
                "stale cache must trigger a fetch",
            );
            let banner = String::from_utf8(buf).unwrap();
            assert!(banner.contains("v0.1.4 is available"), "got: {banner:?}");
            assert!(banner.contains("you have v0.1.3"), "got: {banner:?}");
        });
    }

    #[test]
    fn cache_younger_than_threshold_skips_network() {
        let _g = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        with_isolated_home(|_| {
            // Seed the cache 30 minutes in the past with a known-newer version.
            let now = unix_now();
            let fresh = VersionCache {
                last_checked_unix: Some(now.saturating_sub(30 * 60)),
                last_checked_at: Some(iso8601(now.saturating_sub(30 * 60))),
                latest_version: Some("0.1.4".into()),
                channel: Some("stable".into()),
                checked_by_version: Some("0.1.3".into()),
                last_error_unix: None,
                dismissed_versions: vec![],
            };
            write_cache(&fresh).unwrap();

            let mut buf: Vec<u8> = Vec::new();
            let fetch_calls = std::sync::atomic::AtomicUsize::new(0);
            run_check_and_announce(
                "0.1.3",
                || {
                    fetch_calls.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
                    Ok("0.1.5".to_owned())
                },
                &mut buf,
                false,
            );

            assert_eq!(
                fetch_calls.load(std::sync::atomic::Ordering::SeqCst),
                0,
                "fresh cache must NOT trigger a fetch",
            );
            let banner = String::from_utf8(buf).unwrap();
            // Banner uses the cached value (0.1.4), not the would-be network value (0.1.5).
            assert!(banner.contains("v0.1.4 is available"), "got: {banner:?}");
        });
    }

    #[test]
    fn dismissed_latest_suppresses_banner() {
        let _g = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        with_isolated_home(|_| {
            // Cache is fresh and reports a newer version, but the user
            // dismissed exactly that version — banner must stay silent.
            let now = unix_now();
            let cache = VersionCache {
                last_checked_unix: Some(now),
                last_checked_at: Some(iso8601(now)),
                latest_version: Some("0.1.4".into()),
                channel: Some("stable".into()),
                checked_by_version: Some("0.1.3".into()),
                last_error_unix: None,
                dismissed_versions: vec!["0.1.4".into()],
            };
            write_cache(&cache).unwrap();

            let mut buf: Vec<u8> = Vec::new();
            run_check_and_announce("0.1.3", || Ok("0.1.4".to_owned()), &mut buf, false);
            assert!(buf.is_empty(), "dismissed version must suppress banner");
        });
    }

    // ── Stale-cache invalidation ────────────────────────────────────────

    fn seeded(now: u64, age: u64, latest: &str, built_by: Option<&str>) -> VersionCache {
        VersionCache {
            last_checked_unix: Some(now - age),
            last_checked_at: Some(iso8601(now - age)),
            latest_version: Some(latest.into()),
            channel: Some("stable".into()),
            checked_by_version: built_by.map(Into::into),
            last_error_unix: None,
            dismissed_versions: vec![],
        }
    }

    #[test]
    fn result_cache_is_usable_only_when_young_and_from_this_build() {
        use crate::release_channel::ReleaseChannel::Stable;
        let now = 1_800_000_000;
        // Young, same build: usable.
        assert!(cache_is_usable(
            &seeded(now, 60, "0.34.0", Some("0.33.0")),
            now,
            "0.33.0",
            Stable
        ));
        // Older than the 1h TTL: refresh (the 20h cache of #4755 is gone).
        assert!(!cache_is_usable(
            &seeded(now, 2 * 3600, "0.34.0", Some("0.33.0")),
            now,
            "0.33.0",
            Stable
        ));
        // Written by another build, e.g. before an install replaced the binary.
        assert!(!cache_is_usable(
            &seeded(now, 60, "0.33.4", Some("0.33.0")),
            now,
            "0.34.0",
            Stable
        ));
        // Legacy cache with no build recorded.
        assert!(!cache_is_usable(
            &seeded(now, 60, "0.33.4", None),
            now,
            "0.33.4",
            Stable
        ));
        // Clearly stale: "latest" is older than the running version.
        assert!(!cache_is_usable(
            &seeded(now, 60, "0.33.4", Some("0.34.0")),
            now,
            "0.34.0",
            Stable
        ));
        // Clock skew: a timestamp from the future is not fresh.
        let mut future = seeded(now, 0, "0.34.0", Some("0.33.0"));
        future.last_checked_unix = Some(now + 3600);
        assert!(!cache_is_usable(&future, now, "0.33.0", Stable));
        // Wrong channel.
        assert!(!cache_is_usable(
            &seeded(now, 60, "0.34.0", Some("0.33.0")),
            now,
            "0.33.0",
            crate::release_channel::ReleaseChannel::Nightly
        ));
    }

    #[test]
    fn stale_cache_from_older_build_is_replaced_not_announced() {
        let _g = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        with_isolated_home(|_| {
            // The #4755 shape: a young cache saying 0.33.4, written by the
            // 0.33.4 build, read by the 0.34.0 build that replaced it.
            let now = unix_now();
            write_cache(&seeded(now, 600, "0.33.4", Some("0.33.4"))).unwrap();
            let fetches = std::sync::atomic::AtomicUsize::new(0);
            let mut buf: Vec<u8> = Vec::new();
            run_check_and_announce(
                "0.34.0",
                || {
                    fetches.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
                    Ok("0.34.0".into())
                },
                &mut buf,
                false,
            );
            assert_eq!(fetches.load(std::sync::atomic::Ordering::SeqCst), 1);
            let refreshed = read_cache().unwrap();
            assert_eq!(refreshed.latest_version.as_deref(), Some("0.34.0"));
            assert_eq!(refreshed.checked_by_version.as_deref(), Some("0.34.0"));
        });
    }

    #[test]
    fn failed_lookup_backs_off_but_never_serves_an_untrusted_result() {
        let _g = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        with_isolated_home(|_| {
            let now = unix_now();
            let fetches = std::sync::atomic::AtomicUsize::new(0);
            let failing = || {
                fetches.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
                Err("rate limited".to_owned())
            };
            let count = || fetches.load(std::sync::atomic::Ordering::SeqCst);

            // Cache from another build: the lookup is attempted, fails, and the
            // untrusted 0.33.4 is not shown as a fallback.
            write_cache(&seeded(now, 2 * 3600, "0.99.0", Some("0.33.4"))).unwrap();
            let mut buf: Vec<u8> = Vec::new();
            run_check_and_announce("0.33.0", failing, &mut buf, false);
            assert_eq!(count(), 1);
            assert!(buf.is_empty(), "untrusted result must not be announced");

            // Same build, expired result: lookup fails, the trusted result is
            // still shown, and the failure is recorded.
            write_cache(&seeded(now, 2 * 3600, "0.34.0", Some("0.33.0"))).unwrap();
            let mut buf: Vec<u8> = Vec::new();
            run_check_and_announce("0.33.0", failing, &mut buf, false);
            assert_eq!(count(), 2);
            assert!(String::from_utf8(buf)
                .unwrap()
                .contains("v0.34.0 is available"));
            let after = read_cache().unwrap();
            assert!(after.last_error_unix.is_some());
            assert_eq!(
                after.latest_version.as_deref(),
                Some("0.34.0"),
                "last good result kept"
            );

            // Within the backoff window the lookup is not retried.
            let mut buf: Vec<u8> = Vec::new();
            run_check_and_announce("0.33.0", failing, &mut buf, false);
            assert_eq!(count(), 2, "backoff");
            assert!(String::from_utf8(buf)
                .unwrap()
                .contains("v0.34.0 is available"));
        });
    }

    #[test]
    fn invalidate_cache_drops_the_result_and_keeps_dismissals() {
        let _g = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        with_isolated_home(|_| {
            let now = unix_now();
            let mut cache = seeded(now, 60, "0.33.4", Some("0.33.4"));
            cache.dismissed_versions = vec!["0.33.4".into()];
            write_cache(&cache).unwrap();
            invalidate_cache();
            let after = read_cache().unwrap();
            assert!(after.latest_version.is_none());
            assert!(after.last_checked_unix.is_none());
            assert!(after.checked_by_version.is_none());
            assert_eq!(after.dismissed_versions, vec!["0.33.4".to_owned()]);
            assert!(!cache_is_usable(
                &after,
                now,
                "0.33.4",
                crate::release_channel::ReleaseChannel::Stable
            ));
        });
    }

    #[test]
    fn pick_latest_release_excluding_skips_withdrawn_versions() {
        let body = serde_json::json!([
            {"tag_name": "cua-driver-rs-v0.30.0", "draft": false},
            {"tag_name": "cua-driver-rs-v0.29.0", "draft": false},
        ]);
        let latest = pick_latest_release_excluding(
            &body,
            crate::release_channel::ReleaseChannel::Stable,
            &["0.30.0".to_owned()],
        );
        assert_eq!(latest.as_deref(), Some("0.29.0"));
    }

    // ── Opt-out paths ───────────────────────────────────────────────────

    #[test]
    fn env_opt_out_short_circuits_enabled_check() {
        let _g = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let saved = std::env::var_os(ENV_UPDATE_CHECK);

        unsafe {
            std::env::set_var(ENV_UPDATE_CHECK, "false");
        }
        // Use a separately-redirected HOME so any config file present on
        // the developer's machine can't influence the result.
        with_isolated_home(|_| {
            assert!(!is_enabled(), "explicit false env var must disable");
        });

        unsafe {
            std::env::set_var(ENV_UPDATE_CHECK, "0");
        }
        with_isolated_home(|_| {
            assert!(!is_enabled(), "0 must disable");
        });

        unsafe {
            std::env::set_var(ENV_UPDATE_CHECK, "off");
        }
        with_isolated_home(|_| {
            assert!(!is_enabled(), "off must disable");
        });

        // Restore.
        match saved {
            Some(s) => unsafe {
                std::env::set_var(ENV_UPDATE_CHECK, s);
            },
            None => unsafe {
                std::env::remove_var(ENV_UPDATE_CHECK);
            },
        }
    }

    #[test]
    fn config_flag_disables_check() {
        let _g = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let saved = std::env::var_os(ENV_UPDATE_CHECK);
        unsafe {
            std::env::remove_var(ENV_UPDATE_CHECK);
        }

        with_isolated_home(|home| {
            // Write a config that disables the check.
            let cfg_dir = home.join(".cua-driver");
            std::fs::create_dir_all(&cfg_dir).unwrap();
            std::fs::write(
                cfg_dir.join("config.json"),
                r#"{"update_check_enabled": false}"#,
            )
            .unwrap();

            // Build version is a normal release (this crate's pkg version
            // ships as "0.1.3", a stable release — see workspace Cargo.toml).
            // The env var is unset, so the config flag is the only signal.
            assert!(
                !is_enabled(),
                "persisted update_check_enabled=false must disable the check"
            );
        });

        match saved {
            Some(s) => unsafe {
                std::env::set_var(ENV_UPDATE_CHECK, s);
            },
            None => unsafe {
                std::env::remove_var(ENV_UPDATE_CHECK);
            },
        }
    }

    #[test]
    fn config_flag_true_or_missing_leaves_check_on() {
        let _g = ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let saved = std::env::var_os(ENV_UPDATE_CHECK);
        unsafe {
            std::env::remove_var(ENV_UPDATE_CHECK);
        }

        with_isolated_home(|home| {
            // Case A: no config file at all → enabled.
            // CARGO_PKG_VERSION is "0.1.3" (stable), env unset, no config file.
            assert!(
                is_enabled(),
                "no config file + stable version + no env opt-out → enabled"
            );

            // Case B: config file present but flag = true → still enabled.
            let cfg_dir = home.join(".cua-driver");
            std::fs::create_dir_all(&cfg_dir).unwrap();
            std::fs::write(
                cfg_dir.join("config.json"),
                r#"{"update_check_enabled": true, "other_key": 42}"#,
            )
            .unwrap();
            assert!(
                is_enabled(),
                "explicit update_check_enabled=true must leave check on"
            );
        });

        match saved {
            Some(s) => unsafe {
                std::env::set_var(ENV_UPDATE_CHECK, s);
            },
            None => unsafe {
                std::env::remove_var(ENV_UPDATE_CHECK);
            },
        }
    }

    // ── Banner formatting ───────────────────────────────────────────────

    #[test]
    fn banner_contains_required_lines() {
        let banner = format_banner(
            "0.1.4",
            "0.1.3",
            crate::release_channel::ReleaseChannel::Stable,
        );
        // Headline.
        assert!(
            banner.contains("cua-driver v0.1.4 is available"),
            "got: {banner:?}"
        );
        assert!(banner.contains("you have v0.1.3"), "got: {banner:?}");
        // Update instruction.
        assert!(
            banner.contains("Update with: cua-driver update"),
            "got: {banner:?}"
        );
        // Release notes URL uses the correct tag prefix.
        assert!(
            banner.contains("https://github.com/trycua/cua/releases/tag/cua-driver-rs-v0.1.4"),
            "got: {banner:?}",
        );
    }

    // ── pick_latest_release ─────────────────────────────────────────────

    #[test]
    fn pick_latest_release_filters_swift_port_tags() {
        // Releases JSON contains both Swift-port tags and Rust-port tags;
        // only the Rust-port (`cua-driver-rs-v*`) tags must be considered.
        let body = serde_json::json!([
            {"tag_name": "cua-driver-v0.9.0", "draft": false, "prerelease": false},
            {"tag_name": "cua-driver-rs-v0.1.4", "draft": false, "prerelease": false},
            {"tag_name": "cua-driver-rs-v0.1.3", "draft": false, "prerelease": false},
            {"tag_name": "cua-driver-v9.9.9", "draft": false, "prerelease": false},
        ]);
        assert_eq!(
            pick_latest_release(&body, crate::release_channel::ReleaseChannel::Stable).as_deref(),
            Some("0.1.4")
        );
    }

    #[test]
    fn pick_latest_release_skips_drafts_but_accepts_prereleases() {
        // Drafts are always skipped. Pre-releases are accepted — every
        // cua-driver-rs release on `trycua/cua` is published as a
        // pre-release while the project is pre-1.0, so filtering them
        // out left the check finding zero candidates.
        let body = serde_json::json!([
            {"tag_name": "cua-driver-rs-v0.2.0", "draft": true,  "prerelease": false},
            {"tag_name": "cua-driver-rs-v0.1.5", "draft": false, "prerelease": true},
            {"tag_name": "cua-driver-rs-v0.1.4", "draft": false, "prerelease": false},
        ]);
        assert_eq!(
            pick_latest_release(&body, crate::release_channel::ReleaseChannel::Stable).as_deref(),
            Some("0.1.5")
        );
    }

    #[test]
    fn pick_latest_release_rejects_every_nightly_shape() {
        let body = serde_json::json!([
            {
                "tag_name": "nightly-cua-driver-rs-v0.2.1-nightly.20260812.42",
                "draft": false,
                "prerelease": true
            },
            {
                "tag_name": "cua-driver-rs-v0.2.1-nightly.20260812.42",
                "draft": false,
                "prerelease": true
            },
            {"tag_name": "cua-driver-rs-v0.2.0", "draft": false, "prerelease": true},
        ]);
        assert_eq!(
            pick_latest_release(&body, crate::release_channel::ReleaseChannel::Stable).as_deref(),
            Some("0.2.0")
        );
    }

    #[test]
    fn nightly_discovery_rejects_stable_and_wrong_prefix_tags() {
        let body = serde_json::json!([
            {"tag_name": "cua-driver-rs-v9.9.9", "draft": false},
            {"tag_name": "cua-driver-rs-v0.20.0-nightly.20260812.99", "draft": false},
            {"tag_name": "nightly-cua-driver-rs-v0.20.0-nightly.20260812.42", "draft": false},
            {"tag_name": "nightly-cua-driver-rs-v0.20.0-nightly.20260812.7", "draft": false}
        ]);
        assert_eq!(
            pick_latest_release(&body, crate::release_channel::ReleaseChannel::Nightly).as_deref(),
            Some("0.20.0-nightly.20260812.42")
        );
    }

    #[test]
    fn pick_latest_release_returns_none_for_empty_array() {
        assert_eq!(
            pick_latest_release(
                &serde_json::json!([]),
                crate::release_channel::ReleaseChannel::Stable
            ),
            None
        );
    }

    #[test]
    fn iso8601_round_trips_against_known_unix_timestamp() {
        // 2023-11-14T22:13:20Z = 1_700_000_000 unix seconds.
        assert_eq!(iso8601(1_700_000_000), "2023-11-14T22:13:20Z");
    }
}
