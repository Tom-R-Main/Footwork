//! One strict GUI/recording preflight before a canonical E2E lane runs.

#![cfg(any(target_os = "windows", target_os = "macos", target_os = "linux"))]

use std::any::Any;
use std::collections::HashSet;
use std::panic::{self, AssertUnwindSafe};
use std::process::{Child, Command, Stdio};
use std::time::{Duration, Instant};

#[cfg(target_os = "linux")]
use cua_driver_testkit::e2e::DisplayServer;
use cua_driver_testkit::e2e::{write_environment_from_env, EnvironmentRecord};
use cua_driver_testkit::observer::TargetWindow;
use cua_driver_testkit::sentinel::ForegroundSentinel;
use cua_driver_testkit::{driver_binary, harness_app, spawn_in_job, Driver, McpDriver};

struct PreflightFixture {
    path: std::path::PathBuf,
    args: Vec<&'static str>,
    title: &'static str,
    ax_marker: &'static str,
}

struct FixtureChildGuard {
    child: Option<Child>,
}

impl FixtureChildGuard {
    fn new(child: Child) -> Self {
        Self { child: Some(child) }
    }

    fn child_mut(&mut self) -> &mut Child {
        self.child.as_mut().expect("fixture child guard is armed")
    }

    fn into_child(mut self) -> Child {
        self.child.take().expect("fixture child guard is armed")
    }
}

impl Drop for FixtureChildGuard {
    fn drop(&mut self) {
        if let Some(child) = &mut self.child {
            let _ = child.kill();
            let _ = child.wait();
        }
    }
}

fn preflight_fixture() -> PreflightFixture {
    #[cfg(target_os = "windows")]
    {
        PreflightFixture {
            path: harness_app("harness-electron", "CuaTestHarness.Electron.exe"),
            args: vec![
                "--no-sandbox",
                "--disable-gpu",
                "--force-renderer-accessibility",
            ],
            title: "CuaTestHarness Electron",
            ax_marker: "WEB_HARNESS_MARKER_v1",
        }
    }
    #[cfg(target_os = "macos")]
    {
        PreflightFixture {
            path: harness_app(
                "harness-electron",
                "CuaTestHarness.Electron.app/Contents/MacOS/Electron",
            ),
            args: vec!["--force-renderer-accessibility"],
            title: "CuaTestHarness Electron",
            ax_marker: "WEB_HARNESS_MARKER_v1",
        }
    }
    #[cfg(target_os = "linux")]
    {
        if std::env::var("CUA_E2E_INTERNAL_LANE").as_deref() == Ok("native") {
            PreflightFixture {
                path: harness_app("harness-gtk3", "CuaTestHarness.Gtk3"),
                args: Vec::new(),
                title: "CuaTestHarness GTK3",
                ax_marker: "HARNESS_TEXT_MARKER_v1",
            }
        } else {
            PreflightFixture {
                path: harness_app("harness-electron", "CuaTestHarness.Electron"),
                args: vec![
                    "--no-sandbox",
                    "--disable-gpu",
                    "--force-renderer-accessibility",
                ],
                title: "CuaTestHarness Electron",
                ax_marker: "WEB_HARNESS_MARKER_v1",
            }
        }
    }
}

fn spawn_driver() -> McpDriver {
    #[cfg(target_os = "macos")]
    {
        McpDriver::spawn_macos_daemon_proxy_named("environment-preflight")
            .expect("installed CuaDriver daemon is not available")
    }
    #[cfg(not(target_os = "macos"))]
    {
        McpDriver::spawn_named("environment-preflight")
            .expect("source-built cua-driver could not be started")
    }
}

fn has_image(response: &cua_driver_testkit::ToolResponse) -> bool {
    response.raw["result"]["content"]
        .as_array()
        .map(|content| {
            content
                .iter()
                .any(|item| item["type"].as_str() == Some("image"))
        })
        .unwrap_or(false)
        || response.structured()["screenshot_png_base64"]
            .as_str()
            .map(|png| !png.is_empty())
            .unwrap_or(false)
}

fn readiness_contract(
    is_error: bool,
    element_count: usize,
    marker_present: bool,
    image_present: bool,
) -> bool {
    !is_error && element_count > 0 && marker_present && image_present
}

fn preflight_state_ready(response: &cua_driver_testkit::ToolResponse, ax_marker: &str) -> bool {
    let element_count = response.structured()["element_count"]
        .as_u64()
        .map(|count| count as usize)
        .or_else(|| response.structured()["elements"].as_array().map(Vec::len))
        .unwrap_or_default();
    readiness_contract(
        response.is_error(),
        element_count,
        response.tree_text().contains(ax_marker),
        has_image(response),
    )
}

fn extract_last_video_frame(
    video: &std::path::Path,
    frame: &std::path::Path,
) -> Result<(), String> {
    // Preserve evidence and prevent stale output from hiding a frameless decode.
    if frame
        .try_exists()
        .map_err(|error| format!("could not check preflight frame: {error}"))?
    {
        return Err("preflight frame already exists".to_owned());
    }
    // A VFR recording's final frame can precede its duration by more than a seek
    // offset. Decode in order and overwrite one image to retain the last frame.
    let extracted = Command::new("ffmpeg")
        .args([
            "-hide_banner",
            "-loglevel",
            "error",
            "-nostdin",
            "-xerror",
            "-y",
            "-i",
        ])
        .arg(video)
        .args([
            "-map",
            "0:v:0",
            "-fps_mode",
            "passthrough",
            "-enc_time_base",
            "demux",
            "-f",
            "image2",
            "-update",
            "1",
        ])
        .arg(frame)
        .stdout(Stdio::null())
        .output()
        .map_err(|error| format!("ffmpeg is required for canonical E2E: {error}"))?;
    let has_output = std::fs::metadata(frame)
        .map(|metadata| metadata.is_file() && metadata.len() > 0)
        .unwrap_or(false);
    if !extracted.status.success() || !has_output {
        let stderr = String::from_utf8_lossy(&extracted.stderr);
        let diagnostic: String = stderr.chars().take(4096).collect();
        return Err(format!(
            "could not extract preflight video frame (status {}; output missing/empty: {}): {diagnostic}",
            extracted.status,
            !has_output,
        ));
    }
    Ok(())
}

fn run_preflight() {
    let expected_sha = std::env::var("CUA_E2E_SOURCE_SHA").ok();
    if let Some(expected_sha) = expected_sha.as_deref() {
        assert!(
            expected_sha.len() == 40 && expected_sha.chars().all(|ch| ch.is_ascii_hexdigit()),
            "CUA_E2E_SOURCE_SHA must be a full commit SHA"
        );
        let source = Command::new("git").args(["rev-parse", "HEAD"]).output();
        let actual_sha = source
            .ok()
            .filter(|source| source.status.success())
            .map(|source| String::from_utf8_lossy(&source.stdout).trim().to_owned())
            .or_else(|| {
                let marker = std::env::var_os("CUA_E2E_SOURCE_MARKER")
                    .map(std::path::PathBuf::from)
                    .unwrap_or_else(|| std::path::PathBuf::from(".cua-e2e-source-sha"));
                std::fs::read_to_string(marker)
                    .ok()
                    .map(|source| source.trim().to_owned())
            })
            .expect("neither git HEAD nor .cua-e2e-source-sha identifies the synced source");
        assert_eq!(
            actual_sha.to_ascii_lowercase(),
            expected_sha.to_ascii_lowercase(),
            "checked-out source does not match the workflow's resolved SHA"
        );
    }

    let driver_path = driver_binary();
    assert!(
        driver_path.is_file(),
        "source-built driver is missing at {}",
        driver_path.display()
    );
    let version = Command::new(&driver_path)
        .arg("--version")
        .output()
        .expect("source-built driver --version failed");
    assert!(
        version.status.success(),
        "source-built driver is not runnable"
    );
    let version = String::from_utf8_lossy(&version.stdout);
    assert!(
        version.contains(env!("CARGO_PKG_VERSION")),
        "driver version mismatch: {version}"
    );

    let fixture = preflight_fixture();
    assert!(
        fixture.path.exists(),
        "required preflight fixture is missing at {}",
        fixture.path.display()
    );
    let recordings_root = std::env::var_os("CUA_E2E_RECORDINGS_ROOT")
        .expect("CUA_E2E_RECORDINGS_ROOT is required for canonical E2E");

    let mut driver = spawn_driver();
    let config = driver.call("get_config", serde_json::json!({}));
    assert!(
        !config.is_error(),
        "connected driver get_config failed: {}",
        config.text()
    );
    assert_eq!(
        config.structured()["version"].as_str(),
        Some(env!("CARGO_PKG_VERSION")),
        "connected driver version does not match the source build"
    );
    if let Some(expected_sha) = expected_sha.as_deref() {
        assert_eq!(
            config.structured()["source_sha"].as_str(),
            Some(expected_sha),
            "connected driver was not built from the requested source SHA"
        );
    }
    let recording_dir = driver
        .recording_dir()
        .expect("preflight evidence directory was not prepared")
        .to_path_buf();
    assert!(
        recording_dir.starts_with(&recordings_root),
        "preflight recording escaped the artifact root"
    );

    for tool in ["health_report", "check_permissions"] {
        let response = driver.call(tool, serde_json::json!({}));
        std::fs::write(
            recording_dir.join(format!("{tool}.json")),
            serde_json::to_vec_pretty(&response.structured()).unwrap(),
        )
        .unwrap();
        assert!(!response.is_error(), "{tool} failed: {}", response.text());
    }
    #[cfg(unix)]
    {
        use std::os::unix::fs::{FileTypeExt, MetadataExt};
        let socket = std::fs::metadata(driver.daemon_socket()).expect("daemon socket metadata");
        let uid = Command::new("id").arg("-u").output().unwrap();
        let uid: u32 = String::from_utf8(uid.stdout)
            .unwrap()
            .trim()
            .parse()
            .unwrap();
        assert!(socket.file_type().is_socket());
        assert_eq!(socket.uid(), uid, "daemon socket is not owned by us");
        assert_eq!(
            socket.mode() & 0o077,
            0,
            "daemon socket permits other users"
        );
        std::fs::write(
            recording_dir.join("daemon.json"),
            serde_json::to_vec_pretty(
                &serde_json::json!({"pid": driver.daemon_pid(), "socket": driver.daemon_socket(),
                "uid": socket.uid(), "mode": socket.mode() & 0o777, "config": config.structured()}),
            )
            .unwrap(),
        )
        .unwrap();
    }

    let before = driver.call("list_windows", serde_json::json!({}));
    assert!(!before.is_error(), "list_windows failed: {}", before.text());
    let before_ids = before.structured()["windows"]
        .as_array()
        .map(|windows| {
            windows
                .iter()
                .filter_map(|window| window["window_id"].as_u64())
                .collect::<HashSet<_>>()
        })
        .unwrap_or_default();

    let mut command = Command::new(&fixture.path);
    command
        .args(&fixture.args)
        .stdout(Stdio::null())
        .stderr(Stdio::inherit());
    let child = spawn_in_job(&mut command).expect("preflight fixture failed to launch");
    let launched_pid = child.id() as i64;
    let mut child = FixtureChildGuard::new(child);

    let deadline = Instant::now() + Duration::from_secs(35);
    let mut last_readiness = "fixture window has not appeared".to_owned();
    #[cfg(target_os = "linux")]
    let mut activated_window_id = None;
    let (pid, window_id) = loop {
        if let Some(status) = child
            .child_mut()
            .try_wait()
            .expect("could not inspect preflight fixture process")
        {
            panic!("preflight fixture exited before mapping a window: {status}");
        }
        let windows = driver.call("list_windows", serde_json::json!({}));
        let candidate = windows.structured()["windows"]
            .as_array()
            .and_then(|windows| {
                windows.iter().find_map(|window| {
                    let window_id = window["window_id"].as_u64()?;
                    let is_new = !before_ids.contains(&window_id);
                    let title_matches = window["title"]
                        .as_str()
                        .unwrap_or("")
                        .contains(fixture.title);
                    (is_new && title_matches)
                        .then(|| (window["pid"].as_i64().unwrap_or(launched_pid), window_id))
                })
            });
        if windows.is_error() {
            last_readiness = format!("list_windows failed: {}", windows.text());
        }

        if let Some((pid, window_id)) = candidate {
            #[cfg(target_os = "linux")]
            if DisplayServer::current() == DisplayServer::X11
                && activated_window_id != Some(window_id)
            {
                let activated = driver.call(
                    "bring_to_front",
                    serde_json::json!({ "pid": pid, "window_id": window_id }),
                );
                assert!(
                    !activated.is_error(),
                    "preflight fixture could not be placed on the Linux desktop: {}",
                    activated.text()
                );
                activated_window_id = Some(window_id);
                std::thread::sleep(Duration::from_millis(300));
            }

            let state = driver.call(
                "get_window_state",
                serde_json::json!({
                    "pid": pid,
                    "window_id": window_id,
                    "capture_mode": "ax"
                }),
            );
            if preflight_state_ready(&state, fixture.ax_marker) {
                break (pid, window_id);
            }
            last_readiness = state.text().to_owned();
        }

        if Instant::now() >= deadline {
            panic!(
                "preflight could not map a ready fixture window with AX state and screenshot: {last_readiness}"
            );
        }
        std::thread::sleep(Duration::from_millis(200));
    };
    driver.reaper().push(child.into_child());

    let target = TargetWindow {
        pid: pid as u32,
        native_id: window_id,
    };
    let sentinel = ForegroundSentinel::launch(&mut driver);
    // Sentinel activation is preflight setup, not behavior under test. Starting
    // the recorder before launch turns its bring_to_front call into a captured
    // action; nested Wayland then blocks on a setup-only full-display preimage.
    // Keep the deliberate guard canaries in the recording while excluding the
    // activation that establishes their baseline.
    driver.start_behavior_recording();
    sentinel
        .assert_guard_canaries(&mut driver, target)
        .expect("foreground sentinel guard canaries failed");
    drop(sentinel);

    drop(driver);
    let video = recording_dir.join("recording.mp4");
    assert!(
        std::fs::metadata(&video)
            .map(|metadata| metadata.len() > 0)
            .unwrap_or(false),
        "preflight video is missing or empty at {}",
        video.display()
    );
    assert!(
        !recording_dir.join("recording-error.txt").exists(),
        "preflight recording reported an error"
    );
    let probe = Command::new("ffprobe")
        .args([
            "-v",
            "error",
            "-show_entries",
            "format=duration",
            "-of",
            "default=noprint_wrappers=1:nokey=1",
        ])
        .arg(&video)
        .status()
        .expect("ffprobe is required for canonical E2E");
    assert!(probe.success(), "ffprobe rejected the preflight video");

    let frame = recording_dir.join("preflight-frame.png");
    extract_last_video_frame(&video, &frame).unwrap_or_else(|error| panic!("{error}"));
    let frame = image::open(&frame)
        .expect("preflight video frame is not a readable image")
        .to_rgb8();
    let non_dark_pixels = frame
        .pixels()
        .filter(|pixel| pixel.0.iter().copied().max().unwrap_or(0) > 30)
        .count();
    assert!(
        non_dark_pixels * 1_000 >= frame.pixels().len(),
        "preflight video is effectively blank: {non_dark_pixels}/{} non-dark pixels",
        frame.pixels().len()
    );
}

fn panic_message(payload: &Box<dyn Any + Send>) -> String {
    payload
        .downcast_ref::<String>()
        .cloned()
        .or_else(|| {
            payload
                .downcast_ref::<&str>()
                .map(|message| (*message).to_owned())
        })
        .unwrap_or_else(|| "preflight panicked without a string payload".to_owned())
}

#[test]
fn readiness_requires_nonempty_ax_marker_and_screenshot_together() {
    assert!(readiness_contract(false, 1, true, true));
    assert!(!readiness_contract(false, 0, true, true));
    assert!(!readiness_contract(false, 1, false, true));
    assert!(!readiness_contract(false, 1, true, false));
    assert!(!readiness_contract(true, 1, true, true));
}

#[test]
fn last_frame_extraction_rejects_existing_output() {
    let directory = tempfile::tempdir().unwrap();
    let frame = directory.path().join("frame.png");
    std::fs::write(&frame, b"existing evidence").unwrap();
    let error =
        extract_last_video_frame(&directory.path().join("missing.mp4"), &frame).unwrap_err();
    assert!(error.contains("already exists"), "{error}");
    assert_eq!(std::fs::read(frame).unwrap(), b"existing evidence");
}

#[test]
#[ignore = "requires ffmpeg with lavfi and the mpeg4 encoder; no GUI required"]
fn last_frame_extraction_handles_long_final_duration_and_invalid_input() {
    let directory = tempfile::tempdir().unwrap();
    let video = directory.path().join("two-colors.mp4");
    let generated = Command::new("ffmpeg")
        .args([
            "-hide_banner",
            "-loglevel",
            "error",
            "-nostdin",
            "-y",
            "-f",
            "lavfi",
            "-i",
            "color=c=red:s=32x32:r=2:d=1.5",
            "-vf",
            "drawbox=color=blue:t=fill:enable='gte(t,1)',setpts='if(eq(N,2),4,N)'",
            "-fps_mode",
            "passthrough",
            "-c:v",
            "mpeg4",
        ])
        .arg(&video)
        .output()
        .expect("ffmpeg is required for this regression test");
    assert!(
        generated.status.success(),
        "{}",
        String::from_utf8_lossy(&generated.stderr)
    );

    // VFR timestamps are 0s, 0.5s, and 2s; the last (blue) frame lasts to 2.5s.
    // Seeking to 2.3s reproduces a successful exit without emitting a frame.
    let old_frame = directory.path().join("old-frame.png");
    let old = Command::new("ffmpeg")
        .args([
            "-hide_banner",
            "-loglevel",
            "error",
            "-nostdin",
            "-y",
            "-sseof",
            "-0.2",
            "-i",
        ])
        .arg(&video)
        .args(["-frames:v", "1"])
        .arg(&old_frame)
        .output()
        .unwrap();
    assert!(
        old.status.success(),
        "{}",
        String::from_utf8_lossy(&old.stderr)
    );
    assert!(
        !old_frame.exists(),
        "fixture must reproduce the frameless seek"
    );

    let frame = directory.path().join("last-frame.png");
    extract_last_video_frame(&video, &frame).unwrap();
    let decoded = image::open(&frame).unwrap().to_rgb8();
    assert_eq!(decoded.dimensions(), (32, 32));
    assert!(
        decoded
            .pixels()
            .all(|pixel| pixel[2] > 200 && pixel[0] < 30 && pixel[1] < 30),
        "must retain the last blue frame, not the first red frame"
    );

    let invalid = directory.path().join("invalid.mp4");
    std::fs::write(&invalid, b"not an MP4").unwrap();
    for input in [invalid, directory.path().join("missing.mp4")] {
        let output = directory.path().join("failed-frame.png");
        let error = extract_last_video_frame(&input, &output).unwrap_err();
        assert!(
            error.contains("could not extract preflight video frame"),
            "{error}"
        );
        assert!(!output.exists());
    }
}

#[test]
#[ignore]
fn canonical_e2e_environment_is_ready() {
    let started = Instant::now();
    let outcome = panic::catch_unwind(AssertUnwindSafe(run_preflight));
    match outcome {
        Ok(()) => write_environment_from_env(&EnvironmentRecord::ready(started.elapsed()))
            .expect("write environment record"),
        Err(payload) => {
            let message = panic_message(&payload);
            write_environment_from_env(&EnvironmentRecord::error(started.elapsed(), message))
                .expect("write failed environment record");
            panic::resume_unwind(payload);
        }
    }
}
